/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.meta;

import com.baneo.core.meta.hibernate.*;

/**
 * Factory for retrieving the IMetaManager used by the application.
 *
 * @author  Laurent Boatto
 * @version $Id$
 * @see com.baneo.core.meta.IMetaManager
 */

public class MetaManagerFactory
{
  /**
   * Private constructor, use getIMetaManager() instead.
   */
  private MetaManagerFactory()
  {
  }

  /**
   * Returns the instance of the IMetaManager used by the application.
   *
   * @return the instance of the IMetaManager used by the application.
   * @see com.baneo.core.meta.IMetaManager
   */
  public static final IMetaManager getIMetaManager()
  {
    /**
     * todo get this from a property
     */
    return HibernateMetaManager.instance();
  }
}