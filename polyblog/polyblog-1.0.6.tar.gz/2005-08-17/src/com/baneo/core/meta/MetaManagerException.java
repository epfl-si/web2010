/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.meta;

/**
 * Thrown by an IMetaManager on error.
 *
 * @author  Laurent Boatto
 * @version $Id$
 */

public class MetaManagerException extends Exception
{
  /**
   * Constructs a new MetaManagerException with the given message.
   *
   * @param message the message.
   */
  public MetaManagerException(String message)
  {
    super(message);
  }

  /**
   * Constructs a new MetaManagerException with the given cause.
   *
   * @param cause the cause.
   */
  public MetaManagerException(Throwable cause)
  {
    super(cause);
  }

  /**
   * Constructs a new MetaManagerException with the given cause.
   *
   * @param message the message.
   * @param cause the cause.
   */
  public MetaManagerException(String message, Throwable cause)
  {
    super(message, cause);
  }
}
