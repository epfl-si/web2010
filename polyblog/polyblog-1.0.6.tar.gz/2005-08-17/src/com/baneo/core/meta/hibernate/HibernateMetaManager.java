/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.meta.hibernate;

import com.baneo.core.meta.*;
import com.baneo.core.persistance.hibernate.*;
import com.baneo.core.util.*;
import net.sf.hibernate.*;
import net.sf.hibernate.type.*;
import org.apache.commons.logging.*;

/**
 * Hibernate implementation of an IMetaManager.
 *
 * @author  Laurent Boatto
 * @version $Id$
 * @see com.baneo.core.meta.IMetaManager
 */

public class HibernateMetaManager implements IMetaManager
{
  /**
   * The log.
   */
  private static final Log _log = LogFactory.getLog(HibernateMetaManager.class);

  private static final SessionFactory _sessionFactory = HibernateUtil.getSessionFactory();
  private static final HibernateMetaManager _instance = new HibernateMetaManager();

  private HibernateMetaManager()
  {
  }

  /**
   * Returns the instance of the HibernateMetaManager (singleton).
   *
   * @return  the instance of the HibernateMetaManager (singleton).
   */
  public static final HibernateMetaManager instance()
  {
    return _instance;
  }

  public boolean hasAttribute(Class klass, String attributeName) throws MetaManagerException
  {
    return ArrayUtil.isInArray(attributeName, getAttributesNames(klass));
  }

  public String[] getAttributesNames(Class klass) throws MetaManagerException
  {
    try
    {
      return _sessionFactory.getClassMetadata(klass).getPropertyNames();
    }
    catch (HibernateException e)
    {
      _log.error(e.getMessage(), e);
      throw new MetaManagerException(e);
    }
  }

  public Class[] getAttributesClasses(Class klass) throws MetaManagerException
  {
    try
    {
      /**
       * todo maybe a cache for this...
       */
      Type[] types = _sessionFactory.getClassMetadata(klass).getPropertyTypes();
      Class[] classes = new Class[types.length];

      for (int i = 0; i < types.length; i++)
      {
        Type type = types[i];

        // we want for example int.class, not java.lang.Integer.class
        if (type instanceof PrimitiveType)
        {
          classes[i] = ((PrimitiveType) type).getPrimitiveClass();
        }
        else
        {
          classes[i] = type.getReturnedClass();
        }
      }

      return classes;
    }
    catch (HibernateException e)
    {
      _log.error(e.getMessage(), e);
      throw new MetaManagerException(e);
    }
  }

  public Object geAttributeValue(Object object, String property) throws MetaManagerException
  {
    try
    {
      return _sessionFactory.getClassMetadata(object.getClass()).getPropertyValue(object, property);
    }
    catch (HibernateException e)
    {
      _log.error(e.getMessage(), e);
      throw new MetaManagerException(e);
    }
  }
}