/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.meta;

/**
 * An IMetaManager gives meta informations about given classes.
 *
 * @author  Laurent Boatto
 * @version $Id$
 */

public interface IMetaManager
{
  /**
   * Returns true if the given Class has an attribute of the given name.
   *
   * @param klass the Class to check.
   * @param attributeName the Class attribute name.
   * @return true if the given Class has an attribute of the given name.
   * @throws MetaManagerException on error.
   */
  public boolean hasAttribute(Class klass, String attributeName) throws MetaManagerException;

  /**
   * Returns the names of the given Class persistent attributes.
   *
   * @param klass the Class.
   * @return the names of the given class persistent attributes.
   * @throws MetaManagerException on error.
   */
  public String[] getAttributesNames(Class klass) throws MetaManagerException;

  /**
   * Returns the classes of the given Class persistent attributes.
   *
   * @param klass the Class.
   * @return the Classes of the given Class persistent attributes.
   * @throws MetaManagerException on error.
   */
  public Class[] getAttributesClasses(Class klass) throws MetaManagerException;

  /**
   * Returns the value of the given attribute, for the given object.
   *
   * @param object the object.
   * @param attribute the attribute.
   * @return the value of the given attribute, for the given object.
   * @throws MetaManagerException on error.
   */
  public Object geAttributeValue(Object object, String attribute) throws MetaManagerException;
}