/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.test;

import com.baneo.core.meta.*;
import com.baneo.core.security.*;
import com.baneo.core.system.*;
import com.baneo.core.util.*;
import junit.framework.*;

import java.io.*;
import java.security.*;
import java.util.*;

/**
 * AbstractTestCase provides common methods and utilities for all test cases.
 *
 * @author Laurent Boatto
 * @version $Revision$, $Date$
 */

public abstract class AbstractTestCase extends TestCase
{
  /**
   * A random object that testcases can use for their tests.
   */
  protected Random _random;

  private boolean _cleanupAfterTest = true;
  private boolean _verbose = true;

  /**
   * Common setup run before each test case.
   *
   * @throws Exception
   */
  protected void setUp() throws Exception
  {
    // we need a different random for each test case.
    _random = new Random(System.currentTimeMillis() + getName().hashCode());
    ApplicationInitializer.initialize();
  }

  /**
   * Prints a debug message to the standard output.
   *
   * @param message the message to print.
   */
  protected void debug(Object message)
  {
    System.out.println(this.getClass().getName() + " DEBUG : " + message);
  }

  /**
   * Prints an warn message to the standard output.
   *
   * @param message the message to print.
   */
  protected void warn(Object message)
  {
    System.out.println(this.getClass().getName() + " WARN : " + message);
  }

  /**
   * Prints an error message to the standard output.
   *
   * @param message the message to print.
   */
  protected void error(Object message)
  {
    System.out.println(this.getClass().getName() + " ERROR : " + message);
  }

  /**
   * Prints an separator message to the standard output.
   *
   * @param message the separator message to print.
   */
  protected void separator(Object message)
  {
    System.out.println("________________________________________________________________________________");
    System.out.println(message);
    System.out.println("________________________________________________________________________________");
  }

  /**
   * Creates a temporary html file with the given data. This is most useful
   * when you are doing an httpunit test and you want to "see" the response.
   *
   * @param data the html file data (usually the response html).
   * @return a temporary html file with the given data.
   * @throws IOException
   */
  protected File createHtmlResponseFile(String data) throws IOException
  {
    File file = File.createTempFile("page", ".html");

    FileWriter writer = new FileWriter(file);
    writer.write(data);
    writer.flush();

    return file;
  }

  /**
   * Returns true if the TestCase should do some cleanup after testing.
   * For example if the TestCase has inserted an object in the system during a
   * test, it should delete it at the end. Default is true.
   *
   * @return true if the TestCase should do some cleanup after
   *         testing, false otherwise.
   */
  public boolean cleanupAfterTest()
  {
    return _cleanupAfterTest;
  }

  /**
   * Sets whenever the TestCase should do some cleanup after
   * testing. For example if the TestCase has inserted an object in
   * the system during a test, it should delete it at the end. Default is true.
   *
   * @param cleanupAfterTest true if the TestCase should do some cleanup
   *         after testing, false otherwise.
   */
  public void setCleanupAfterTest(boolean cleanupAfterTest)
  {
    _cleanupAfterTest = cleanupAfterTest;
  }

  /**
   * Tests whether this TestCase is verbose.
   *
   * @return true if the TestCase is verbose, false otherwise.
   */
  public boolean isVerbose()
  {
    return _verbose;
  }

  /**
   * Utility method that sets a TestCaseSecurityContext according to the
   * parameters.
   *
   * @param username the username.
   * @param userId the user id.
   * @param roles a comma separated role list (e.g administrator,moderator).
   * @param footprint the footprint.
   */
  public void setSecurityContext(String username, int userId, String roles, String footprint)
  {
    SecurityContextManager.setSecurityContext(new TestCaseSecurityContext(username, userId, roles, footprint));
  }

  /**
   * Utility method that removes the ISecurityContext for the current thread.
   */
  public void removeSecurityContext()
  {
    SecurityContextManager.removeSecurityContext();
  }

  /**
   * Utility method that sets a TestCaseSecurityContext according to the
   * parameters.
   *
   * @param principal the principal.
   * @param roles a comma separated role list (e.g administrator,moderator).
   * @param footprint the footprint.
   */
  public void setSecurityContext(Principal principal, int userId, String roles, String footprint)
  {
    TestCaseSecurityContext context = new TestCaseSecurityContext(principal.getName(), userId, roles, footprint);
    context.setPrincipal(principal);
    SecurityContextManager.setSecurityContext(context);
  }

  /**
   * Populates the given simple bean with random values, and returns the values
   * used in a Map.
   *
   * @param bean the bean to populate.
   * @throws com.baneo.core.meta.MetaManagerException
   * @throws java.lang.IllegalAccessException
   * @throws java.lang.reflect.InvocationTargetException
   */
  protected Map populate(Object bean) throws Exception
  {
    IMetaManager metaManager = MetaManagerFactory.getIMetaManager();
    String[] attributes = metaManager.getAttributesNames(bean.getClass());
    Class[] classes = metaManager.getAttributesClasses(bean.getClass());
    return BeanUtil.randomPopulate(bean, attributes, classes);
  }

  /**
   * Set to true if you want the validator to be verbose.
   *
   * @param verbose true if you want the validator to be verbose.
   */
  public void setVerbose(boolean verbose)
  {
    _verbose = verbose;
  }
}
