/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.test;

import com.meterware.httpunit.*;

/**
 * AbstractWebTestCase provides common methods and utilities for web test cases
 * (using httpunit).
 *
 * @author Laurent Boatto
 * @version $Id$
 */

public class AbstractWebTestCase extends AbstractTestCase
{
  /**
   * Returns the first WebForm found at the given url.
   *
   * @param conversation the WebConversation to use for retrieving the WebForm.
   * @param url the url from where to find the WebForm.
   * @return the first WebForm found at the given url.
   * @throws Exception on error.
   */
  public WebForm getWebForm(WebConversation conversation, String url) throws Exception
  {
    WebResponse response = conversation.getResponse(url);
    return response.getForms()[0];
  }

  /**
   * Returns the protected WebForm at the given url after having logged with
   * the given <code>username</code> and <code>password</code>.
   *
   * @param url the url to get the WebForm from.
   * @param username the username to use for the form.
   * @param password the password to use for the form.
   * @return the protected WebForm at the given URL.
   * @throws Exception
   */
  protected WebForm getWebFormAfterLogin(WebConversation conversation, String url, String username, String password) throws Exception
  {
    WebForm form = getWebForm(conversation, url);

    // First we get the login form
    form.setParameter("j_username", username);
    form.setParameter("j_password", password);

    WebResponse response = form.submit();

    return response.getForms()[0];
  }
}
