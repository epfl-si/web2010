/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.util;

import java.text.*;
import java.util.*;

/**
 * Various utilities for Dates.
 *
 * @author  Laurent Boatto
 * @version $Id$
 */

public class DateUtil
{
  // number of milliseconds in an hour
  private static final long MILLISECONDS_IN_HOUR = 1000 * 60 * 60;

  // number of milliseconds in a day
  private static final long MILLISECONDS_IN_DAY = MILLISECONDS_IN_HOUR * 24;
  private static final SimpleDateFormat ISO_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
  private static final SimpleDateFormat ISO_DATETIME_FORMAT = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
  private static final SimpleDateFormat RFC_822_FORMAT = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss Z", Locale.ENGLISH);

  /**
   * DateUtil instances should NOT be constructed in standard programming, you
   * should only use the static methods. This constructor is public to permit
   * tools that require a JavaBean instance to operate.
   */
  public DateUtil()
  {
  }

  /**
   * Checks if two dates have the same year, month, and day, without taking in
   * account hours, minutes, etc.
   *
   * @param date1 the first date to check
   * @param date2 the second date to check
   * @return true if the two dates have the same year, month, and day
   */
  public static boolean isSameDate(Date date1, Date date2)
  {
    Calendar c1 = new GregorianCalendar();
    c1.setTime(date1);
    Calendar c2 = new GregorianCalendar();
    c2.setTime(date2);

    // If it's the same year and day of year, we have a match
    return ((c1.get(Calendar.YEAR) == c2.get(Calendar.YEAR)) &&
        (c1.get(Calendar.DAY_OF_YEAR) == c2.get(Calendar.DAY_OF_YEAR)));
  }

  /**
   * Checks if two dates have the same year and month.
   *
   * @param date1 the first date to check
   * @param date2 the second date to check
   * @return true if two dates have the same year and month.
   */
  public static boolean isSameMonth(Date date1, Date date2)
  {
    Calendar c1 = new GregorianCalendar();
    c1.setTime(date1);
    Calendar c2 = new GregorianCalendar();
    c2.setTime(date2);

    return ((c1.get(Calendar.YEAR) == c2.get(Calendar.YEAR)) &&
        (c1.get(Calendar.MONTH) == c2.get(Calendar.MONTH)));
  }

  /**
   * Checks if two dates have the same year, month, and day, without taking in
   * account hours, minutes, etc.
   *
   * @param date1 the first date (milliseconds since January 1, 1970) to check
   * @param date2 the second date (milliseconds since January 1, 1970) to check
   * @return true if the two dates have the same year, month, and day
   */
  public static boolean isSameDate(long date1, long date2)
  {
    return isSameDate(new Date(date1), new Date(date2));
  }

  /**
   * Checks if the two Dates have the same time (number of milliseconds since
   * January 1, 1970), given an allowed difference, in milliseconds.
   *
   * @param date1 the first date (milliseconds since January 1, 1970) to check
   * @param date2 the second date (milliseconds since January 1, 1970) to check
   * @param allowedDifference the allowed difference, in milliseconds
   * @return true if the two dates have the same time, given the allowed
   *         difference
   */
  public static boolean isSameTime(long date1, long date2, long allowedDifference)
  {
    return (Math.abs(date1 - date2) <= allowedDifference);
  }

  /**
   * Checks if the two Dates have the same time (number of milliseconds since
   * January 1, 1970), given an allowed difference, in milliseconds.
   *
   * @param date1 the first date to check
   * @param date2 the second date to check
   * @param allowedDifference the allowed difference, in milliseconds
   * @return true if the two dates have the same time, given the allowed
   *         difference
   */
  public static boolean isSameTime(Date date1, Date date2, long allowedDifference)
  {
    return isSameTime(date1.getTime(), date2.getTime(), allowedDifference);
  }

  /**
   * Returns the current year.
   *
   * @return the current year.
   */
  public static int getCurrentYear()
  {
    Calendar calendar = new GregorianCalendar();

    return calendar.get(Calendar.YEAR);
  }

  /**
   * Formats the given date in ISO format (yyyy-MM-dd). This method saves
   * you the creation of a SimpleDateFormat.
   *
   * @param date the date to format.
   * @return the given date in ISO format (yyyy-MM-dd).
   */
  public static String formatIsoDate(Date date)
  {
    return ISO_DATE_FORMAT.format(date);
  }

  /**
   * Formats the given date in RFC 822 format (EEE, dd MMM yyyy HH:mm:ss Z).
   * This method saves you the creation of a SimpleDateFormat.
   *
   * @param date the date to format.
   * @return the given date in RFC 822 format
   *         (EEE, dd MMM yyyy HH:mm:ss Z).
   */
  public static String formatRfc822Date(Date date)
  {
    return RFC_822_FORMAT.format(date);
  }

  /**
   * Formats the given date in ISO format (yyyy-MM-dd'T'HH:mm:ss).
   * This method saves you the creation of a SimpleDateFormat.
   *
   * @param date the date to format.
   * @return the given date in ISO format (yyyy-MM-dd'T'HH:mm:ss).
   */
  public static String formatIsoDatetime(Date date)
  {
    return ISO_DATETIME_FORMAT.format(date);
  }

  /**
   * Parses the given source in ISO format (yyyy-MM-dd) to produce a Date.
   * This method has the same behavior as DateFormat.parse, except for two
   * things :
   * <ul>
   *   <li>It's 2x faster (only one format is allowed)
   *   <li>The source is expected to be in valid ISO format. If the date
   *       cannot be parsed, null is returned.
   * </ul>
   *
   * @param source the String containing the date in ISO format (yyy-MM-dd).
   * @return a Date from the given source or null if the source cannot be parsed.
   */
  public static Date parseIsoDate(String source)
  {
    try
    {
      if (source == null)
      {
        return null;
      }

      String yearString = source.substring(0, 4);
      String monthString = source.substring(5, 7);
      String dayString = source.substring(8, 10);

      if (monthString.charAt(0) == '0')
      {
        monthString = monthString.substring(1);
      }

      if (dayString.charAt(0) == '0')
      {
        dayString = dayString.substring(1);
      }

      int year = Integer.parseInt(yearString);
      int month = Integer.parseInt(monthString) - 1;
      int day = Integer.parseInt(dayString);

      Calendar calendar = new GregorianCalendar(year, month, day);

      return calendar.getTime();
    }
        // We cannot parse the date, we return null.
    catch (Exception e)
    {
      return null;
    }
  }

  /**
   * Clears the fields which are "less" than a day, i.e. the hour, minute,
   * second and millisecond of the given calendar.
   *
   * @param calendar the calendar to clear.
   */
  public static void clearSubDayFields(Calendar calendar)
  {
    // both hour and hour_of_day should be cleared, see :
    // http://groups.google.com/groups?q=calendar+clearing+hour+java&hl=fr&lr=&ie=UTF-8&selm=utg0it0a3bqo8a2c03r1r8viuc2knqobom%404ax.com&rnum=1
    calendar.clear(Calendar.HOUR_OF_DAY);
    calendar.clear(Calendar.HOUR);
    calendar.clear(Calendar.MINUTE);
    calendar.clear(Calendar.SECOND);
    calendar.clear(Calendar.MILLISECOND);
  }

  /**
   * Return the number of days between the first and second given dates,
   * the order of the dates is important (it's always secondDate - firstDate).
   *
   * @param firstDate the first date.
   * @param secondDate the second date.
   * @return the number of days between the two given dates.
   */
  public static int daysBetweenDates(Date firstDate, Date secondDate)
  {
    return daysBetweenDates(firstDate.getTime(), secondDate.getTime());
  }

  /**
   * Return the number of days between the first and second given times,
   * the order of the times is important (it's always secondTime - firstTime).
   *
   * @param firstTime the first time (number of milliseconds since 1970-01-01).
   * @param secondTime the second time (number of milliseconds since 1970-01-01).
   * @return the number of days between the two given times.
   */
  public static int daysBetweenDates(long firstTime, long secondTime)
  {
    Calendar calendar1 = new GregorianCalendar();
    Calendar calendar2 = new GregorianCalendar();
    calendar1.setTimeInMillis(firstTime);
    calendar2.setTimeInMillis(secondTime);
    clearSubDayFields(calendar1);
    clearSubDayFields(calendar2);

    long elapsed = calendar2.getTimeInMillis() - calendar1.getTimeInMillis();

    // divide by the number of milliseconds in a day
    return (int) (elapsed / MILLISECONDS_IN_DAY);
  }
}