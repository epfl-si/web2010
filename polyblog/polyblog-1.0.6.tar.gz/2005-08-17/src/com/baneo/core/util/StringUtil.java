/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.util;

import java.util.*;
import java.util.regex.*;

/**
 * Various usefull methods for Strings.
 *
 * @author  Laurent Boatto
 * @version $Id$
 */

public class StringUtil
{
  /**
   * This class is not meant to be instanciated.
   */
  private StringUtil()
  {
  }

  /**
   * Returns a copy of the given String with the first character upper cased.
   * <p>
   * For example StringUtil.upperCaseFirstChar("bob") will return "Bob".
   *
   * @param subject the String to upper case the first character.
   * @return a copy of the given String with the first character upper cased.
   */
  public static String upperCaseFirstChar(String subject)
  {
    if (subject == null || subject.length() == 0)
    {
      return subject;
    }

    return Character.toUpperCase(subject.charAt(0)) + subject.substring(1);
  }

  /**
   * Returns the given String with the first character lower cased.
   *
   * @param subject the String to lower case the first character.
   * @return the String with the first character lower cased.
   */
  public static String lowerCaseFirstChar(String subject)
  {
    return Character.toLowerCase(subject.charAt(0)) + subject.substring(1);
  }

  /**
   * Returns a String with the first occurence of <i>search</i> in <i>subject</i>
   * replaced with the given <i>replace</i> value.
   *
   * @param search  The pattern to search
   * @param replace The replace String
   * @param subject The String in which the replace occurs
   * @return        The resulting String
   */
  public static String replaceFirst(String search, String replace, String subject)
  {
    if (subject == null)
    {
      return null;
    }

    StringBuffer buf = new StringBuffer(subject);

    int index = subject.indexOf(search);

    if (index > -1)
    {
      return buf.replace(index, index + search.length(), replace).toString();
    }
    else
    {
      return subject;
    }
  }

  /**
   * Strip the tags (< and > characters) of a String.
   *
   * @param  subject The String to strip
   * @return The given String without tags
   */
  public static String stripTags(String subject)
  {
    return stripTags(subject, ' ');
  }

  /**
   * Strips the tags (actually only removes the '<' and '>' characters) of the
   * given String.
   *
   * @param subject the string to strip the tags.
   * @param replaceBy the character used to replace the characters.
   * @return a new String with the tags replaced.
   */
  public static String stripTags(String subject, char replaceBy)
  {
    return subject.replace('<', replaceBy).replace('>', replaceBy);
  }

  /**
   * Returns a String of the given length, composed uniquely of 'A'
   * characters (useful if you want to test the maximum String length
   * in your setters e.g.).
   * <p>
   * If you need a String with random characters instead of 'A', use
   * randomString(int length).
   *
   * @param length the desired length
   * @return a String with the given length
   * @see    #randomString(int)
   */
  public static String getStringOfLength(int length)
  {
    if (length < 0)
    {
      length = 0;
    }

    StringBuffer buf = new StringBuffer(length);

    for (int i = 0; i < length; i++)
    {
      buf.append('A');
    }

    return buf.toString();
  }

  /**
   * Returns a String with the double quotes (") escaped
   * (replaced with "&quot;"$9.
   *
   * @param subject the String to escape.
   * @return the escaped String.
   */
  public static String escapeDoubleQuote(String subject)
  {
    return subject.replaceAll("\"", "&quot;");
  }

  /**
   * Highlights the given <code>subject</code> if words in the given
   * <code>query</code> are found.
   * <p>
   * To highlight the String, <code>highlightStart</code> is prepended and
   * <code>highlightEnd</code> is appended to each words in the subject.
   * <p>
   * Some notes :
   * <ul>
   *   <li>The search is case insensitive</li>
   *   <li>The search takes into account only whole words</li>
   *   <li>The space character is used to delimit words in the query</li>
   * </ul>
   * @param subject
   * @param query
   * @return
   */
  public static String highlight(String subject, String query, String highlightStart, String highlightEnd)
  {
    // We must replace the \E in the String, because it's the
    // regular expression operator for end of quotation, used later
    query = query.replaceAll("\\\\E", "E");
    query = removeDuplicateWhitespace(query);

    String[] words = query.split(" ");

    // The search is case insensitive (?i)
    StringBuffer regex = new StringBuffer("(?i)(");

    for (int i = 0; i < words.length; i++)
    {
      String word = words[i];
      // \Q means start of quotation, \E end of quotation, \b take whole
      // words only. Quotation is important to "escape" regular expression
      // containing operators, like .( etc.
      regex.append("\\Q" + word + "\\E\\b");

      if (i + 1 != words.length)
      {
        // | is the or operator
        regex.append("|");
      }
    }

    regex.append(")");

    Pattern pattern = Pattern.compile(regex.toString());
    Matcher matcher = pattern.matcher(subject);

    StringBuffer result = new StringBuffer();

    while (matcher.find())
    {
      String key = matcher.group();
      matcher.appendReplacement(result, highlightStart + key + highlightEnd);
    }

    matcher.appendTail(result);
    return result.toString();
  }

  /**
   * Returns a random String of the given length. The String is composed
   * of 1/3 of lowercase letters, 1/3 of uppercase letters, and 1/3 of
   * numbers.
   * <p>
   * Examples of output with 8 characters :
   * <p>
   * <pre>
   * a7Lb3Dd2
   * d0Jw4Kb8
   * l6Up6Hl5
   * i8Hs4Qg2
   * </pre>
   *
   * @param length the String length
   * @return a random String of the given length
   */
  public static String randomString(int length)
  {
    return randomString(length, new Random());
  }

  /**
   * Returns a random String of the given length, using the random object
   * for randomization. The String is composed
   * of 1/3 of lowercase letters, 1/3 of uppercase letters, and 1/3 of
   * numbers.
   * <p>
   * Examples of output with 8 characters :
   * <p>
   * <pre>
   * a7Lb3Dd2
   * d0Jw4Kb8
   * l6Up6Hl5
   * i8Hs4Qg2
   * </pre>
   *
   * @param length the String length.
   * @param random the Random object used to do the randomization.
   * @return a random String of the given length.
   */
  public static String randomString(int length, Random random)
  {
    int index = 0;
    StringBuffer buf = new StringBuffer(length);

    for (int i = 0; i < length; i++)
    {
      int modulo = i % 3;

      if (modulo == 0)
      {
        // letters lowercase (97 to 122)
        index = random.nextInt(26) + 97;
      }
      else if (modulo == 1)
      {
        // letter uppercase (65 to 90)
        index = random.nextInt(26) + 65;
      }
      else
      {
        // number (48 to 57)
        index = random.nextInt(10) + 48;
      }

      buf.append((char) index);
    }

    return buf.toString();
  }

  /**
   * Returns a copy of the given String with all the whitespaces removed.
   * This is different from String.trim() which only removes the leading and
   * trailing whitespaces.
   *
   * @param subject the String to remove the whitespaces from.
   * @return a copy of the given String with all the whitespaces removed.
   */
  public static String removeWhitespace(String subject)
  {
    int length = subject.length();
    StringBuffer result = new StringBuffer(length);

    for (int i = 0; i < length; i++)
    {
      char currentChar = subject.charAt(i);

      if (currentChar != ' ')
      {
        result.append(currentChar);
      }
    }

    return result.toString();
  }

  /**
   * Returns a copy of the given String with all the non digit characters
   * removed.
   *
   * @param subject the String to remove the non digit characters from.
   * @return a copy of the given String with awith all the non digit characters
   *         removed.
   */
  public static String removeNonDigit(String subject)
  {
    if (subject == null)
    {
      return null;
    }

    int length = subject.length();
    StringBuffer result = new StringBuffer(length);

    for (int i = 0; i < length; i++)
    {
      char currentChar = subject.charAt(i);

      if (Character.isDigit(currentChar))
      {
        result.append(currentChar);
      }
    }

    return result.toString();
  }

  /**
   * Removes the duplicate whitespaces of the given <code>subject</code>,
   * e.g. the String " Hello,   this  is   a test  " will return
   * "Hello, this is a test".
   *
   * @param subject the String to remove the duplicate whitespaces from.
   * @return a copy of the given String with all the duplicate whitespaces
   *         removed.
   */
  public static String removeDuplicateWhitespace(String subject)
  {
    if (subject == null)
    {
      return null;
    }

    subject = subject.trim();
    int length = subject.length();

    if (length == 0)
    {
      return subject;
    }

    StringBuffer result = new StringBuffer(length);

    char lastChar = subject.charAt(0);

    for (int i = 0; i < length; i++)
    {
      char currentChar = subject.charAt(i);

      if (currentChar == ' ' && lastChar == ' ')
      {
      }
      else
      {
        result.append(currentChar);
      }

      lastChar = currentChar;
    }

    return result.toString();
  }

  /**
   * Returns a copy of the given String with all the new lines (\n) replaced
   * by the "<br>" String.
   *
   * @param data the data to transform.
   * @return a copy of the given String with all the new lines (\n) replaced
   *         by the "<br>" String.
   */
  public static String newLineToBr(String data)
  {
    if (data == null)
    {
      return null;
    }

    StringBuffer result = new StringBuffer();

    int length = data.length();

    for (int i = 0; i < length; i++)
    {
      char currentChar = data.charAt(i);

      if (currentChar == '\n')
      {
        result.append("<br>");
      }
      else
      {
        result.append(currentChar);
      }
    }

    return result.toString();
  }

  /**
   * Returns the domain (e.g. yahoo.com) from the given email
   * (e.g. mike@yahoo.com). Note that this method excepts a syntaxic valid
   * email, otherwise it will throw an IllegalArgumentException.
   *
   * @param email the email to get the domain from.
   * @return the domain (e.g. yahoo.com) from the given email
   *         (e.g. mike@yahoo.com).
   */
  public String getDomainFromEmail(String email)
  {
    if (!Check.isValidEmailSyntax(email))
    {
      throw new IllegalArgumentException("The email '" + email + "' has a wrong syntax");
    }

    return email.substring(email.lastIndexOf('@') + 1);
  }
}