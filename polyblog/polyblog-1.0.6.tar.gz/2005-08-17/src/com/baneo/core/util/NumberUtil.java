/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.util;

import java.text.*;

/**
 * Various utilities for numbers.
 *
 * @author  Laurent Boatto
 * @version $Id$
 */

public class NumberUtil
{
  private static final DecimalFormat JAVA_FORMAT = new DecimalFormat("0.##");

  static
  {
    DecimalFormatSymbols symbols = new DecimalFormatSymbols();
    symbols.setDecimalSeparator('.');
    JAVA_FORMAT.setDecimalFormatSymbols(symbols);
  }

  private NumberUtil()
  {
  }

  /**
   * Formats the given int with the given grouping separator.
   * Examples of output with the ' grouping separator :
   * <pre>
   * 100 => "100"
   * 1000 => "1'000"
   * 10000 => "10'000"
   * </pre>
   * Note that this method is much simplier (and less powerful of course) to
   * use than java.text.DecimalFormat, and 2x faster.
   *
   * @param value the int to format.
   * @param groupingSeparator the number grouping separator.
   * @return the given int formatted with the given grouping separator.
   * @see java.text.DecimalFormat
   */
  public static final String formatInt(int value, char groupingSeparator)
  {
    String valueString = String.valueOf(value);
    StringBuffer result = new StringBuffer();

    if (value < 0)
    {
      result.append('-');
      valueString = valueString.substring(1);
    }

    char[] characters = valueString.toCharArray();

    for (int i = 0; i < characters.length; i++)
    {
      result.append(characters[i]);

      // we assume a grouping of 3..
      if (!(i + 1 == characters.length) && (((characters.length - (i + 1)) % 3) == 0))
      {
        result.append(groupingSeparator);
      }
    }

    return result.toString();
  }

  /**
   * Parse the given String and returns and int, taking into account only
   * the digits characters of the String. This is different from
   * Integer.parseInt() which will throw an Exception it there are non-digits
   * characters. This method can be used to get an int from a user input which
   * might contain non-digits characters, e.g. "1'000'000.-".
   *
   * @param string the String to parse into a int.
   * @return an int from the given String, taking into account only
   *         the digits characters of the String
   */
  public static int parseIntLenient(String string)
  {
    int length = string.length();
    StringBuffer result = new StringBuffer(length);

    for (int i = 0; i < length; i++)
    {
      char currentChar = string.charAt(i);

      if (Character.isDigit(currentChar))
      {
        result.append(currentChar);
      }
    }

    return Integer.parseInt(result.toString());
  }

  /**
   * Parse the given String and returns and int, taking into account only
   * the digits characters of the String. If the String cannot be parsed, it
   * returns the given default value.
   *
   * @param string the String to parse into a int.
   * @param defaultValue the value to return if the String cannot be parsed.
   * @return an int from the given String, taking into account only
   *         the digits characters of the String
   */
  public static int parseIntLenient(String string, int defaultValue)
  {
    if (Check.isEmpty(string))
    {
      return defaultValue;
    }

    try
    {
      return parseIntLenient(string);
    }
    catch (NumberFormatException e)
    {
      return defaultValue;
    }
  }

  /**
   * Returns the int value of the given String, or the given default value if
   * the String cannot be parsed.
   *
   * @param value the value to parse.
   * @param defaultValue the default value returned if the String cannot be
   *        parsed.
   * @return the int value of the given String.
   */
  public static int parseInt(String value, int defaultValue)
  {
    // if the value is empty, it cannot be valid
    if (Check.isEmpty(value))
    {
      return defaultValue;
    }

    int returnValue = 0;

    try
    {
      returnValue = Integer.parseInt(value);
    }
    catch (NumberFormatException e)
    {
      returnValue = defaultValue;
    }

    return returnValue;
  }

  /**
   * Formats the given double in the "java" format (without a grouping separator,
   * and using the dot (.) for the decimal separator). This method can be
   * usefull because String.valueOf(double) use the computerized scientific
   * notation if the number is bigger than 10^7, e.g. "1.0E7" instead of
   * "10000000".
   *
   *
   * @param number the double to format.
   * @return the given double in the "java" format.
   */
  public static String javaFormat(double number)
  {
    return JAVA_FORMAT.format(number);
  }

  /**
   * Parses the given String as a double, using the given unit separator. The
   * only characters taken into account for parsing are digits and the unit
   * separator, therefore the following Strings will all return 1200 :
   * <pre>
   * 1200
   * 1'200
   * 1'200.-
   * 1'200.00
   * 1-2-0-0.00
   * aaaa1200
   * 1'200.00.00 // the unit separator is took into account only once
   * </pre>
   *
   * @param string the String to parse.
   * @param unitSeparators the allowed unit separators, e.g. '.'
   * @return the given String as a double.
   */
  public static double parseDoubleLenient(String string, char[] unitSeparators)
  {
    int length = string.length();
    StringBuffer toParse = new StringBuffer(length);
    boolean hasUnit = false;

    for (int i = 0; i < length; i++)
    {
      char currentChar = string.charAt(i);

      if (Character.isDigit(currentChar))
      {
        toParse.append(currentChar);
      }
      // We append only once the unit separator, otherwise we have a
      // NumberFormatException
      else if (CharacterUtil.isInArray(currentChar, unitSeparators) && !hasUnit)
      {
        // only the point is allowed by Double.parseDouble
        toParse.append('.');
        hasUnit = true;
      }
    }

    return Double.parseDouble(toParse.toString());
  }

  /**
   * Parses the given String as a double, but returns the given default value
   * if the double cannot be parsed.
   *
   * @param string the String to parse.
   * @param unitSeparators the allowed unit separators, e.g. '.'
   * @param defaultValue the value to return if the double cannot be parsed.
   * @return the given String as a double or the defaultValue if it cannot be
   *         parsed.
   */
  public static double parseDoubleLenient(String string, char[] unitSeparators, double defaultValue)
  {
    // if empty the double cannot be parsed
    if (Check.isEmpty(string))
    {
      return defaultValue;
    }

    try
    {
      return parseDoubleLenient(string, unitSeparators);
    }
    catch (NumberFormatException e)
    {
      return defaultValue;
    }
  }
}