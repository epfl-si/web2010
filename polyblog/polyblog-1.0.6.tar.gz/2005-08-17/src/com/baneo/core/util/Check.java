/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.util;

import java.net.*;
import java.util.*;

/**
 * Various methods for testing data validity.
 *
 * @author  Laurent Boatto
 * @version $Id$
 */

public class Check
{
  /**
   * A cache with valid domain names (e.g. "yahoo.com") used by the
   * isEmailDomainValid method.
   */
  private static final Map _validDomainCache = new HashMap();

  /**
   * The regular expression used to check the syntax validity of an email.
   */
  private static final String VALID_EMAIL_REGEXP = "^([a-zA-Z0-9_\\-])+(\\.([a-zA-Z0-9_\\-])+)*@((\\[(((([0-1])?([0-9])?[0-9])|(2[0-4][0-9])|(2[0-5][0-5])))\\.(((([0-1])?([0-9])?[0-9])|(2[0-4][0-9])|(2[0-5][0-5])))\\.(((([0-1])?([0-9])?[0-9])|(2[0-4][0-9])|(2[0-5][0-5])))\\.(((([0-1])?([0-9])?[0-9])|(2[0-4][0-9])|(2[0-5][0-5]))\\]))|((([a-zA-Z0-9])+(([\\-])+([a-zA-Z0-9])+)*\\.)+([a-zA-Z])+(([\\-])+([a-zA-Z0-9])+)*))$";

  /**
   * The regular expression used to check if a text contains an email.
   */
  private static final String CONTAINS_EMAIL_REGEXP = ".*([a-zA-Z0-9_\\-])+(\\.([a-zA-Z0-9_\\-])+)*@((\\[(((([0-1])?([0-9])?[0-9])|(2[0-4][0-9])|(2[0-5][0-5])))\\.(((([0-1])?([0-9])?[0-9])|(2[0-4][0-9])|(2[0-5][0-5])))\\.(((([0-1])?([0-9])?[0-9])|(2[0-4][0-9])|(2[0-5][0-5])))\\.(((([0-1])?([0-9])?[0-9])|(2[0-4][0-9])|(2[0-5][0-5]))\\]))|((([a-zA-Z0-9])+(([\\-])+([a-zA-Z0-9])+)*\\.)+([a-zA-Z])+(([\\-])+([a-zA-Z0-9])+)*)).*";

  /**
   * Private constructor, use static methods instead.
   */
  private Check()
  {
  }

  /**
   * Returns true if the given text contains an email somewhere in it.
   *
   * @param text the text to check.
   * @return true if the given text contains an email somewhere in it.
   */
  public static boolean containsEmail(String text)
  {
    return text.matches(CONTAINS_EMAIL_REGEXP);
  }

  /**
   * Checks if the given String can be parsed as an int.
   *
   * @param str the String to check.
   * @return true if the String can be parsed as an int.
   */
  public static boolean isValidInt(String str)
  {
    try
    {
      Integer.parseInt(str);
      return true;
    }
    catch (NumberFormatException ex)
    {
      return false;
    }
  }

  /**
   * Checks if the given String starts with a letter.
   *
   * @param str the String to check.
   * @return true if the given String starts with a letter.
   */
  public static boolean startsWithLetter(String str)
  {
    if (str == null || str.equals(""))
    {
      return false;
    }

    return Character.isLetter(str.charAt(0));
  }

  /**
   * Checks if the given String is empty (null , "", or only composed of spaces
   * e.g. "        ").
   *
   * @param   str The String to check
   * @return  true if is String is empty, false otherwise
   */
  public static boolean isEmpty(String str)
  {
    if (str == null || str.trim().length() == 0)
    {
      return true;
    }

    return false;
  }

  /**
   * Checks if the given String has enough words.
   *
   * @param string the String to check.
   * @param minNumWords the minimum number of words the String has to have.
   * @return true if the given String has enough words.
   */
  public static boolean hasEnoughWords(String string, int minNumWords)
  {
    string = string.trim();
    int length = string.length();
    char currentChar = 0;
    char previousChar = 0;
    int numWords = 1;

    for (int i = 0; i < length; i++)
    {
      currentChar = string.charAt(i);

      // if we encounter a space, the string has one more word. We count multiple
      // spaces between words only once.
      if (currentChar == ' ' && previousChar != ' ')
      {
        numWords++;
      }

      previousChar = currentChar;
    }

    return numWords >= minNumWords;
  }

  /**
   * Returns true if the given string has too much non alphanumeric characters.
   *
   * @param string the String to check.
   * @param percentAllowed the percent of non alphanumeric characters allowed
   * @return true if the given string has too much non alphanumeric characters.
   */
  public static boolean hasTooMuchNonAlphaNumericChars(String string, int percentAllowed)
  {
    string = string.trim().toLowerCase();
    int length = string.length();
    int nonAlphaNum = 0;

    for (int i = 0; i < length; i++)
    {
      if (!Character.isLetterOrDigit(string.charAt(i)))
      {
        nonAlphaNum++;
      }
    }

    return ((float) nonAlphaNum / length) > ((float) percentAllowed / 100);
  }

  /**
   * Checks if the given value is included in the range delimited by
   * the from (inclusive) and to (inclusive) parameters.
   *
   * @param rangeFrom the lower limit (inclusive) of the range.
   * @param rangeTo the upper limit (inclusive) of the range.
   * @param value the value to check.
   * @return true if value is included in the given range.
   */
  public static boolean isInRange(int value, int rangeFrom, int rangeTo)
  {
    if (rangeFrom > rangeTo)
    {
      String message = "The 'from' parameter (in this call " + rangeFrom + ") must " +
          " be bigger than the 'to' parameter (in this call " + rangeTo + ")";
      throw new IllegalArgumentException(message);
    }

    if (value < rangeFrom || value > rangeTo)
    {
      return false;
    }
    else
    {
      return true;
    }
  }

  /**
   * Checks if the given email syntax is valid.
   *
   * @param email the email to check.
   * @return true if the given email syntax is valid.
   */
  public static boolean isValidEmailSyntax(String email)
  {
    if (email == null)
    {
      return false;
    }

    return email.matches(VALID_EMAIL_REGEXP);
  }

  /**
   * Checks if the given email domain is valid. This is done by trying to
   * resolve the domain name to find the corresponding ip. If none is found, the
   * domain is invalid. Note that this method doesn't check if the domain has
   * a valid mail server. This method use a cache so it could return true
   * even if the domain is now invalid (e.g. a domain was valid at first,
   * but it was deleted later), but this shouldn't be a problem. Note that this
   * method excepts a syntaxic valid email, otherwise it will throw an
   * IllegalArgumentException.
   *
   * @param email the email to check.
   * @return true if the given email domain is valid.
   */
  public static boolean isValidEmailDomain(String email)
  {
    if (!isValidEmailSyntax(email))
    {
      throw new IllegalArgumentException("The email '" + email + "' has a wrong syntax");
    }

    String domain = email.substring(email.lastIndexOf('@') + 1);

    // Look in the cache to see if we have already to the lookup.
    if (_validDomainCache.get(domain) != null)
    {
      return true;
    }

    try
    {
      InetAddress.getByName(domain);
      // Put the valid domain in the cache. The cache SHOULD be flushed
      // everyday because a valid host can become invalid (deletion) but
      // we don't care, it's very infrequent and harmless anyway.
      _validDomainCache.put(domain, domain);
      return true;
    }
    catch (UnknownHostException e)
    {
      return false;
    }
  }

  /**
   * ClassifiedCheckTestCase the length of a String, and returns true if it's valid, i.e. greater
   * or equal to min, and lower or equal to max parameters.
   *
   * @param str the String to check.
   * @param min the mininum length allowed (inclusive).
   * @param max the maximum length allowed (inclusive).
   * @return true if the length is valid.
   */
  public static boolean hasValidLength(String str, int min, int max)
  {
    if (str == null)
    {
      return false;
    }

    if (min > max)
    {
      String message = "The 'min' parameter (in this call " + min + ") must " +
          " be bigger than the 'max' parameter (in this call " + max + ")";
      throw new IllegalArgumentException(message);
    }

    int length = str.length();

    if (length < min || length > max)
    {
      return false;
    }
    else
    {
      return true;
    }
  }

  /**
   * Checks that the given String length is a multiple of the given number and
   * if so returns true.
   *
   * @param str the String to check.
   * @param number the number the String length should be a multiple of.
   * @return true if the String's length is a multiple of the given number,
   *         false otherwise.
   */
  public static boolean hasValidLengthMultiple(String str, int number)
  {
    if ((str.length() % number) > 0)
    {
      return false;
    }
    else
    {
      return true;
    }
  }
}