/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.util;

/**
 * Simple timer class.
 *
 * @author Laurent Boatto
 * @version $Id$
 */

public class SimpleTimer
{
  private long _start;
  private long _stop;

  /**
   * Constructs a new timer and starts it.
   */
  public SimpleTimer()
  {
    start();
  }

  /**
   * Starts the timer.
   */
  public void start()
  {
    _start = System.currentTimeMillis();
  }

  /**
   * Stops the timer.
   */
  public void stop()
  {
    _stop = System.currentTimeMillis();
  }

  /**
   * Returns the elapsed time, in milliseconds.
   *
   * @return the elapsed time, in milliseconds.
   */
  public long elapsed()
  {
    return _stop - _start;
  }

  /**
   * Prints the number of elapsed milliseconds since the Timer has been started.
   */
  public void printElapsed()
  {
    System.out.println(System.currentTimeMillis() - _start);
  }
}