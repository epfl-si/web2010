/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.util;

import org.apache.commons.logging.*;

import java.security.*;

/**
 * Cryptography utilities.
 *
 * @author Laurent Boatto
 * @version $Id$
 */

public class CryptUtil
{
  /**
   * The log.
   */
  private static final Log _log = LogFactory.getLog(CryptUtil.class);

  /**
   * This class is not meant to be instanciated.
   */
  private CryptUtil()
  {
  }

  /**
   * Calculates the MD5 hash of str using the RSA Data Security,
   * Inc MD5 Message-Digest Algorithm, and returns that hash.
   * The hash is a 32-character hexadecimal number. This will output the same
   * result as the md5() function in PHP, see :
   * http://forum.java.sun.com/thread.jsp?thread=429739&forum=9&message=1919720
   *
   * @param str the String to get the MD5 hash from.
   * @return the MD5 hash of str.
   */
  public static String md5(String str)
  {
    try
    {
      MessageDigest md5 = MessageDigest.getInstance("MD5");
      md5.update(str.getBytes());
      return toHexadecimalString(md5.digest());
    }
        // This will never happen anyway, MD5 is a valid algorithm
    catch (NoSuchAlgorithmException e)
    {
      throw new RuntimeException(e);
    }
  }

  /**
   * Transforms the given bytes into an hexadecimal String.
   *
   * @param bytes the bytes.
   * @return the given bytes into an hexadecimal String.
   */
  private static String toHexadecimalString(byte[] bytes)
  {
    StringBuffer sb = new StringBuffer();
    byte n1, n2;
    for (int i = 0; i < bytes.length; i++)
    {
      n1 = (byte) ((bytes[i] & 0xF0) >>> 4);
      n2 = (byte) ((bytes[i] & 0x0F));
      sb.append(n1 >= 0xA ? (char) (n1 - 0xA + 'a') : (char) (n1 + '0'));
      sb.append(n2 >= 0xA ? (char) (n2 - 0xA + 'a') : (char) (n2 + '0'));
    }
    return sb.toString();
  }
}
