/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.util;

/**
 * Various utilities for characters.
 *
 * @author  Laurent Boatto
 * @version $Id$
 */

public class CharacterUtil
{
  private CharacterUtil()
  {
  }

  /**
   * Returns true if the given char is in the given array.
   *
   * @param c the char to search for.
   * @param array the array to search in.
   * @return true if the given char is in the given array.
   */
  public static boolean isInArray(char c, char[] array)
  {
    for (int i = 0; i < array.length; i++)
    {
      if (c == array[i])
      {
        return true;
      }
    }

    return false;
  }
}
