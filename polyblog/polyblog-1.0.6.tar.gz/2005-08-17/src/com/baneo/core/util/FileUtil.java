/*
 * $Id$
 *
 * Copyright 2005 EPFL. All rights reserved.
 */

package com.baneo.core.util;

import java.io.*;
import java.util.*;

/**
 * Various utilities for files.
 *
 * @author Laurent Boatto
 */
public class FileUtil
{
  private FileUtil()
  {
  }

  /**
   * Returns the absolute path of the given file name, or null if the file
   * cannot be found in the classpath. This method is usefull as there is
   * no other way to know the full path of a file in the classpath, as
   * Class.getResourceAsStream() returns an InputStream.
   *
   * @param fileName the file name.
   * @return the absolute path of the given file name.
   */
  public static String getFileAbsolutePath(String fileName)
  {
    String classPath = System.getProperty("java.class.path");

    StringTokenizer tokenizer = new StringTokenizer(classPath, File.pathSeparator);

    // For each classpath entry, tries to find the given resource name
    while (tokenizer.hasMoreTokens())
    {
      String filePath = tokenizer.nextToken();

      // we do not treat the jar files
      if (filePath.endsWith(".jar"))
      {
        continue;
      }

      filePath = filePath + File.separatorChar + fileName;

      File file = new File(filePath);

      // The resource has been found
      if (file.exists())
      {
        return file.getAbsolutePath();
      }
    }

    return null;
  }

  public static String loadTextFile(String path) throws IOException
  {
    StringBuffer result = new StringBuffer();

    BufferedReader in = new BufferedReader(new FileReader("infilename"));
    String str;

    while ((str = in.readLine()) != null)
    {
      result.append(str + "\n");
    }

    in.close();
    return result.toString();
  }

  /**
   * Copy a file.
   *
   * @param sourceFile the source file to copy.
   * @param destinationFile the destination file for the copy.
   * @throws IOException on IO error.
   */
  public static void copy(File sourceFile, File destinationFile) throws IOException
  {
    FileInputStream from = new FileInputStream(sourceFile);
    FileOutputStream to = new FileOutputStream(destinationFile);

    byte[] buffer = new byte[4096];
    int bytesRead;

    while ((bytesRead = from.read(buffer)) != -1)
    {
      to.write(buffer, 0, bytesRead);
    }

    // Very important, we close the streams otherwise the files have a lock
    // on them! (cannot delete them under windows)
    from.close();
    to.close();
  }
}
