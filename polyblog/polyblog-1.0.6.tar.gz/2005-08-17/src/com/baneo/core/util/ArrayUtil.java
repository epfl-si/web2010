/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.util;

import java.util.*;

/**
 * Various utilities for arrays.
 *
 * @author  Laurent Boatto
 * @version $Id$
 */

public class ArrayUtil
{
  /**
   * This class is not meant to be instanciated.
   */
  private ArrayUtil()
  {
  }

  /**
   * Merge the two given String arrays.
   * <p>
   * The order of the elements of the merged array is the insertion order.
   * <p>
   * For example :
   * <p>
   * String[] array1 = {"tree", "bird", "sky", "grass", "flower"};<br>
   * String[] array2 = {"grass", "sky", "bird", "apple", "flower"};<br>
   * <p>
   * ArrayUtil.mergeStringArrays(array1, array2);
   * <p>
   * will have a result of :
   * <p>
   * {"tree", "bird", "sky", "grass", "flower", "apple"}
   *
   * @param array1 the first array.
   * @param array2 the second array.
   * @return the merged array.
   */
  public static String[] mergeStringArrays(String[] array1, String[] array2)
  {
    Set set = new LinkedHashSet(array1.length);

    for (int i = 0; i < array1.length; i++)
    {
      set.add(array1[i]);
    }

    for (int i = 0; i < array2.length; i++)
    {
      set.add(array2[i]);
    }

    return (String[]) set.toArray(new String[0]);
  }

  /**
   * Returns true if the given object equals an other object present in
   * the given objects array.
   *
   * @param object the object to find in the array.
   * @param array the array of objects.
   * @return true if the given object is in the given objects array.
   */
  public static boolean isInArray(Object object, Object[] array)
  {
    for (int i = 0; i < array.length; i++)
    {
      if (object.equals((array[i])))
      {
        return true;
      }
    }

    return false;
  }

  /**
   * Returns true if the given int equals an other int present in
   * the given array.
   *
   * @param value the int to find in the array.
   * @param array the array of ints.
   * @return true if the given object is in the given objects array.
   */
  public static boolean isInArray(int value, int[] array)
  {
    for (int i = 0; i < array.length; i++)
    {
      if (array[i] == value)
      {
        return true;
      }
    }

    return false;
  }

  /**
   * Transforms a String array into a single String, using the given delimiter
   * to delimit the array elements.
   *
   * @param array the array.
   * @param delimiter the delimiter.
   * @return a single String from the given String array.
   */
  public static String arrayToString(String[] array, String delimiter)
  {
    return arrayToString(array, delimiter, null, null);
  }

  /**
   * Transforms a String array into a single String, using the given delimiter
   * to delimit the array elements.
   *
   * @param array the array.
   * @param delimiter the delimiter.
   * @param prefix the String that will be put before every array element, can
   *        be null.
   * @param suffix the String that will be put after every array element, can
   *        be null.
   * @return a single String from the given String array.
   */
  public static String arrayToString(String[] array, String delimiter, String prefix, String suffix)
  {
    if (array == null)
    {
      return null;
    }

    StringBuffer buf = new StringBuffer(128);

    if (prefix != null)
    {
      buf.append(prefix);
    }

    buf.append(array[0]);

    if (suffix != null)
    {
      buf.append(suffix);
    }

    for (int i = 1; i < array.length; i++)
    {

      buf.append(delimiter);

      if (prefix != null)
      {
        buf.append(prefix);
      }

      buf.append(array[i]);

      if (suffix != null)
      {
        buf.append(suffix);
      }
    }

    return buf.toString();
  }

  /**
   * Removes the elements of the given <code>remove</code> array from the given
   * <code>subject</code> array.
   *
   * @param subject the array to remove the elements from.
   * @param remove the array containing the elements to remove.
   * @return a new array with the wanted elements removed.
   */
  public static String[] removeFromArray(String[] subject, String[] remove)
  {
    List result = new ArrayList();

    for (int i = 0; i < subject.length; i++)
    {
      if (isInArray(subject[i], remove))
      {
        continue;
      }

      result.add(subject[i]);
    }

    return (String[]) result.toArray(new String[result.size()]);
  }
}