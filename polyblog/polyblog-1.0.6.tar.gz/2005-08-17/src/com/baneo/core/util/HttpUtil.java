/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.util;

import com.baneo.core.servlet.*;
import com.jspsmart.upload.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.net.*;
import java.util.*;

/**
 * Utilities related to http.
 *
 * @author  Laurent Boatto
 * @version $Id$
 */
public class HttpUtil
{
  private HttpUtil()
  {
  }

  /**
   * Translates a string into application/x-www-form-urlencoded format using
   * the ISO-8859-1 encoding scheme. This method is different from URLEncoder as
   * it only uses ISO-8859-1 (which is widely used) and it does not
   * throw the annoying UnsupportedEncodingException.
   *
   * @param string String to be translated.
   * @return the translated String.
   */
  public static final String encode(String string)
  {
    try
    {
      return URLEncoder.encode(string, "ISO-8859-1");
    }
    catch (UnsupportedEncodingException e)
    {
      // this will never happen, ISO-8859-1 is supported
      throw new RuntimeException(e);
    }
  }

  /**
   * Decodes a application/x-www-form-urlencoded string using the UTF-8
   * encoding scheme.  This method is different from URLDeccoder as
   * it only uses ISO-8859-1 (which is widely used) and it does not
   * throw the annoying UnsupportedEncodingException.
   *
   * @param string the String to decode.
   * @return the newly decoded String.
   */
  public static final String decode(String string)
  {
    try
    {
      return URLDecoder.decode(string, "ISO-8859-1");
    }
    catch (UnsupportedEncodingException e)
    {
      // this will never happen, ISO-8859-1 is supported
      throw new RuntimeException(e);
    }
  }


  /**
   * Returns the full request url, including the query string, if any, unlike
   * <code>HttpServletRequest.getRequestURI()</code>.
   * <p>
   * Examples of returns :
   * <p>
   * /category/view.jsp <br>
   * /category/view.jsp?code=123
   *
   * @param request the request to get the url from.
   * @return the full request url, including the query string, if any.
   */
  public static String getFullRequestUrl(HttpServletRequest request)
  {
    String queryString = request.getQueryString();

    if (queryString != null)
    {
      return request.getRequestURI() + "?" + queryString;
    }
    else
    {
      return request.getRequestURI();
    }
  }

  public static String addParameterToRequest(String baseUrl, HttpServletRequest request, String parameterName, Object parameterValue)
  {
    return addParameterToRequest(baseUrl, request, parameterName, parameterValue, null);
  }

  /**
   * Adds the given parameter name and value to the given request
   * url, using the given base url. The base url is used instead
   * of request.getRequestURI(), this is useful in Apache tiles as the real
   * request URI is lost.
   *
   * @param baseUrl the base url.
   * @param request the request.
   * @param parameterName the parameter name.
   * @param parameterValue the parameter value.
   * @return
   */
  public static String addParameterToRequest(String baseUrl, HttpServletRequest request, String parameterName, Object parameterValue, String anchor)
  {
    Enumeration enumeration = request.getParameterNames();
    StringBuffer result = new StringBuffer(baseUrl);
    int i = 0;

    while (enumeration.hasMoreElements())
    {
      String key = (String) enumeration.nextElement();

      if (key.equals(parameterName))
      {
        continue;
      }

      if (i == 0)
      {
        result.append('?');
      }
      else
      {
        result.append('&');
      }

      // encode the parameter value, important for spaces
      result.append(key + "=" + HttpUtil.encode(request.getParameter(key)));

      i++;
    }

    if (i == 0)
    {
      result.append('?');
    }
    else
    {
      result.append('&');
    }

    // encode the parameter value, important for spaces
    result.append(parameterName + "=" + HttpUtil.encode(String.valueOf(parameterValue)));

    if (anchor != null)
    {
      result.append("#" + anchor);
    }

    return result.toString();
  }

  /**
   * Simple method that returns the full ip of the given request, including
   * the ip for which the request was forwarded, if any.
   * <p>
   * Examples of output :
   * <p>
   * 194.123.123.23
   * 194.123.123.24 (128.178.12.13)
   * <p>
   * The forwarded ip, if any, is put between parenthesises.
   *
   * @param request the request to get the full ip from.
   * @return the full ip of the given request, including
   *         the ip for which the request was forwarded, if any.
   */
  public static String getFullIp(HttpServletRequest request)
  {
    String result = request.getRemoteAddr();
    String forwarded = request.getHeader("HTTP_X_FORWARDED_FOR");

    if (forwarded != null)
    {
      result += " (" + forwarded + ")";
    }

    return result;
  }

  /**
   * Add a parameter to the query string of a request. This method makes sure
   * that the existing parameter (if any) is overriden.
   * <p>
   * If the query String was :
   * <p>
   * page=1&order=up
   * <p>
   * and you call addParameterToQuery(request, "page", "2");
   * the returned String will be :
   * <p>
   * page=2&order=up
   *
   * @param  request the request to get the query string from.
   * @param  parameterName  the name of the parameter.
   * @param  parameterValue the value of the parameter.
   * @return the new query String.
   */
  public static String addParameterToQueryString(HttpServletRequest request,
                                                 String parameterName,
                                                 String parameterValue)
  {
    String parameter = request.getParameter(parameterName);

    if (parameter == null)
    {
      String queryString = request.getQueryString();

      if (queryString == null)
      {
        return parameterName + "=" + parameterValue;
      }
      else
      {
        return queryString + "&" + parameterName + "=" + parameterValue;
      }
    }
    else
    {
      return StringUtil.replaceFirst(parameterName + "=" + HttpUtil.encode(parameter),
          parameterName + "=" + parameterValue,
          request.getQueryString());
    }
  }

  /**
   * Add a parameter to the url of a request. This method makes sure
   * that the existing parameter (if any) is overriden.
   *
   * @param  request the request to get the query string from.
   * @param  addKey  the key of the parameter.
   * @param  addValue the value of the parameter.
   * @return the new query String.
   * @see    HttpUtil#addParameterToQueryString(HttpServletRequest, String, String)
   */
  public static String addParameterToUrl(HttpServletRequest request,
                                         String addKey,
                                         String addValue)
  {
    return request.getRequestURI() + "?" + addParameterToQueryString(request,
        addKey,
        addValue);
  }

  /**
   * Returns the request paramater value (given the parameter name) if it's not
   * null and not empty ("", or "   ", etc.), otherwise returns the given
   * default value.
   *
   * @param request the request.
   * @param parameterName the paramater name.
   * @param defaultValue the default value to return if the parameter value is
   *        null or empty.
   * @return the parameter value if it's not null and not empty, otherwise the
   *         given default parameter value.
   */
  public static String getParameter(ServletRequest request, String parameterName, String defaultValue)
  {
    String value = request.getParameter(parameterName);

    if (value == null || value.trim().equals(""))
    {
      return defaultValue;
    }
    else
    {
      return value;
    }
  }

  /**
   * Returns a Map containing the parameters names and values of the given
   * query string.
   *
   * @param queryString the query string to parse.
   * @return a Map containing the parameters names and values of the given
   *         query string.
   */
  public static Map queryStringToParameters(String queryString)
  {
    Map parameters = new HashMap();

    if (Check.isEmpty(queryString))
    {
      return parameters;
    }

    String[] namesAndValues = queryString.split("&");

    for (int i = 0; i < namesAndValues.length; i++)
    {
      String nameAndValue = namesAndValues[i];

      // we do not have a valid name=value pair, we continue
      if (nameAndValue.indexOf('=') == -1)
      {
        continue;
      }

      String name = nameAndValue.substring(0, nameAndValue.indexOf('='));
      String value = nameAndValue.substring(nameAndValue.indexOf('=') + 1);
      parameters.put(name, HttpUtil.decode(value));
    }

    return parameters;
  }

  /**
   * Returns a map built with the different <i>parameters</i> of the
   * <i>request</i>, using the "enum" String representation for parameters
   * having several values (see parameterValuesToEnumString(java.lang.String[])).
   *
   * @param parameters the parameters names.
   * @param request the request to get the parameters values from.
   * @return a map build with the different parameters of the request.
   * @see #parameterValuesToEnumString(java.lang.String[])
   */
  public static Map requestToMap(HttpServletRequest request, String[] parameters)
  {
    HashMap values = new HashMap();

    for (int i = 0; i < parameters.length; i++)
    {
      String parameterValues[] = request.getParameterValues(parameters[i]);

      if (parameterValues == null)
      {
        values.put(parameters[i], null);
        continue;
      }

      if (parameterValues.length > 1)
      {
        values.put(parameters[i], parameterValuesToEnumString(parameterValues));
      }
      else
      {
        values.put(parameters[i], parameterValues[0]);
      }
    }

    return values;
  }

  /**
   * Returns an "enum" String representation of the given parameter values.
   * This method expects that all the values contained in the array are parsable
   * as valid ints. The String representation is composed of only "1" and "0",
   * e.g. "1000101". "1" means that at one of the value is the character index
   * where "1" is located. For example, "1001" means that we have two values :
   * "1", and "4", because there is a "1" at the first at fourth characters of
   * the String. This is called an "enum" String because it's almost the same
   * as the "enum" type in MySQL.
   *
   * @param parameterValues the parameter values.
   * @return an "enum" String representation of the given parameter values.
   */
  public static String parameterValuesToEnumString(String[] parameterValues)
  {
    Map parameterMap = new HashMap();

    int max = 0;

    for (int i = 0; i < parameterValues.length; i++)
    {
      int value = Integer.parseInt(parameterValues[i]);

      if (value > max)
      {
        max = value;
      }

      parameterMap.put(new Integer(value), null);
    }

    StringBuffer result = new StringBuffer(max);

    for (int i = 1; i <= max; i++)
    {
      if (parameterMap.containsKey(new Integer(i)))
      {
        result.append('1');
      }
      else
      {
        result.append('0');
      }
    }

    return result.toString();
  }

  /**
   * Returns a SmartUploadHttpServletRequest from the given servletConfig,
   * maxFileSize, request and response. Use this when you have a
   * multipart/form-data form you need to parse.
   *
   * @param servletConfig the Servlet config.
   * @param maxFileSize the maximum file size allowed.
   * @param request the request.
   * @param response the response.
   * @return a SmartUploadHttpServletRequest.
   * @throws ServletException if an error occurs during form parsing.
   * @throws SecurityException if a file was bigger than maxFileSize.
   */
  public static SmartUploadHttpServletRequest getSmartUploadHttpServletRequest(ServletConfig servletConfig, long maxFileSize, HttpServletRequest request, HttpServletResponse response) throws ServletException
  {
    try
    {
      SmartUpload upload = new SmartUpload();
      upload.initialize(servletConfig, request, response);
      upload.setMaxFileSize(maxFileSize);
      upload.upload();
      return new SmartUploadHttpServletRequest(upload.getRequest(), request, upload);
    }
    catch (SmartUploadException e)
    {
      throw new ServletException(e);
    }
    catch (IOException e)
    {
      throw new ServletException(e);
    }
  }
}