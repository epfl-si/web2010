/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.util;

import org.apache.commons.beanutils.*;

import java.lang.reflect.*;
import java.util.*;

/**
 * Utilities for beans.
 *
 * @author  Laurent Boatto
 * @version $Id$
 */

public class BeanUtil
{
  private static final Random _random = new Random();

  /**
   * Private constructor, use only static methods.
   */
  private BeanUtil()
  {
  }

  /**
   * Returns a Map with the attribute values of the given bean.
   * The Map key is the attribute name, and the Map value is the
   * attribute value (String).
   *
   * @param bean the bean to get the values from.
   * @param attributes an array containing all the attribute names for which
   *                   you want the values.
   * @return  a Map with the attribute values of the given bean.
   */
  public static Map getValuesMap(Object bean, String[] attributes)
  {
    Map map = new HashMap();

    for (int i = 0; i < attributes.length; i++)
    {
      String attribute = attributes[i];

      try
      {
        map.put(attribute, BeanUtils.getSimpleProperty(bean, attribute));
      }
          // If an exception occurs, it's because we have a bad bean or bad
          // attributes, there's nothing we can do about it so we throw a
          // RuntimeException
      catch (IllegalAccessException e)
      {
        throw new RuntimeException(e);
      }
      catch (InvocationTargetException e)
      {
        throw new RuntimeException(e);
      }
      catch (NoSuchMethodException e)
      {
        throw new RuntimeException(e);
      }
    }

    return map;
  }

  /**
   * Populates the given simple bean with random values, and returns the values
   * used in a Map.
   *
   * @param bean the bean to populate.
   * @param attributesNames the attributes to populate.
   * @param attributesClasses the attributes' classes.
   * @return a Map with the values used for population.
   * @throws IllegalAccessException
   * @throws InvocationTargetException
   */
  public static Map randomPopulate(Object bean, String[] attributesNames, Class[] attributesClasses) throws IllegalAccessException, InvocationTargetException
  {
    Map values = new HashMap();

    for (int i = 0; i < attributesNames.length; i++)
    {
      String attribute = attributesNames[i];

      Class klass = attributesClasses[i];
      Object value = null;

      // String
      if (klass == String.class)
      {
        value = StringUtil.randomString(8, _random);
      }
      // int
      else if (klass == int.class)
      {
        value = new Integer(_random.nextInt(100));
      }
      // long
      else if (klass == long.class)
      {
        value = new Long(_random.nextInt(100));
      }
      // float
      else if (klass == float.class)
      {
        value = new Float(_random.nextInt(100) / 100f);
      }
      // double
      else if (klass == double.class)
      {
        value = new Double(_random.nextInt(100) / 100f);
      }
      // boolean
      else if (klass == boolean.class)
      {
        value = new Boolean(_random.nextBoolean());
      }
      // date
      else if (klass == Date.class)
      {
        value = new java.util.Date();
      }

      values.put(attribute, value);
    }

    BeanUtils.populate(bean, values);

    return values;
  }

  /**
   * Randomly populates <code>num</code> objects of the given class.
   *
   * @param num the number of objects to populate.
   * @param beanClass the bean class to populate.
   * @param attributesNames the bean attributes to populate.
   * @param attributesClasses the bean attributes' classes.
   * @return the number of desired objects randomly populated.
   * @throws IllegalAccessException
   * @throws InstantiationException
   * @throws InvocationTargetException
   */
  public static Collection randomPopulate(int num, Class beanClass, String[] attributesNames, Class[] attributesClasses) throws IllegalAccessException, InstantiationException, InvocationTargetException
  {
    Collection results = new ArrayList();

    for (int i = 0; i < num; i++)
    {
      Object bean = beanClass.newInstance();
      BeanUtil.randomPopulate(bean, attributesNames, attributesClasses);
      results.add(bean);
    }

    return results;
  }

  /**
   * Returns true if the two given beans have the same properties values. This
   * method only check simple types, like String, int, boolean, float, etc. but
   * not Date, Class, etc..
   *
   * @param bean1 the first bean.
   * @param bean2 the second bean.
   * @return true if the two given beans have the same properties values.
   */
  public static boolean haveSamePropertiesValues(Object bean1, Object bean2)
  {
    try
    {
      Map bean1map = PropertyUtils.describe(bean1);
      Map bean2map = PropertyUtils.describe(bean2);

      Iterator it = bean1map.keySet().iterator();

      while (it.hasNext())
      {
        Object key = it.next();

        if (!bean2map.containsKey(key))
        {
          continue;
        }

        Object value1 = bean1map.get(key);
        Object value2 = bean2map.get(key);

        // We don't check Dates and Classes
        if (value1 instanceof Date || value1 instanceof Class)
        {
          continue;
        }

        if (value1 == null)
        {
          if (value2 != null)
          {
            return false;
          }
        }
        else if (!value1.equals(value2))
        {
          return false;
        }
      }

      return true;
    }
    catch (Exception e)
    {
      throw new RuntimeException(e);
    }
  }
}
