/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.persistance.hibernate;

import net.sf.hibernate.*;
import net.sf.hibernate.cfg.*;

/**
 * HibernateUtil
 *
 * @author  Laurent Boatto
 * @version $Id$
 */

public class HibernateUtil
{
  private static SessionFactory _sessionFactory = null;

  static
  {
    try
    {
      _sessionFactory = new Configuration().configure().buildSessionFactory();
    }
    catch (HibernateException e)
    {
      throw new ExceptionInInitializerError(e);
    }
  }

  public static final Session getSession() throws HibernateException
  {
    return _sessionFactory.openSession();
  }

  public static final SessionFactory getSessionFactory()
  {
    return _sessionFactory;
  }
}