/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.persistance.hibernate;

import net.sf.hibernate.*;
import org.apache.commons.logging.*;

import java.util.*;

/**
 * Various utilities for managing persistance objects with Hibernate. see
 * com.baneo.core.persistance.IPersistanceManager for the documentation of
 * the various methods.
 *
 * @author  Laurent Boatto
 * @version $Id$
 * @see com.baneo.core.persistance.IPersistanceManager
 */

public class HibernateObjectManager
{
  private static final ThreadLocal _sessionThreadContext = new ThreadLocal();
  private static final ThreadLocal _transactionThreadContext = new ThreadLocal();

  /**
   * The log.
   */
  private static final Log _log = LogFactory.getLog(HibernateObjectManager.class);

  private static final HibernateObjectManager _instance = new HibernateObjectManager();

  /**
   * Private constructor, use instance() instead.
   */
  private HibernateObjectManager()
  {
  }

  /**
   * Returns the instance of the HibernateObjectManager (singleton).
   *
   * @return the instance of the HibernateObjectManager (singleton).
   */
  public static HibernateObjectManager instance()
  {
    return _instance;
  }

  public void beginTransaction() throws HibernateException
  {
    Session session = HibernateUtil.getSession();
    Transaction transaction = session.beginTransaction();
    _sessionThreadContext.set(session);
    _transactionThreadContext.set(transaction);
  }

  public void commitTransaction() throws HibernateException
  {
    Session session = getCurrentSession();
    Transaction transaction = getCurrentTransaction();

    try
    {
      if (transaction != null)
      {
        transaction.commit();
      }
    }
    finally
    {
      if (session != null)
      {
        session.close();
      }
    }
  }

  private Session getCurrentSession()
  {
    return (Session) _sessionThreadContext.get();
  }

  private Transaction getCurrentTransaction()
  {
    return (Transaction) _sessionThreadContext.get();
  }

  public Collection findByQuery(String queryString, Object[] queryAttributes) throws HibernateException
  {
    Session session = null;

    try
    {
      session = HibernateUtil.getSession();

      Query query = session.createQuery(queryString);

      if (queryAttributes != null)
      {
        for (int i = 0; i < queryAttributes.length; i++)
        {
          query.setParameter(i, queryAttributes[i]);
        }
      }

      return query.list();
    }
    catch (HibernateException e)
    {
      _log.error(e.getMessage(), e);

      throw e;
    }
    finally
    {
      if (session != null)
      {
        session.close();
      }
    }
  }

  public int findByQueryCount(String queryString, Object[] queryAttributes) throws HibernateException
  {
    Session session = null;

    try
    {
      session = HibernateUtil.getSession();

      Query query = session.createQuery(queryString);

      if (queryAttributes != null)
      {
        for (int i = 0; i < queryAttributes.length; i++)
        {
          query.setParameter(i, queryAttributes[i]);
        }
      }

      return ((Integer) query.list().get(0)).intValue();
    }
    catch (HibernateException e)
    {
      _log.error(e.getMessage(), e);
      throw e;
    }
    finally
    {
      if (session != null)
      {
        session.close();
      }
    }
  }


  public Collection findByQuery(String queryString, Object[] queryAttributes, String orderBy, int startIndex, int maxResults) throws HibernateException
  {
    Session session = null;

    try
    {
      session = HibernateUtil.getSession();

      Query query = null;

      if (orderBy != null)
      {
        query = session.createQuery(queryString + " ORDER BY " + orderBy);
      }
      else
      {
        query = session.createQuery(queryString);
      }

      if (queryAttributes != null)
      {
        for (int i = 0; i < queryAttributes.length; i++)
        {
          query.setParameter(i, queryAttributes[i]);
        }
      }

      query.setFirstResult(startIndex);
      query.setMaxResults(maxResults);

      return query.list();
    }
    catch (HibernateException e)
    {
      _log.error(e.getMessage(), e);
      throw e;
    }
    finally
    {
      if (session != null)
      {
        session.close();
      }
    }
  }


  public Collection findByAttribute(Class klass, String attributeName, Object attributeValue) throws HibernateException
  {
    Session session = null;

    try
    {
      session = HibernateUtil.getSession();
      Query query = session.createQuery("FROM " + klass.getName() + " WHERE " + attributeName + " = ?");
      query.setParameter(0, attributeValue);
      return query.list();
    }
    catch (HibernateException e)
    {
      _log.error(e.getMessage(), e);
      throw e;
    }
    finally
    {
      if (session != null)
      {
        session.close();
      }
    }
  }

  public Collection findByAttribute(Class klass, String attributeName, Object attributeValue, String orderBy, int startIndex, int maxResults) throws HibernateException
  {
    Session session = null;

    try
    {
      session = HibernateUtil.getSession();

      Query query = null;

      if (orderBy != null)
      {
        query = session.createQuery("FROM " + klass.getName() + " WHERE " + attributeName + " = ? ORDER BY " + orderBy);
      }
      else
      {
        query = session.createQuery("FROM " + klass.getName() + " WHERE " + attributeName + " = ?");
      }

      query.setParameter(0, attributeValue);
      query.setFirstResult(startIndex);
      query.setMaxResults(maxResults);

      return query.list();
    }
    catch (HibernateException e)
    {
      _log.error(e.getMessage(), e);
      throw e;
    }
    finally
    {
      if (session != null)
      {
        session.close();
      }
    }
  }

  public Object findFirstByAttribute(Class klass, String attributeName, Object attributeValue) throws HibernateException
  {
    List result = (List) findByAttribute(klass, attributeName, attributeValue);

    if (result.size() == 0)
    {
      return null;
    }

    return result.get(0);
  }

  public int findByAttributeCount(Class klass, String attributeName, Object attributeValue) throws HibernateException
  {
    Session session = null;

    try
    {
      session = HibernateUtil.getSession();
      Query query = session.createQuery("SELECT COUNT(*) FROM " + klass.getName() + " WHERE " + attributeName + " = ?");
      query.setParameter(0, attributeValue);
      return ((Integer) query.list().get(0)).intValue();
    }
    catch (HibernateException e)
    {
      _log.error(e.getMessage(), e);
      throw e;
    }
    finally
    {
      if (session != null)
      {
        session.close();
      }
    }
  }

  public void insert(Object object) throws HibernateException
  {
    Session session = null;
    Transaction transaction = null;

    try
    {
      session = HibernateUtil.getSession();
      transaction = session.beginTransaction();

      session.save(object);
      transaction.commit();
    }
    catch (HibernateException e)
    {
      _log.error(e.getMessage(), e);

      if (transaction != null)
      {
        transaction.rollback();
      }

      throw e;
    }
    finally
    {
      if (session != null)
      {
        session.close();
      }
    }
  }

  public void update(Object object) throws HibernateException
  {
    Session session = null;
    Transaction transaction = null;

    try
    {
      session = HibernateUtil.getSession();
      transaction = session.beginTransaction();
      session.update(object);
      transaction.commit();
    }
    catch (HibernateException e)
    {
      _log.error(e.getMessage(), e);

      if (transaction != null)
      {
        transaction.rollback();
      }

      throw e;
    }
    finally
    {
      if (session != null)
      {
        session.close();
      }
    }
  }

  public void delete(Object object) throws HibernateException
  {
    Session session = null;
    Transaction transaction = null;

    try
    {
      session = HibernateUtil.getSession();
      transaction = session.beginTransaction();
      session.delete(object);
      transaction.commit();
    }
    catch (HibernateException e)
    {
      _log.error(e.getMessage(), e);

      if (transaction != null)
      {
        transaction.rollback();
      }

      throw e;
    }
    finally
    {
      if (session != null)
      {
        session.close();
      }
    }
  }

  public Object get(Class klass, int id) throws HibernateException
  {
    Session session = null;

    try
    {
      session = HibernateUtil.getSession();
      return session.load(klass, new Integer(id));
    }
    catch (ObjectNotFoundException e)
    {
      return null;
    }
    catch (HibernateException e)
    {
      _log.error(e.getMessage(), e);
      throw e;
    }
    finally
    {
      if (session != null)
      {
        session.close();
      }
    }
  }

  public Object findFirst(Class klass) throws HibernateException
  {
    Session session = null;

    try
    {
      session = HibernateUtil.getSession();
      Query query = session.createQuery("FROM " + klass.getName() + " ORDER BY id ASC");
      query.setFirstResult(0);
      query.setMaxResults(1);
      return query.iterate().next();
    }
    catch (HibernateException e)
    {
      _log.error(e.getMessage(), e);
      throw e;
    }
    finally
    {
      if (session != null)
      {
        session.close();
      }
    }
  }

  public Object findLast(Class klass) throws HibernateException
  {
    Session session = null;

    try
    {
      session = HibernateUtil.getSession();
      Query query = session.createQuery("FROM " + klass.getName() + " ORDER BY id DESC");
      query.setFirstResult(0);
      query.setMaxResults(1);
      return query.iterate().next();
    }
    catch (HibernateException e)
    {
      _log.error(e.getMessage(), e);
      throw e;
    }
    finally
    {
      if (session != null)
      {
        session.close();
      }
    }
  }

  public Collection findAll(Class klass) throws HibernateException
  {
    Session session = null;

    try
    {
      session = HibernateUtil.getSession();
      return session.find("FROM " + klass.getName());
    }
    catch (HibernateException e)
    {
      _log.error(e.getMessage(), e);
      throw e;
    }
    finally
    {
      if (session != null)
      {
        session.close();
      }
    }
  }

  public Collection findAll(Class klass, String orderBy, int startIndex, int maxResults) throws HibernateException
  {
    Session session = null;

    try
    {
      session = HibernateUtil.getSession();

      Query query = null;

      if (orderBy != null)
      {
        query = session.createQuery("FROM " + klass.getName() + " ORDER BY " + orderBy);
      }
      else
      {
        query = session.createQuery("FROM " + klass.getName());
      }

      query.setFirstResult(startIndex);
      query.setMaxResults(maxResults);
      return query.list();
    }
    catch (HibernateException e)
    {
      _log.error(e.getMessage(), e);
      throw e;
    }
    finally
    {
      if (session != null)
      {
        session.close();
      }
    }
  }

  public int count(Class klass) throws HibernateException
  {
    return count("SELECT COUNT(*) FROM " + klass.getName());
  }

  public int count(String countQuery) throws HibernateException
  {
    Session session = null;

    try
    {
      session = HibernateUtil.getSession();
      return ((Integer) session.iterate(countQuery).next()).intValue();
    }
    catch (HibernateException e)
    {
      _log.error(e.getMessage(), e);
      throw e;
    }
    finally
    {
      if (session != null)
      {
        session.close();
      }
    }
  }

  public Collection findByAttributes(Class klass, String[] attributesNames, Object[] attributesValues) throws HibernateException
  {
    Session session = null;

    try
    {
      session = HibernateUtil.getSession();
      StringBuffer queryBuffer = new StringBuffer("FROM " + klass.getName() + " WHERE " + attributesNames[0] + " = ?");

      for (int i = 1; i < attributesNames.length; i++)
      {
        queryBuffer.append(" AND " + attributesNames[i] + " = ?");
      }

      Query query = session.createQuery(queryBuffer.toString());

      for (int i = 0; i < attributesNames.length; i++)
      {
        query.setParameter(i, attributesValues[i]);
      }

      return query.list();
    }
    catch (HibernateException e)
    {
      _log.error(e.getMessage(), e);
      throw e;
    }
    finally
    {
      if (session != null)
      {
        session.close();
      }
    }
  }

  public Collection findByAttributes(Class klass, String[] attributesNames, Object[] attributesValues, String orderBy, int startIndex, int maxResults) throws HibernateException
  {
    Session session = null;

    try
    {
      session = HibernateUtil.getSession();
      StringBuffer queryBuffer = new StringBuffer("FROM " + klass.getName() + " WHERE " + attributesNames[0] + " = ?");

      for (int i = 1; i < attributesNames.length; i++)
      {
        queryBuffer.append(" AND " + attributesNames[i] + " = ?");
      }

      if (orderBy != null)
      {
        queryBuffer.append(" ORDER BY " + orderBy);
      }

      Query query = session.createQuery(queryBuffer.toString());

      for (int i = 0; i < attributesNames.length; i++)
      {
        query.setParameter(i, attributesValues[i]);
      }

      query.setFirstResult(startIndex);
      query.setMaxResults(maxResults);

      return query.list();
    }
    catch (HibernateException e)
    {
      _log.error(e.getMessage(), e);
      throw e;
    }
    finally
    {
      if (session != null)
      {
        session.close();
      }
    }
  }

  public int findByAttributesCount(Class klass, String[] attributesNames, Object[] attributesValues) throws HibernateException
  {
    Session session = null;

    try
    {
      session = HibernateUtil.getSession();

      StringBuffer queryBuffer = new StringBuffer("SELECT COUNT(*) FROM " + klass.getName() + " WHERE " + attributesNames[0] + " = ?");

      for (int i = 1; i < attributesNames.length; i++)
      {
        queryBuffer.append(" AND " + attributesNames[i] + " = ?");
      }

      Query query = session.createQuery(queryBuffer.toString());

      for (int i = 0; i < attributesNames.length; i++)
      {
        query.setParameter(i, attributesValues[i]);
      }

      return ((Integer) query.list().get(0)).intValue();
    }
    catch (HibernateException e)
    {
      _log.error(e.getMessage(), e);
      throw e;
    }
    finally
    {
      if (session != null)
      {
        session.close();
      }
    }
  }

  public Object findFirstByAttributes(Class klass, String[] attributesNames, Object[] attributesValues) throws HibernateException
  {
    List result = (List) findByAttributes(klass, attributesNames, attributesValues);

    if (result.size() == 0)
    {
      return null;
    }

    return result.get(0);
  }
}