/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.persistance;

import java.util.*;

/**
 * An IPersistanceManager lets you easily manage persistance objects with
 * methods for inserting, updating, deleting, retrieving, searching etc.
 * objects of a given class.
 *
 */
public interface IPersistanceManager
{
  /**
   * Inserts the given object.
   *
   * @param object the object to insert.
   * @throws PersistanceException on persistance error.
   */
  void insert(Object object) throws PersistanceException;

  /**
   * Updates the given object.
   *
   * @param object the object to update.
   * @throws PersistanceException on persistance error.
   */
  void update(Object object) throws PersistanceException;

  /**
   * Deletes the given object.
   *
   * @param object the object to delete.
   * @throws PersistanceException on persistance error.
   */
  void delete(Object object) throws PersistanceException;

  /**
   * Returns the object of the given class having the given id or null if
   * it does not exist.
   *
   * @param klass the object class.
   * @param id the object id.
   * @return the object of the given class having the given id or null if
   *         it does not exist.
   * @throws PersistanceException on persistance error.
   */
  Object get(Class klass, int id) throws PersistanceException;

  /**
   * Returns the first object of the given class.
   *
   * @param klass the object class.
   * @return the first object of the given class.
   * @throws PersistanceException on persistance error.
   */
  Object findFirst(Class klass) throws PersistanceException;

  /**
   * Returns the last object of the given class.
   *
   * @param klass the object class.
   * @return the last object of the given class.
   * @throws PersistanceException on persistance error.
   */
  Object findLast(Class klass) throws PersistanceException;

  /**
   * Returns the objects corresponding to the given query string and attributes.
   * The query attributes may be null.
   *
   * @param queryString the query string.
   * @param queryAttributes the query attributes.
   * @throws PersistanceException on persistance layer error.
   */
  Collection findByQuery(String queryString, Object[] queryAttributes) throws PersistanceException;

  /**
   * Returns the number of objects corresponding to the given query string
   * and attributes. The query attributes may be null.
   *
   * @param queryString the query string.
   * @param queryAttributes the query attributes.
   * @throws PersistanceException on persistance layer error.
   */
  int findByQueryCount(String queryString, Object[] queryAttributes) throws PersistanceException;

  /**
   * Returns the objects corresponding to the given query string and attributes,
   * ordered by the given order, starting at startIndex and returning at most
   * maxResults. The query attributes may be null.
   *
   * @param queryString the query string.
   * @param queryAttributes the query attributes.
   * @param orderBy the attribute used to order the objects, can be null.
   * @param startIndex the index to start (e.g. 0 to start at the beginning).
   * @param maxResults the maximum number of objects to return.
   * @throws PersistanceException on persistance error.
   */
  Collection findByQuery(String queryString, Object[] queryAttributes, String orderBy, int startIndex, int maxResults) throws PersistanceException;

  /**
   * Returns the objects of the given class having the given value for the
   * given attribute. If you expect to receive only one object, use
   * findFirstByAttribute instead.
   *
   * @param klass the object class.
   * @param attributeName the object attribute name.
   * @param attributeValue the object attribute value.
   * @return the object of the given class having the given value
   *         for the given attribute.
   * @see #findFirstByAttribute(Class, String, Object)
   * @throws PersistanceException on persistance error.
   */
  Collection findByAttribute(Class klass, String attributeName, Object attributeValue) throws PersistanceException;

  /**
   * Returns the objects of the given class having the given values for the
   * given attributes. If you expect to receive only one object, use
   * findFirstByAttributes instead.
   *
   * @param klass the object class.
   * @param attributesNames the object attributes names.
   * @param attributesValues the object attributes values.
   * @return the object of the given class having the given values
   *         for the given attributes.
   * @see #findFirstByAttributes(Class, String[], Object[])
   * @throws PersistanceException on persistance layer error.
   */
  Collection findByAttributes(Class klass, String[] attributesNames, Object[] attributesValues) throws PersistanceException;

  /**
   * Returns the objects of the given class having the given value for the
   * given attribute, ordered by the given order, starting at startIndex and
   * returning at most maxResults.
   *
   * @param klass the object class.
   * @param attributeName the object attribute name.
   * @param attributeValue the object attribute value.
   * @param orderBy the attribute used to order the objects, can be null.
   * @param startIndex the index to start (e.g. 0 to start at the beginning).
   * @param maxResults the maximum number of objects to return.
   * @return the objects of the given class having the given value
   *         for the given attribute.
   * @throws PersistanceException on persistance error.
   */
  Collection findByAttribute(Class klass, String attributeName, Object attributeValue, String orderBy, int startIndex, int maxResults) throws PersistanceException;

  /**
   * Returns the objects of the given class having the given values for the
   * given attributes, ordered by the given order, starting at startIndex and
   * returning at most maxResults.
   *
   * @param klass the object class.
   * @param attributesNames the object attributes names.
   * @param attributesValues the object attributes values.
   * @param orderBy the attribute used to order the objects, can be null.
   * @param startIndex the index to start (e.g. 0 to start at the beginning).
   * @param maxResults the maximum number of objects to return.
   * @return the objects of the given class having the given values
   *         for the given attributes.
   * @throws PersistanceException on persistance error.
   */
  Collection findByAttributes(Class klass, String[] attributesNames, Object[] attributesValues, String orderBy, int startIndex, int maxResults) throws PersistanceException;


  /**
   * Returns the number of objects having the given value for the given
   * attribute.
   *
   * @param klass the object class.
   * @param attributeName the object attribute name.
   * @param attributeValue the object attribute value.
   * @return the number of objects have the given value for the given
   *         the attribute.
   * @throws PersistanceException on persistance error.
   */
  int findByAttributeCount(Class klass, String attributeName, Object attributeValue) throws PersistanceException;

  /**
   * Returns the number of objects having the given values for the given
   * attributes.
   *
   * @param klass the object class.
   * @param attributesNames the object attributes names.
   * @param attributesValues the object attributes values.
   * @return the number of objects have the given values for the given
   *         the attributes.
   * @throws PersistanceException on persistance error.
   */
  int findByAttributesCount(Class klass, String[] attributesNames, Object[] attributesValues) throws PersistanceException;

  /**
   * Returns the first object of the given class having the given value for the
   * given attribute.
   *
   * @param klass the object class.
   * @param attributeName the object attribute name.
   * @param attributeValue the object attribute value.
   * @return the first object of the given class having the given value
   *         for the given attribute.
   * @throws PersistanceException on persistance error.
   */
  Object findFirstByAttribute(Class klass, String attributeName, Object attributeValue) throws PersistanceException;

  /**
   * Returns the first object of the given class having the given values for the
   * given attributes.
   *
   * @param klass the object class.
   * @param attributesNames the object attributes names.
   * @param attributesValues the object attributes values.
   * @return the first object of the given class having the given values
   *         for the given attributes.
   * @throws PersistanceException on persistance error.
   */
  Object findFirstByAttributes(Class klass, String[] attributesNames, Object[] attributesValues) throws PersistanceException;

  /**
   * Returns all the objects of the given class.
   *
   * @param klass the class to get all the objects from.
   * @return all the objects of the given class.
   * @throws PersistanceException on persistance error.
   */
  Collection findAll(Class klass) throws PersistanceException;

  /**
   * Returns all the objects of the given class, ordered by the given order,
   * starting at startIndex and returning at most maxResults.
   *
   * @param klass the class to get all the objects from.
   * @param orderBy the attribute used to order the objects, can be null.
   * @param startIndex the index to start (e.g. 0 to start at the beginning).
   * @param maxResults the maximum number of objects to return.
   * @return all the objects of the given class, ordered by the given order,
   *         starting at startIndex and returning at most maxResults.
   * @throws PersistanceException on persistance error.
   */
  Collection findAll(Class klass, String orderBy, int startIndex, int maxResults) throws PersistanceException;

  /**
   * Returns the number of objects of the given class.
   *
   * @param klass the class to get the number of objects from.
   * @return the number of objects of the given class.
   * @throws PersistanceException on persistance error.
   */
  int count(Class klass) throws PersistanceException;

  /**
   * Returns the number of results of the given count query, e.g.
   * "SELECT COUNT(*) FROM...".
   *
   * @param countQuery the count query, e.g. "SELECT COUNT(*) FROM...".
   * @return the number of results of the given count query.
   * @throws PersistanceException on persistance error.
   */
  int count(String countQuery) throws PersistanceException;
}
