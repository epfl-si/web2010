/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.persistance;

import com.baneo.core.persistance.hibernate.*;

/**
 * Factory for retrieving the IPersistanceManager used by the application.
 *
 * @author  Laurent Boatto
 * @version $Id$
 * @see com.baneo.core.persistance.IPersistanceManager
 */

public class PersistanceManagerFactory
{
  /**
   * Private constructor, use getIPersistanceManager instead.
   */
  private PersistanceManagerFactory()
  {
  }

  /**
   * Returns the IPersistanceManager used by the application.
   *
   * @return the IPersistanceManager used by the application.
   * @see com.baneo.core.persistance.IPersistanceManager
   */
  public static final IPersistanceManager getIPersistanceManager()
  {
    /**
     * todo get this from a property
     */
    return HibernatePersistanceManager.instance();
  }
}
