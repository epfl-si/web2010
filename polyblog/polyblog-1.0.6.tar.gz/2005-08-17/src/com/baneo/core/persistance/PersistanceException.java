/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.persistance;

/**
 * Thrown when a problem occurs with the persistance layer.
 *
 * @author  Laurent Boatto
 * @version $Id$
 */

public class PersistanceException extends Exception
{
  /**
   * Constructs a new PersistanceException with the specified message.
   *
   * @param message the message.
   */
  public PersistanceException(String message)
  {
    super(message);
  }

  /**
   * Constructs a new PersistanceException with the specified cause.
   *
   * @param cause the cause.
   */
  public PersistanceException(Throwable cause)
  {
    super(cause);
  }

  /**
   * Constructs a new PersistanceException with the specified detail message
   * and cause.
   *
   * @param message the message.
   * @param cause the cause.
   */
  public PersistanceException(String message, Throwable cause)
  {
    super(message, cause);
  }
}


