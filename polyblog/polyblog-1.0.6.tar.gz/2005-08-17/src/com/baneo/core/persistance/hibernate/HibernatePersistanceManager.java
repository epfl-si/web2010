/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.persistance.hibernate;

import com.baneo.core.persistance.*;
import net.sf.hibernate.*;

import java.util.*;

/**
 * An implementation of IPersistanceManager using Hibernate.
 *
 * @author  Laurent Boatto
 * @version $Id$
 * @see com.baneo.core.persistance.IPersistanceManager
 */

public class HibernatePersistanceManager implements IPersistanceManager
{
  private static final HibernateObjectManager _manager = HibernateObjectManager.instance();
  private static final HibernatePersistanceManager _instance = new HibernatePersistanceManager();

  public static final HibernatePersistanceManager instance()
  {
    return _instance;
  }

  private HibernatePersistanceManager()
  {
  }

  public void insert(Object object) throws PersistanceException
  {
    try
    {
      _manager.insert(object);
    }
    catch (HibernateException e)
    {
      throw new PersistanceException(e);
    }
  }

  public void update(Object object) throws PersistanceException
  {
    try
    {
      _manager.update(object);
    }
    catch (HibernateException e)
    {
      throw new PersistanceException(e);
    }
  }

  public void delete(Object object) throws PersistanceException
  {
    try
    {
      _manager.delete(object);
    }
    catch (HibernateException e)
    {
      throw new PersistanceException(e);
    }
  }

  public Object get(Class klass, int id) throws PersistanceException
  {
    try
    {
      return _manager.get(klass, id);
    }
    catch (HibernateException e)
    {
      throw new PersistanceException(e);
    }
  }

  public Object findFirst(Class klass) throws PersistanceException
  {
    try
    {
      return _manager.findFirst(klass);
    }
    catch (HibernateException e)
    {
      throw new PersistanceException(e);
    }
  }

  public Object findLast(Class klass) throws PersistanceException
  {
    try
    {
      return _manager.findLast(klass);
    }
    catch (HibernateException e)
    {
      throw new PersistanceException(e);
    }
  }

  public Collection findAll(Class klass) throws PersistanceException
  {
    try
    {
      return _manager.findAll(klass);
    }
    catch (HibernateException e)
    {
      throw new PersistanceException(e);
    }
  }

  public Collection findAll(Class klass, String orderBy, int startIndex, int maxResults) throws PersistanceException
  {
    try
    {
      return _manager.findAll(klass, orderBy, startIndex, maxResults);
    }
    catch (HibernateException e)
    {
      throw new PersistanceException(e);
    }
  }

  public Collection findByAttribute(Class klass, String attributeName, Object attributeValue) throws PersistanceException
  {
    try
    {
      return _manager.findByAttribute(klass, attributeName, attributeValue);
    }
    catch (HibernateException e)
    {
      throw new PersistanceException(e);
    }
  }

  public Object findFirstByAttribute(Class klass, String attributeName, Object attributeValue) throws PersistanceException
  {
    try
    {
      return _manager.findFirstByAttribute(klass, attributeName, attributeValue);
    }
    catch (HibernateException e)
    {
      throw new PersistanceException(e);
    }
  }

  public int findByAttributeCount(Class klass, String attributeName, Object attributeValue) throws PersistanceException
  {
    try
    {
      return _manager.findByAttributeCount(klass, attributeName, attributeValue);
    }
    catch (HibernateException e)
    {
      throw new PersistanceException(e);
    }
  }

  public Collection findByAttribute(Class klass, String attribute, Object value, String orderBy, int startIndex, int maxResults) throws PersistanceException
  {
    try
    {
      return _manager.findByAttribute(klass, attribute, value, orderBy, startIndex, maxResults);
    }
    catch (HibernateException e)
    {
      throw new PersistanceException(e);
    }
  }

  public int count(Class klass) throws PersistanceException
  {
    try
    {
      return _manager.count(klass);
    }
    catch (HibernateException e)
    {
      throw new PersistanceException(e);
    }
  }

  public int count(String countQuery) throws PersistanceException
  {
    try
    {
      return _manager.count(countQuery);
    }
    catch (HibernateException e)
    {
      throw new PersistanceException(e);
    }
  }

  public Collection findByAttributes(Class klass, String[] attributesNames, Object[] attributesValues) throws PersistanceException
  {
    try
    {
      return _manager.findByAttributes(klass, attributesNames, attributesValues);
    }
    catch (HibernateException e)
    {
      throw new PersistanceException(e);
    }
  }

  public Collection findByAttributes(Class klass, String[] attributesNames, Object[] attributesValues, String orderBy, int startIndex, int maxResults) throws PersistanceException
  {
    try
    {
      return _manager.findByAttributes(klass, attributesNames, attributesValues, orderBy, startIndex, maxResults);
    }
    catch (HibernateException e)
    {
      throw new PersistanceException(e);
    }
  }

  public int findByAttributesCount(Class klass, String[] attributesNames, Object[] attributesValues) throws PersistanceException
  {
    try
    {
      return _manager.findByAttributesCount(klass, attributesNames, attributesValues);
    }
    catch (HibernateException e)
    {
      throw new PersistanceException(e);
    }
  }

  public Object findFirstByAttributes(Class klass, String[] attributesNames, Object[] attributesValues) throws PersistanceException
  {
    try
    {
      return _manager.findFirstByAttributes(klass, attributesNames, attributesValues);
    }
    catch (HibernateException e)
    {
      throw new PersistanceException(e);
    }
  }

  public Collection findByQuery(String queryString, Object[] queryAttributes) throws PersistanceException
  {
    try
    {
      return _manager.findByQuery(queryString, queryAttributes);
    }
    catch (HibernateException e)
    {
      throw new PersistanceException(e);
    }
  }

  public int findByQueryCount(String queryString, Object[] queryAttributes) throws PersistanceException
  {
    try
    {
      return _manager.findByQueryCount(queryString, queryAttributes);
    }
    catch (HibernateException e)
    {
      throw new PersistanceException(e);
    }
  }

  public Collection findByQuery(String queryString, Object[] queryAttributes, String orderBy, int startIndex, int maxResults) throws PersistanceException
  {
    try
    {
      return _manager.findByQuery(queryString, queryAttributes, orderBy, startIndex, maxResults);
    }
    catch (HibernateException e)
    {
      throw new PersistanceException(e);
    }
  }
}