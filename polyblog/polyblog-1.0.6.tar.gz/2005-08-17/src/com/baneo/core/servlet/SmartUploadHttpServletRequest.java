/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.servlet;

import com.jspsmart.upload.*;

import javax.servlet.http.*;
import java.util.*;

/**
 * An HttpServletRequestWrapper using SmartUpload that lets you manage request
 * in the multipart format.
 *
 * @author  Laurent Boatto
 * @version $Id$
 */

public class SmartUploadHttpServletRequest extends HttpServletRequestWrapper
{
  private Request _smartRequest;
  private SmartUpload _smartUpload;
  private HttpServletRequest _standardRequest;

  public SmartUploadHttpServletRequest(Request smartRequest, HttpServletRequest standardRequest, SmartUpload smartUpload)
  {
    super(standardRequest);
    _smartRequest = smartRequest;
    _standardRequest = standardRequest;
    _smartUpload = smartUpload;
  }

  public String getParameter(String s)
  {
    return _smartRequest.getParameter(s);
  }

  public Enumeration getParameterNames()
  {
    return _smartRequest.getParameterNames();
  }

  public String[] getParameterValues(String s)
  {
    return _smartRequest.getParameterValues(s);
  }

  public SmartUpload getSmartUpload()
  {
    return _smartUpload;
  }
}