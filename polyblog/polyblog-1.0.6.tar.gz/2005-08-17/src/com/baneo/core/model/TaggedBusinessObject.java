/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.model;

import java.util.*;

/**
 * A TaggedBusinessObject is a BusinessObject with informations like who
 * created / last updated the BusinessObject, when, where, etc.
 *
 * @author  Laurent Boatto
 * @version $Id$
 */

public class TaggedBusinessObject extends BusinessObject
{
  private int _version;
  private Date _created;
  private int _createdBy;
  private String _createdFootprint;
  private Date _lastModified;
  private int _lastModifiedBy;
  private String _lastModifiedFootprint;

  /**
   * The attributes of the TaggedBusinessObject which are calculated,
   * i.e. that are automatically set by the system
   */
  public static final String[] CALCULATED_ATTRIBUTES
      = {"id", "version", "created", "createdBy", "createdFootprint",
         "lastModified", "lastModifiedBy", "lastModifiedFootprint"};

  /**
   * Returns true if the given attribute is a calculated attribute.
   *
   * @param attribute the attribute to check.
   * @return true if the given attribute is a calculated attribute.
   */
  public static boolean isCalculatedAttribute(String attribute)
  {
    for (int i = 0; i < CALCULATED_ATTRIBUTES.length; i++)
    {
      if (CALCULATED_ATTRIBUTES[i].equals(attribute))
      {
        return true;
      }
    }

    return false;
  }

  /**
   * Returns the BO's version. When a BO is first created it's version is 1, if
   * it's updated once it's version is 2, etc.
   *
   * @return the BO's version.
   */
  public final int getVersion()
  {
    return _version;
  }

  /**
   * Sets the version. This method is only meant to be called by the
   * IPersistanceManager. Any other call is useless as it will be overriden
   * by the IPersistanceManager when a BusinessObject is inserted or actionPerformed.
   *
   * @param version the version.
   */
  public final void setVersion(int version)
  {
    _version = version;
  }


  /**
   * Returns the creation date.
   *
   * @return the creation date.
   */
  public final Date getCreated()
  {
    return _created;
  }

  /**
   * Sets the creation date. This method is only meant to be called by the
   * IPersistanceManager. Any other call is useless as it will be overriden
   * by the IPersistanceManager when a BusinessObject is inserted or actionPerformed.
   *
   * @param created the creation date.
   */
  public final void setCreated(Date created)
  {
    _created = created;
  }

  /**
   * Returns the id of the user who created this BO.
   *
   * @return the id of the user who created this BO.
   */
  public final int getCreatedBy()
  {
    return _createdBy;
  }

  /**
   * Sets the id of the user who created this BO. This method is only meant to
   * be called by the IPersistanceManager. Any other call is useless as it will
   * be overriden by the IPersistanceManager when a BusinessObject is inserted
   * or actionPerformed.
   *
   * @param createdBy the id of the user who created this BO.
   */
  public final void setCreatedBy(int createdBy)
  {
    _createdBy = createdBy;
  }

  /**
   * Returns the footprint of the user who created this BO. In a web
   * environment, the footprint is e.g. the IP address.
   *
   * @return the footprint of the user who created this BO.
   */
  public final String getCreatedFootprint()
  {
    return _createdFootprint;
  }

  /**
   * Sets the footprint of the user who created this BO. In a web
   * environment, the footprint is e.g. the IP address. This method is only
   * meant to be called by the IPersistanceManager. Any other call is useless
   * as it will be overriden by the IPersistanceManager when a BusinessObject
   * is inserted or actionPerformed.
   *
   * @param createdFootprint the footprint of the user who created this BO.
   */
  public final void setCreatedFootprint(String createdFootprint)
  {
    _createdFootprint = createdFootprint;
  }

  /**
   * Returns the last modification date of the BO.
   *
   * @return the last modification date of the BO.
   */
  public final Date getLastModified()
  {
    return _lastModified;
  }

  /**
   * Sets the last modification date of the BO. This method is only meant to
   * be called by the IPersistanceManager. Any other call is useless as it will
   * be overriden by the IPersistanceManager when a BusinessObject is inserted
   * or actionPerformed.
   *
   * @param lastModified the last modification date of the BO.
   */
  public final void setLastModified(Date lastModified)
  {
    _lastModified = lastModified;
  }

  /**
   * Returns the id of the user who last actionPerformed this BO.
   *
   * @return the id of the user who last actionPerformed this BO.
   */
  public final int getLastModifiedBy()
  {
    return _lastModifiedBy;
  }

  /**
   * Sets the id of the user who last actionPerformed this BO. This method is only
   * meant to be called by the IPersistanceManager. Any other call is useless
   * as it will be overriden by the IPersistanceManager when a BusinessObject is
   * inserted or actionPerformed.
   *
   * @param lastModifiedBy the id of the user who last actionPerformed this BO.
   */
  public final void setLastModifiedBy(int lastModifiedBy)
  {
    _lastModifiedBy = lastModifiedBy;
  }

  /**
   * Returns the footprint of the user who last actionPerformed this BO. In a web
   * environment, the footprint is e.g. the IP address.
   *
   * @return the footprint of the user who last actionPerformed this BO.
   */
  public final String getLastModifiedFootprint()
  {
    return _lastModifiedFootprint;
  }

  /**
   * Sets the footprint of the user who last actionPerformed this BO. In a web
   * environment, the footprint is e.g. the IP address. This method is only meant
   * to be called by the IPersistanceManager. Any other call is useless as it
   * will be overriden by the IPersistanceManager when a BusinessObject is
   * inserted or actionPerformed.
   *
   * @param lastModifiedFootprint the footprint of the user who last
   *        actionPerformed this BO.
   */
  public final void setLastModifiedFootprint(String lastModifiedFootprint)
  {
    _lastModifiedFootprint = lastModifiedFootprint;
  }
}