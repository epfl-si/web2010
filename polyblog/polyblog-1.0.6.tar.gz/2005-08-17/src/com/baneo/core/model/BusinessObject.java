/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.model;

/**
 * Abstract class that all the business objects (BOs) must extend.
 *
 * @author  Laurent Boatto
 * @version $Id$
 */

public abstract class BusinessObject implements Cloneable
{
  private int _id;

  /**
   * Returns the id.
   *
   * @return the id.
   */
  public final int getId()
  {
    return _id;
  }

  /**
   * Sets the id.
   *
   * @param id the id.
   */
  public final void setId(int id)
  {
    _id = id;
  }

  /**
   * Indicates whether some other BO is "equal to" this one.
   * <p>
   * Two BOs are equal if they have the same class and id.
   *
   * @param other the BO with which to compare.
   * @return true if the BOs are equal, false otherwise.
   */
  public boolean equals(Object other)
  {
    if (this == other)
    {
      return true;
    }

    if ((other.getClass() == this.getClass()) && (_id == ((BusinessObject) other).getId()))
    {
      return true;
    }

    return false;
  }

  /**
   * Returns a hash code value for the BusinessObject.
   *
   * @return  a hash code value for this BusinessObject.
   * @see     java.lang.Object#equals(java.lang.Object)
   */
  public int hashCode()
  {
    /**
     * todo is this enough???
     */
    return _id;
  }

  /**
   * Returns a string representation of the BusinessObject.
   * @return  a string representation of the BusinessObject.
   */
  public String toString()
  {
    return "[id = " + _id + ", class = " + this.getClass().getName() + "]";
  }

  /**
   * Creates an returns a copy of this BusinessObject.
   *
   * @return a clone of this BusinessObject, or null if it can not be cloned.
   */
  public Object clone()
  {
    try
    {
      return super.clone();
    }
        // This will never happen anyway.
    catch (CloneNotSupportedException e)
    {
      return null;
    }
  }
}