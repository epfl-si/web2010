/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.model;


/**
 * _Object_. todo add the object description.
 *
 * @author  Laurent Boatto
 * @version $Id$
 */

public final class _Object_ extends BusinessObject
{
  /**
   * todo declare the attributes here as private
   */

  /**
   * Constructs a new _object_.
   */
  public _Object_()
  {
  }

  /**
   * todo generates the getters and setters here
   */
}