/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.view.web.action;

import com.baneo.core.validator.*;
import org.apache.struts.action.*;

import javax.servlet.http.*;
import java.util.*;
import java.io.*;

/**
 * Common action for updating objects.
 * <p>
 * This action do the following :
 * <ul>
 * <li>If the user is just starting his update process, load the object
 *     and forward it to the appropriate "init" view.
 * <li>When the user posts his changes, it verifies the data (with the
 *     validator).
 * <li>If there is no error, it forwards the request to the "success" view,
 *     otherwise to the "error" view.
 * </ul>
 *
 * @author  Laurent Boatto
 * @version $Id$
 * @see     org.apache.struts.action.Action
 */

public abstract class ObjectUpdateAction extends Action
{
  /**
   * The name of the request attribute holding the updated object values
   * (a Map having for the key the value key, and for the value the value
   * itself (e.g. "username" => "admin").
   */
  public static final String ATTRIBUTE_VALUES = "values";

  /**
   * The name of the request attribute holding the updated object.
   */
  public static final String ATTRIBUTE_UPDATED_OBJECT = "updatedObject";

  /**
   * The name of the parameter used to specify the object to update.
   */
  public static final String PARAMETER_UPDATE_ID = "id";

  /**
   * The mode used at initialization, when the user first see the object to
   * update.
   */
  public static final int MODE_INIT = 1;

  /**
   * The mode used when the user is really updating the object.
   */
  public static final int MODE_UPDATE = 2;

  public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    // ClassifiedCheckTestCase the token. The token can be invalid if the form is printed for the
    // first time to the user (in this case it's null) or if the user tries to
    // reload the insert confirmation page. In both cases we print the "init"
    // view.
    if (!isTokenValid(request))
    {
      saveToken(request);
      // Retrieves the values of the BusinessObject the user is updating
      // and forward them to the view.
      Map values = getValues(request, response);

      if (values != null)
      {
        request.setAttribute("values", values);
        // We have no errors, put an empty Map (null is not valid)
        request.setAttribute("errors", new HashMap());
        return mapping.findForward("init");
      }
      else
      {
        return mapping.findForward("generalError");
      }
    }

    // The user is updating
    Validator validator = getValidator(request, response);
    validator.validate();
    Map errors = validator.getErrors();

    if (errors.size() > 0)
    {
      Map values = validator.getValues();

      request.setAttribute("values", values);
      request.setAttribute("errors", errors);

      return mapping.findForward("error");
    }
    else
    {
      // Persist the update
      update(validator.getObject(), validator, request, response);

      resetToken(request);

      return getSuccessActionForward(mapping, request, response);
    }
  }

  protected ActionForward getSuccessActionForward(ActionMapping mapping, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    return mapping.findForward("success");
  }

  /**
   * Returns a Map with the attribute values of the object the user
   * wants to update. The Map key is the attribute name, and the Map value
   * is the attribute value. This method can return null if the object the user
   * wants to update is not found (e.g. a wrong id).
   *
   * @param request the request.
   * @param response the response.
   * @return a Map with the attribute values of the object the user wants to
   *         update.
   * @throws Exception if an error occurs while retrieving the values.
   */
  protected abstract Map getValues(HttpServletRequest request, HttpServletResponse response) throws Exception;

  /**
   * Returns the validator used to validate the object.
   *
   * @param request the request.
   * @param response the response.
   * @return the validator used to validate the object.
   * @throws Exception if an error occurs while getting the validator.
   */
  protected abstract Validator getValidator(HttpServletRequest request, HttpServletResponse response) throws Exception;

  /**
   * Update the object in the system.
   *
   * @param object the object to update.
   * @param validator the validator used for validation.   *
   * @param request the request.
   * @param response the response.
   * @throws Exception if an error occurs while updating the object.
   */
  protected abstract void update(Object object, Validator validator, HttpServletRequest request, HttpServletResponse response) throws Exception;
}