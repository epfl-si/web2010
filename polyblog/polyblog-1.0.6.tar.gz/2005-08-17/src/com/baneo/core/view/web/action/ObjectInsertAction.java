/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.view.web.action;

import com.baneo.core.validator.*;
import org.apache.struts.action.*;

import javax.servlet.http.*;
import java.util.*;

/**
 * Common action for inserting objects.
 *
 * @author  Laurent Boatto
 * @version $Id$
 * @see     org.apache.struts.action.Action
 */

public abstract class ObjectInsertAction extends Action
{
  /**
   * The action mapping used first to present to the user the form used to
   * insert the object.
   */
  public static final String MAPPING_INIT = "init";

  /**
   * The action mapping used when the insertion has failed (because of an
   * error on the form).
   */
  public static final String MAPPING_ERROR = "error";

  /**
   * The action mapping used when the insertion has succeeded (confirmation
   * page).
   */
  public static final String MAPPING_SUCCESS = "success";

  /**
   * The name of the request attribute holding the object to insert values
   * (a Map having for the key the value key, and for the value the value
   * itself (e.g. "username" => "admin").
   */
  public static final String ATTRIBUTE_VALUES = "values";

  /**
   * The name of the request attributes holding the object to insert errors
   * (a Map having for the key the error key, and for the value the error
   * itself (e.g. "username" => "Username already taken").
   */
  public static final String ATTRIBUTE_ERRORS = "errors";

  /**
   * The name of the request attribute holding the inserted object.
   */
  public static final String ATTRIBUTE_INSERTED_OBJECT = "insertedObject";

  public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    // Checks the token. The token can be invalid if the form is printed for the
    // first time to the user (in this case it's null) or if the user tries to
    // reload the insert confirmation page. In both cases we print the "init"
    // view.
    if (!isTokenValid(request))
    {
      saveToken(request);
      onInit(request, response);
      return mapping.findForward(MAPPING_INIT);
    }

    // Validate the values
    Validator validator = getValidator(request, response);
    validator.validate();
    Map values = validator.getValues();
    Map errors = validator.getErrors();

    // If there is errors, prints them back to user.
    if (errors.size() > 0)
    {
      request.setAttribute(ATTRIBUTE_VALUES, values);
      request.setAttribute(ATTRIBUTE_ERRORS, errors);

      return mapping.findForward(MAPPING_ERROR);
    }
    else
    {
      // Insert the object
      Object toInsert = validator.getObject();
      insert(toInsert, validator, request, response);
      request.setAttribute(ATTRIBUTE_INSERTED_OBJECT, toInsert);

      resetToken(request);

      return getSuccessActionForward(mapping, request, response);
    }
  }

  protected ActionForward getSuccessActionForward(ActionMapping mapping, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    return mapping.findForward(MAPPING_SUCCESS);
  }

  /**
   * This method is called just before the Action forwards the user to the
   * "init" forward mapping (e.g. when the form is printed for the first time).
   * The default behavior is to put the "values" and "errors" attribute as new
   * HashMaps, override as needed.
   *
   * @param request the request.
   * @param response the response.
   * @throws Exception if an error occurs on initialization.
   */
  protected void onInit(HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    // we create the values map only if it has not been set previously by an
    // other action
    if (request.getAttribute(ATTRIBUTE_VALUES) == null)
    {
      request.setAttribute(ATTRIBUTE_VALUES, new HashMap());
    }

    // idem for the errors
    if (request.getAttribute(ATTRIBUTE_ERRORS) == null)
    {
      request.setAttribute(ATTRIBUTE_ERRORS, new HashMap());
    }
  }

  /**
   * Returns the validator used to validate the object.
   *
   * @param request the request.
   * @param response the response.
   * @return the validator used to validate the object.
   * @throws Exception if an exception occurs while getting the validator.
   */
  protected abstract Validator getValidator(HttpServletRequest request, HttpServletResponse response) throws Exception;

  /**
   * Insert the object in the system.
   *
   * @param object the object to insert.
   * @param validator the validator used for validation.
   * @param request the request.
   * @param response the response.
   * @throws Exception if a problem occurs while persisting the object.
   */
  protected abstract void insert(Object object, Validator validator, HttpServletRequest request, HttpServletResponse response) throws Exception;
}