/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.view.web.action;

import com.baneo.core.util.*;
import org.apache.struts.action.*;

import javax.servlet.http.*;
import java.util.*;

/**
 * Common action for finding objects.
 *
 * @author Laurent Boatto
 * @version $Id$
 * @see     org.apache.struts.action.Action
 */

public abstract class ObjectFindAction extends Action
{
  /**
   * The parameter used to specify the find attribute name.
   */
  public static final String PARAMETER_FIND_ATTRIBUTE_NAME = "findAttributeName";

  /**
   * The parameter used to specify the find attribute value.
   */
  public static final String PARAMETER_FIND_ATTRIBUTE_VALUE = "findAttributeValue";

  /**
   * The parameter used to specify the order.
   */
  public static final String PARAMETER_ORDER = "order";

  /**
   * The parameter used to specify the page.
   */
  public static final String PARAMETER_PAGE = "page";

  /**
   * Number of results to show per page by default.
   */
  public static final int RESULTS_PER_PAGE_DEFAULT = 20;


  public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    // Retrieve the search criterias
    String findAttributeName = request.getParameter(PARAMETER_FIND_ATTRIBUTE_NAME);
    String findAttributeValue = request.getParameter(PARAMETER_FIND_ATTRIBUTE_VALUE);
    String orderBy = request.getParameter(PARAMETER_ORDER);

    // The user has done an empty search, we show him the search page again
    if (findAttributeName == null || findAttributeName.trim().equals("") ||
        findAttributeValue == null || findAttributeValue.trim().equals(""))
    {
      return mapping.findForward("init");
    }

    int startIndex = (NumberUtil.parseInt(request.getParameter(PARAMETER_PAGE), 1) - 1) * getResultsPerPage();

    // Find the objects given the search criterias
    Collection results = find(findAttributeName, findAttributeValue, orderBy, startIndex, getResultsPerPage());

    /**
     * todo IMPORTANTs! count should NOT be the results size here, but rather
     * a separate query to find the real count, because results can be only a
     * subset of the total results.
     */
    int count = results.size();

    if (count == 0)
    {
      return mapping.findForward("noResults");
    }

    request.setAttribute("results", results);
    // Note : the count is necessary here, we cannot just use results.size()
    // because the results collection could be only a subset of the full results
    // (e.g. if we have more than one page of results).
    request.setAttribute("count", new Integer(results.size()));

    return mapping.findForward("results");
  }

  /**
   * Find the objects given the find attribute name and value. If there is no
   * object corresponding to the search, this method returns an empty
   * collection, but never null.
   *
   * @param findAttributeName the find attribute name.
   * @param findAttributeValue the find attribute value.
   * @param orderBy the attribute used to order the results.
   * @param startIndex the result's index to start from, by default 0
   *        (the beginning).
   * @param limit the maximum number of results to return.
   * @return a Collection filled with the objects corresponding to the search
   *         criterias.
   * @throws Exception if a problem occurs with the persistance layer.
   */
  protected abstract Collection find(String findAttributeName, String findAttributeValue, String orderBy, int startIndex, int limit) throws Exception;

  /**
   * Returns the number of results per page to show. Override this method
   * if you want to show more than the default (20).
   *
   * @return the number of results per page to show.
   */
  protected int getResultsPerPage()
  {
    return RESULTS_PER_PAGE_DEFAULT;
  }
}