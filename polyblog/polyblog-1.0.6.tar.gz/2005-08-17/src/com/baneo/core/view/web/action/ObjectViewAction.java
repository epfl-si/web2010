/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.view.web.action;

import org.apache.struts.action.*;

import javax.servlet.http.*;

/**
 * Common action for viewing objects.
 *
 * @author Laurent Boatto
 * @version $Id$
 * @see org.apache.struts.action.Action
 */

public class ObjectViewAction extends Action
{
  /**
   * The action mapping used to show the viewed object.
   */
  public static final String MAPPING_VIEW = "view";

  /**
   * The action mapping used when the viewed object cannot be found.
   */
  public static final String MAPPING_EMPTY = "empty";

  /**
   * The name of the parameter used to specify the object to view.
   */
  public static final String PARAMETER_VIEW_ID = "id";

  /**
   * The name of the request attribute holding the updated object.
   */
  public static final String ATTRIBUTE_VIEWED_OBJECT = "viewedObject";

  public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    // The viewed object may have already been set by a previous action
    if (request.getAttribute(ATTRIBUTE_VIEWED_OBJECT) != null)
    {
      return mapping.findForward(MAPPING_VIEW);
    }

    Object viewedObject = find(request, response);

    if (viewedObject == null)
    {
      return mapping.findForward(MAPPING_EMPTY);
    }

    request.setAttribute(ATTRIBUTE_VIEWED_OBJECT, viewedObject);

    return mapping.findForward(MAPPING_VIEW);
  }

  /**
   * Finds the object to view, given the request and response. Returns null
   * be default, overrides as needed in your class.
   *
   * @param request the request.
   * @param response the response.
   * @return the object we want to view.
   * @throws Exception if a problem occurs while retrieving the object.
   */
  protected Object find(HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    // Implementation note : the find method and the ObjectViewAction class are
    // abstract because otherwise they could not be directly used as is
    // (because they could not be instanciated).
    return null;
  }
}