/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.view.web.action;

import org.apache.struts.action.*;

import javax.servlet.http.*;
import java.util.*;
import java.io.*;

/**
 * Common action for deleting objects.
 * <p>
 * This action do the following :
 * <ul>
 * <li>If the user hasn't selected any objects to delete, redirect him to
 *     the "back" struts forward
 * <li>If the user has selected one or more objects to delete, ask him to
 *     confirm his choice by presenting the list of the objects that will be
 *     deleted
 * <li>If the user confirm, delete the objects and forward the user to the
 *     "success" struts action forward
 * <li>If the user doesn't confirm, redirect him to the "back" struts
 *     action forward.
 * </ul>
 * This action also verify that the user is not reloading the page and such
 * trying to delete two times the same objects.
 *
 * @author  Laurent Boatto
 * @version $Id$
 * @see     org.apache.struts.action.Action
 */

public abstract class ObjectDeleteAction extends Action
{
  /**
   * The action mapping used first to present to the user the list of objects
   * to delete.
   */
  public static final String MAPPING_INIT = "init";

  /**
   * The action mapping used to redirect the user back to the previous page,
   * e.g. if he does not confirm the deletion.
   */
  public static final String MAPPING_BACK = "back";

  /**
   * The action mapping used when the deletion has succeeded.
   */
  public static final String MAPPING_SUCCESS = "success";

  /**
   * The name of the request attribute holding the objects to delete.
   */
  public static final String ATTRIBUTE_RESULTS = "results";

  /**
   * The name of the request attribute holding the number of objects to delete or deleted.
   */
  public static final String ATTRIBUTE_COUNT = "count";

  /**
   * The parameter used to specify the object to delete.
   */
  public static final String PARAMETER_DELETE_ID = "ids";

  /**
   * The parameter used to confirm the deletion.
   */
  public static final String PARAMETER_DELETION_CONFIRMATION = "deletionConfirmation";

  /**
   * The parameter used to cancel the deletion.
   */
  public static final String PARAMETER_DELETION_CANCELLATION = "deletionCancellation";

  public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    String[] ids = request.getParameterValues(PARAMETER_DELETE_ID);

    // The user should select at least one object to delete
    if (ids == null || ids.length == 0)
    {
      return mapping.findForward(MAPPING_BACK);
    }

    // The user has confirmed the deletion, we delete the objects
    if (request.getParameter(PARAMETER_DELETION_CONFIRMATION) != null)
    {
      // Check the token
      if (!isTokenValid(request))
      {
        return mapping.findForward(MAPPING_BACK);
      }

      // We delete all the selected objects
      for (int i = 0; i < ids.length; i++)
      {
        delete(ids[i], request, response);
      }

      resetToken(request);
      request.setAttribute(ATTRIBUTE_COUNT, new Integer(ids.length));
      return getSuccessActionForward(mapping, request, response);
    }
    // The user has canceled the deletion, forward him to cancel page
    else if (request.getParameter(PARAMETER_DELETION_CANCELLATION) != null)
    {
      return mapping.findForward(MAPPING_BACK);
    }

    // Makes sure the form won't be posted several times
    saveToken(request);

    // Load the objects the user want to delete, for the confirmation page
    Collection results = new ArrayList();

    for (int i = 0; i < ids.length; i++)
    {
      results.add(find(ids[i], request, response));
    }

    request.setAttribute(ATTRIBUTE_COUNT, new Integer(results.size()));
    request.setAttribute(ATTRIBUTE_RESULTS, results);
    return mapping.findForward(MAPPING_INIT);
  }

  protected ActionForward getSuccessActionForward(ActionMapping mapping, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    return mapping.findForward(MAPPING_SUCCESS);
  }

  /**
   * Deletes the object having the given "id". Note that "id" here is just
   * an unique identifier for the deletion, so it can be a code or something
   * else.
   *
   * @param id the object's "id".
   * @param request the request.
   * @param response the response.
   * @throws Exception if a problem occurs while deleting the object.
   */
  protected abstract void delete(String id, HttpServletRequest request, HttpServletResponse response) throws Exception;

  /**
   * Finds the object having the given "id". Note that "id" here is just
   * an unique identifier for the deletion, so it can be a code or something
   * else.
   *
   * @param id the object's "id".
   * @param request the request.
   * @param response the response.
   * @return the object having the given "id".
   * @throws Exception if a problem occurs while retrieving the object.
   */
  protected abstract Object find(String id, HttpServletRequest request, HttpServletResponse response) throws Exception;
}