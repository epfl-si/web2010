/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.view.web.action;

import com.baneo.core.util.*;
import org.apache.struts.action.*;

import javax.servlet.http.*;
import java.util.*;

/**
 * Common action for listing objects.
 *
 * @author  Laurent Boatto
 * @version $Id$
 * @see     org.apache.struts.action.Action
 */

public abstract class ObjectListAction extends Action
{
  /**
   * The action mapping used when there is no objects to list.
   */
  public static final String MAPPING_EMPTY = "empty";

  /**
   * The optional action mapping used when there is only one object to list. If
   * it's not defined, the MAPPING_LIST mapping is used.
   */
  public static final String MAPPING_SINGLE = "single";

  /**
   * The action mapping used to list the results.
   */
  public static final String MAPPING_LIST = "list";

  /**
   * The name of the request attribute holding the objects to list.
   */
  public static final String ATTRIBUTE_RESULTS = "results";

  /**
   * The name of the request attribute holding the number of objects to list.
   */
  public static final String ATTRIBUTE_COUNT = "count";

  /**
   * The name of the request attribute holding the listed object, this attribute
   * is only available if there is only one object to list, and that the
   * MAPPING_SINGLE mapping is defined in the action.
   */
  public static final String ATTRIBUTE_LISTED_OBJECT = "listedObject";

  /**
   * The parameter used to specify the order.
   */
  public static final String PARAMETER_ORDER = "order";

  /**
   * The parameter used to specify the page.
   */
  public static final String PARAMETER_PAGE = "page";

  /**
   * Number of results to show per page by default.
   */
  public static final int RESULTS_PER_PAGE_DEFAULT = 20;

  public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    String order = request.getParameter(PARAMETER_ORDER);

    if (order == null)
    {
      order = getDefaultOrder();
    }
    else
    {
      order = HttpUtil.decode(order);
    }

    int count = count(request, response);

    // nothing to list
    if (count == 0)
    {
      return mapping.findForward(MAPPING_EMPTY);
    }

    int startIndex = (NumberUtil.parseInt(request.getParameter(PARAMETER_PAGE), 1) - 1) * getResultsPerPage();
    Collection results = find(request, response, order, startIndex, getResultsPerPage());

    // just one element to list, if the optional single mapping is defined
    // we use it
    if (count == 1 && mapping.findForward(MAPPING_SINGLE) != null)
    {
      request.setAttribute(ATTRIBUTE_LISTED_OBJECT, results.iterator().next());
      return mapping.findForward(MAPPING_SINGLE);
    }

    request.setAttribute(ATTRIBUTE_RESULTS, results);

    // Note : the count is necessary here, we cannot just use results.size()
    // because the results collection could be only a subset of the full results
    // (e.g. if we have more than one page of results).
    request.setAttribute(ATTRIBUTE_COUNT, new Integer(count));

    return mapping.findForward(MAPPING_LIST);
  }

  /**
   * Returns the default order attribute name to use if none is specified.
   *
   * @return the default order attribute name to use if none is specified.
   */
  protected abstract String getDefaultOrder();

  /**
   * Returns the objects to list, given the startIndex and limit arguments,
   * ordered by the given orderBy.
   *
   * @param request the request.
   * @param response the response.
   * @param orderBy the attribute used to order the results.
   * @param startIndex the start index.
   * @param maxResults the maximum number of results to return.
   * @return all the objects, given the startIndex and limit arguments, ordered
   *         by the given orderBy.
   * @throws Exception on persistance layer error.
   */
  protected abstract Collection find(HttpServletRequest request, HttpServletResponse response, String orderBy, int startIndex, int maxResults) throws Exception;

  /**
   * Returns the total number of objects that will be listed.
   *
   * @param request the request.
   * @param response the response.
   * @return the total number of objects that will be listed.
   * @throws Exception on persistance layer error.
   */
  protected abstract int count(HttpServletRequest request, HttpServletResponse response) throws Exception;

  /**
   * Returns the number of results per page to show. Override this method
   * if you want to show more than the default (20).
   *
   * @return the number of results per page to show.
   */
  protected int getResultsPerPage()
  {
    return RESULTS_PER_PAGE_DEFAULT;
  }
}