/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.service;

import com.baneo.core.persistance.*;

import java.util.*;

/**
 * IBusinessObjectManagerListener.
 *
 * @author Laurent Boatto
 * @version $Id$
 */

public interface IBusinessObjectManager
{
  /**
   * Returns all the BusinessObjects of the manager. Use with care, as this
   * could return a large Collection. If you need only a subset of it, use
   * <code>find(String, int, int)</code>.
   *
   * @return a Collection containing all the BusinessObjects of the manager.
   * @throws PersistanceException on persistance layer error.
   * @see #findAll(java.lang.String, int, int)
   */
  Collection findAll() throws PersistanceException;

  /**
   * Returns all the BusinessObjects of the manager, given the startIndex
   * and limit arguments, ordered by the given orderBy.
   *
   * @param orderBy the attribute by which you want to order the results.
   * @param startIndex the start index.
   * @param limit the maximum number of results to return.
   * @return a Collection containing all the BusinessObjects of the manager.
   * @throws PersistanceException on persistance layer error.
   */
  Collection findAll(String orderBy, int startIndex, int limit) throws PersistanceException;

  /**
   * Returns the total number of BusinessOjects of the manager.
   *
   * @return the total number of BusinessOjects of the manager.
   */
  int count() throws PersistanceException;
}
