/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.service;

import com.baneo.core.persistance.*;

/**
 * Base IBusinessObjectManagerListener with empty implementations.
 *
 * @author Laurent Boatto
 * @see IBusinessObjectManagerListener
 */
public abstract class BaseBusinessObjectManagerListener implements IBusinessObjectManagerListener
{
  public void preInsert(BusinessObjectManagerEvent event) throws PersistanceException
  {
  }

  public void postInsert(BusinessObjectManagerEvent event) throws PersistanceException
  {
  }

  public void preUpdate(BusinessObjectManagerEvent event) throws PersistanceException
  {
  }

  public void postUpdate(BusinessObjectManagerEvent event) throws PersistanceException
  {
  }

  public void preDelete(BusinessObjectManagerEvent event) throws PersistanceException
  {
  }

  public void postDelete(BusinessObjectManagerEvent event) throws PersistanceException
  {
  }
}