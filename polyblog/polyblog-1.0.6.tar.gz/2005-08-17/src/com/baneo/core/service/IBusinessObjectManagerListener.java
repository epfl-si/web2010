/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.service;

import com.baneo.core.persistance.*;

/**
 * Specifies the methods that a listener interested in
 * BusinessObjectManager events must implement.
 *
 * @author Laurent Boatto
 */
public interface IBusinessObjectManagerListener
{
  /**
   * Called when an object is about to be inserted.
   *
   * @param event the event.
   * @throws PersistanceException on persistance layer error.
   */
  public void preInsert(BusinessObjectManagerEvent event) throws PersistanceException;

  /**
   * Called when an object has been inserted.
   *
   * @param event the event.
   * @throws PersistanceException on persistance layer error.
   */
  public void postInsert(BusinessObjectManagerEvent event) throws PersistanceException;

  /**
   * Called when an object is about to be updated.
   *
   * @param event the event.
   * @throws PersistanceException on persistance layer error.
   */
  public void preUpdate(BusinessObjectManagerEvent event) throws PersistanceException;

  /**
   * Called when an object has been updated.
   *
   * @param event the event.
   * @throws PersistanceException on persistance layer error.
   */
  public void postUpdate(BusinessObjectManagerEvent event) throws PersistanceException;

  /**
   * Called when an object is about to be deleted.
   *
   * @param event the event.
   * @throws PersistanceException on persistance layer error.
   */
  public void preDelete(BusinessObjectManagerEvent event) throws PersistanceException;

  /**
   * Called when an object has been deleted.
   *
   * @param event the event.
   * @throws PersistanceException on persistance layer error.
   */
  public void postDelete(BusinessObjectManagerEvent event) throws PersistanceException;
}