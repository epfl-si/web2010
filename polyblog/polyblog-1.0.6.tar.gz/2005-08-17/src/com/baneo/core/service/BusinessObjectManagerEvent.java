/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.service;

import java.util.*;

/**
 * This class represents an event fired by a BusinessObjectManager.
 *
 * @author Laurent Boatto
 */
public class BusinessObjectManagerEvent extends EventObject
{
  /**
   * Constructs an instance of BusinessObjectManagerEvent with the given source.
   *
   * @param source the source of the event.
   */
  public BusinessObjectManagerEvent(Object source)
  {
    super(source);
  }
}