/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.service;

import com.baneo.core.meta.*;
import com.baneo.core.model.*;
import com.baneo.core.persistance.*;
import com.baneo.core.security.*;

import java.util.*;

/**
 * Base class for all the BusinessObjectManagers.
 *
 * @author Laurent Boatto
 * @version $Id$
 */

public abstract class BusinessObjectManager implements IBusinessObjectManager
{
  /**
   * The BusinessObjectManager listeners.
   */
  private List _listeners = new ArrayList();

  /**
   * Returns the IPersistanceManager used by the manager to persist the
   * BusinessObjects.
   *
   * @return the IPersistanceManager used by the manager to persist the
   *         business objects.
   */
  protected abstract IPersistanceManager getIPersistanceManager();

  /**
   * Returns the class that this BusinessObjectManager is managing.
   *
   * @return the class that this BusinessObjectManager is managing.
   */
  protected abstract Class getManagedClass();

  /**
   * Utility class that returns the managed object attributes names, using the
   * application IMetaManager.
   *
   * @return the managed class attributes names.
   * @throws MetaManagerException on meta error.
   */
  public String[] getManagedObjectAttributesNames() throws MetaManagerException
  {
    return MetaManagerFactory.getIMetaManager().getAttributesNames(getManagedClass());
  }

  /**
   * Utility class that returns the managed object attributes classes, using the
   * application IMetaManager.
   *
   * @return the managed class attributes classes.
   * @throws MetaManagerException on meta error.
   */
  public Class[] getManagedObjectAttributesClasses() throws MetaManagerException
  {
    return MetaManagerFactory.getIMetaManager().getAttributesClasses(getManagedClass());
  }

  /**
   * Returns all the BusinessObjects of the manager. Use with care, as this
   * could return a large Collection. If you need only a subset of it, use
   * <code>find(String, int, int)</code>.
   *
   * @return a Collection containing all the BusinessObjects of the manager.
   * @throws PersistanceException on persistance layer error.
   * @see #findAll(java.lang.String, int, int)
   */
  public Collection findAll() throws PersistanceException
  {
    return getIPersistanceManager().findAll(getManagedClass());
  }

  /**
   * Adds the given IBusinessObjectManagerListener to the manager.
   *
   * @param listener the IBusinessObjectManagerListener to add.
   */
  public void addIBusinessObjectManagerListener(IBusinessObjectManagerListener listener)
  {
    // you can add a listener of a given class only once
    for (int i = 0; i < _listeners.size(); i++)
    {
      if (listener.getClass().equals(_listeners.get(i).getClass()))
      {
        return;
      }
    }

    _listeners.add(listener);
  }

  /**
   * Removes the given IBusinessObjectManagerListener from the manager.
   *
   * @param listener the IBusinessObjectManagerListener to remove.
   */
  public void removeIBusinessObjectManagerListener(IBusinessObjectManagerListener listener)
  {
    _listeners.remove(listener);
  }

  /**
   * Returns the IBusinessObjectManagerListeners registered in this manager.
   *
   * @return the IBusinessObjectManagerListeners registered in this manager.
   */
  public List getIBusinessObjectManagerListeners()
  {
    return _listeners;
  }

  /**
   * Launches the event telling that the given object is about to be inserted.
   *
   * @param object the object that is about to be inserted.
   * @throws PersistanceException on persistance layer error.
   */
  protected void launchPreInsertEvent(Object object) throws PersistanceException
  {
    BusinessObjectManagerEvent event = new BusinessObjectManagerEvent(object);

    for (int i = 0; i < _listeners.size(); i++)
    {
      ((IBusinessObjectManagerListener) _listeners.get(i)).preInsert(event);
    }
  }

  /**
   * Launches the event telling that the given object has been inserted.
   *
   * @param object the inserted object.
   * @throws PersistanceException on persistance layer error.
   */
  protected void launchPostInsertEvent(Object object) throws PersistanceException
  {
    BusinessObjectManagerEvent event = new BusinessObjectManagerEvent(object);

    for (int i = 0; i < _listeners.size(); i++)
    {
      ((IBusinessObjectManagerListener) _listeners.get(i)).postInsert(event);
    }
  }

  /**
   * Launches the event telling that the given object is about to be updated.
   *
   * @param object the object that is about to be updated.
   * @throws PersistanceException on persistance layer error.
   */
  protected void launchPreUpdateEvent(Object object) throws PersistanceException
  {
    BusinessObjectManagerEvent event = new BusinessObjectManagerEvent(object);

    for (int i = 0; i < _listeners.size(); i++)
    {
      ((IBusinessObjectManagerListener) _listeners.get(i)).preUpdate(event);
    }
  }

  /**
   * Launches the event telling that the given object has been updated.
   *
   * @param object the updated object.
   * @throws PersistanceException on persistance layer error.
   */
  protected void launchPostUpdateEvent(Object object) throws PersistanceException
  {
    BusinessObjectManagerEvent event = new BusinessObjectManagerEvent(object);

    for (int i = 0; i < _listeners.size(); i++)
    {
      ((IBusinessObjectManagerListener) _listeners.get(i)).postUpdate(event);
    }
  }

  /**
   * Launches the event telling that the given object is about to be deleted.
   *
   * @param object the object that is about to be deleted.
   * @throws PersistanceException on persistance layer error.
   */
  protected void launchPreDeleteEvent(Object object) throws PersistanceException
  {
    BusinessObjectManagerEvent event = new BusinessObjectManagerEvent(object);

    for (int i = 0; i < _listeners.size(); i++)
    {
      ((IBusinessObjectManagerListener) _listeners.get(i)).preDelete(event);
    }
  }

  /**
   * Launches the event telling that the given object has been deleted.
   *
   * @param object the deleted object.
   * @throws PersistanceException on persistance layer error.
   */
  protected void launchPostDeleteEvent(Object object) throws PersistanceException
  {
    BusinessObjectManagerEvent event = new BusinessObjectManagerEvent(object);

    for (int i = 0; i < _listeners.size(); i++)
    {
      ((IBusinessObjectManagerListener) _listeners.get(i)).postDelete(event);
    }
  }

  /**
   * Returns all the BusinessObjects of the manager, given the startIndex
   * and limit arguments, ordered by the given orderBy.
   *
   * @param orderBy the attribute by which you want to order the results.
   * @param startIndex the start index.
   * @param limit the maximum number of results to return.
   * @return a Collection containing all the BusinessObjects of the manager.
   * @throws PersistanceException on persistance layer error.
   */
  public Collection findAll(String orderBy, int startIndex, int limit) throws PersistanceException
  {
    return getIPersistanceManager().findAll(getManagedClass(), orderBy, startIndex, limit);
  }

  /**
   * Returns the total number of BusinessOjects of the manager.
   *
   * @return the total number of BusinessOjects of the manager.
   * @throws PersistanceException on persistance layer error.
   */
  public int count() throws PersistanceException
  {
    return getIPersistanceManager().count(getManagedClass());
  }

  /**
   * Set the common attributes of all TaggedBusinessObjects (created, createdBy,
   * createdFootprint, lastModified, etc.) given the current SecurityContext
   * for an insert.
   * This method must be called from the managers everytime a
   * TaggedBusinessObject is inserted.
   *
   * @param bo the TaggedBusinessObject.
   */
  protected void setCommonAttributesForInsert(TaggedBusinessObject bo)
  {
    ISecurityContext context = SecurityContextManager.getISecurityContext();
    Date currentDate = new java.util.Date();
    String footprint = context.getFootprint();
    bo.setCreated(currentDate);
    bo.setCreatedBy(context.getUserId());
    bo.setCreatedFootprint(footprint);
    // We start at version 1
    bo.setVersion(1);
    bo.setLastModified(currentDate);
    bo.setLastModifiedFootprint(footprint);
    bo.setLastModifiedBy(context.getUserId());
  }

  /**
   * Set the common attributes of all TaggedBusinessObjects (created, createdBy,
   * createdFootprint, lastModified, etc.) given the current SecurityContext
   * for an update.
   * This method must be called from the managers everytime a
   * TaggedBusinessObject is updated.
   *
   * @param bo the TaggedBusinessObject.
   */
  protected void setCommonAttributesForUpdate(TaggedBusinessObject bo)
  {
    ISecurityContext context = SecurityContextManager.getISecurityContext();
    String footprint = context.getFootprint();
    // Increment the version
    /** todo this is weak as the version can be set by the application */
    bo.setVersion(bo.getVersion() + 1);
    bo.setLastModified(new java.util.Date());
    bo.setLastModifiedFootprint(footprint);
    bo.setLastModifiedBy(context.getUserId());
  }
}