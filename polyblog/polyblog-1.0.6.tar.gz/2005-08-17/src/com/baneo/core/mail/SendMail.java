/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.mail;

import org.apache.commons.logging.*;

import javax.mail.*;
import javax.mail.internet.*;
import java.io.*;
import java.util.*;

/**
 * Utilities for sending emails.
 *
 * @author Laurent Boatto
 * @version $Id$
 */

public class SendMail
{
  private static final Properties _properties = System.getProperties();
  private static final Session _session = Session.getDefaultInstance(_properties);

  /**
   * The log.
   */
  private static final Log _log = LogFactory.getLog(SendMail.class);

  static
  {
    // we use localhost by default
    _properties.put("mail.smtp.host", "localhost");
  }

  /**
   * Sets the smtp host. Beware that this will affect all applications using
   * this class!
   *
   * @param smtpHost the smpt host, e.g. "smpt.myhost.com".
   */
  public static void setSmtpHost(String smtpHost)
  {
    _properties.put("mail.smtp.host", smtpHost);
  }

  /**
   * Sends a text email with the given informations, using the application
   * email session.
   *
   * @param from the sender email.
   * @param to the recepient email.
   * @param subject the email subject.
   * @param text the email text.
   * @throws MessagingException if the email can not be sent.
   */
  public static void sendTextMail(String from, String to, String subject, String text) throws MessagingException
  {
    sendTextEmail(new InternetAddress(from),
        new InternetAddress(to),
        subject,
        text);
  }

  /**
   * Sends a text email with the given informations, using the application
   * email session.
   *
   * @param fromEmail the sender email.
   * @param fromEmail the sender name.
   * @param toEmail the recipient email.
   * @param toEmail the recipient name.
   * @param subject the email subject.
   * @param text the email text.
   * @throws MessagingException if the email can not be sent.
   */
  public static void sendTextMail(String fromEmail, String fromName, String toEmail, String toName, String subject, String text) throws MessagingException
  {
    try
    {
      sendTextEmail(new InternetAddress(fromEmail, fromName),
          new InternetAddress(toEmail, toName),
          subject,
          text);

    }
    catch (UnsupportedEncodingException e)
    {
      _log.error(e.getMessage(), e);
      throw new MessagingException(e.getMessage(), e);
    }
  }

  /**
   * Sends a text email with the given informations, using the application
   * email session.
   *
   * @param from the sender InternetAddress.
   * @param to the recepient InternetAddress.
   * @param subject the email subject.
   * @param text the email text.
   * @throws MessagingException if the email can not be sent.
   */
  public static void sendTextEmail(InternetAddress from, InternetAddress to, String subject, String text) throws MessagingException
  {
    MimeMessage message = new MimeMessage(_session);

    message.setFrom(from);
    message.addRecipient(Message.RecipientType.TO, to);
    message.setSubject(subject);
    message.setText(text);

    Transport.send(message);
  }

  /**
   * Returns a text email with the given informations, using the application
   * email session.
   *
   * @param fromEmail the sender email.
   * @param fromEmail the sender name.
   * @param toEmail the recipient email.
   * @param toEmail the recipient name.
   * @param subject the email subject.
   * @param text the email text.
   * @throws MessagingException if the email can not be sent.
   */
  public static MimeMessage getTextMimeMessage(String fromEmail, String fromName, String toEmail, String toName, String subject, String text) throws MessagingException
  {
    try
    {
      MimeMessage message = new MimeMessage(_session);

      message.setFrom(new InternetAddress(fromEmail, fromName));
      message.addRecipient(Message.RecipientType.TO, new InternetAddress(toEmail, toName));
      message.setSubject(subject);
      message.setText(text);

      return message;
    }
    catch (UnsupportedEncodingException e)
    {
      _log.error(e.getMessage(), e);
      throw new MessagingException(e.getMessage(), e);
    }
  }

  /**
   * Sends the given message using the application email session.
   *
   * @param message the message to send.
   * @throws MessagingException if the message cannot be send.
   */
  public static void send(Message message) throws MessagingException
  {
    Transport.send(message);
  }
}
