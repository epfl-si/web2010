/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.jsp.taglib;

import javax.servlet.jsp.*;

/**
 * A navigation bar item.
 *
 * @author  Laurent Boatto
 * @version $Id$
 */

public class NavBarItemTag extends AbstractTag
{
  private String _item;
  private String _link;

  /**
   * Method doStartTag
   *
   * @return
   *
   * @throws JspException
   */
  public int doStartTag() throws JspException
  {
    NavBarTag parent = (NavBarTag) getParent();

    if (_link != null)
    {
      parent.addItem(_item, _link);
    }
    else
    {
      parent.addItem(_item);
    }

    return SKIP_BODY;
  }

  /**
   * Method setItem
   *
   *
   * @param item
   */
  public void setItem(String item)
  {
    _item = item;
  }

  /**
   * Method setLink
   *
   *
   * @param link
   */
  public void setLink(String link)
  {
    _link = link;
  }

  /**
   * Method getItem
   *
   * @return
   */
  public String getItem()
  {
    return _item;
  }

  /**
   * Method getLink
   *
   * @return
   */
  public String getLink()
  {
    return _link;
  }
}