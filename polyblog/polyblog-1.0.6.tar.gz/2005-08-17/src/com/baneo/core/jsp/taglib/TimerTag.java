/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.jsp.taglib;

import javax.servlet.jsp.*;
import java.io.*;

/**
 * Simple timer taglib. Starts the timer when the taglib is open, and prints the
 * elapsed time in milliseconds when the taglib is closed.
 *
 * @author Laurent Boatto
 * @version $Id$
 */
public class TimerTag extends AbstractBodyTag
{
  private long _start;
  private long _stop;
  private double _elapsed;

  public int doStartTag() throws JspException
  {
    _start = System.currentTimeMillis();

    return EVAL_BODY_BUFFERED;
  }

  public int doEndTag(JspWriter out) throws JspException, IOException
  {
    _stop = System.currentTimeMillis();

    _elapsed = (_stop - _start) / 1000d;
    /** todo i18n.. */

    if ((_stop - _start) == 0)
    {
      out.print("<font color=gray size=1> Page g�n�r�e en moins d'une milliseconde.");
    }
    else
    {
      out.print("<font color=gray size=1> Page g�n�r�e en " + _elapsed + " secondes.");
    }

    return EVAL_PAGE;
  }
}