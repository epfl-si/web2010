/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.jsp.taglib;

import com.baneo.core.util.*;

import javax.servlet.jsp.*;
import java.io.*;

/**
 * TabsTag and it's child TabTag let's you easily creates server side tabs.
 * <p>
 * Usage example :
 * <p>
 * <pre>
 * &lt;p:tabs&gt;
 * &lt;p:tab label="Main"&gt;
 * ... Main content here, can be included ...
 * &lt;/p:tab&gt;
 * &lt;p:tab label="Options"&gt;
 * ... Options content here, can be included ...
 * &lt;/p:tab&gt;
 * &lt;/p:tabs&gt;
 * </pre>
 *
 * @author  Laurent Boatto
 * @version $Id$
 * @see     TabTag
 */

public class TabsTag extends AbstractBodyTag
{
  /**
   * the name of the parameter used in the url to select the tab.
   */
  public static final String SELECTED_TAB_PARAMETER = "selectedTab";

  private String _content;
  private String _selectedTab;
  private int _registeredTabs;
  private String _defaultTab;
  private String _width = "100%";

  public int doStartTag(JspWriter out) throws JspException, IOException
  {
    // First we search the selectedTag as a paramameter
    _selectedTab
        = HttpUtil.getParameter(pageContext.getRequest(), SELECTED_TAB_PARAMETER, null);


    // then as an attribute
    if (_selectedTab == null)
    {
      _selectedTab = (String) pageContext.findAttribute(SELECTED_TAB_PARAMETER);
    }

    if (_selectedTab == null)
    {
      _selectedTab = _defaultTab;
    }

    out.print("<table cellpadding=5 cellspacing=0 border=0 width=" + _width + ">");
    out.print("<tr>");

    // After the "header" with evaluate the different <p:tab> tags
    return EVAL_BODY_BUFFERED;
  }

  public int doEndTag(JspWriter out) throws JspException, IOException
  {
    out.print("<td width=100% class=tabTop>&nbsp;</td></tr>");
    out.print("<tr><td colspan=" + (_registeredTabs + 1) + " class=tabBody><br>");

    // The content, set by the selected TabTag
    out.print(_content);

    out.print("<br>&nbsp;</td></tr></table>");

    return EVAL_PAGE;
  }

  /**
   * Returns the selected tab index.
   *
   * @return the selected tab index.
   */
  protected String getSelectedTab()
  {
    return _selectedTab;
  }

  /**
   * Let a TabTag register itself to his parent (TabsTag).
   *
   * @param tabTag the tabTag to register.
   */
  protected void register(TabTag tabTag)
  {
    _registeredTabs++;
  }

  /**
   * Sets the content, i.e. the text of the selected tab.
   *
   * @param content the content of the selected tab.
   */
  protected void setContent(String content)
  {
    _content = content;
  }

  public void release()
  {
    _content = null;
    _selectedTab = null;
    _registeredTabs = 0;
    _defaultTab = null;
    _width = "100%";
  }

  public String getWidth()
  {
    return _width;
  }

  public void setWidth(String width)
  {
    _width = width;
  }

  public String getDefaultTab()
  {
    return _defaultTab;
  }

  public void setDefaultTab(String defaultTab)
  {
    _defaultTab = defaultTab;
  }
}