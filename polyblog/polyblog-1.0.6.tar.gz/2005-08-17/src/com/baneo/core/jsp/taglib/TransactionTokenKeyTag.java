/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.jsp.taglib;

import org.apache.struts.action.*;
import org.apache.struts.taglib.html.*;

import javax.servlet.jsp.*;
import java.io.*;

/**
 * This tag prints an hidden input form parameter containing a transaction key.
 * For more informations, see how Struts use transactions keys.
 *
 * @author Laurent Boatto
 * @version $Id$
 * @see org.apache.struts.action.Action
 */

public class TransactionTokenKeyTag extends AbstractTag
{
  public int doStartTag(JspWriter out) throws IOException
  {
    out.print("<input type=\"hidden\" name=\"" + Constants.TOKEN_KEY + "\" " +
        "value=\"" + pageContext.getSession().getAttribute(Action.TRANSACTION_TOKEN_KEY) +
        "\">");

    return SKIP_BODY;
  }
}