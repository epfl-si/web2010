/*
 * $Id$
 *
 * Copyright 2005 EPFL. All rights reserved.
 */

package com.baneo.core.jsp.taglib;

import com.baneo.core.system.*;

import javax.servlet.jsp.*;
import java.io.*;

/**
 * Prints the message corresponding to the given key. This is similar to the
 * Struts MessageTag, excepts that is a bit faster, it uses the
 * com.baneo.core.system.Message class for finding the best ResourceBundle,
 * and if a message with the given key cannot be found it simply prints back
 * the key instead of launching an exception (much better when developping).
 *
 * @author Laurent Boatto
 * @see com.baneo.core.system.Message
 */
public class MessageTag extends AbstractTag
{
  private String _key;
  private Object _arg0;
  private Object _arg1;
  private Object _arg2;

  public String getKey()
  {
    return _key;
  }

  public void setKey(String key)
  {
    _key = key;
  }

  public Object getArg0()
  {
    return _arg0;
  }

  public void setArg0(Object arg0)
  {
    _arg0 = arg0;
  }

  public Object getArg1()
  {
    return _arg1;
  }

  public void setArg1(Object arg1)
  {
    _arg1 = arg1;
  }

  public Object getArg2()
  {
    return _arg2;
  }

  public void setArg2(Object arg2)
  {
    _arg2 = arg2;
  }

  public int doStartTag(JspWriter out) throws IOException, JspException
  {
    // The frequent case where we have no formatting to do
    if (_arg0 == null)
    {
      out.print(Message.get(_key, pageContext.getRequest().getLocale()));
      return SKIP_BODY;
    }

    Object[] arguments = new Object[3];
    arguments[0] = _arg0;
    arguments[1] = _arg1;
    arguments[2] = _arg2;

    out.print(Message.format(_key, pageContext.getRequest().getLocale(), arguments));

    return SKIP_BODY;
  }

  public void release()
  {
    super.release();
    _key = null;
    _arg0 = null;
    _arg1 = null;
    _arg2 = null;
  }
}