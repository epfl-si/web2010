/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.jsp.taglib;

import com.baneo.core.system.*;
import com.baneo.core.util.*;

import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.io.*;

/**
 * TabTag and it's parent TabsTag let's you easily creates server side tabs.
 * <p>
 * Usage example :
 * <p>
 * <pre>
 * &lt;p:tabs&gt;
 * &lt;p:tab label="Main"&gt;
 * ... Main content here, can be included ...
 * &lt;/p:tab&gt;
 * &lt;p:tab label="Options"&gt;
 * ... Options content here, can be included ...
 * &lt;/p:tab&gt;
 * &lt;/p:tabs&gt;
 * </pre>
 *
 * @author  Laurent Boatto
 * @version $Id$
 * @see     TabsTag
 */

public class TabTag extends AbstractBodyTag
{
  private String _id;
  private String _label;
  private TabsTag _parent;
  private String _url;

  public int doStartTag(JspWriter out) throws JspException, IOException
  {
    HttpServletRequest request = (HttpServletRequest) pageContext.getRequest();
    _parent = (TabsTag) getParent();
    _parent.register(this);

    // is the current tab selected?
    boolean selected = _id.equals(_parent.getSelectedTab());

    if (selected)
    {
      out.print("<td class=tabSelected nowrap>" + Message.get(_label, request.getLocale()) + "</td>");
    }
    else
    {
      out.print("<td class=tabNotSelected nowrap>");
      out.print("<a href=");

      if (_url != null)
      {
        out.print(request.getContextPath() + _url);
      }
      else
      {
        out.print(HttpUtil.addParameterToUrl((HttpServletRequest) pageContext.getRequest(), _parent.SELECTED_TAB_PARAMETER, _id));
      }
      out.print(">" + Message.get(_label, request.getLocale()) + "</a></td>");
    }

    // if the tab is selected, we need to evaluate the body, otherwise we just
    // skip it.
    if (selected)
    {
      return EVAL_BODY_BUFFERED;
    }
    else
    {
      return SKIP_BODY;
    }
  }

  public int doAfterBody() throws JspException
  {
    // Sets the selected tab content to the TabsTag so he can later print it
    _parent.setContent(getBodyContent().getString());

    return SKIP_BODY;
  }

  /**
   * Returns the tab id.
   *
   * @return the tab id.
   */
  public String getId()
  {
    return _id;
  }

  /**
   * Sets the tab id.
   *
   * @param id the tab id.
   */
  public void setId(String id)
  {
    _id = id;
  }

  /**
   * Sets the label for the tab, e.g. "Main".
   */
  public void setLabel(String label)
  {
    _label = label;
  }

  /**
   * Returns the tab's label.
   *
   * @return the tab's label.
   */
  public String getLabel()
  {
    return _label;
  }

  public String getUrl()
  {
    return _url;
  }

  public void setUrl(String url)
  {
    _url = url;
  }

  public void release()
  {
    super.release();
    _id = null;
    _label = null;
    _parent = null;
    _url = null;
  }
}