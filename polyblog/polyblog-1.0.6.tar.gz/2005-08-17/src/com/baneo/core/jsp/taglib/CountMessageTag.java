package com.baneo.core.jsp.taglib;

import com.baneo.core.system.*;

import javax.servlet.jsp.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

/**
 * Displays a message in singular or plural according to an attribute.
 *
 * @author Laurent Boatto
 */
public class CountMessageTag extends AbstractTag
{
  private String _countAttribute;
  private Integer _countValue;
  private String _singularMessage;
  private String _pluralMessage;

  public int doStartTag(JspWriter out) throws IOException, JspException
  {
    HttpServletRequest request = (HttpServletRequest) pageContext.getRequest();
    Locale locale = request.getLocale();

    int count = 0;

    if (_countValue != null)
    {
      count = _countValue.intValue();
    }
    else
    {
      count = ((Integer) pageContext.findAttribute(_countAttribute)).intValue();
    }

    if (count == 1)
    {
      out.print(Message.get(_singularMessage, locale));
    }
    else
    {
      out.print(Message.format(_pluralMessage, locale, new Integer(count)));
    }

    return SKIP_BODY;
  }


  public String getCountAttribute()
  {
    return _countAttribute;
  }

  /**
   * Sets the attribute name that specify how many results we have.
   *
   * @param countAttribute
   */
  public void setCountAttribute(String countAttribute)
  {
    _countAttribute = countAttribute;
  }

  public String getSingularMessage()
  {
    return _singularMessage;
  }

  /**
   * Sets the message (key or phrase) to display when the count is 1.
   *
   * @param singularMessage he message (key or phrase) to display when the count is 1.
   */
  public void setSingularMessage(String singularMessage)
  {
    _singularMessage = singularMessage;
  }

  public String getPluralMessage()
  {
    return _pluralMessage;
  }

  /**
   * Sets the message (key or phrase) to display when the count is greater than 1.
   *
   * @param pluralMessage the message (key or phrase) to display when the count is greater than 1.
   */
  public void setPluralMessage(String pluralMessage)
  {
    _pluralMessage = pluralMessage;
  }

  /**
   * Returns the count value.
   *
   * @return the count value.
   */
  public Integer getCountValue()
  {
    return _countValue;
  }

  /**
   * Sets the count value.
   *
   * @param countValue the count value.
   */
  public void setCountValue(Integer countValue)
  {
    _countValue = countValue;
  }
}