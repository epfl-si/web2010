/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.jsp.taglib;

import com.baneo.core.system.*;
import com.baneo.core.util.*;

import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.io.*;

/**
 * Prints the header of a lister.
 *
 * @author  Laurent Boatto
 * @version $Id$
 */

public class ListerHeaderTag extends AbstractTag
{
  /**
   * The name of the displayed field.
   */
  private String _name;

  /**
   * The label of the displayed field. You can either specify a key from the
   * application ResourceBundle (e.g. "model.user.name.label") or some plain
   * text, (e.g. "Name").
   */
  private String _label;

  /**
   * If true, show the sort icons.
   */
  private boolean _showSortIcons = true;

  /**
   * Alignment for the header row.
   */
  private String _align;

  /**
   * Width of the header row.
   */
  private String _width;

  public int doStartTag(JspWriter out) throws IOException, JspException
  {
    HttpServletRequest request = (HttpServletRequest) pageContext.getRequest();
    String contextPath = request.getContextPath();

    ListerTag parent = (ListerTag) getParent();

    if (parent == null)
    {
      throw new JspException("The <listerHeader> tag must be used inside a <lister> tag");
    }

    String anchor = null;

    if (parent.getUseAnchor())
    {
      anchor = ListerTag.LISTER_ANCHOR;
    }

    int count = parent.getCount();
    String defaultSortBy = parent.getDefaultSortBy();
    String order = request.getParameter(parent.getOrderParameter());
    String baseUrl = parent.getBaseUrl();

    if (baseUrl == null)
    {
      baseUrl = request.getRequestURI();
    }
    else
    {
      baseUrl = request.getContextPath() + baseUrl;
    }

    if (order != null)
    {
      // We decode the order, as it could have been encoded (e.g. in
      // ListerPagesTag) to strip spaces.
      order = HttpUtil.decode(order);
    }

    out.print("<th width=" + _width + " class=l");

    // We must set the default to left here, because by default a <th> is
    // centered, and if we override this in the CSS (with text-align:left;)
    // we cannot override it anymore for a specific <th>.
    if (_align == null)
    {
      _align = "left";
    }

    out.print(" align=" + _align);

    // This will return the message in the current application ResourceBundle,
    // or the key if it does not exist.
    _label = Message.get(_label, request.getLocale());

    out.print(" nowrap>" + _label);

    // We don't print the icons if the label if it's null or "empty"
    if (_label == null || _label.equals("&nbsp;") || _label.equals(""))
    {
      _showSortIcons = false;
    }

    if (_showSortIcons && count > 1)
    {
      // Sort up
      if ((order != null && order.equals(_name)) || (order == null && defaultSortBy.equals(_name)))
      {
        out.print(" <img src=" + contextPath + "/i/upSelected>");
      }
      else
      {
        out.print(" <a href=" + HttpUtil.addParameterToRequest(baseUrl, request, "order", _name, anchor) + ">");
        out.print("<img src=" + contextPath + "/i/up border=0></a>");
      }

      // Sort down
      if ((order != null && order.equals(_name + " DESC")) || (order == null && defaultSortBy.equals(_name + " DESC")))
      {
        out.print("<img src=" + contextPath + "/i/downSelected>");
      }
      else
      {
        out.print("<a href=" + HttpUtil.addParameterToRequest(baseUrl, request, "order", _name + "+DESC", anchor) + ">");
        out.print("<img src=" + contextPath + "/i/down border=0></a>");
      }
    }

    out.print("</th>");

    return SKIP_BODY;
  }

  public String getName()
  {
    return _name;
  }

  public void setName(String name)
  {
    _name = name;
  }

  /**
   * Returns the label of the displayed field.
   *
   * @return the label of the displayed field.
   */
  public String getLabel()
  {
    return _label;
  }

  /**
   * Sets the label of the displayed field. You can either specify a key from
   * the application ResourceBundle (e.g. "model.user.name.label") or some plain
   * text, (e.g. "Name").
   */
  public void setLabel(String label)
  {
    _label = label;
  }

  public boolean isShowSortIcons()
  {
    return _showSortIcons;
  }

  public void setShowSortIcons(boolean showSortIcons)
  {
    _showSortIcons = showSortIcons;
  }

  public String getAlign()
  {
    return _align;
  }

  public void setAlign(String align)
  {
    _align = align;
  }

  public String getWidth()
  {
    return _width;
  }

  public void setWidth(String width)
  {
    _width = width;
  }
}


