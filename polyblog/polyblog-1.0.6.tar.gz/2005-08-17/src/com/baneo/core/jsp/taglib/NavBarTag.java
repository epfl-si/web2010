/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.jsp.taglib;

import javax.servlet.jsp.*;
import java.io.*;

/**
 * Print a navigation bar, which can be built easily in conjunction with the
 * NavBarItemTag
 *
 * Example of use in a jsp :
 *
 * <p:navBar>
 *   <p:navBarItem item="Contact" link="/contact/" />
 *   <p:navBarItem item="Webmaster" />
 * </p:navBar>
 *
 * This will print a navigation bar like this :
 *
 * Home / Contact / Webmaster
 *
 * with links for home and contact.
 *
 * @author  Laurent Boatto
 * @version $Id$
 */

public class NavBarTag extends AbstractBodyTag
{
  // Default base navbar, redifine these in your subclass if needed
  private String _baseNavbar = "Home";
  private String _baseNavbarLinked = "<a href=/>Home</a>";
  private String _navbarSeparator = " / ";
  private String _navbar = "";

  public int doEndTag(JspWriter out) throws IOException, JspException
  {
    out.print("<table width=100% border=0 cellspacing=0 cellpadding=0 bgcolor=black>");
    out.print("<tr><td><img src=/i/spacer height=2></td>");
    out.print("<tr><td><table width=100% border=0 cellspacing=0 cellpadding=7 bgcolor=#B0C4DE><tr><td>" + getNavbar() + "</table>");
    out.print("<tr><td><img src=/i/spacer height=2></td></table><br>");

    return EVAL_PAGE;
  }

  public void release()
  {
    super.release();
    // Release for next usage
    _navbar = "";
  }

  /**
   * Sets the navbar.
   *
   * @param navbar the navbar.
   */
  public void setNavbar(String navbar)
  {
    _navbar = navbar;
  }

  /**
   * Returns the navbar.
   *
   * @return the navbar.
   */
  public String getNavbar()
  {
    if (_navbar.equals(""))
    {
      _navbar = _baseNavbar;
    }
    else
    {
      _navbar = _baseNavbarLinked + _navbar;
    }

    return _navbar;
  }

  /**
   * Add the given item to the navbar.
   *
   * @param item the item to add.
   */
  public void addItem(String item)
  {
    _navbar += _navbarSeparator + item;
  }

  /**
   * Add the given item to the navbar with the given link.
   *
   * @param item the item to add.
   * @param link the link corresponding to the item.
   */
  public void addItem(String item, String link)
  {
    _navbar += _navbarSeparator + "<a href=" + link + ">" + item + "</a>";
  }
}