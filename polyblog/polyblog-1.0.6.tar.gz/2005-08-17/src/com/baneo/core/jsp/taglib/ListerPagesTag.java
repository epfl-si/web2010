/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.jsp.taglib;

import com.baneo.core.system.*;
import com.baneo.core.util.*;

import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.io.*;
import java.util.*;

/**
 * Prints the page list of a lister, like this :
 * <p>
 * Page : <u>1</u> <u>2</u> <b>3</b> <u>4</u> <u>5</u> <u>Next ></u>
 * <p>
 * Because of i18n issues, the labels (Page, Next, Previous) are loaded from
 * the application ResourceBundle, via
 * <code>ApplicationResources.getDefaultResourceBundle()</code>, so don't forget to set
 * it in your application bootstrap.
 * <p>
 * The ResourceBundle must have the following entries :
 * <p>
 * <ul>
 * <li>com.baneo.core.jsp.taglib.ListerPagesTag.page : the label printed before
 *     the page list, e.g. "Page "
 * <li>com.baneo.core.jsp.taglib.ListerPagesTag.previous : the label used to go to
 *     the previous page, e.g. "< Previous"
 * <li>com.baneo.core.jsp.taglib.ListerPagesTag.next : the label used to go to the
 *     next page, e.g. "Next >"
 * </ul>
 *
 * @author  Laurent Boatto
 * @version $Id$
 * @see     com.baneo.core.system.ApplicationResources
 * @see     java.util.ResourceBundle
 */

public class ListerPagesTag extends AbstractTag
{
  public int doStartTag(JspWriter out) throws IOException, JspException
  {
    Locale locale = pageContext.getRequest().getLocale();

    HttpServletRequest request = (HttpServletRequest) pageContext.getRequest();

    ListerTag parent = (ListerTag) getParent();
    int count = parent.getCount();
    int showNum = parent.getObjectsPerPage();
    String pageParameter = parent.getPageParameter();
    String baseUrl = parent.getBaseUrl();

    if (baseUrl == null)
    {
      baseUrl = request.getRequestURI();
    }
    else
    {
      baseUrl = request.getContextPath() + baseUrl;
    }

    // No need to go further...
    if (count == 0)
    {
      return SKIP_BODY;
    }

    // Number of pages
    int numPage = (int) Math.ceil((float) count / showNum);

    // We have only one page, no need to go further either..
    if (numPage == 1)
    {
      return SKIP_BODY;
    }

    String anchor = null;

    if (parent.getUseAnchor())
    {
      anchor = ListerTag.LISTER_ANCHOR;
    }

    // Current page
    int currentPage = NumberUtil.parseInt(request.getParameter(pageParameter), 1);

    String pageLabel = Message.get("com.baneo.core.jsp.taglib.ListerPagesTag.page", locale);
    out.print(pageLabel + " : ");

    // Previous pageLabel
    if (currentPage > 1)
    {
      String previousLabel = Message.get("com.baneo.core.jsp.taglib.ListerPagesTag.previous", locale);
      out.print("<a href=" + HttpUtil.addParameterToRequest(baseUrl, request, pageParameter, new Integer(currentPage - 1), anchor) +
          ">" + previousLabel + "</a> ");
    }

    int startPage = currentPage - 9;
    int diffToEnd = numPage - currentPage;
    int endPage = 0;

    if (startPage < 2)
    {
      startPage = 1;
    }

    if (diffToEnd == 0)
    {
      endPage = currentPage;
    }
    else if (diffToEnd > 9)
    {
      endPage = currentPage + 9;
    }
    else
    {
      endPage = currentPage + diffToEnd;
    }


    for (int i = startPage; i <= endPage; i++)
    {
      if (i == currentPage)
      {
        out.print("<b>" + i + "</b> ");
      }
      else
      {
        out.print("<a href=" + HttpUtil.addParameterToRequest(baseUrl, request, pageParameter, new Integer(i), anchor) +
            ">" + i + "</a> ");
      }
    }

    // Next pageLabel
    if (currentPage != numPage)
    {
      String nextLabel = Message.get("com.baneo.core.jsp.taglib.ListerPagesTag.next", locale);
      out.print("<a href=" + HttpUtil.addParameterToRequest(baseUrl, request, pageParameter, new Integer(currentPage + 1), anchor) +
          ">" + nextLabel + "</a> ");
    }

    return SKIP_BODY;
  }
}