/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.jsp.taglib;

import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import java.io.*;

/**
 * Provides some useful methods for tags, like a doStartTag which takes
 * directly a JspWriter and throws IOException.
 *
 * @author Laurent Boatto
 * @version $Id$
 */

public class AbstractTag extends TagSupport
{
  public int doStartTag() throws JspException
  {
    try
    {
      return doStartTag(pageContext.getOut());
    }
    catch (IOException e)
    {
      throw new JspException(e.getMessage(), e);
    }
  }

  /**
   * Default implementation, overrides this in your tag.
   *
   * @param out the JspWriter used to print the content.
   * @return
   * @throws IOException
   * @throws JspException
   */
  public int doStartTag(JspWriter out) throws IOException, JspException
  {
    return SKIP_BODY;
  }
}