/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.jsp.taglib;

import javax.servlet.jsp.*;
import java.io.*;

/**
 * Lister Tag. This is just a value holder taglib for the different child tags
 * like ListerPagesTag and ListerHeaderTag.
 *
 * @author  Laurent Boatto
 * @version $Id$
 * @see ListerPagesTag
 * @see ListerHeaderTag
 */

public class ListerTag extends AbstractBodyTag
{
  public static final String LISTER_ANCHOR = "lister";

  /**
   * The attribute used to sort the objects if none is specified.
   */
  private String _defaultSortBy;

  /**
   * The number of objects this lister contains. This is used for example to
   * know the total page number.
   */
  private int _count;

  /**
   * The url from where this lister is shown.
   */
  private String _baseUrl;

  /**
   * If true an html anchor "#lister" will be added to all the lister urls
   * (order by, pages, etc.), default = true.
   */
  private boolean _useAnchor = true;

  /**
   * The request parameter used to specify the page to show. By default
   * it's "page".
   */
  private String _pageParameter = "page";

  /**
   * The request parameter used to specify the order. By default
   * it's "order".
   */
  private String _orderParameter = "order";

  /**
   * The number of objects to show per page, by default 20.
   */
  private int _objectsPerPage = 20;

  public int doStartTag(JspWriter out) throws IOException, JspException
  {
    out.print("<a name=" + LISTER_ANCHOR + ">");
    return EVAL_BODY_BUFFERED;
  }

  /**
   * Returns the attribute used to sort the objects if none is specified.
   *
   * @return the attribute used to sort the objects if none is specified.
   */
  public String getDefaultSortBy()
  {
    return _defaultSortBy;
  }

  /**
   * Sets the attribute used to sort the objects if none is specified.
   *
   * @param defaultSortBy the attribute used to sort the objects if none is
   *        specified.
   */
  public void setDefaultSortBy(String defaultSortBy)
  {
    _defaultSortBy = defaultSortBy;
  }

  /**
   * Returns the number of objects this lister contains. This is used for
   * example to know the total page number.
   *
   * @return the number of objects this lister contains.
   */
  public int getCount()
  {
    return _count;
  }

  /**
   * Sets the number of objects this lister contains. This is used for
   * example to know the total page number.
   *
   * @param count the number of objects this lister contains.
   */
  public void setCount(int count)
  {
    _count = count;
  }

  public void setCount(Integer count)
  {
    _count = count.intValue();
  }

  /**
   * Sets the number of objects to show per page.
   *
   * @param objectsPerPage the number of objects to show per page.
   */
  public void setObjectsPerPage(int objectsPerPage)
  {
    _objectsPerPage = objectsPerPage;
  }

  /**
   * Returns the number of objects to show per page.
   *
   * @return the number of objects to show per page.
   */
  public int getObjectsPerPage()
  {
    return _objectsPerPage;
  }

  /**
   * Returns the url (without the context path) from where this lister is shown.
   *
   * @return the url (without the context path) from where this lister is shown.
   */
  public String getBaseUrl()
  {
    return _baseUrl;
  }

  /**
   * Sets the url (without the context path) from where this lister is shown.
   *
   * @param baseUrl the url (without the context path) from where this lister
   *        is shown.
   */
  public void setBaseUrl(String baseUrl)
  {
    _baseUrl = baseUrl;
  }

  /**
   * Returns the request parameter used to specify the page to show. By default
   * it's "show".
   *
   * @return the request parameter used to specify the page to show.
   */
  public String getPageParameter()
  {
    return _pageParameter;
  }

  /**
   * Sets the request parameter used to specify the page to show. By default
   * it's "show".
   *
   * @param pageParameter the request parameter used to specify the page to show.
   */
  public void setPageParameter(String pageParameter)
  {
    _pageParameter = pageParameter;
  }

  /**
   * Returns the request parameter used to specify the order. By default
   * it's "order".
   *
   * @return the request parameter used to specify the page the order.
   */
  public String getOrderParameter()
  {
    return _orderParameter;
  }

  /**
   * Sets the request parameter used to specify the order. By default
   * it's "order".
   *
   * @param orderParameter the request parameter used to specify the order.
   */
  public void setOrderParameter(String orderParameter)
  {
    _orderParameter = orderParameter;
  }

  public boolean getUseAnchor()
  {
    return _useAnchor;
  }

  public void setUseAnchor(boolean useAnchor)
  {
    _useAnchor = useAnchor;
  }

  public void release()
  {
    super.release();
    _defaultSortBy = null;
    _count = 0;
    _baseUrl = null;
    _useAnchor = true;
    _pageParameter = "page";
    _orderParameter = "order";
    _objectsPerPage = 20;
  }
}