/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.jsp.taglib;

import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import java.io.*;

/**
 * Provides some useful methods for body tags, like printBody.
 *
 * @author  Laurent Boatto
 * @version $Id$
 */

public abstract class AbstractBodyTag extends BodyTagSupport
{
  public int doStartTag() throws JspException
  {
    try
    {
      return doStartTag(pageContext.getOut());
    }
    catch (IOException e)
    {
      throw new JspException(e.getMessage(), e);
    }
  }

  public int doEndTag() throws JspException
  {
    try
    {
      return doEndTag(pageContext.getOut());
    }
    catch (IOException e)
    {
      throw new JspException(e.getMessage(), e);
    }
  }

  public int doAfterBody() throws JspException
  {
    BodyContent body = getBodyContent();

    if (body != null)
    {
      try
      {
        JspWriter out = body.getEnclosingWriter();
        out.print(body.getString());
      }
      catch (IOException e)
      {
        throw new JspException(e);
      }
    }

    return SKIP_BODY;
  }

  /**
   * Default implementation, overrides this in your tag.
   *
   * @param out the JspWriter used to print the content.
   * @return
   * @throws IOException
   * @throws JspException
   */
  public int doStartTag(JspWriter out) throws IOException, JspException
  {
    return EVAL_BODY_BUFFERED;
  }

  /**
   * Default implementation, overrides this in your tag.
   *
   * @param out the JspWriter used to print the content.
   * @return
   * @throws IOException
   * @throws JspException
   */
  public int doEndTag(JspWriter out) throws IOException, JspException
  {
    return EVAL_PAGE;
  }
}