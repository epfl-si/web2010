/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.jsp.taglib;

import com.baneo.core.system.*;

import javax.servlet.jsp.*;
import java.io.*;

/**
 * Prints a column with one checkbox allowing the user to check
 * or uncheck all the column checkboxes with one click.
 *
 * @author Laurent Boatto
 * @version $Id$
 */

public class ListerSelectAllHeaderTag extends AbstractTag
{
  /**
   * The name of the checkbox used to check or uncheck all the checkboxes.
   */
  public static final String SELECT_ALL_CHECKBOX_NAME = "selectAllCheckbox";

  /**
   * The name of the javascript function called to check or uncheck all the
   * checkboxes.
   */
  public static final String JAVASCRIPT_FUNCTION = "selectAllCheckboxes";

  /**
   * The column width.
   */
  private String _width = "1%";

  /**
   * The help text shown when the user puts the mouse over the checkbox. You can
   * either specify a key from the application ResourceBundle
   * (e.g. "model.user.name.label") or some plain text, (e.g. "Name").
   */
  private String _helpText;

  /**
   * The name of the form containing the checkboxes.
   */
  private String _formName;

  public int doStartTag(JspWriter out) throws IOException, JspException
  {
    ListerTag parent = (ListerTag) getParent();

    if (parent == null)
    {
      throw new JspException("The <listerSelectAllHeaderTag> tag must be used inside a <lister> tag");
    }

    out.print("<th width=" + _width + " class=l>");

    out.print("<input type=\"checkbox\" name=\"" + SELECT_ALL_CHECKBOX_NAME +
        "\" onClick=\"" + JAVASCRIPT_FUNCTION + "(document." + _formName + ")\"");

    if (_helpText != null)
    {
      // This will return the message in the current application ResourceBundle,
      // or the key if it does not exist.
      _helpText = Message.get(_helpText, pageContext.getRequest().getLocale());
      out.print(" title=\"" + _helpText + "\"");
    }

    out.print(">");

    out.print("</th>");

    return SKIP_BODY;
  }

  /**
   * Releases the tag for next usage.
   */
  public void release()
  {
    _width = "1%";
    _helpText = null;
    _formName = null;
  }

  /**
   * Returns the column width, by default "1%".
   *
   * @return the column width, by default "1%".
   */
  public String getWidth()
  {
    return _width;
  }

  /**
   * Sets the column width.
   *
   * @param width the column width.
   */
  public void setWidth(String width)
  {
    _width = width;
  }

  /**
   * Returns the help text.
   *
   * @return the help text.
   */
  public String getHelpText()
  {
    return _helpText;
  }

  /**
   * Sets the help text.
   *
   * @param helpText the help text.
   */
  public void setHelpText(String helpText)
  {
    _helpText = helpText;
  }

  /**
   * Returns the name of the form containing the checkboxes.
   *
   * @return the name of the form containing the checkboxes.
   */
  public String getFormName()
  {
    return _formName;
  }

  /**
   * Sets the name of the form containing the checkboxes.
   *
   * @param formName the name of the form containing the checkboxes.
   */
  public void setFormName(String formName)
  {
    _formName = formName;
  }
}