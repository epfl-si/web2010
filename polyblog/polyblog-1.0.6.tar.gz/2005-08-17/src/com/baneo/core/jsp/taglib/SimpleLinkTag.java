/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.jsp.taglib;

import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.io.*;

/**
 * Prints a link (e.g. &lt;a href=/login.do&gt;login&lt;/a;&gt;), prefixing
 * the url with the request context path. This is similar than the Struts
 * html:link tag, except that's it's much faster, as it only takes care of
 * the request context path and nothing else (jsessionid, etc.).
 *
 * @author  Laurent Boatto
 * @version $Id$
 */

public class SimpleLinkTag extends AbstractBodyTag
{
  private String _page;
  private String _styleClass;

  public int doStartTag(JspWriter out) throws JspException, IOException
  {
    out.print("<a ");

    if (_styleClass != null)
    {
      out.print(" class=\"" + _styleClass + "\"");
    }

    out.print(" href=\"" + ((HttpServletRequest) pageContext.getRequest()).getContextPath() + _page + "\">");

    return EVAL_BODY_BUFFERED;
  }

  public int doEndTag(JspWriter out) throws JspException, IOException
  {
    out.print("</a>");
    return EVAL_PAGE;
  }

  public void release()
  {
    super.release();
    _page = null;
    _styleClass = null;
  }

  public String getPage()
  {
    return _page;
  }

  public void setPage(String page)
  {
    _page = page;
  }

  public String getStyleClass()
  {
    return _styleClass;
  }

  public void setStyleClass(String styleClass)
  {
    _styleClass = styleClass;
  }
}