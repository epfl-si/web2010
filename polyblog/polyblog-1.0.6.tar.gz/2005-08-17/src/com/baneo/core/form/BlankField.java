/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.form;

import java.io.*;

/**
 * BlankField.
 *
 * @author Laurent Boatto
 * @version $Id$
 */

public class BlankField extends Field
{
  protected void printBody() throws IOException
  {
    printFieldStart();
    _out.print("&nbsp;");
    printFieldEnd();
  }
}
