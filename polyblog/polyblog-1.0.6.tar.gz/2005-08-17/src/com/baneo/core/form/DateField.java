/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.form;

import com.baneo.core.system.*;
import com.baneo.core.util.*;

import javax.servlet.http.*;
import java.io.*;
import java.util.*;

/**
 * A field that prints a date with 3 dropdown columns. Note that because of
 * i18n issues, you must define the following messages in your application
 * ResourceBundle :
 * <p>
 * "com.baneo.core.form.DateField.january"
 * etc.. to :
 * "com.baneo.core.form.DateField.december"
 * <p>
 * This will specify the labels for monthes, and also :
 * <p>
 * "com.baneo.core.form.DateField.day.label"
 * "com.baneo.core.form.DateField.month.label"
 * <p>
 * for the dropdown labels.
 *
 * @author  Laurent Boatto
 * @version $Id$
 */
public class DateField extends Field
{
  private int _yearFrom;
  private int _yearTo;
  private boolean _selectTodayByDefault;
  private int _defaultYear;
  private int _defaultMonth;
  private static final String DAY_LABEL = Message.get("com.baneo.core.form.DateField.day.label", null);
  private static final String MONTH_LABEL = Message.get("com.baneo.core.form.DateField.month.label", null);

  private static final String[] MONTH_LABELS = new String[12];

  static
  {
    MONTH_LABELS[0] = Message.get("com.baneo.core.form.DateField.january", null);
    MONTH_LABELS[1] = Message.get("com.baneo.core.form.DateField.february", null);
    MONTH_LABELS[2] = Message.get("com.baneo.core.form.DateField.march", null);
    MONTH_LABELS[3] = Message.get("com.baneo.core.form.DateField.april", null);
    MONTH_LABELS[4] = Message.get("com.baneo.core.form.DateField.may", null);
    MONTH_LABELS[5] = Message.get("com.baneo.core.form.DateField.june", null);
    MONTH_LABELS[6] = Message.get("com.baneo.core.form.DateField.july", null);
    MONTH_LABELS[7] = Message.get("com.baneo.core.form.DateField.august", null);
    MONTH_LABELS[8] = Message.get("com.baneo.core.form.DateField.september", null);
    MONTH_LABELS[9] = Message.get("com.baneo.core.form.DateField.october", null);
    MONTH_LABELS[10] = Message.get("com.baneo.core.form.DateField.november", null);
    MONTH_LABELS[11] = Message.get("com.baneo.core.form.DateField.december", null);
  }

  /**
   * Constructs a new DateField.
   *
   * @param name the field name.
   * @param label the field label.
   * @param required true if the field is required, false otherwise.
   */
  public DateField(String name, String label, boolean required)
  {
    super(name, label, required);
  }

  public void printBody() throws IOException
  {
    printFieldStart();

    Object value = getValue();
    Date valueDate = null;

    // The date can also we set as a valid ISO String (yyyy-MM-dd)
    if (value instanceof String)
    {
      valueDate = DateUtil.parseIsoDate((String) value);
    }
    else
    {
      valueDate = (Date) value;
    }

    Calendar calendar = null;

    if (valueDate == null)
    {
      if (_selectTodayByDefault)
      {
        calendar = new GregorianCalendar();
      }
    }
    else
    {
      calendar = new GregorianCalendar();
      calendar.setTime(valueDate);
    }

    // day
    _out.print("<select name=" + _name + "_day>");

    _out.print("<option value=''>" + DAY_LABEL);

    for (int i = 1; i <= 31; i++)
    {
      _out.print("<option");

      if (calendar != null && i == (calendar.get(Calendar.DAY_OF_MONTH)))
      {
        _out.print(" selected");
      }

      _out.print(">" + i);
    }

    _out.print("</select> ");

    // month
    _out.print("<select name=" + _name + "_month>");

    _out.print("<option value=''>" + MONTH_LABEL);

    for (int i = 0; i < MONTH_LABELS.length; i++)
    {
      _out.print("<option value=" + i);

      if (calendar != null && i == (calendar.get(Calendar.MONTH)))
      {
        _out.print(" selected");
      }
      else if (calendar == null && i == _defaultMonth)
      {
        _out.print(" selected");
      }

      _out.print(">" + MONTH_LABELS[i]);
    }

    _out.print("</select> ");

    // year
    _out.print("<select name=" + _name + "_year>");

    for (int i = _yearFrom; i <= _yearTo; i++)
    {
      _out.print("<option");

      if (calendar != null && i == (calendar.get(Calendar.YEAR)))
      {
        _out.print(" selected");
      }
      else if (calendar == null && i == _defaultYear)
      {
        _out.print(" selected");
      }

      _out.print(">" + i);
    }

    _out.print("</select>");

    printFieldEnd();
  }

  /**
   * The focus field is the day dropdown for DateFields.
   *
   * @return the day dropdown.
   */
  public String getFocusFieldName()
  {
    return _name + "_day";
  }

  public int getYearFrom()
  {
    return _yearFrom;
  }

  public void setYearFrom(int yearFrom)
  {
    _yearFrom = yearFrom;
  }

  public int getYearTo()
  {
    return _yearTo;
  }

  public void setYearTo(int yearTo)
  {
    _yearTo = yearTo;
  }

  public boolean isSelectTodayByDefault()
  {
    return _selectTodayByDefault;
  }

  public void setSelectTodayByDefault(boolean selectTodayByDefault)
  {
    _selectTodayByDefault = selectTodayByDefault;
  }

  public int getDefaultYear()
  {
    return _defaultYear;
  }

  public void setDefaultYear(int defaultYear)
  {
    _defaultYear = defaultYear;
  }

  public int getDefaultMonth()
  {
    return _defaultMonth;
  }

  public void setDefaultMonth(int defaultMonth)
  {
    _defaultMonth = defaultMonth;
  }

  public static Date requestToValue(HttpServletRequest request, String parameter)
  {
    int day = getParameter(request, parameter + "_day");
    int month = getParameter(request, parameter + "_month");
    int year = getParameter(request, parameter + "_year");

    if (day == -1 || month == -1 || year == -1)
    {
      return null;
    }

    GregorianCalendar calendar = new GregorianCalendar();
    calendar.set(Calendar.DAY_OF_MONTH, day);
    calendar.set(Calendar.MONTH, month);
    calendar.set(Calendar.YEAR, year);
    return calendar.getTime();
  }

  private static int getParameter(HttpServletRequest request, String attribute)
  {
    String value = request.getParameter(attribute);

    if (value == null || Check.isEmpty(value))
    {
      return -1;
    }

    try
    {
      return Integer.parseInt(request.getParameter(attribute));
    }
    catch (NumberFormatException e)
    {
      return -1;
    }
  }
}
