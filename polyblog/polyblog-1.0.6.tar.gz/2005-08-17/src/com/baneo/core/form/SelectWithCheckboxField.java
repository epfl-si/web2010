/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.form;

import java.io.*;
import java.util.*;

/**
 * A select field with a checkbox at the end. This field has 2 inputs and
 * therefore two values, one for the select input element, and one for the
 * checkbox input element.
 *
 * @author  Laurent Boatto
 * @version $Id$
 * @see com.baneo.core.form.SelectField
 */

public class SelectWithCheckboxField extends Field
{
  private Map _options;
  private int _size;
  private boolean _firstOptionEmpty = true;
  private String _checkboxName;
  private String _checkboxLabel;


  /**
   * Constructs a new SelectWithCheckboxField.
   *
   * @param selectName the name of the select input element.
   * @param selectLabel the label of the select input element.
   * @param checkboxName the name of the checkbox input element.
   * @param checkboxLabel the label of the checkbox input element.
   * @param required true if the field is required, false otherwise.
   */
  public SelectWithCheckboxField(String selectName, String selectLabel, String checkboxName, String checkboxLabel, boolean required)
  {
    super(selectName, selectLabel, required);
    _checkboxName = checkboxName;
    _checkboxLabel = checkboxLabel;
  }

  public void printBody() throws IOException
  {
    printFieldStart();

    Map values = getValues();

    String selectValue = (String) values.get(getName());
    String checkBoxValue = (String) values.get(_checkboxName);

    _out.print("<select name=" + getName());

    if (_size > 1)
    {
      _out.print(" size=" + _size);
    }

    if (_styleClass != null)
    {
      _out.print(" class=" + _styleClass);
    }

    _out.print(">");

    // The empty option
    if (_firstOptionEmpty)
    {
      _out.print("<option>");
    }

    // Should not happend anyway, but if it does, it's better than a
    // NullPointerException.
    if (_options == null)
    {
      _out.print("</select>");
      printCheckBox(checkBoxValue);
      printFieldEnd();
      return;
    }

    String key = null;
    String label = null;

    Set keys = _options.keySet();
    Iterator it = keys.iterator();

    while (it.hasNext())
    {
      key = (String) it.next();
      label = (String) _options.get(key);

      _out.print("<option value=\"" + key + "\"");

      if (key.equals(selectValue))
      {
        _out.print(" selected");
      }

      _out.print(">");
      _out.print(label);
    }

    _out.print("</select>");

    printCheckBox(checkBoxValue);

    printFieldEnd();
  }

  /**
   * Prints the field's checkbox.
   *
   * @param checkboxValue the checkbox value.
   * @throws IOException
   */
  private void printCheckBox(String checkboxValue) throws IOException
  {
    _out.print(" <input type=checkbox id=" + _checkboxName + " name=" + _checkboxName);

    if (checkboxValue != null && !checkboxValue.equals("false"))
    {
      _out.print(" checked");
    }

    _out.print("> <label for=" + _checkboxName + ">" + _checkboxLabel + "</label>");
  }

  public String[] getInputs()
  {
    return new String[]{_name, _checkboxName};
  }

  /**
   * Add an option to the field. The options are then presented in the order
   * of insert. Beware that this method should NOT be used in conjunction with
   * setOptions(), because setOptions will reset the options previously set by
   * addOption().
   *
   * @param value the option value, e.g. "ch".
   * @param label the option label, e.g. "Switzerland".
   */
  public void addOption(String value, String label)
  {
    if (_options == null)
    {
      _options = new LinkedHashMap();
    }

    _options.put(value, label);
  }

  /**
   * Returns the options of the select field. The options are a Map having for
   * the map key the field value (e.g. "ch" for a country), and for the map
   * value the field label (e.g. "Switzerland");
   *
   * @return the options of the select field.
   */
  public Map getOptions()
  {
    return _options;
  }

  /**
   * Sets the options of the select field. The options are a Map having for
   * the map key the field value (e.g. "ch" for a country), and for the map
   * value the field label (e.g. "Switzerland");
   *
   * @param options the options of the select field.
   */
  public void setOptions(Map options)
  {
    _options = options;
  }

  /**
   * Returns the size of the select field (by default : 0).
   *
   * @return the size of the select field.
   */
  public int getSize()
  {
    return _size;
  }

  /**
   * Sets the size of the select field (by default : 0).
   *
   * @param size the size of the select field.
   */
  public void setSize(int size)
  {
    _size = size;
  }

  /**
   * If true, a first empty option will be printed (default : true).
   *
   * @return true if a first empty option will be printed, false otherwise.
   */
  public boolean isFirstOptionEmpty()
  {
    return _firstOptionEmpty;
  }

  /**
   * Set to true if you want to print a first empty option, false otherwise
   * (default : true).
   *
   * @param firstOptionEmpty true if you want to print a first empty option,
   *        false otherwise.
   */
  public void setFirstOptionEmpty(boolean firstOptionEmpty)
  {
    _firstOptionEmpty = firstOptionEmpty;
  }
}