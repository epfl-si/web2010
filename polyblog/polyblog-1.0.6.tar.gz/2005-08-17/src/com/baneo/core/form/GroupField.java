/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.form;

import java.io.*;
import java.util.*;

/**
 * A GroupField is a group of Fields (you guessed it), which can be useful
 * when you need to logically group some Fields (e.g. a city Field,
 * a state Field, a country Field could be grouped in a region GroupField).
 * The fields are stored in a Map, having for the key the Field name, and for
 * the value the Field itself.
 *
 * @author Laurent Boatto
 * @version $Id$
 */

public class GroupField extends Field
{
  /**
   * The Fields of the GroupField, we use a LinkedHashMap because the insertion
   * order is important.
   */
  private Map _fields = new LinkedHashMap();

  protected void printBody() throws IOException
  {
    // Do nothing, a group field is just a "logical" field
  }

  public String getFocusFieldName()
  {
    // The focus is set on the first field of the group if another field
    // has not been specified
    if (_focusField != null)
    {
      return _focusField;
    }
    else
    {
      return ((Field) _fields.values().iterator().next()).getFocusFieldName();
    }
  }

  /**
   * Returns the Field of the GroupField having the given name.
   *
   * @param name the name of the Field you want to find.
   * @return the Field of the GroupField having the given name.
   */
  public Field getField(String name)
  {
    return (Field) _fields.get(name);
  }

  /**
   * Returns all the Fields of the GroupField.
   *
   * @return all the Fields of the GroupField.
   */
  public Collection getFields()
  {
    return _fields.values();
  }

  /**
   * Sets the GroupField Fields.
   *
   * @param fields the GroupField Fields.
   */
  public void setFields(Map fields)
  {
    _fields = fields;
  }

  /**
   * Adds the given Field to the GroupField.
   *
   * @param field the Field to add.
   */
  public void addField(Field field)
  {
    _fields.put(field.getName(), field);
  }

  /**
   * Removes the given Field from the GroupField.
   *
   * @param field the Field to remove.
   */
  public void removeField(Field field)
  {
    _fields.remove(field.getName());
  }
}