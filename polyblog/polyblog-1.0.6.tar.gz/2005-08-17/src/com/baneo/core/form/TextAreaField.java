/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.form;

import org.apache.commons.lang.*;

import java.io.*;

/**
 * TextAreaField.
 *
 * @author  Laurent Boatto
 * @version $Id$
 */

public class TextAreaField extends Field
{
  private int _cols;
  private int _rows;

  /**
   * Constructor.
   *
   * @param name the field name.
   * @param label the field label.
   * @param required true if the field is required, false otherwise.
   * @param cols the number of columns.
   * @param rows the number of rows.
   */
  public TextAreaField(String name, String label, boolean required, int cols, int rows)
  {
    super(name, label, required);

    _cols = cols;
    _rows = rows;
  }

  /**
   * Prints the field.
   */
  public void printBody() throws IOException
  {
    // We cannot use printFieldStart() here because of valign=top
    _out.print("<tr valign=top>");
    printLabel();
    _out.print("<td>");

    String value = (String) getValue();

    _out.write("<textarea name=" + getName() + " cols=" + _cols + " rows=" + _rows + ">");

    if (value != null)
    {
      _out.write(StringEscapeUtils.escapeHtml(value));
    }

    _out.write("</textarea>");

    printFieldEnd();
  }

  /**
   * Returns the textarea number of columns.
   *
   * @return the textarea number of columns.
   */
  public int getCols()
  {
    return _cols;
  }

  /**
   * Sets the textarea number of columns.
   *
   * @param cols the textarea number of columns.
   */
  public void setCols(int cols)
  {
    _cols = cols;
  }

  /**
   * Returns the textarea number of rows.
   *
   * @return the textarea number of rows.
   */
  public int getRows()
  {
    return _rows;
  }

  /**
   * Sets the textarea number of rows.
   *
   * @param rows the textarea number of rows.
   */
  public void setRows(int rows)
  {
    _rows = rows;
  }
}
