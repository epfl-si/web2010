/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.form;

import com.baneo.core.util.*;

import javax.servlet.jsp.*;
import java.io.*;
import java.util.*;

/**
 * Field.
 *
 * @author  Laurent Boatto
 * @version $Id$
 */

public abstract class Field
{
  public static final String STYLE_VERY_SMALL = "fieldVerySmall";
  public static final String STYLE_SMALL = "fieldSmall";
  public static final String STYLE_MEDIUM = "fieldMedium";
  public static final String STYLE_BIG = "fieldBig";
  public static final String CSS_ERROR = "formError";
  public static final String CSS_ADVICE = "formAdvice";

  protected JspWriter _out;
  protected PageContext _pageContext;
  protected boolean _required;
  protected Object _value;
  protected Map _values = new HashMap();
  protected String _error;
  protected String _name;
  protected String _focusField;
  protected String _label;
  protected String _helpText = "&nbsp;";
  protected String _suffix;
  protected String _advice;
  protected Form _form;
  protected int _helpTextRowSpan = 1;
  protected String _styleClass;
  boolean _hasBlankHelpText = true;

  /**
   * Constructs a new Field.
   */
  public Field()
  {
  }

  /**
   * Constructs a new Field.
   *
   * @param name the Field name.
   * @param label the Field label.
   * @param required true if the field is required, false otherwise.
   */
  public Field(String name, String label, boolean required)
  {
    _name = name;
    _label = label;
    _required = required;
  }

  /**
   * Prints the field.
   *
   * @throws IOException on IO error.
   */
  public void print() throws IOException
  {
    if (_error != null)
    {
      printError();
    }

    printBody();
  }

  /**
   * Prints the field body.
   *
   * @throws IOException on IO error.
   */
  protected abstract void printBody() throws IOException;

  /**
   * Print the field hidden value.
   *
   * @throws IOException on IO error.
   */
  protected void printHiddenValue() throws IOException
  {
    if (getValue() != null && !getValue().equals(""))
    {
      _out.print("<input type=hidden name=" + _name + " value=\"" + getValue() + "\">");
    }
  }

  /**
   * Prints the field label.
   *
   * @throws IOException on IO error.
   */
  protected void printLabel() throws IOException
  {
    if (Check.isEmpty(_label))
    {
      _out.print("<td>&nbsp;</td>");
    }
    else
    {
      _out.print("<td align=right nowrap>" + _label);
      _out.print(_form.getLabelSeparator() + "</td>");
    }
  }

  /**
   * Prints the field suffix.
   *
   * @throws IOException on IO error.
   */
  protected void printSuffix() throws IOException
  {
    if (_suffix != null)
    {
      _out.print(" " + _suffix);
    }
  }

  /**
   * Prints the field help text.
   *
   * @throws IOException on IO error.
   */
  protected void printHelpText() throws IOException
  {
    if (!_form.getShowHelpText() || (_helpText == null))
    {
      return;
    }

    _out.print("<td class=" + Form.CSS_HELP_TEXT + " valign=top");

    if (_helpTextRowSpan > 1)
    {
      _out.print(" rowspan=" + _helpTextRowSpan);
    }

    _out.print(">");

    if ("&nbsp;".equals(_helpText))
    {
      _out.print("&nbsp;");
    }
    else
    {
      _out.print("<ul><li>" + _helpText + "</ul>");
    }

    _out.print("</td>");
  }

  /**
   * Prints the required String.
   *
   * @throws IOException on IO error.
   */
  protected void printRequiredString() throws IOException
  {
    if (_required && _form.getShowRequiredString())
    {
      _out.print(" " + _form.getRequiredString());
    }
  }

  /**
   * Prints the field error.
   */
  protected void printError() throws IOException
  {
    _out.print("<tr>");

    _out.print("<td>&nbsp;</td><td class=" + CSS_ERROR + ">" + _error
        + _form.getErrorSeparator() + "</td>");

    if (_hasBlankHelpText)
    {
      _form.printHelpText("&nbsp;");
    }

    _out.print("</tr>");
  }

  /**
   * Prints the field advice.
   *
   * @throws IOException
   */
  protected void printAdvice() throws IOException
  {
    if (_advice != null && _form.getShowAdvice())
    {
      _out.print("<tr><td>&nbsp;</td>");
      _out.print("<td class=" + CSS_ADVICE + "> " + _advice + "</td>");
      _out.print("</tr>");
    }
  }

  /**
   * Prints the field start, with the first "<tr>", the field label, etc.
   *
   * @throws IOException
   */
  protected void printFieldStart() throws IOException
  {
    _out.print("<tr>");
    printLabel();
    _out.print("<td>");
  }

  /**
   * Prints the field end, with the field suffix, advice, closes the "</td>"
   * and "</tr>", etc.
   *
   * @throws IOException
   */
  protected void printFieldEnd() throws IOException
  {
    printSuffix();
    printRequiredString();
    _out.print("</td>");
    printHelpText();
    _out.print("</tr>");
    printAdvice();
  }

  /**
   * Escape the given value.
   *
   * @param value the value to escape.
   * @return the escaped value.
   */
  protected String escapeStringValue(String value)
  {
    return StringUtil.escapeDoubleQuote(value);
  }

  /**
   * Returns true if the Field has several inputs.
   *
   * @return true if the Field has several inputs.
   */
  public boolean hasSeveralInputs()
  {
    return getInputs().length > 1;
  }

  /**
   * Returns true if the field has an error associated to it, false otherwise.
   *
   * @return true if the field has an error associated to it, false otherwise.
   */
  public boolean hasError()
  {
    if (_error == null || _error.equals(""))
    {
      return false;
    }

    return true;
  }

  /**
   * Returns true if the field is required, false otherwise.
   *
   * @return true if the field is required, false otherwise.
   */
  public boolean isRequired()
  {
    return _required;
  }

  /**
   * Set to true if the field is required, false otherwise.
   *
   * @param required true if the field is required, false otherwise.
   */
  public void setRequired(boolean required)
  {
    _required = required;
  }

  /**
   * Returns the field value.
   *
   * @return the field value.
   */
  public Object getValue()
  {
    return _value;
  }

  /**
   * Sets the field value.
   *
   * @param value the field value.
   */
  public void setValue(Object value)
  {
    _value = value;
    _values.put(_name, value);
  }

  /**
   * Adds the given value with the given key to the Field values.
   *
   * @param key the value key.
   * @param value the value value.
   */
  public void addValue(Object key, Object value)
  {
    _values.put(key, value);
  }

  /**
   * Returns the values of the Field. Most of the time a Field has only one
   * value, but it may have several if it has several inputs (see getInputs()).
   *
   * @return the values of the Field.
   */
  public Map getValues()
  {
    return _values;
  }

  /**
   * Sets the values of the Field. Most of the time a Field has only one
   * value, but it may have several if it has several inputs (see getInputs()).
   *
   * @@param values the values of the Field
   */
  public void setValues(Map values)
  {
    _values = values;
  }

  /**
   * Returns the field error.
   *
   * @return the field error.
   */
  public String getError()
  {
    return _error;
  }

  /**
   * Sets the field error.
   *
   * @param error the field error.
   */
  public void setError(String error)
  {
    _error = error;
  }

  /**
   * Returns the field name.
   *
   * @return the field name.
   */
  public String getName()
  {
    return _name;
  }

  /**
   * Returns the names of the Field inputs. Most of the time a Field has only
   * one input, but it may have several, e.g. two text inputs for a price field
   * (dollars and cents).
   *
   * @return he names of the Field inputs
   */
  public String[] getInputs()
  {
    /**
     * todo do not create a new String[] here everytime
     */
    return new String[]{_name};
  }

  /**
   * Sets the field name.
   *
   * @param name the field name.
   */
  public void setName(String name)
  {
    _name = name;
  }

  /**
   * Returns the field label.
   *
   * @return the field label.
   */
  public String getLabel()
  {
    return _label;
  }

  /**
   * Sets the field label.
   *
   * @param label the field label.
   */
  public void setLabel(String label)
  {
    _label = label;
  }

  /**
   * Returns the field help text.
   *
   * @return the field help text.
   */
  public String getHelpText()
  {
    return _helpText;
  }

  /**
   * Sets the field help text (by default it's "&nbsp;".
   *
   * @param helpText the field helpText.
   */
  public void setHelpText(String helpText)
  {
    _helpText = helpText;
  }

  /**
   * Returns the field suffix.
   *
   * @return the field suffix.
   */
  public String getSuffix()
  {
    return _suffix;
  }

  /**
   * Sets the field suffix.
   *
   * @param suffix the field suffix.
   */
  public void setSuffix(String suffix)
  {
    _suffix = suffix;
  }

  /**
   * Returns the field help text rowspan. The help text rowspan is the number
   * of rows the help text span on (by default 1).
   *
   * @return the field help text rowspan.
   */
  public int getHelpTextRowSpan()
  {
    return _helpTextRowSpan;
  }

  /**
   * Sets the field help text rowspan. The help text rowspan is the number
   * of rows the help text span on (by default 1).
   *
   * @param helpTextRowSpan the field help text rowspan.
   */
  public void setHelpTextRowSpan(int helpTextRowSpan)
  {
    _helpTextRowSpan = helpTextRowSpan;
  }

  /**
   * Returns the field Form.
   *
   * @return the field form.
   */
  public Form getForm()
  {
    return _form;
  }

  /**
   * Sets the field Form.
   *
   * @param form the field Form.
   */
  public void setForm(Form form)
  {
    _form = form;
  }

  /**
   * Returns the JspWriter that the field will use to print it's content.
   *
   * @return the JspWriter that the field will use to print it's content.
   */
  public JspWriter getOut()
  {
    return _out;
  }

  /**
   * Sets the JspWriter that the field will use to print it's content.
   *
   * @param out the JspWriter that the field will use to print it's content.
   */
  public void setOut(JspWriter out)
  {
    _out = out;
  }

  /**
   * Returns the Field PageContext.
   *
   * @return the Field PageContext.
   */
  public PageContext getPageContext()
  {
    return _pageContext;
  }

  /**
   * Sets the Field PageContext.
   *
   * @param pageContext the PageContext.
   */
  public void setPageContext(PageContext pageContext)
  {
    _pageContext = pageContext;
  }

  /**
   * Returns the field CSS style class.
   *
   * @return the field CSS style class.
   */
  public String getStyleClass()
  {
    return _styleClass;
  }

  /**
   * Sets the field CSS style class.
   *
   * @param styleClass the field CSS style class.
   */
  public void setStyleClass(String styleClass)
  {
    _styleClass = styleClass;
  }

  /**
   * Returns the field advice.
   *
   * @return the field advice.
   */
  public String getAdvice()
  {
    return _advice;
  }

  /**
   * Returns the name of the field to put the focus on if needed (e.g. on error).
   * This is normally the name of the field itself, but it can be something else
   * if the field is composed of multiple dropdowns (see DateField). If the
   * Field should never have the focus (e.g. a LabelField), this method must
   * return null;
   *
   * @return the name of the field to put the focus on if needed (e.g. on error).
   */
  public String getFocusFieldName()
  {
    return _name;
  }

  /**
   * Returns the name of the field to put the focus on if needed (e.g. on error).
   * This is normally the name of the field itself, but it can be something else
   * if the field is composed of multiple dropdowns (see DateField).
   *
   * @param focusField the name of the field to put the focus on if needed
   *        (e.g. on error).
   */
  public void setFocusField(String focusField)
  {
    _focusField = focusField;
  }

  /**
   * Sets the field advice.
   *
   * @param advice the field advice.
   */
  public void setAdvice(String advice)
  {
    if ("".equals(advice))
    {
      advice = null;
    }

    _advice = advice;
  }

  /**
   * Sets to true if the field needs to print a blank (&nbsp;) help text,
   * false otherwise.  This is purely a UI hack, you should never need to use
   * this method.
   *
   * @param hasBlankHelpText true if the field needs to print a blank (&nbsp;)
   *        help text, false otherwise
   */
  void setHasBlankHelpText(boolean hasBlankHelpText)
  {
    _hasBlankHelpText = hasBlankHelpText;
  }

  /**
   * Returns true if the field needs to print a blank (&nbsp;) help text,
   * false otherwise. This is purely a UI hack, you should never need to use
   * this method.
   *
   * @return true if the field needs to print a blank (&nbsp;) help text, false
   *         otherwise.
   */
  boolean hasErrorHelpText()
  {
    return _hasBlankHelpText;
  }
}