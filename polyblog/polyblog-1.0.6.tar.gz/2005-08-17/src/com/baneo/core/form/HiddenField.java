/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.form;

import java.io.*;

/**
 * HiddenField.
 *
 * @author  Laurent Boatto
 * @version $Id$
 */
public class HiddenField extends Field
{
  public HiddenField(String name)
  {
    _name = name;
  }

  /**
   * Returns null as an HiddenField should never has the focus.
   *
   * @return null as an HiddenField should never has the focus.
   */
  public String getFocusFieldName()
  {
    return null;
  }

  public void printBody() throws IOException
  {
    if (_value != null)
    {
      _out.print("<input type=hidden name=" + _name + " value=\"" + escapeStringValue((String) _value) + "\">");
    }
  }
}
