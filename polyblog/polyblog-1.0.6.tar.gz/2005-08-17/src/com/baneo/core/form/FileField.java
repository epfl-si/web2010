/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.form;

import java.io.*;

/**
 * FileField.
 *
 * @author  Laurent Boatto
 * @version $Id$
 */

public class FileField extends Field
{
  private int _size;

  /**
   * Constructor.
   *
   * @param name the field name.
   * @param label the field label.
   * @param required true if the field is required, false otherwise.
   * @param size the field size.
   */
  public FileField(String name, String label, boolean required, int size)
  {
    super(name, label, required);

    _size = size;
  }

  public void printBody() throws IOException
  {
    printFieldStart();

    _out.print("<input type=file name=" + getName());

    if (_size != 0)
    {
      _out.print(" size=" + _size);
    }
    if (_styleClass != null)
    {
      _out.print(" class=" + _styleClass);
    }

    _out.print(">");

    printFieldEnd();
  }

  /**
   * Returns the field size.
   *
   * @return the field size.
   */
  public int getSize()
  {
    return _size;
  }

  /**
   * Sets the field size.
   *
   * @param size the field size.
   */
  public void setSize(int size)
  {
    _size = size;
  }
}
