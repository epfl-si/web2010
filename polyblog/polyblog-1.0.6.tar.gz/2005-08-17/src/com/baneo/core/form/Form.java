/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.form;

import com.baneo.core.system.*;
import org.apache.struts.action.*;
import org.apache.struts.taglib.html.*;

import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.io.*;
import java.util.*;

/**
 * An HTML form, containing various fields (input types, text, textarea, file,
 * etc.).
 *
 * @author  Laurent Boatto
 * @version $Id$
 * @see com.baneo.core.form.Field
 */

abstract public class Form
{
  /**
   * The POST method.
   */
  public static final String METHOD_POST = "POST";
  /**
   * The GET method.
   */
  public static final String METHOD_GET = "GET";

  /**
   * Mode INSERT, used when the form is used to create a new object.
   */
  public static final int MODE_INSERT = 0;

  /**
   * Mode UPDATE, used when the form is used to update an existing object.
   */
  public static final int MODE_UPDATE = 1;

  /**
   * The encoding type used when the form contains a file field.
   */
  public static final String ENCTYPE_MULTIPART_FORM_DATA = "multipart/form-data";

  /**
   * The CSS style used to print the help text.
   */
  public static final String CSS_HELP_TEXT = "formHelp";

  /**
   * The CSS style used to print the form header.
   */
  public static final String CSS_HEADER = "formHeader";

  /**
   * The CSS style used to print the form box.
   */
  public static final String CSS_BOX = "formBox";

  /**
   * The request attribute used to store the form values.
   */
  public static final String ATTRIBUTE_VALUES = "values";

  /**
   * The request attribute used to store the form errors.
   */
  public static final String ATTRIBUTE_ERRORS = "errors";

  private Map _values;
  private Map _errors;
  private List _fields = new ArrayList();
  private int _mode;
  protected PageContext _pageContext;
  protected HttpSession _session;
  protected HttpServletRequest _request;
  protected Locale _locale;
  protected JspWriter _out;

  /**
   * The name of the form.
   */
  private String _name;
  private String _method = METHOD_POST;
  private String _action;
  private String _enctype;
  private String _width = "100%";
  private boolean _showRequiredString = true;
  private boolean _showHelpText = true;
  private boolean _showAdvice = true;
  private String _requiredString = "<font class=required>*</font>";
  private String _labelSeparator = " :";
  private String _submitButtonLabel;
  private String _errorSeparator = " :";
  private String _formHeader;
  private boolean _showBox = true;
  private String _language = "fr";
  private String _errorHeaderBgColor = "#FCD6D6";
  private String _focusField;

  /**
   * Constructs a new form.
   *
   * @param context the PageContext.
   * @param action the form URL action (without the context path).
   * @param mode the form mode (use Form.MODE_UPDATE and Form.MODE_INSERT).
   * @param values the form values, can be null.
   * @param errors the form errors, can be null.
   */
  public Form(PageContext context, String action, int mode, Map values, Map errors)
  {
    _pageContext = context;
    _action = action;
    _session = context.getSession();
    _request = (HttpServletRequest) context.getRequest();
    _locale = _request.getLocale();
    _out = context.getOut();
    _mode = mode;
    _values = values;
    _errors = errors;

    // Locale specific strings
    Locale locale = _request.getLocale();
    _submitButtonLabel = Message.get("com.baneo.core.form.Form.submitButtonLabel", locale);
  }

  /**
   * Constructs a new form.
   *
   * @param context the PageContext.
   * @param action the form URL action (without the context path).
   * @param mode the form mode (use Form.MODE_UPDATE and Form.MODE_INSERT).
   */
  public Form(PageContext context, String action, int mode)
  {
    this(context, action, mode, null, null);

    // we retrieve the values and errors from the request
    _values = (Map) context.getRequest().getAttribute(ATTRIBUTE_VALUES);
    _errors = (Map) context.getRequest().getAttribute(ATTRIBUTE_ERRORS);
  }

  /**
   * Prints the form.
   *
   * @throws IOException if an I/O error occurs.
   */
  public void print() throws IOException
  {
    // First we set the form properties
    initForm();
    // ClassifiedCheckTestCase that everything we need has been set
    checkInit();
    // Then we initialize the fields
    initFields();
    // We add the fields to the form
    addFields();
    // We prepare the form
    prepare();
    printFormStart();

    for (int i = 0; i < _fields.size(); i++)
    {
      ((Field) _fields.get(i)).print();
    }

    printFormEnd();
  }

  /**
   * Checks that the form has been initialized properly.
   */
  private void checkInit()
  {
    // We need to have a form name, otherwise it's impossible to
    // set the focus on a form input with javascript.
    if (_name == null)
    {
      throw new IllegalStateException("It's mandatory to set the form name (with the setName(String) method) in initForm().");
    }
  }

  /**
   * Prepare the form before printing it.
   */
  void prepare()
  {
    // The helpTextRowSpan is bigger if one or more of the following fields
    // has an error, we need to reset it for each field.
    for (int i = 0; i < _fields.size(); i++)
    {
      Field current = (Field) _fields.get(i);

      // How many extra rowSpan do we have?
      int extraHelpTextRowSpan = current.getHelpTextRowSpan() - 1;

      // The field advice use a row, so even if the helpTextRowSpan equals 2,
      // we have no extra rowSpan.
      if (current.getAdvice() != null)
      {
        extraHelpTextRowSpan--;
      }

      // How many extraRowSpan do we need? We look at the following fields
      // to see if they have an error to see that.
      int neededExtraRowSpan = 0;

      for (int j = 0; j < extraHelpTextRowSpan; j++)
      {
        Field followingField = (Field) _fields.get(i + j + 1);

        if (followingField.hasError())
        {
          neededExtraRowSpan++;
          // UI hack, we must not put any "<td>" here, this is used
          // in printError()
          followingField.setHasBlankHelpText(false);
        }
      }

      current.setHelpTextRowSpan(current.getHelpTextRowSpan() + neededExtraRowSpan);
    }
  }

  /**
   * Adds the given field to the form.
   *
   * @param field the field to add to the form.
   */
  public void addField(Field field)
  {
    if (field == null)
    {
      return;
    }

    setupField(field);

    // If we got a GroupField we need to setup it's inner fields.
    if (field instanceof GroupField)
    {
      Collection subfields = ((GroupField) field).getFields();

      for (Iterator iterator = subfields.iterator(); iterator.hasNext();)
      {
        addField((Field) iterator.next());
      }
    }

    _fields.add(field);
  }

  /**
   * Setup the field.
   *
   * @param field the field to setup.
   */
  private void setupField(Field field)
  {
    field.setForm(this);

    // Set the value
    // We do not set the value if it's null because it could have been
    // set earlier directly in the Form.
    if (_values != null && field.getValue() == null)
    {
      String[] inputs = field.getInputs();

      for (int i = 0; i < inputs.length; i++)
      {
        String input = inputs[i];

        if (_values.get(input) != null)
        {
          if (inputs.length > 1)
          {
            field.addValue(input, _values.get(input));
          }
          else
          {
            field.setValue(_values.get(input));
          }
        }
      }
    }

    // Set the error
    if (_errors != null)
    {
      String[] inputs = field.getInputs();

      for (int i = 0; i < inputs.length; i++)
      {
        String input = inputs[i];

        if (_errors.get(input) != null)
        {
          field.setError((String) _errors.get(input));
          // We allow only one error per field
          break;
        }
      }
    }

    field.setOut(_out);
    field.setPageContext(_pageContext);
  }

  /**
   * Removes the given field from the form.
   *
   * @param field the field to remove from the form.
   */
  public void removeField(Field field)
  {
    _fields.remove(field);
  }

  /**
   * Prints the form start.
   *
   * @throws IOException if an I/O error occurs.
   */
  protected void printFormStart() throws IOException
  {
    _out.print("<form");

    if (_name != null)
    {
      _out.print(" name=\"" + _name + "\"");
    }

    if (_method != null)
    {
      _out.print(" method=\"" + _method + "\"");
    }

    if (_action != null)
    {
      _out.print(" action=\"" + _request.getContextPath() + _action + "\"");
    }

    if (_enctype != null)
    {
      _out.print(" enctype=\"" + _enctype + "\"");
    }

    _out.print(">");

    printHiddenToken();

    /** todo let the user choose the cellpadding */
    if (_showBox)
    {
      _out.print("<table width=" + _width + " class=" + CSS_BOX + " cellpadding=3>");
    }
    else
    {
      _out.print("<table width=" + _width + " cellpadding=3>");
    }

    if (_formHeader != null)
    {
      _out.print("<tr><td colspan=" + numColumns() + " class=" + CSS_HEADER + ">" + _formHeader + "</td></tr>");
    }

    // Print the error header, if any
    printErrorHeader();

    if (_showBox)
    {
      printBlankLine();
    }

    _out.print("</tr>");
  }

  /**
   * Prints the form end.
   *
   * @throws IOException if an I/O error occurs.
   */
  protected void printFormEnd() throws IOException
  {
    printSubmitLine();
    _out.print("</table>");
    _out.print("</form>");
    setFocusOnRelevantField();
  }

  /**
   * Sets the focus (with JavaScript) on the relevant field, which is the
   * focusField if it's set, or if the form is printed for the first time the
   * first field, otherwise if the form has errors on the first field that
   * has an error.
   *
   * @throws IOException if an I/O error occurs.
   */
  private void setFocusOnRelevantField() throws IOException
  {
    // The focusField takes precedence over the first form field and first
    // error field
    if (_focusField != null)
    {
      printFocusScript(_focusField);
      return;
    }

    String focusField = null;

    // If the form has errors, the focus is on the first field with an error.
    if (hasErrors())
    {
      for (int i = 0; i < _fields.size(); i++)
      {
        Field field = (Field) _fields.get(i);

        if (field.hasError())
        {
          focusField = field.getFocusFieldName();
          break;
        }
      }

      printFocusScript(focusField);
    }
    // If we have the Form has no errors, the focus is on the first field that
    // has a focusField (LabelField for example has no focusField).
    else
    {
      for (int i = 0; i < _fields.size(); i++)
      {
        Field field = (Field) _fields.get(i);

        if (field.getFocusFieldName() != null)
        {
          focusField = field.getFocusFieldName();
          break;
        }
      }

      printFocusScript(focusField);
    }
  }

  /**
   * Prints the focus field
   * @throws IOException
   */
  private void printFocusScript(String focusField) throws IOException
  {
    _out.print("<script>var f=document." + _name + "." + focusField + ";f.focus();var r=f.createTextRange;if(r){var s=r();s.collapse(false);s.select();}</script>");
  }

  /**
   * Prints the header error.
   *
   * @throws IOException if an I/O error occurs.
   */
  protected void printErrorHeader() throws IOException
  {
    if (_errors == null)
    {
      return;
    }

    int numErrors = _errors.size();

    if (numErrors < 1)
    {
      return;
    }

    _out.print("<tr><td");

    if (_errorHeaderBgColor != null)
    {
      _out.print(" bgcolor=" + _errorHeaderBgColor);
    }

    _out.print(" colspan=" + numColumns() + ">");

    // If the box is not print, there is no need for a space around the
    // header error message
    if (_showBox)
    {
      _out.print("<br>&nbsp;");
    }

    if (numErrors > 1)
    {
      _out.print(Message.format("com.baneo.core.form.Form.errorHeaderPlural", _request.getLocale(), new Integer(numErrors)));
    }
    else
    {
      _out.print(Message.get("com.baneo.core.form.Form.errorHeaderSingular", _request.getLocale()));
    }

    // If the box is not print, there is no need for a space around the
    // header error message
    if (_showBox)
    {
      _out.print("<br>&nbsp;");
    }

    _out.print("</td>");

    _out.print("</tr>");

    if (!_showBox)
    {
      printBlankLine();
    }
  }

  /**
   * Prints the help text.
   *
   * @param helpText the help text.
   * @throws IOException if an I/O error occurs.
   */
  protected void printHelpText(String helpText) throws IOException
  {
    if (!_showHelpText || helpText == null)
    {
      return;
    }

    _out.print("<td class=" + Form.CSS_HELP_TEXT + ">");
    _out.print(helpText);
    _out.print("</td>");
  }

  /**
   * Prints a blank line.
   *
   * @throws IOException if an I/O error occurs.
   */
  protected void printBlankLine() throws IOException
  {
    // If we print the help text, we have 3 columns, otherwise 2.
    if (_showHelpText)
    {
      _out.print("<tr><td colspan=2>&nbsp;</td><td class=" + Form.CSS_HELP_TEXT + ">&nbsp;</td></tr>");
    }
    else
    {
      _out.print("<tr><td>&nbsp;</td><td>&nbsp;</td>");
    }
  }

  /**
   * Prints a section line. A section separate the form in multiple parts.
   *
   * @param sectionLabel the section label
   * @throws IOException if an I/O error occurs.
   */
  protected void printSectionLine(String sectionLabel) throws IOException
  {
    printBlankLine();
    _out.print("<tr><td colspan=" + numColumns() + " class=" + CSS_HEADER + ">" + sectionLabel + "</td></tr>");
    printBlankLine();
  }

  /**
   * Prints the submit line.
   *
   * @throws IOException if an I/O error occurs.
   */
  protected void printSubmitLine() throws IOException
  {
    // Note : we set the column width here at the end, for UI issues : if we
    // do not show the box we cannot print a blank line at the beginning with
    // the width
    if (_showHelpText)
    {
      _out.print("<tr><td width=22%>&nbsp;</td><td width=33%><td width=45% class=" + Form.CSS_HELP_TEXT + ">&nbsp;</td></tr>");
    }
    else
    {
      _out.print("<tr><td width=22%>&nbsp;</td><td width=78%>&nbsp;</td>");
    }

    _out.print("<tr>");

    _out.print("<td align=right");

    // If we don't show the box, the background is white
    if (_showBox)
    {
      _out.print(" class=" + CSS_HEADER);
    }

    _out.print("><input type=submit name=" + _name + ".submit value=\""
        + _submitButtonLabel + "\">");

    _out.print("</td>");

    _out.print("<td");

    if (_showHelpText)
    {
      _out.print(" colspan=2");
    }

    // If we don't show the box, the background is white
    if (_showBox)
    {
      _out.print(" class=" + CSS_HEADER);
    }

    _out.print(">&nbsp;</td>");

    _out.print("</tr>");
  }

  /**
   * Prints the hidden token, used to ensure that the user will not post
   * the same form several times.
   *
   * @throws IOException if an I/O error occurs.
   */
  protected void printHiddenToken() throws IOException
  {
    _out.print("<input type=hidden name=\"" + Constants.TOKEN_KEY +
        "\" value=\"" + _session.getAttribute(Action.TRANSACTION_TOKEN_KEY) + "\">");
  }

  /**
   * Returns the number of columns for the table form. If we print the
   * help text, we have 3 columns, otherwise 2.
   * <p>
   * This is used in colspan=x
   *
   * @return The number of columns for the table form
   */
  protected int numColumns()
  {
    if (_showHelpText)
    {
      return 3;
    }
    else
    {
      return 2;
    }
  }

  /**
   * Returns true if the form has errors, false otherwise.
   *
   * @return true if the form has errors, false otherwise.
   */
  protected boolean hasErrors()
  {
    if (_errors == null)
    {
      return false;
    }
    else
    {
      return !_errors.isEmpty();
    }
  }

  /**
   * Returns the form name.
   *
   * @return the form name.
   */
  public String getName()
  {
    return _name;
  }

  /**
   * Sets the form name.
   *
   * @param name the form name.
   */
  public void setName(String name)
  {
    _name = name;
  }

  /**
   * Returns the form method. (By default it's set to POST).
   *
   * @return the form method.
   */
  public String getMethod()
  {
    return _method;
  }

  /**
   * Sets the form method. (By default it's set to POST).
   *
   * @param method the form method.
   */
  public void setMethod(String method)
  {
    _method = method;
  }

  /**
   * Returns the form action.
   *
   * @return the form action.
   */
  public String getAction()
  {
    return _action;
  }

  /**
   * Sets the form action.
   *
   * @param action the form action.
   */
  public void setAction(String action)
  {
    _action = action;
  }

  /**
   * Returns the form enctype.
   *
   * @return the form enctype.
   */
  public String getEnctype()
  {
    return _enctype;
  }

  /**
   * Sets the form enctype.
   *
   * @param enctype the form enctype.
   */
  public void setEnctype(String enctype)
  {
    _enctype = enctype;
  }

  /**
   * Sets the form width.
   *
   * @param width the form width.
   */
  public void setWidth(String width)
  {
    _width = width;
  }

  /**
   * Sets the submit button label.
   *
   * @param submitButtonLabel the submit button label.
   */
  public void setSubmitButtonLabel(String submitButtonLabel)
  {
    _submitButtonLabel = submitButtonLabel;
  }

  /**
   *
   */
  public void setErrorSeparator(String errorSeparator)
  {
    _errorSeparator = errorSeparator;
  }

  /**
   * Returns the error separator.
   */
  public String getErrorSeparator()
  {
    return _errorSeparator;
  }

  /**
   *
   */
  public void setFormHeader(String formHeader)
  {
    _formHeader = formHeader;
  }

  /**
   *
   */
  public void setShowBox(boolean showBox)
  {
    _showBox = showBox;
  }

  /**
   * Returns the background color used for the error header.
   *
   * @return the background color used for the error header.
   */
  public String getErrorHeaderBgColor()
  {
    return _errorHeaderBgColor;
  }

  /**
   * Sets the background color used for the error header.
   *
   * @param errorHeaderBgColor the background color used for the error header.
   */
  public void setErrorHeaderBgColor(String errorHeaderBgColor)
  {
    _errorHeaderBgColor = errorHeaderBgColor;
  }

  public boolean getShowRequiredString()
  {
    return _showRequiredString;
  }

  public void setShowRequiredString(boolean showRequiredString)
  {
    _showRequiredString = showRequiredString;
  }

  public String getRequiredString()
  {
    return _requiredString;
  }

  public void setRequiredString(String requiredString)
  {
    _requiredString = requiredString;
  }

  public String getLabelSeparator()
  {
    return _labelSeparator;
  }

  public void setLabelSeparator(String labelSeparator)
  {
    _labelSeparator = labelSeparator;
  }

  public int getMode()
  {
    return _mode;
  }

  public void setMode(int mode)
  {
    _mode = mode;
  }

  /**
   * Returns the form values.
   *
   * @return the form values.
   */
  public Map getValues()
  {
    return _values;
  }

  /**
   * Returns the form value having the given key.
   *
   * @param key the form value key.
   * @return the form value having the given key.
   */
  public Object getValue(Object key)
  {
    return _values.get(key);
  }

  /**
   * Sets the form values.
   *
   * @param values the form values.
   */
  public void setValues(Map values)
  {
    _values = values;
  }

  /**
   * Sets the value for the given key.
   *
   * @param key the key.
   * @param value the value.
   */
  public void setValue(Object key, Object value)
  {
    _values.put(key, value);
  }

  /**
   * Returns the form errors.
   *
   * @return the form errors.
   */
  public Map getErrors()
  {
    return _errors;
  }

  /**
   * Sets the form errors.
   *
   * @param errors the form errors.
   */
  public void setErrors(Map errors)
  {
    _errors = errors;
  }

  public boolean getShowHelpText()
  {
    return _showHelpText;
  }

  public void setShowHelpText(boolean showHelpText)
  {
    _showHelpText = showHelpText;
  }

  public boolean getShowAdvice()
  {
    return _showAdvice;
  }

  public void setShowAdvice(boolean showAdvice)
  {
    _showAdvice = showAdvice;
  }

  /**
   * Returns the field where the focus will be set (with javascript) when the
   * form is printed.
   *
   * @return the field where the focus will be set (with javascript) when the
   *         form is printed.
   */
  public String getFocusField()
  {
    return _focusField;
  }

  /**
   * Sets the field where the focus will be set (with javascript) when the form
   * is printed. Beware that the form normally automatically sets the focus on
   * the first field of the form, or on the first field that has an error.
   * Setting a focusField will override this behavior.
   *
   * @param focusField the field where the focus will be set (with javascript)
   *        when the form is printed.
   */
  public void setFocusField(String focusField)
  {
    _focusField = focusField;
  }

  /**
   * Returns the form language (ISO 639 language code, see
   * http://www.ics.uci.edu/pub/ietf/http/related/iso639.txt).
   *
   * @return the form language.
   */
  public String getLanguage()
  {
    return _language;
  }

  /**
   * Sets the form language (ISO 639 language code, see
   * http://www.ics.uci.edu/pub/ietf/http/related/iso639.txt).
   *
   * @param language the form language (ISO 639 language code, see
   *        http://www.ics.uci.edu/pub/ietf/http/related/iso639.txt).
   */
  public void setLanguage(String language)
  {
    _language = language;
  }

  /**
   * Returns true if the form is in mode MODE_INSERT.
   *
   * @return true if the form is in mode MODE_INSERT.
   */
  public boolean isInsertMode()
  {
    return _mode == MODE_INSERT;
  }

  /**
   * Returns true if the form is in mode MODE_UPDATE.
   *
   * @return true if the form is in mode MODE_UPDATE.
   */
  public boolean isUpdateMode()
  {
    return _mode == MODE_UPDATE;
  }

  /**
   * Init the form by setting it's properties like the name (mandatory), method,
   * header, etc.
   */
  protected abstract void initForm();

  /**
   * Init the form fields.
   */
  protected abstract void initFields();

  /**
   * Add the fields to the form.
   */
  protected abstract void addFields();
}