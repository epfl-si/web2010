/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.form;

import java.io.*;

/**
 * SectionField.
 *
 * @author Laurent Boatto
 * @version $Id$
 */

public class SectionField extends Field
{
  /**
   * Constructs a new SectionField with the given label.
   *
   * @param label
   */
  public SectionField(String name, String label)
  {
    super(name, label, false);
  }

  protected void printBody() throws IOException
  {
    getForm().printSectionLine(_label);
  }
}
