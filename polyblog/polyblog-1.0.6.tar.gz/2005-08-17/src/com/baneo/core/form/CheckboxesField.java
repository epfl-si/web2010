/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.form;

import javax.servlet.http.*;
import java.io.*;
import java.util.*;

/**
 * Field with a lot of checkboxes (more than 20). The checkboxes are printed
 * on the left on 2 columns, therefore there is no Field label and no
 * required star printed.
 *
 * @author Laurent Boatto
 * @version $Id$
 */

public class CheckboxesField extends Field
{
  private Map _options;

  /**
   * Constructs a new CheckboxesField.
   *
   * @param name the field name.
   */
  public CheckboxesField(String name)
  {
    _name = name;
  }

  protected void printBody() throws IOException
  {
    _out.print("<tr><td colspan=2>");

    _out.println("<table width=100% cellspacing=0><tr><td width=50% nowrap>");

    int size = _options.size();
    int middle = (int) Math.ceil((float) size / 2);
    int i = 0;
    boolean split = false;

    transformValue();
    String[] value = (String[]) getValue();

    // Transform the value as a Map, it will be faster for value checking
    Map valueMap = null;
    if (value != null)
    {
      valueMap = new HashMap();
      for (int j = 0; j < value.length; j++)
      {
        valueMap.put(value[j], null);
      }
    }

    Collection optionValues = _options.keySet();

    for (Iterator iterator = optionValues.iterator(); iterator.hasNext();)
    {
      String optionValue = (String) iterator.next();
      String optionLabel = (String) _options.get(optionValue);

      if ((i == middle) && !split)
      {
        _out.print("</td><td nowrap>");
        split = true;
      }

      _out.print("<input type=checkbox name=" + _name + " value=" + (i + 1));

      if (valueMap != null && valueMap.containsKey(String.valueOf(i + 1)))
      {
        _out.println(" checked");
      }

      _out.print("> " + optionLabel + "<br>");

      i++;
    }

    _out.print("</td></tr></table>");

    _out.println("</td>");

    printFieldEnd();
  }

  /**
   * Returns the field options.
   *
   * @return the field options.
   */
  public Map getOptions()
  {
    return _options;
  }

  /**
   * Sets the field options.
   *
   * @param options the field options.
   */
  public void setOptions(Map options)
  {
    _options = options;
  }

  public static Object requestToValue(HttpServletRequest request, String parameter)
  {
    String[] parameterValues = request.getParameterValues(parameter);

    if (parameterValues == null)
    {
      return null;
    }

    Map parameterMap = new HashMap();

    int max = 0;

    for (int i = 0; i < parameterValues.length; i++)
    {
      int value = Integer.parseInt(parameterValues[i]);

      if (value > max)
      {
        max = value;
      }

      parameterMap.put(new Integer(value), null);
    }

    StringBuffer result = new StringBuffer(max);

    for (int i = 1; i <= max; i++)
    {
      if (parameterMap.containsKey(new Integer(i)))
      {
        result.append('1');
      }
      else
      {
        result.append('0');
      }
    }

    return result.toString();
  }

  /**
   * Transforms the Field value from a String to a String[] if needed. The
   * transformation is needed because the value is often persisted as a simple
   * String, not a String[] (e.g. in a database).
   */
  private void transformValue()
  {
    if (_value != null && _value instanceof String)
    {
      String value = (String) _value;
      int length = value.length();
      int count = 0;
      List result = new ArrayList();

      for (int i = 0; i < length; i++)
      {
        if (value.charAt(i) == '1')
        {
          result.add(String.valueOf(i + 1));
          count++;
        }
      }

      _value = result.toArray(new String[count]);
    }
  }

}