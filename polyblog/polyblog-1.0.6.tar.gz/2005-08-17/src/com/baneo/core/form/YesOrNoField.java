/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.form;

import com.baneo.core.system.*;

import java.io.*;
import java.util.*;

/**
 * A field with two radio buttons, yes and no. The yes and no labels must be
 * defined in the application ResourceBundle with the following keys :
 * <p>
 * com.baneo.core.form.YesOrNoField.yes<br>
 * com.baneo.core.form.YesOrNoField.no
 * </p>
 * The "yes" value is 1, "no" is 2. These are definied as the class static
 * fields VALUE_YES and VALUE_NO.
 *
 * @author Laurent Boatto
 * @version $Id$
 */

public class YesOrNoField extends Field
{
  /**
   * The value used for a "Yes".
   */
  public static final String VALUE_YES = "1";

  /**
   * The value used for a "No".
   */
  public static final String VALUE_NO = "2";

  private String _labelYes;
  private String _labelNo;

  /**
   * Constructs a new YesOrNoField.
   *
   * @param name the field name.
   * @param label the field label.
   * @param locale the locale used to retrieve the "Yes" and "No" labels.
   * @param required true if the field is required, false otherwise.
   */
  public YesOrNoField(String name, String label, Locale locale, boolean required)
  {
    super(name, label, required);
    _labelYes = Message.get("com.baneo.core.form.YesOrNoField.yes", locale);
    _labelNo = Message.get("com.baneo.core.form.YesOrNoField.no", locale);
  }

  public void printBody() throws IOException
  {
    printFieldStart();

    String value = (String) getValue();

    _out.print("<input type=radio name=" + _name + " value=" + VALUE_YES);

    if (value != null && value.equals(VALUE_YES))
    {
      _out.print(" checked");
    }

    _out.print("> " + _labelYes + " ");

    _out.print("<input type=radio name=" + _name + " value=" + VALUE_NO);

    if (value != null && value.equals(VALUE_NO))
    {
      _out.print(" checked");
    }

    _out.print("> " + _labelNo);

    printFieldEnd();
  }
}