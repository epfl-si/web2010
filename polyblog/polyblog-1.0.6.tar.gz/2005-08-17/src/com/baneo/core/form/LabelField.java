/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.form;

import java.io.*;

/**
 * A label field, simply printing the field value. This is used when a
 * field value cannot be changed by the user.
 *
 * @author  Laurent Boatto
 * @version $Id$
 */
public class LabelField extends Field
{
  public LabelField(String name, String label)
  {
    _name = name;
    _label = label;
  }

  /**
   * Returns null as a LabelField should never has the focus.
   *
   * @return null as a LabelField should never has the focus.
   */
  public String getFocusFieldName()
  {
    return null;
  }

  public void printBody() throws IOException
  {
    printFieldStart();

    if (_value != null)
    {
      _out.print((String) _value);
    }

    printFieldEnd();
  }
}
