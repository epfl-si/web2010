/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */
package com.baneo.core.form;

import com.baneo.core.system.*;

import java.io.*;

/**
 * MultipleFileWithCheckboxField.
 *
 * @author  Lilian Robert
 * @version $Id$
 */
public class MultipleFileWithCheckboxField extends FileWithCheckboxField
{
  /**
   * the base name of the html checkbox fields
   */
  private String _checkboxName;

  /**
   * the number of html file fields to generate
   */
  private int _maxNumberOfFields;

  /**
   * the number of html fiel fields displayed originally
   */
  private int _displayedFieldsCount;

  /**
   * @param fileName the name of the file field.
   * @param fileLabel the label of the file field.
   * @param checkboxName the name of the checkbox field.
   * @param checkboxLabel the label of the checkbox field.
   * @param required true if the field is required, false otherwise.
   * @param size the field size.
   */
  public MultipleFileWithCheckboxField(String fileName, String fileLabel, String checkboxName, String checkboxLabel, boolean required, int size, int maxNumberOfFields, int displayedFieldsCount)
  {
    super(fileName, fileLabel, checkboxName, checkboxLabel, required, size);
    _checkboxName = checkboxName;
    setMaxNumberOfFields(maxNumberOfFields);
    setDisplayedFieldsCount(displayedFieldsCount);
  }

  public void printBody() throws IOException
  {
    /** todo include the code directly in this class */
    _out.print("<script language=\"javascript\" src=\"/tools.js\"></script>\r\n");

    int i = 0;

    for (; i < getDisplayedFieldsCount(); i++)
    {
      printFileField(i, true, i == getDisplayedFieldsCount() - 1);
    }

    for (; i < getMaxNumberOfFields(); i++)
    {
      printFileField(i, false, false);
    }

    String label = Message.get("com.baneo.core.form.MultipleFileWithCheckboxField.addAnotherFile", _pageContext.getRequest().getLocale());

    _out.println("<tr id=\"addLink\"><td colspan=2><a href=\"javascript:addFileField()\">" + label + "</a></td></tr>");
  }

  protected void printFileField(int number, boolean visible, boolean linkVisible) throws IOException
  {
    printFieldStart(visible, number);

    _out.print("\r\n<input type=file name=" + getName() + number);

    if (_size != 0)
    {
      _out.print(" size=" + _size);
    }
    if (_styleClass != null)
    {
      _out.print(" class=" + _styleClass);
    }

    _out.print(">");

    String checkBoxValue = (String) getValues().get(_checkboxName);

    printCheckBox(checkBoxValue, number);

    printFieldEnd();
  }

  protected void printCheckBox(String checkboxValue, int number) throws IOException
  {
    _out.print(" <input type=checkbox value=true id=" + _checkboxName + number + " name=" + _checkboxName + number);

    if (checkboxValue != null && !checkboxValue.equals("false"))
    {
      _out.print(" checked");
    }

    _out.print("> <label for=" + _checkboxName + number + ">" + _checkboxLabel + "</label>");
  }

  public int getDisplayedFieldsCount()
  {
    return _displayedFieldsCount;
  }

  public void setDisplayedFieldsCount(int fieldsCount)
  {
    _displayedFieldsCount = fieldsCount;

    if (_displayedFieldsCount < 1)
    {
      _displayedFieldsCount = 1;
    }

    if (_displayedFieldsCount > _maxNumberOfFields)
    {
      _displayedFieldsCount = _maxNumberOfFields;
    }
  }

  public int getMaxNumberOfFields()
  {
    return _maxNumberOfFields;
  }

  public void setMaxNumberOfFields(int numberOfFields)
  {
    _maxNumberOfFields = numberOfFields;

    if (_displayedFieldsCount > _maxNumberOfFields)
    {
      _displayedFieldsCount = _maxNumberOfFields;
    }
  }

  protected void printFieldStart(boolean visible, int number) throws IOException
  {
    _out.print("<tr id=\"ligne" + number + "\"");

    if (!visible)
    {
      _out.print(" style=\"display: none\"");
    }

    _out.println(">");
    printLabel();
    _out.print("<td>");
  }

  protected void printFieldEnd() throws IOException
  {
    printSuffix();
    printRequiredString();
    _out.print("</td>");
    printHelpText();
    _out.print("</tr>");
    printAdvice();
  }
}