/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.form;

import java.io.*;

/**
 * A field with a checkbox.
 *
 * @author  Laurent Boatto
 * @version $Id$
 */

public class CheckboxField extends Field
{
  /**
   * Constructs a new CheckboxField with the given name, label, and required
   * boolean.
   *
   * @param name the Field name.
   * @param label the Field label.
   * @param required true if the field is required, false otherwise.
   */
  public CheckboxField(String name, String label, boolean required)
  {
    super(name, label, required);
  }

  protected void printBody() throws IOException
  {
    printFieldStart();

    _out.print("<input type=checkbox value=true name=" + _name);

    boolean checked = Boolean.valueOf((String) getValue()).booleanValue();

    if (checked)
    {
      _out.print(" checked");
    }

    _out.print(">");

    printFieldEnd();
  }
}
