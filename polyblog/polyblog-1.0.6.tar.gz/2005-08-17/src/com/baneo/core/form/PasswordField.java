/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.form;

import java.io.*;

/**
 * PasswordField.
 *
 * @author Laurent Boatto
 * @version $Id$
 */

public class PasswordField extends Field
{
  private int _size;
  private int _maxLength;

  /**
   * Constructor.
   *
   * @param name the field name.
   * @param label the field label.
   * @param required true if the field is required, false otherwise.
   * @param size the field size.
   * @param maxLength the field maximum length.
   */
  public PasswordField(String name, String label, boolean required, int size, int maxLength)
  {
    super(name, label, required);
    _size = size;
    _maxLength = maxLength;
  }

  /**
   * Prints the field.
   */
  public void printBody() throws IOException
  {
    printFieldStart();

    String value = (String) getValue();

    _out.print("<input type=password name=" + getName());

    if (_size != 0)
    {
      _out.print(" size=" + _size);
    }
    if (_maxLength != 0)
    {
      _out.print(" maxlength=" + _maxLength);
    }
    if (_styleClass != null)
    {
      _out.print(" class=" + _styleClass);
    }

    if (value != null)
    {
      _out.print(" value=\"" + value + "\"");
    }

    _out.print(">");

    printFieldEnd();
  }

  /**
   * Returns the input size.
   *
   * @return the input size.
   */
  public int getSize()
  {
    return _size;
  }

  /**
   * Sets the input size.
   *
   * @param size the input size.
   */
  public void setSize(int size)
  {
    _size = size;
  }

  /**
   * Returns the input maxLength.
   *
   * @return the input maxLength.
   */
  public int getMaxLength()
  {
    return _maxLength;
  }

  /**
   * Sets the input maxLength.
   *
   * @param maxLength the input maxLength.
   */
  public void setMaxLength(int maxLength)
  {
    _maxLength = maxLength;
  }
}
