/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */
package com.baneo.core.form;

import java.io.*;

/**
 * FileField.
 *
 * @author  Laurent Boatto
 * @version $Id$
 */

public class FileWithCheckboxField extends Field
{
  protected int _size;
  protected String _checkboxName;
  protected String _checkboxLabel;

  /**
   * Constructor.
   *
   * @param fileName the name of the file field.
   * @param fileLabel the label of the file field.
   * @param checkboxName the name of the checkbox field.
   * @param checkboxLabel the label of the checkbox field.
   * @param required true if the field is required, false otherwise.
   * @param size the field size.
   */
  public FileWithCheckboxField(String fileName, String fileLabel, String checkboxName, String checkboxLabel, boolean required, int size)
  {
    super(fileName, fileLabel, required);
    _checkboxName = checkboxName;
    _checkboxLabel = checkboxLabel;
    _size = size;
  }

  public void printBody() throws IOException
  {
    printFieldStart();

    _out.print("<input type=file name=" + getName());

    if (_size != 0)
    {
      _out.print(" size=" + _size);
    }
    if (_styleClass != null)
    {
      _out.print(" class=" + _styleClass);
    }

    _out.print(">");

    String checkBoxValue = (String) getValues().get(_checkboxName);

    printCheckBox(checkBoxValue);

    printFieldEnd();
  }

  /**
   * Prints the field's checkbox.
   *
   * @param checkboxValue the checkbox value.
   * @throws IOException
   */
  protected void printCheckBox(String checkboxValue) throws IOException
  {
    _out.print(" <input type=checkbox value=true id=" + _checkboxName + " name=" + _checkboxName);

    if (checkboxValue != null && !checkboxValue.equals("false"))
    {
      _out.print(" checked");
    }

    _out.print("> <label for=" + _checkboxName  + ">" + _checkboxLabel + "</label>");
  }

  public String[] getInputs()
  {
    return new String[]{_name, _checkboxName};
  }

  /**
   * Returns the field size.
   *
   * @return the field size.
   */
  public int getSize()
  {
    return _size;
  }

  /**
   * Sets the field size.
   *
   * @param size the field size.
   */
  public void setSize(int size)
  {
    _size = size;
  }
}
