/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.form;

import java.io.*;

/**
 * A text input field.
 *
 * @author  Laurent Boatto
 * @version $Id$
 */
public class TextField extends Field
{
  private int _size;
  private int _maxLength = 255;
  private boolean _printValueIfZero = false;
  private String _prefix;

  /**
   * Constructor.
   *
   * @param name the field name.
   * @param label the field label.
   * @param required true if the field is required, false otherwise.
   * @param size the field size.
   * @param maxLength the field maximum length.
   */
  public TextField(String name, String label, boolean required, int size, int maxLength)
  {
    super(name, label, required);
    _size = size;
    _maxLength = maxLength;
  }

  /**
   * Prints the field.
   */
  public void printBody() throws IOException
  {
    printFieldStart();

    String value = (String) getValue();

    if (_prefix != null)
    {
      _out.print(_prefix);
    }

    _out.print("<input type=text name=" + getName());

    if (_size != 0)
    {
      _out.print(" size=" + _size);
    }
    if (_maxLength != 0)
    {
      _out.print(" maxlength=" + _maxLength);
    }
    if (_styleClass != null)
    {
      _out.print(" class=" + _styleClass);
    }

    if (value != null)
    {
      if (_printValueIfZero || !value.equals("0") && !value.equals("0.0"))
      {
        _out.print(" value=\"" + escapeStringValue(value) + "\"");
      }
    }

    _out.print(">");

    printFieldEnd();
  }

  /**
   * Returns the input size.
   *
   * @return the input size.
   */
  public int getSize()
  {
    return _size;
  }

  /**
   * Sets the input size.
   *
   * @param size the input size.
   */
  public void setSize(int size)
  {
    _size = size;
  }

  /**
   * Returns the input maximum length.
   *
   * @return the input maximum length.
   */
  public int getMaxLength()
  {
    return _maxLength;
  }

  /**
   * Returns the prefix, which is a String that's printed before the html input
   * field.
   *
   * @return the prefix, which is a String that's printed before the html input
   * field.
   */
  public String getPrefix()
  {
    return _prefix;
  }

  /**
   * Sets the prefix, which is a String that's printed before the html input
   * field.
   *
   * @param prefix the prefix.
   */
  public void setPrefix(String prefix)
  {
    _prefix = prefix;
  }


  /**
   * Sets the input maximum length (by default it's 255).
   *
   * @param maxLength the input maximum length.
   */
  public void setMaxLength(int maxLength)
  {
    _maxLength = maxLength;
  }

  /**
   * If true, the value will be printed if it's equal to "0" or "0.0", otherwise
   * it will be left blank.
   */
  public boolean printValueIfZero()
  {
    return _printValueIfZero;
  }

  /**
   * Set to true if you want the value to be printed if it's equal to "0"
   * or "0.0", false otherwise (the default is false).
   *
   * @param printValueIfZero true if you want the value to be printed if it's
   *        equal to "0" or "0.0", false otherwise (the default is false).
   */
  public void setPrintValueIfZero(boolean printValueIfZero)
  {
    _printValueIfZero = printValueIfZero;
  }
}
