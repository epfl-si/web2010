/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.validator;

/**
 * Thrown when a validator encounters a problem when trying to do it's
 * validation. This exception has nothing to do with a business exception,
 * it's a system exception, e.g. a validateXXX method could be inaccessible.
 *
 * @author  Laurent Boatto
 * @version $Id$
 */

public class ValidatorException extends RuntimeException
{
  /**
   * Constructs the ValidatorException with the specified  cause.
   *
   * @param cause the cause.
   */
  public ValidatorException(Throwable cause)
  {
    super(cause);
  }

  /**
   * Constructs the ValidatorException with the specified message and cause.
   *
   * @param message the error message.
   * @param cause the cause.
   */
  public ValidatorException(String message, Throwable cause)
  {
    super(message, cause);
  }
}