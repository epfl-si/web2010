/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.validator;

import com.baneo.core.system.*;
import com.baneo.core.util.*;
import org.apache.commons.beanutils.*;

import java.lang.reflect.*;
import java.util.*;

/**
 * A validator purpose is to validate the values received from an untrusted
 * source (e.g. a web user) and if there is no error, to populate the values
 * in the specified value object.
 * <p>
 * You need three things to validate and populate a value object :
 * <ol>
 *   <li>A value object, with setXXX methods for each attribute
 *   <li>A map of values, with key = attribute name, and value = attribute value
 *   <li>A mode, can be MODE_INSERT if you are validating a new value object, or
 *       MODE_UPDATE if you are validating an existing value object
 * </ol>
 * Usage example :
 * <p>
 * <pre>
 * // The value object we will validate
 * Category category = new Category();
 * // The values, this is usually populated from an HttpServletRequest, or else.
 * Map values = new Hashmap();
 * values.put("name", "Cars");
 * values.put("displayOrder", "1");
 * // Do the validation
 * Validator validator = new CategoryValidator(category, values, Validator.MODE_INSERT);
 * validator.validate();
 * // Here you can find the errors found in the validation.
 * // Key is attribute name, value is the corresponding error
 * Map errors = validator.getErrors();
 *
 * // If there is no error, this should be true, as the value object has been
 * // automatically populated :
 * "Cars".equals(category.getName())
 *
 * <p>
 * Note that you can also use a validator without a value object.
 *
 * @author  Laurent Boatto
 * @version $Id$
 */

public abstract class Validator
{
  /**
   * Mode used if you are validating a new object.
   */
  public static final int MODE_INSERT = 0;
  /**
   * Mode used if you are validating an existing object.
   */
  public static final int MODE_UPDATE = 1;

  /**
   * The object we are validating.
   */
  protected Object _object;

  /**
   * The validation mode.
   */
  protected int _mode;

  /**
   * The errors found during validation.
   */
  protected Map _errors = new HashMap();

  /**
   * The values to validate.
   */
  protected Map _values = new HashMap();

  /**
   * The locale used by the validator, mainly for retrieving the errors
   * messages.
   */
  protected Locale _locale;

  /**
   * The validator methods, see #findMethods
   */
  private Map _methods = new HashMap();

  /**
   * The attribute that is currently validated.
   */
  private String _currentValidatingAttribute;

  /**
   * Constructs a new validator with the given object, values, and mode.
   *
   * @param object the object to validate
   * @param values a Map having for the key the attribute name, and for the
   *        value the attribute value.
   * @param mode the mode for validation, can be MODE_INSERT if you are
   *        validating a new object, or MODE_UPDATE if you are validating an
   *        existing object (use static variables of this class for the mode).
   * @param locale the locale used to format the error messages, it can be null
   *        in which case the application default ResourceBundle will be used.
   */
  public Validator(Object object, Map values, int mode, Locale locale)
  {
    _object = object;
    _values = values;
    _mode = mode;
    _locale = locale;

    findMethods();
  }

  /**
   * Find the validator methods and put them in a map, with key = the method
   * name and value = the method itself. This is used later in validate().
   */
  private void findMethods()
  {
    Method[] methods = this.getClass().getMethods();

    for (int i = 0; i < methods.length; i++)
    {
      Method method = methods[i];
      _methods.put(method.getName(), method);
    }
  }

  /**
   * Validate the specified values by calling the various validateXXX() methods
   * (where XXX is the attribute name).
   *
   * @param values the values.
   */
  protected void validateValues(Map values)
  {
    Method method = null;
    String methodName = null;

    Iterator it = values.keySet().iterator();

    while (it.hasNext())
    {
      String key = (String) it.next();
      methodName = "validate" + StringUtil.upperCaseFirstChar(key);

      try
      {
        // We cannot find the method directly with Class.getMethod(String, Class)
        // because we don't know the parameter type, it could be anything, so
        // we first put all the methods in a Map (see findMethods()) and then
        // we find the method by it's name.
        method = (Method) _methods.get(methodName);

        if (method != null)
        {
          Object value = values.get(key);
          setCurrentValidatingAttribute(key);
          method.invoke(this, new Object[]{value});
        }
      }
          // If something goes wrong it's a progammation error, nothing that we
          // should catch.
      catch (InvocationTargetException ex)
      {
        throw new RuntimeException("InvocationTargetException for method " + methodName, ex);
      }
      catch (IllegalAccessException ex)
      {
        throw new RuntimeException("Illegal access for method " + methodName, ex);
      }
    }
  }

  /**
   * Populate the given object with the given values. This method is called at
   * the end, when the values have been validated. This ensure that you don't
   * have a "semi-valid" object.
   *
   * @param object the object to populate.
   * @param values the values, key = attribute name, value = attribue value.
   * @throws ValidatorException if an error occurs while populating the object.
   */
  protected void populateBean(Object object, Map values) throws ValidatorException
  {
    try
    {
      BeanUtils.populate(object, values);
    }
    catch (IllegalAccessException e)
    {
      throw new ValidatorException(e);
    }
    catch (InvocationTargetException e)
    {
      throw new ValidatorException(e);
    }
  }

  /**
   * Validate the values with the different validateXXX methods of the
   * validator. If there is no error, populate the object you gave in the
   * constructor with the values.
   *
   * @throws ValidatorException if an error occurs while populating the object.
   */
  public void validate() throws ValidatorException
  {
    validateValues(_values);

    if (this.getErrors().size() == 0 && _object != null)
    {
      populateBean(_object, _values);
    }
  }

  /**
   * Returns the errors, i.e. a Map with for the key the name of the attribute,
   * and for the value the corresponding error.
   *
   * @return the errors.
   */
  public Map getErrors()
  {
    return _errors;
  }

  /**
   * Returns the error having the given key, or null if it doesn't exist.
   *
   * @param key the error key.
   * @return the error having the given key, or null if it doesn't exist.
   */
  public String getError(String key)
  {
    if (_errors == null)
    {
      return null;
    }

    return (String) _errors.get(key);
  }

  /**
   * Returns the value having the given key, or null if it doesn't exist.
   *
   * @param key the value key.
   * @return the value having the given key, or null if it doesn't exist.
   */
  public Object getValue(String key)
  {
    if (_values == null)
    {
      return null;
    }

    return _values.get(key);
  }

  /**
   * Sets the value having the given key to the given value.
   *
   * @param key the value's key.
   * @param value the value's value.
   */
  public void setValue(Object key, Object value)
  {
    _values.put(key, value);
  }

  /**
   * Sets the error having the given key to the given value.
   *
   * @param key the error's key.
   * @param value the error's value.
   */
  public void setError(Object key, Object value)
  {
    _errors.put(key, value);
  }

  /**
   * Sets the given value to the current validating attribute.
   *
   * @param value the value's value.
   * @see #getCurrentValidatingAttribute()
   */
  protected void setValue(Object value)
  {
    _values.put(_currentValidatingAttribute, value);
  }

  /**
   * Saves the trimmed value of the current validating attribute and returns it.
   * This method excepts that the current validating attribute is a String and
   * is not null. This method is useful when you want to "correct" the value
   * without disturbing the user, e.g. if the value is "email@host.com " (with
   * a space at the end), the value will be set to "email@host.com".
   *
   * @return the trimmed value of the current validating attribute.
   */
  protected String saveTrimmedValue()
  {
    String value = (String) getValue(getCurrentValidatingAttribute());

    value = value.trim();
    _values.put(getCurrentValidatingAttribute(), value);
    return value;
  }

  /**
   * Removes all the whitespaces of the current validating attributes, saves it
   * and returns it.
   * This method excepts that the current validating attribute is a String and
   * is not null. This method is useful when you want to "correct" the value
   * without disturbing the user, e.g. if the value is "10 000 " the value will
   * be set to "10000".
   *
   * @return the value of the current validating attribute with all the
   *          whitespaces removed.
   */
  protected String saveWhitespaceRemovedValue()
  {
    String value = (String) getValue(getCurrentValidatingAttribute());

    value = StringUtil.removeWhitespace(value);
    _values.put(getCurrentValidatingAttribute(), value);
    return value;
  }

  /**
   * Saves the trimmed, lowercased value of the current validating attribute
   * and returns it. This method excepts that the current validating attribute
   * is a String and is not null. This method is useful when you want to
   * "correct" the value without disturbing the user, e.g. if the value is
   * "EMAIL@HOST.COM " (with a space at the end), the value will be set
   * to "email@host.com".
   *
   * @return the trimmed value of the current validating attribute.
   */
  public String saveTrimmedLowerCasedValue()
  {
    String value = (String) getValue(getCurrentValidatingAttribute());

    value = value.trim().toLowerCase();
    _values.put(getCurrentValidatingAttribute(), value);
    return value;
  }

  /**
   * Saves the trimmed, first char upper cased value of the current validating
   * attribute and returns it. This method excepts that the current validating
   * attribute is a String and is not null.  This method is useful when you want
   * to "correct" the value without disturbing the user, e.g. if the value is
   * "paris " (with a space at the end), the value will be set
   * to "Paris".
   *
   * @return the trimmed, first char upper cased value of the current validating
   *         attribute.
   */
  protected String saveTrimmedFirstCharUpperCasedValue()
  {
    String value = (String) getValue(getCurrentValidatingAttribute());

    value = StringUtil.upperCaseFirstChar(value.trim());
    _values.put(getCurrentValidatingAttribute(), value);
    return value;
  }

  /**
   * Returns the values, i.e. a Map with for the key the name of the attribute,
   * and for the value Object value.
   *
   * @return the values.
   */
  public Map getValues()
  {
    return _values;
  }

  /**
   * Returns the object we are validating.
   *
   * @return the  object we are validating.
   */
  public Object getObject()
  {
    return _object;
  }

  /**
   * Resets the errors.
   */
  public void resetErrors()
  {
    _errors.clear();
  }

  /**
   * Resets the values.
   */
  public void resetValues()
  {
    _errors.clear();
  }

  /**
   * Returns true if the validator has errors, false otherwise.
   *
   * @return true if the validator has errors, false otherwise.
   */
  public boolean hasErrors()
  {
    if (_errors.size() > 0)
    {
      return true;
    }
    else
    {
      return false;
    }
  }

  /**
   * Returns the attribute that is currently validated.
   *
   * @return the attribute that is currently validated.
   */
  protected String getCurrentValidatingAttribute()
  {
    return _currentValidatingAttribute;
  }

  /**
   * Sets the attribute that is currently validated.
   *
   * @param currentValidatingAttribute the attribute that is currently
   *        validated.
   */
  protected void setCurrentValidatingAttribute(String currentValidatingAttribute)
  {
    _currentValidatingAttribute = currentValidatingAttribute;
  }

  /**
   * Adds the common mandatory attribute error (error.common.mandatoryField)
   * to the current validating attribute if the value is empty and then
   * returns true. If the value is not empty, it returns false.
   *
   * @param value the attribute's value.
   * @return true if the value is empty, false otherwise.
   */
  public boolean addErrorIfEmpty(String value)
  {
    if (Check.isEmpty(value))
    {
      addError("error.common.mandatoryField");

      // we trim the value if it wasn't null
      if (value != null)
      {
        setValue(value.trim());
      }

      return true;
    }
    else
    {
      return false;
    }
  }

  /**
   * Adds the common mandatory attribute error (error.common.mandatoryField)
   * to the current validating attribute if the value is null and then
   * returns true. If the value is not empty, it returns false.
   *
   * @param value the attribute's value.
   * @return true if the value is empty, false otherwise.
   */
  protected boolean addErrorIfNull(Object value)
  {
    if (value == null)
    {
      addError("error.common.mandatoryField");
      return true;
    }
    else
    {
      return false;
    }
  }

  /**
   * Adds the common invalid int error (error.common.int.invalid)
   * to the current validating attribute if the value is not a valid int, and
   * returns true.
   *
   * @param value the attribute's value.
   * @return true if the value is not a valid int.
   */
  protected boolean addErrorIfInvalidInt(String value)
  {
    if (!Check.isValidInt(value))
    {
      addError("error.common.int.invalid");
      return true;
    }

    return false;
  }

  /**
   * Adds the common too long attribute error (error.common.string.tooLong)
   * to the current validating attribute if the value is empty and then
   * returns true. If the value is not empty, it returns false.
   *
   * @param value the attribute's value.
   * @param maxLength the maximum length authorized.
   * @return true if the value is too long, false otherwise.
   */
  protected boolean addErrorIfTooLong(String value, int maxLength)
  {
    int valueLength = value.length();

    if (valueLength > maxLength)
    {
      addError("error.common.string.tooLong", new Integer(valueLength));
      return true;
    }
    else
    {
      return false;
    }
  }

  /**
   * Validates the given value of an optional int attribute, using the given
   * regular expression for validation, and adding the given error to the
   * current validating attribute if the value is invalid. This method is meant
   * to be used in a Validator validateXXX() method.
   *
   * @param value the value to validate.
   * @param validIntRegexp the regular expression used to validate the value,
   *        e.g. "[0-9'` ]+"
   * @param invalidIntErrorKey the error key to add if the value is not a valid
   *        int.
   */
  protected void validateOptionalIntAttribute(String value, String validIntRegexp, String invalidIntErrorKey)
  {
    // The attribute is optional
    if (Check.isEmpty(value))
    {
      return;
    }

    value = saveTrimmedValue();

    if (!value.matches(validIntRegexp))
    {
      addError(invalidIntErrorKey);
      return;
    }

    setValue(String.valueOf(NumberUtil.parseIntLenient(value)));
  }

  /**
   * Validates the given value of an optional int attribute, using the given
   * regular expression and range limits for validation,
   * and adding the given error to the current validating attribute if the
   * value is invalid. This method is meant to be used in a Validator
   * validateXXX() method.
   *
   * @param value the value to validate.
   * @param validIntRegexp the regular expression used to validate the value,
   *        e.g. "[0-9'` ]+"
   * @param invalidIntErrorKey the error key to add if the value is not a valid
   *        int.
   * @param rangeFrom the lower limit (inclusive) of the valid range.
   * @param rangeTo the upper limit (inclusive) of the valid range.
   * @param outOfRangeErrorKey the error key to add if the value is out of range.
   */
  protected void validateOptionalIntAttribute(String value, String validIntRegexp, String invalidIntErrorKey, int rangeFrom, int rangeTo, String outOfRangeErrorKey)
  {
    // The attribute is optional
    if (Check.isEmpty(value))
    {
      return;
    }

    value = saveTrimmedValue();

    if (!value.matches(validIntRegexp))
    {
      addError(invalidIntErrorKey);
      return;
    }

    int intValue = NumberUtil.parseIntLenient(value);

    if (!Check.isInRange(intValue, rangeFrom, rangeTo))
    {
      addError(outOfRangeErrorKey);
      return;
    }

    setValue(String.valueOf(NumberUtil.parseIntLenient(value)));
  }


  /**
   * Returns true if the validator is in insert mode.
   *
   * @return true if the validator is in insert mode.
   */
  public boolean isInsertMode()
  {
    return _mode == MODE_INSERT;
  }

  /**
   * Returns true if the validator is in update mode.
   *
   * @return true if the validator is in update mode.
   */
  public boolean isUpdateMode()
  {
    return _mode == MODE_UPDATE;
  }

  /**
   * Adds the error having the given key to the current validating attribute.
   *
   * @param errorKey the error message key.
   */
  public void addError(String errorKey)
  {
    _errors.put(getCurrentValidatingAttribute(), Message.get(errorKey, _locale));
  }

  /**
   * Adds the error having the given key to the current validating attribute
   * and format it with the specified argument.
   *
   * @param errorKey the error message key.
   * @param arg0 the argument used to format the message.
   */
  public void addError(String errorKey, Object arg0)
  {
    _errors.put(getCurrentValidatingAttribute(), Message.format(errorKey, _locale, arg0));
  }

  /**
   * Adds the error having the given key to the current validating attribute
   * and format it with the specified arguments.
   *
   * @param errorKey the error message key.
   * @param arg0 the first argument used to format the message.
   * @param arg1 the second argument used to format the message.
   */
  public void addError(String errorKey, Object arg0, Object arg1)
  {
    Object[] args = {arg0, arg1};
    _errors.put(getCurrentValidatingAttribute(), Message.format(errorKey, _locale, args));
  }

  /**
   * Adds the error having the given type and model to the
   * current validating attribute. For example if the current validating
   * attribute is "firstName" from the "user" model, and the error type
   * is "mandatory", the call addModelError("user", "mandatory") will add the
   * error "error.user.firstName.mandatory".
   *
   * @param model the model.
   * @param errorType the error type.
   */
  public void addModelError(String model, String errorType)
  {
    addError("error." + model + "." + getCurrentValidatingAttribute() + "." + errorType);
  }

  /**
   * Adds the error having the given type and model to the current
   * validating attribute and format it with the specified argument.
   *
   * @param model the model.
   * @param errorType the error type.
   * @param arg0 the argument used to format the message.
   * @see #addModelError(java.lang.String, java.lang.String)
   */
  public void addModelError(String model, String errorType, Object arg0)
  {
    addError("error." + model + "." + getCurrentValidatingAttribute() + "." + errorType, arg0);
  }

  /**
   * Adds the error having the given type and model to the current validating
   * attribute and format it with the specified arguments.
   *
   * @param model the model.
   * @param errorType the error type.
   * @param arg0 the first argument used to format the message.
   * @param arg1 the second argument used to format the message.
   * @see #addModelError(java.lang.String, java.lang.String)
   */
  public void addModelError(String model, String errorType, Object arg0, Object arg1)
  {
    addError("error." + model + "." + getCurrentValidatingAttribute() + "." + errorType, arg0, arg1);
  }
}