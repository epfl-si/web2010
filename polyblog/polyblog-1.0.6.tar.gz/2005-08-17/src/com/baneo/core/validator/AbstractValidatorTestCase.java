/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.validator;

import com.baneo.core.test.*;
import com.baneo.core.util.*;

import java.lang.reflect.*;

/**
 * Base class for Validator test cases. Extends this class to test
 * your Validator.
 *
 * @author Laurent Boatto
 * @version   $Revision$
 */

public abstract class AbstractValidatorTestCase extends AbstractTestCase
{
  /**
   * Tests all the attributes of the object by trying to set both valid and
   * invalid values.
   *
   * @throws java.lang.Exception
   */
  public abstract void testAttributes() throws Exception;

  /**
   * Checks that the attribute does not accept empty value.
   *
   * @param attribute the attribute to check.
   * @throws java.lang.Exception
   */
  public void testRejectEmptyValue(String attribute) throws Exception
  {
    testAttributeAssertInvalid(attribute, null);
    testAttributeAssertInvalid(attribute, "");
    testAttributeAssertInvalid(attribute, "      ");
  }

  /**
   * Tests that the attribute rejects strings longer than <i>max</i>
   * and shorter than <i>max</i>.
   *
   * @param attribute the attribute to check.
   * @param min the minimum string's length allowed.
   * @param max the maximum string's length allowed.
   * @throws java.lang.Exception
   */
  public void testAttributeLength(String attribute, int min, int max) throws Exception
  {
    String tooShort = StringUtil.getStringOfLength(min - 1);
    String tooLong = StringUtil.getStringOfLength(max + 1);
    testAttributeAssertInvalid(attribute, tooShort);
    testAttributeAssertInvalid(attribute, tooLong);
  }

  /**
   * Tests that the BusinessObject does not accept null or empty values for it's
   * mandatory attributes.
   *
   * @param mandatoryAttibutes the mandatory attributes
   * @throws java.lang.Exception
   */
  public void testMandatoryAttributes(String mandatoryAttibutes[]) throws Exception
  {
    for (int i = 0; i < mandatoryAttibutes.length; i++)
    {
      String attribute = mandatoryAttibutes[i];
      testRejectEmptyValue(attribute);
    }
  }

  /**
   * Test an attribute with the given value, asserting that the value is valid.
   * If the value is rejected, the test fails.
   *
   * @param attribute the attribute to check.
   * @param value a valid value for the attribute.
   * @throws java.lang.Exception
   */
  public final void testAttributeAssertValid(String attribute, String value) throws Exception
  {
    Class validatorClass = getValidator().getClass();

    // Set the currently validating attribute, this is important for the
    // error message.
    getValidator().setCurrentValidatingAttribute(attribute);
    // Sets the value for the attribute, this is important because the value
    // might be trimmed, lowercased, etc.
    getValidator().setValue(attribute, value);

    String methodName = "validate" + StringUtil.upperCaseFirstChar(attribute);

    Method method = validatorClass.getDeclaredMethod(methodName, new Class[]{String.class});

    method.invoke(getValidator(), new String[]{value});

    assertTrue("Value '" + value + "' should be accepted by " + methodName + ". Error was : " + getValidator().getError(attribute), errorSize() == 0);

    if (isVerbose())
    {
      debug("Value '" + value + "' ACCEPTED by " + methodName);
    }

    getValidator().resetErrors();
  }

  /**
   * test.Test an attribute with the given value, asserting that the value is invalid.
   * If the value is accepted, the test fails.
   *
   * @param attribute the attribute to check.
   * @param value an invalid value for the attribute.
   * @throws java.lang.Exception
   */
  public final void testAttributeAssertInvalid(String attribute, String value) throws Exception
  {
    Class validatorClass = getValidator().getClass();

    // Set the currently validating attribute, this is important for the
    // error message.
    getValidator().setCurrentValidatingAttribute(attribute);
    // Sets the value for the attribute, this is important because the value
    // might be trimmed, lowercased, etc.
    getValidator().setValue(attribute, value);

    String methodName = "validate" + StringUtil.upperCaseFirstChar(attribute);

    Method method = validatorClass.getDeclaredMethod(methodName, new Class[]{String.class});

    method.invoke(getValidator(), new String[]{value});

    assertTrue("Value '" + value + "' should be rejected by " + methodName, errorSize() > 0);

    if (isVerbose())
    {
      debug("Value '" + value + "' REJECTED by " + methodName + " : " + getValidator().getErrors().get(attribute));
    }

    getValidator().resetErrors();
  }

  /**
   * Returns the number of errors contained in the Validator.
   *
   * @return the number of errors contained in the Validator.
   */
  public int errorSize()
  {
    return getValidator().getErrors().size();
  }

  /**
   * Return a Validator, used for testing the validateXXX methods.
   *
   * @return a Validator, used for testing the validateXXX methods.
   */
  public abstract Validator getValidator();
}