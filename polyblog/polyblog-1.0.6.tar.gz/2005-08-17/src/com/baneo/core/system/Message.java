/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.system;

import java.text.*;
import java.util.*;

/**
 * Central message catalog. Messages (e.g. error messages) should never
 * be hardcoded in the code because of i18n issues.
 * <p>
 * See :
 * <p>
 * http://www.javaworld.com/javaworld/jw-12-2001/jw-1221-exceptions-p2.html
 * <p>
 * Usage example :
 * <p>
 * String error = Message.get("error.common.mandatoryField");
 * <p>
 * Please note that prior to using this class, you must have initialized
 * the ResourceBundle(s) in com.baneo.core.system.ApplicationResources. If this
 * class is used by multiple applications, you must not share the class between
 * classloaders.
 *
 * @author  Laurent Boatto
 * @version $Id$
 * @see     com.baneo.core.system.ApplicationResources
 * @see     java.util.ResourceBundle
 * @see     java.text.MessageFormat
 */

public abstract class Message
{
  /**
   * The default ResourceBundle used to retrieve the messages. Initialize this
   * with ApplicationResources.setDefaultResourceBundle().
   */
  private static final ResourceBundle _defaultResourceBundle = ApplicationResources.getDefaultResourceBundle();

  /**
   * Returns the message corresponding to the given key and locale, or the key
   * itself if the message does not exist. If the locale is null, the
   * application default ResourceBundle will be used.
   *
   * @param key the message key.
   * @param locale the locale.
   * @return the message corresponding to the given key and locale, or the key
   *         itself if the message does not exist.
   */
  public static String get(String key, Locale locale)
  {
    try
    {
      return ApplicationResources.findBestResourceBundle(locale).getString(key);
    }
    catch (MissingResourceException e)
    {
      return key;
    }
  }

  /**
   * Returns the formatted message for the given locale, corresponding to the
   * given key with the given argument, or the key itself if the message does
   * not exist. If the locale is null, the application default ResourceBundle
   * will be used.
   *
   * @param key the message key.
   * @param locale the locale, can be null.
   * @param argument the argument.
   * @return the formatted message for the given locale, corresponding to the
   *         given key with the given argument, or the key itself if the
   *         message does not exist.
   */
  public static String format(String key, Locale locale, Object argument)
  {
    try
    {
      String message = ApplicationResources.findBestResourceBundle(locale).getString(key);
      Object[] args = {argument};
      return MessageFormat.format(message, args);
    }
    catch (MissingResourceException e)
    {
      return key;
    }
  }

  /**
   * Returns the formatted message for the given locale, corresponding to the
   * given key with the given arguments, or the key itself if the message
   * does not exist. If the locale is null, the application default
   * ResourceBundle  will be used.
   *
   * @param key the message key.
   * @param locale the locale, can be null.
   * @param firstArgument the first argument.
   * @param secondArgument the second argument.
   * @return the formatted message for the given locale, corresponding to the
   *         given key with the given arguments, or the key itself if the message
   *         does not exist.
   */
  public static String format(String key, Locale locale, Object firstArgument, Object secondArgument)
  {
    try
    {
      String message = ApplicationResources.findBestResourceBundle(locale).getString(key);
      Object[] args = {firstArgument, secondArgument};
      return MessageFormat.format(message, args);
    }
    catch (MissingResourceException e)
    {
      return key;
    }
  }

  /**
   * Returns the formatted message for the given locale, corresponding to the
   * given key with the given arguments, or the key itself if the message
   * does not exist. If the locale is null, the application default
   * ResourceBundle  will be used.
   *
   * @param key the message key.
   * @param locale the locale, can be null.
   * @param firstArgument the first argument.
   * @param secondArgument the second argument.
   * @param thirdArgument the third argument.
   * @return the formatted message for the given locale, corresponding to the
   *         given key with the given arguments, or the key itself if the message
   *         does not exist.
   */
  public static String format(String key, Locale locale, Object firstArgument, Object secondArgument, Object thirdArgument)
  {
    try
    {
      String message = ApplicationResources.findBestResourceBundle(locale).getString(key);
      Object[] args = {firstArgument, secondArgument, thirdArgument};
      return MessageFormat.format(message, args);
    }
    catch (MissingResourceException e)
    {
      return key;
    }
  }


  /**
   * Returns the formatted message for the given locale, corresponding to the
   * given key with the given argument, or the key itself if the message does
   * not exist. If the locale is null, the application default ResourceBundle
   * will be used.
   *
   * @param key the message key.
   * @param locale the locale, can be null.
   * @param arguments the array of arguments.
   * @return the formatted message for the given locale, corresponding to the
   *         given key with the given argument, or the key itself if the message
   *         does not exist.
   */
  public static String format(String key, Locale locale, Object[] arguments)
  {
    try
    {
      String message = ApplicationResources.findBestResourceBundle(locale).getString(key);
      return MessageFormat.format(message, arguments);
    }
    catch (MissingResourceException e)
    {
      return key;
    }
  }

  /**
   * Returns the model's attribute value label at the given index.
   * <p>
   * For example, the User.title attribute has three different possible values :
   * <p>
   * "Madame" (index 1)
   * "Mademoiselle" (index 2)
   * "Monsieur" (index 3)
   * <p>
   * To find the value label "Mademoiselle" you would do :
   * <p>
   * <code>
   * Message.getAttributeValueLabel("user", "title", 2);
   * </code>
   *
   * @param model the model to find the attribute value label from.
   * @param attribute the attribute.
   * @param valueIndex the value index, starts at 1.
   * @param locale the locale, can be null.
   * @return the model's attribute value label at the given index.
   */
  public static String getAttributeValueLabel(String model, String attribute, int valueIndex, Locale locale)
  {
    return get("model." + model + "." + attribute + ".valueLabel." + valueIndex, locale);
  }

  /**
   * Return all the possible value labels for the given model attribute.
   *
   * @param model the model.
   * @param attribute the attribute.
   * @param locale the locale, can be null.
   * @return all the possible value labels for the given model attribute.
   */
  public static String[] getAttributeValueLabels(String model, String attribute, Locale locale)
  {
    List result = new ArrayList();
    String valueLabel = null;
    int i = 1;

    // We load the valueLabel option 1, 2, 3, etc. until the returned value
    // is the key itself (meaning it does not exist).
    while (!(valueLabel = Message.getAttributeValueLabel(model, attribute, i, locale)).equals("model." + model + "." + attribute + ".valueLabel." + i))
    {
      result.add(valueLabel);
      i++;
    }

    return (String[]) result.toArray(new String[result.size()]);
  }

  /**
   * Returns the default ResourceBundle used to retrieve the messages.
   *
   * @return the default ResourceBundle used to retrieve the messages.
   */
  public static final ResourceBundle getDefaultResourceBundle()
  {
    return _defaultResourceBundle;
  }
}