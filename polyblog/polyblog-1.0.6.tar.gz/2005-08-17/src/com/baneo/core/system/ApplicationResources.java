/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.system;

import java.util.*;

/**
 * Holds the resources used by the current application. The different resources
 * should be set during the application boostrap so they can be accessed later
 * on by other classes, in particular classes that are not especially part of
 * the application, like utilities, common tools, etc.
 *
 * @author  Laurent Boatto
 * @version $Id$
 */

public class ApplicationResources
{
  private static ResourceBundle _defaultResourceBundle;
  private static Locale _defaultLocale;
  private static Map _resourceBundles = new HashMap();
  private static Map _locales = new HashMap();
  private static Properties _properties;

  /**
   * Finds the best ResourceBundle for the given locale. This method first
   * tries to find a ResourceBundle corresponding to the locale's language and
   * country (e.g. fr_CH). If nothing is found, it tries to find a
   * ResourceBundle for the language (e.g. fr). If nothing is found, it returns
   * the default ResourceBundle. The given locale can be null, in which case the
   * default ResourceBundle is returned.
   *
   * @param locale the locale, can be null (default ResourceBundle is then
   *        returned).
   * @return the best ResourceBundle for the given locale.
   */
  public static ResourceBundle findBestResourceBundle(Locale locale)
  {
    if (locale == null || _resourceBundles.size() == 1)
    {
      return _defaultResourceBundle;
    }

    // first we try to get the ResourceBundle for the language / country,
    // e.g. fr_CH
    ResourceBundle resource = (ResourceBundle) _resourceBundles.get(locale.toString());

    // next we try the language only, e.g. fr
    if (resource == null)
    {
      resource = (ResourceBundle) _resourceBundles.get(locale.getLanguage());
    }

    // if nothing found, we return the default ResourceBundle
    if (resource == null)
    {
      resource = _defaultResourceBundle;
    }

    return resource;
  }

  /**
   * Finds the best (nearest) registered Locale for the given locale.
   * This method first tries to find the registered Locale corresponding to
   * the given locale's language and country (e.g. fr_CH). If nothing is found,
   * it tries to find a registered Locale for the language (e.g. fr).
   * If nothing is found, it returns the default Locale. The given locale can
   * be null, in which case the default Locale is returned.
   *
   * @param locale the locale, can be null (the default Locale is then returned).
   * @return the best registered Locale for the given locale.
   */
  public static Locale findBestRegisteredLocale(Locale locale)
  {
    if (locale == null || _locales.size() == 1)
    {
      return _defaultLocale;
    }

    // first we try to get the exact Locale (e.g. fr_CH)
    Locale found = (Locale) _locales.get(locale.toString());

    // next we try the language only, e.g. fr
    if (found == null)
    {
      found = (Locale) _locales.get(locale.getLanguage());
    }

    // if nothing found, we return the default Locale
    if (found == null)
    {
      found = _defaultLocale;
    }

    return found;
  }

  /**
   * Adds the given ResouceBundle to the application resources. The
   * ResourceBundles are used in the findBestResourceBundle() method.
   * The ResourceBundles are put in a Map, using for the key the
   * Locale.toString() result (e.g. fr_CH).
   *
   * @param resourceBundle the ResourceBundle to add.
   * @param isDefault true if the given resource bundle should be used as
   *        default if a better one cannot be found, false otherwise.
   */
  public static void addResourceBundle(ResourceBundle resourceBundle, boolean isDefault)
  {
    Locale locale = resourceBundle.getLocale();

    if (isDefault)
    {
      _defaultResourceBundle = resourceBundle;
      _defaultLocale = locale;
    }

    _resourceBundles.put(locale.toString(), resourceBundle);
    _locales.put(locale.toString(), locale);
  }

  /**
   * Returns the default ResourceBundle used by this application.
   *
   * @return the default ResourceBundle used by this application.
   */
  public static ResourceBundle getDefaultResourceBundle()
  {
    if (_defaultResourceBundle == null)
    {
      throw new IllegalStateException("The application default ResourceBundle has not been initialized. See com.baneo.core.system.ApplicationResources for more informations.");
    }

    return _defaultResourceBundle;
  }

  /**
   * Returns the default Locale used by this application.
   *
   * @return the default Locale used by this application.
   */
  public static Locale getDefaultLocale()
  {
    return _defaultLocale;
  }

  /**
   * Sets the application properties.
   *
   * @param properties the properties.
   */
  public static void setProperties(Properties properties)
  {
    _properties = properties;
  }

  /**
   * Returns the application properties.
   *
   * @return the application properties.
   */
  public static Properties getProperties()
  {
    if (_properties == null)
    {
      throw new IllegalStateException("The application properties has not been initialized. See com.baneo.core.system.ApplicationResources for more informations.");
    }

    return _properties;
  }
}