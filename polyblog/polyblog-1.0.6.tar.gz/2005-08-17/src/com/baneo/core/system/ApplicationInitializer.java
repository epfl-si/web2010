/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.system;

import java.io.*;
import java.util.*;

/**
 * Initialize the current application by setting the Properties object
 * in ApplicationResources and by launching the application specific
 * initialization method. The application properties file must be named
 * "baneo.application.properties" and must be present in the class path. In this
 * properties file, a property named
 * "com.baneo.core.system.ClassifiedInitializer.implementationClass" must
 * specify which Initializer the application is actually using to initialize
 * itself.
 *
 * @author Laurent Boatto
 * @see com.baneo.core.system.ApplicationResources
 * @see com.baneo.core.system.Initializer
 */
public class ApplicationInitializer
{
  /**
   * The application properties file name, which must be present in the class
   * path.
   */
  public static final String PROPERTIES_FILE_NAME = "baneo.application.properties";

  /**
   * The name of the property specifying which class (implementing
   * com.baneo.core.system.Initializer
   */
  public static final String INITIALIZER_CLASS = "com.baneo.core.system.ApplicationInitializer.implementationClass";

  private ApplicationInitializer()
  {
  }

  /**
   * Initialize the application.
   *
   * @throws InitializerException on initialization error.
   */
  public static void initialize() throws InitializerException
  {
    String implementationClass = null;

    try
    {
      Properties properties = new Properties();
      properties.load(ApplicationInitializer.class.getResourceAsStream("/" + ApplicationInitializer.PROPERTIES_FILE_NAME));
      ApplicationResources.setProperties(properties);

      implementationClass = properties.getProperty(INITIALIZER_CLASS);

      if (implementationClass == null)
      {
        throw new InitializerException("The property '" + INITIALIZER_CLASS +
            "' must be set in the properties file '" + PROPERTIES_FILE_NAME +
            "' to the class used for initialization");
      }

      Class klass = Class.forName(implementationClass);

      Initializer initializer = (Initializer) klass.newInstance();
      initializer.initialize();
    }
    catch (IOException e)
    {
      throw new InitializerException("Can not find config/application.properties in the class path", e);
    }
    catch (ClassNotFoundException e)
    {
      throw new InitializerException("Can not find initialize class " + implementationClass, e);
    }
    catch (InstantiationException e)
    {
      throw new InitializerException("Error trying to instanciate class  " + implementationClass, e);
    }
    catch (IllegalAccessException e)
    {
      throw new InitializerException("Error trying to access class  " + implementationClass, e);
    }
  }
}