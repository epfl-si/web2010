/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.system;

import java.util.*;

/**
 * Config lets you retrieve the application properties.
 *
 * @author Laurent Boatto
 * @version $Id$
 * @see com.baneo.core.system.ApplicationResources
 */
public abstract class Config
{
  /**
   * The Properties object.
   */
  private static final Properties _properties = ApplicationResources.getProperties();

  /**
   * Returns the String value of the property designed by the given key.
   *
   * @param key the key designing the property.
   * @return the value of the property.
   */
  public static String get(String key)
  {
    return _properties.getProperty(key);
  }

  /**
   * Returns an array with the String values of the given property key.
   * The property should be set as follow :
   * <pre>
   * myKey.1 = myValue1 // index starts as 1, not 0
   * myKey.2 = myValue2
   * myKey.3 = myValue3
   * etc.
   * </pre>
   *
   * @param key the key designing the property.
   * @return an array with the String values of the given property key.
   */
  public static String[] getStringArray(String key)
  {
    int i = 1;

    String value = null;
    List values = new ArrayList();

    while ((value = get(key + "." + i)) != null)
    {
      values.add(value);
      i++;
    }

    return (String[]) values.toArray(new String[values.size()]);
  }

  /**
   * Returns an array with the char values of the given property key.
   * The property should be set as follow :
   * <pre>
   * myKey.1 = a // index starts as 1, not 0
   * myKey.2 = b
   * myKey.3 = c
   * etc.
   * </pre>
   *
   * @param key the key designing the property.
   * @return an array with the char values of the given property key.
   */
  public static char[] getCharArray(String key)
  {
    String[] stringArray = getStringArray(key);
    char[] charArray = new char[stringArray.length];

    for (int i = 0; i < stringArray.length; i++)
    {
      charArray[i] = stringArray[i].charAt(0);
    }

    return charArray;
  }

  /**
   * Returns the boolean value of the property designed by the given key. The
   * given property must exist, otherwise a NullPointerException is thrown.
   *
   * @param key the key designing the property.
   * @return the value of the property.
   */
  public static boolean getBoolean(String key)
  {
    return Boolean.valueOf((_properties.getProperty(key))).booleanValue();
  }

  /**
   * Returns the int value of the property designed by the given key.
   *
   * @param key the key designing the property.
   * @return the value of the property.
   */
  public static int getInt(String key)
  {
    return Integer.parseInt(_properties.getProperty(key));
  }

  /**
   * Returns the char value of the property designed by the given key.
   *
   * @param key the key designing the property.
   * @return the value of the property.
   */
  public static char getChar(String key)
  {
    return get(key).charAt(0);
  }

  /**
   * Returns the properties.
   *
   * @return the properties
   */
  public static Properties getProperties()
  {
    return _properties;
  }
}