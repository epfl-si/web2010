/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.system;

/**
 * InitializerException, thrown by ClassifiedInitializer when something goes wrong
 * during initialization.
 *
 * @author Laurent Boatto
 * @version $Id$
 */
public class InitializerException extends Exception
{
  /**
   * Constructs a new InitializerException with the specified detail message.
   *
   * @param message the detail message.
   */
  public InitializerException(String message)
  {
    super(message);
  }

  /**
   * Constructs a new InitializerException with the cause.
   */
  public InitializerException(Throwable cause)
  {
    super(cause);
  }

  /**
   * Constructs a new InitializerException with the specified detail message and
   * cause.
   */
  public InitializerException(String message, Throwable cause)
  {
    super(message, cause);
  }
}