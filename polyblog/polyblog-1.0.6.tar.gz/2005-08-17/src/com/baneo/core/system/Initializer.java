/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.system;

/**
 * Initializer.
 *
 * @author Laurent Boatto
 */
public interface Initializer
{
  /**
   * Initialize the application.
   *
   * @throws InitializerException on initialization exception.
   */
  void initialize() throws InitializerException;
}
