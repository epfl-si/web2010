/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.security;

import java.security.*;

/**
 * A security context.
 *
 * @author Laurent Boatto
 * @version $Id$
 */
public interface ISecurityContext
{
  /**
   * Returns a boolean indicating whether the authenticated user is included
   * in the specified logical "role".
   *
   * @param role a String specifying the name of the role.
   * @return a boolean indicating whether the user making this request belongs
   *         to a given role; false if the user has not been authenticated.
   */
  boolean isUserInRole(String role);

  /**
   * Returns a java.security.Principal object containing the name of the
   * current authenticated user. If the user has not been authenticated,
   * the method returns null.
   *
   * @return a java.security.Principal containing the name of the user making
   *         this request; null if the user has not been authenticated.
   */
  Principal getPrincipal();

  /**
   * Returns the name of the current authenticated user.
   * If the user has not been authenticated, the method returns null.
   *
   * @return the name of the current authenticated user or null if the user is
   *         not authenticated.
   */
  String getUsername();

  /**
   * Returns the id of the current authenticated user.
   * If the user is not authenticated, the method returns -1.
   *
   * @return the id of the current authenticated user.
   */
  int getUserId();

  /**
   * Returns the user's footprint. In a web context, this could be
   * e.g an IP address, on a desktop context this could be a machine
   * name, etc.
   *
   * @return the user's footprint.
   */
  String getFootprint();
}
