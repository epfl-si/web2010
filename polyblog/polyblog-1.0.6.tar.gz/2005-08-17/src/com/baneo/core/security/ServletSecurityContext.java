/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.security;

import javax.servlet.http.*;
import java.security.*;

/**
 * Implementation of an ISecurityContext using the information of a request.
 *
 * @author Laurent Boatto
 * @version $Id$
 * @see ISecurityContext
 */
public class ServletSecurityContext implements ISecurityContext
{
  /**
   * The name of the Session attribute which holds the logged user id (as an
   * Integer).
   */
  public static final String USER_ID_SESSION_ATTRIBUTE = "com.baneo.core.security.ServletSecurityContext.userId";

  private HttpServletRequest _request;

  /**
   * Constructs a new ServletSecurityContext with the given request.
   *
   * @param request the request.
   */
  public ServletSecurityContext(HttpServletRequest request)
  {
    _request = request;
  }

  public boolean isUserInRole(String role)
  {
    return _request.isUserInRole(role);
  }

  public String getUsername()
  {
    return _request.getRemoteUser();
  }

  public Principal getPrincipal()
  {
    return _request.getUserPrincipal();
  }

  public String getFootprint()
  {
    String footprint = _request.getRemoteAddr();
    String forwarded = _request.getHeader("HTTP_X_FORWARDED_FOR");

    if (forwarded != null)
    {
      footprint += " (" + forwarded + ")";
    }

    return footprint;
  }

  public int getUserId()
  {
    Integer id = (Integer) _request.getSession().getAttribute(USER_ID_SESSION_ATTRIBUTE);

    if (id == null)
    {
      return -1;
    }
    else
    {
      return id.intValue();
    }
  }
}