/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.security;

/**
 * The SecurityContextManager lets you retrieve, set and remove the
 * ISecurityContext for the current thread.
 *
 * @author  Laurent Boatto
 * @version $Id$
 * @see com.baneo.core.security.ISecurityContext
 */

public final class SecurityContextManager
{
  private static final ThreadLocal _threadContext = new ThreadLocal();

  /**
   * Returns the ISecurityContext for the current thread. You should not use
   * this method directly in your code, but rather wrap in a custom
   * ApplicationSecurityManager.
   *
   * @return he ISecurityContext for the current thread.
   */
  public static final ISecurityContext getISecurityContext()
  {
    return (ISecurityContext) _threadContext.get();
  }

  /**
   * Sets the ISecurityContext for the current thread.
   *
   * @param context the ISecurityContext for the current thread.
   */
  public static final ISecurityContext setSecurityContext(ISecurityContext context)
  {
    _threadContext.set(context);

    return context;
  }

  /**
   * Removes the ISecurityContext for the current thread.
   */
  public static final void removeSecurityContext()
  {
    _threadContext.set(null);
  }
}