/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.security;

import java.security.*;

/**
 * ISecurityContext used by the system when it needs to performe
 * restricted operations. The system is always authentificated and
 * has every role.
 *
 * @author Laurent Boatto
 * @version $Id$
 * @see com.baneo.core.security.ISecurityContext
 */

public final class SystemSecurityContext implements ISecurityContext
{
  /**
   * The reserved username used by the "system" user.
   */
  public static final String SYSTEM_USERNAME = "system";

  /**
   * The reserved id used by the "system" user.
   */
  public static final int SYSTEM_ID = 1;

  /**
   * The system Principal.
   */
  private SystemPrincipal _principal;

  /**
   * Constructs a new SystemSecurityContext.
   */
  public SystemSecurityContext()
  {
    _principal = new SystemPrincipal();
  }

  /**
   * Returns a boolean indicating whether the authenticated user is included
   * in the specified logical "role".
   *
   * @param role a String specifying the name of the role.
   * @return a boolean indicating whether the user making this request belongs
   *         to a given role; false if the user has not been authenticated.
   */
  public boolean isUserInRole(String role)
  {
    // The system has every role
    return true;
  }

  /**
   * Returns a java.security.Principal object containing the name of the
   * current authenticated user. If the user has not been authenticated,
   * the method returns null.
   *
   * @return a java.security.Principal containing the name of the user making
   *         this request; null if the user has not been authenticated
   */
  public Principal getPrincipal()
  {
    return _principal;
  }

  /**
   * Returns the name of the current authenticated user.
   * If the user has not been authenticated, the method returns null.
   *
   * @return the name of the current authenticated user or null if the user is
   *         not authenticated
   */
  public String getUsername()
  {
    return SYSTEM_USERNAME;
  }

  /**
   * Returns the id of the current authenticated user.
   * If the user is not authenticated, the method returns 0.
   *
   * @return the id of the current authenticated user.
   */
  public int getUserId()
  {
    return SYSTEM_ID;
  }

  /**
   * Returns the user's footprint. In a web context, this could be
   * e.g an IP address, on a desktop context this could be a machine
   * name, etc.
   *
   * @return the user's footprint.
   */
  public String getFootprint()
  {
    return SYSTEM_USERNAME;
  }

  private class SystemPrincipal implements Principal
  {
    /**
     * Returns the name of this principal.
     *
     * @return the name of this principal.
     */
    public String getName()
    {
      return SYSTEM_USERNAME;
    }
  }
}
