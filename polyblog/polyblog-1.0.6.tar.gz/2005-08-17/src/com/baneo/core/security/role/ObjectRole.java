package com.baneo.core.security.role;

import com.baneo.core.model.*;

import java.security.*;

/**
 * ObjectRole.
 *
 * @author Laurent Boatto
 */
public class ObjectRole extends BusinessObject
{
  private String _principalName;
  private String _principalClassName;
  private String _principalLabel;
  private int _businessObjectId;
  private String _businessObjectClassName;
  private String _role;

  public ObjectRole()
  {
  }

  public ObjectRole(Principal principal, String role, BusinessObject businessObject)
  {
    _principalName = principal.getName();
    _principalClassName = principal.getClass().getName();
    _role = role;
    _businessObjectId = businessObject.getId();
    _businessObjectClassName = businessObject.getClass().getName();
  }

  public String getPrincipalName()
  {
    return _principalName;
  }

  public void setPrincipalName(String principalName)
  {
    _principalName = principalName;
  }

  public Class getPrincipalClass()
  {
    try
    {
      return Class.forName(_principalClassName);
    }
        // we expect this will never fail, so if it does there's something
        // really wrong we cannot catch
    catch (ClassNotFoundException e)
    {
      throw new RuntimeException(e);
    }
  }

  public String getPrincipalClassName()
  {
    return _principalClassName;
  }

  public void setPrincipalClassName(String principalClassName)
  {
    _principalClassName = principalClassName;
  }

  public int getBusinessObjectId()
  {
    return _businessObjectId;
  }

  public void setBusinessObjectId(int businessObjectId)
  {
    _businessObjectId = businessObjectId;
  }

  public String getPrincipalLabel()
  {
    return _principalLabel;
  }

  public void setPrincipalLabel(String principalLabel)
  {
    _principalLabel = principalLabel;
  }

  public Object getBusinessObjectClass()
  {
    try
    {
      return Class.forName(_businessObjectClassName);
    }
        // we expect this will never fail, so if it does there's something
        // really wrong we cannot catch
    catch (ClassNotFoundException e)
    {
      throw new RuntimeException(e);
    }
  }

  public String getBusinessObjectClassName()
  {
    return _businessObjectClassName;
  }

  public void setBusinessObjectClassName(String businessObjectClassName)
  {
    _businessObjectClassName = businessObjectClassName;
  }

  public String getRole()
  {
    return _role;
  }

  public void setRole(String role)
  {
    _role = role;
  }
}