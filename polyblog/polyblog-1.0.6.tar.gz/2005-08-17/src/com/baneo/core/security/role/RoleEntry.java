/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.security.role;

/**
 * A RoleEntry represents a mapping between a user (using the user id), and
 * a role (using the role name). A user can have several roles, thus several
 * RoleEntry.
 *
 * @author  Laurent Boatto
 * @version $Id$
 * @see com.baneo.core.security.role.IRoleManager
 */

public class RoleEntry
{
  private int _id;
  private int _userId;
  private String _role;

  /**
   * Returns the id.
   *
   * @return the id.
   */
  public int getId()
  {
    return _id;
  }

  /**
   * Sets the id (this is only done by the IRoleManager).
   *
   * @param id the id.
   */
  void setId(int id)
  {
    _id = id;
  }

  /**
   * Returns the user id.
   *
   * @return the user id.
   */
  public int getUserId()
  {
    return _userId;
  }

  /**
   * Sets the user id.
   *
   * @param userId the user id.
   */
  public void setUserId(int userId)
  {
    _userId = userId;
  }

  /**
   * Returns the role.
   *
   * @return the role.
   */
  public String getRole()
  {
    return _role;
  }

  /**
   * Sets the role.
   *
   * @param role the role to set.
   */
  public void setRole(String role)
  {
    _role = role;
  }
}