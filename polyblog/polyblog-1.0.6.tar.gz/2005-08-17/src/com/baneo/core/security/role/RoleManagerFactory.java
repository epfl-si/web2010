/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.security.role;


/**
 * Factory for retrieving the IRoleManager used by the application.
 *
 * @author  Laurent Boatto
 * @version $Id$
 * @see com.baneo.core.security.role.IRoleManager
 */

public class RoleManagerFactory
{
  private RoleManagerFactory()
  {
  }

  /**
   * Returns the IRoleManager used by the application.
   *
   * @return the IRoleManager used by the application.
   */
  public static final IRoleManager getIRoleManager()
  {
    /**
     * todo get this from a property
     */
    return HibernateRoleManager.instance();
  }
}