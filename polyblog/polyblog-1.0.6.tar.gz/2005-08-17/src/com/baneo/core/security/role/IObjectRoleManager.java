package com.baneo.core.security.role;

import com.baneo.core.model.*;
import com.baneo.core.persistance.*;

import java.security.*;
import java.util.*;

/**
 * IObjectRoleManager.
 *
 * @author Laurent Boatto
 */
public interface IObjectRoleManager
{
  /**
   * The reserved role name for ownership.
   */
  String ROLE_OWNER = "owner";

  /**
   * The reserved role name for ownership.
   */
  String ROLE_ADMINISTRATOR = "administrator";

  Collection findByPrincipal(Principal principal) throws PersistanceException;

  Collection findByPrincipal(Principal principal, Class klass) throws PersistanceException;

  Collection findByBusinessObject(BusinessObject object) throws PersistanceException;

  Collection findByBusinessObjectClass(Class klass) throws PersistanceException;

  ObjectRole findFirstByBusinessObjectAndRole(BusinessObject businessObject, String role) throws PersistanceException;

  Collection findByBusinessObjectAndRole(BusinessObject businessObject, String role) throws PersistanceException;

  int findByBusinessObjectAndRoleCount(BusinessObject object, String role) throws PersistanceException;

  Collection findAll() throws PersistanceException;

  Collection findByBusinessObject(BusinessObject object, String orderBy, int startIndex, int maxResults) throws PersistanceException;

  int findByBusinessObjectCount(BusinessObject object) throws PersistanceException;

  ObjectRole findFirstByPrincipalAndBusinessObject(Principal principal, BusinessObject businessObject) throws PersistanceException;

  Collection findByPrincipalAndBusinessObject(Principal principal, BusinessObject businessObject) throws PersistanceException;

  public ObjectRole get(int id) throws PersistanceException;

  public ObjectRole get(String id) throws PersistanceException;

  boolean hasRole(Principal principal, String role, BusinessObject object) throws PersistanceException;

  boolean hasOwnerRole(Principal principal, BusinessObject object) throws PersistanceException;

  ObjectRole addRole(String role, Principal principal, String principalLabel, BusinessObject object) throws PersistanceException;

  void removeRole(String role, Principal principal, BusinessObject object) throws PersistanceException;

  void insert(ObjectRole objectRole) throws PersistanceException;

  void update(ObjectRole objectRole) throws PersistanceException;

  void delete(ObjectRole objectRole) throws PersistanceException;
}