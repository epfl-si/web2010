/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.security.role;

import com.baneo.core.persistance.*;
import com.baneo.core.persistance.hibernate.*;

import java.util.*;

/**
 * Implementation of an IRoleManager using Hibernate as the persistance layer.
 * A cache is used to improve performance.
 *
 * @author  Laurent Boatto
 * @version $Id$
 * @see com.baneo.core.security.role.IRoleManager
 */

public class HibernateRoleManager implements IRoleManager
{
  private static final HibernateRoleManager _instance = new HibernateRoleManager();
  private static final HibernatePersistanceManager _persistanceManager = HibernatePersistanceManager.instance();
  private static final Map _cache = new HashMap();

  static
  {
    try
    {
      loadCache();
    }
    catch (PersistanceException e)
    {
      throw new ExceptionInInitializerError(e);
    }
  }

  /**
   * Private constructor, use instance instead.
   */
  private HibernateRoleManager()
  {
  }

  /**
   * Returns the instance of HibernateRoleManager (singleton).
   *
   * @return the instance of HibernateRoleManager (singleton).
   */
  public static final HibernateRoleManager instance()
  {
    return _instance;
  }

  public boolean isUserInRole(int userId, String roleName) throws PersistanceException
  {
    List userRoles = (List) _cache.get(new Integer(userId));

    if (userRoles == null || userRoles.isEmpty())
    {
      return false;
    }

    int size = userRoles.size();
    for (int i = 0; i < size; i++)
    {
      RoleEntry entry = (RoleEntry) userRoles.get(i);
      if (entry.getRole().equals(roleName))
      {
        return true;
      }
    }

    return false;
  }

  public List findByUserId(int userId) throws PersistanceException
  {
    List list = (List) _cache.get(new Integer(userId));

    if (list == null)
    {
      return null;
    }

    return Collections.unmodifiableList(list);
  }

  public void insert(RoleEntry roleEntry) throws PersistanceException
  {
    _persistanceManager.insert(roleEntry);
    putInCache(roleEntry);
  }

  public void delete(RoleEntry roleEntry) throws PersistanceException
  {
    _persistanceManager.delete(roleEntry);
    removeFromCache(roleEntry);
  }

  /**
   * Loads the cache.
   *
   * @throws com.baneo.core.persistance.PersistanceException
   */
  private static void loadCache() throws PersistanceException
  {
    Collection roles = _persistanceManager.findAll(RoleEntry.class);

    for (Iterator iterator = roles.iterator(); iterator.hasNext();)
    {
      RoleEntry roleEntry = (RoleEntry) iterator.next();
      putInCache(roleEntry);
    }
  }

  /**
   * Puts the given RoleEntry in the cache.
   *
   * @param roleEntry
   */
  private static void putInCache(RoleEntry roleEntry)
  {
    Integer userId = new Integer(roleEntry.getUserId());

    List userRoles = (List) _cache.get(userId);

    /** todo think about concurrence access problem */
    if (userRoles == null)
    {
      userRoles = new ArrayList();
      _cache.put(userId, userRoles);
    }

    userRoles.add(roleEntry);
  }

  /**
   * Removes the given RoleEntry from the cache.
   *
   * @param roleEntry
   */
  private static void removeFromCache(RoleEntry roleEntry)
  {
    Integer userId = new Integer(roleEntry.getUserId());
    List userRoles = (List) _cache.get(userId);
    userRoles.remove(roleEntry);
    if (userRoles.isEmpty())
    {
      _cache.remove(userId);
    }
  }
}