/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.security.role;

import com.baneo.core.persistance.*;

import java.util.*;

/**
 * An IRoleManager is a manager for RoleEntry. A RoleEntry is a mapping between
 * an user id, an a role name. You can insert, delete and retrieve RoleEntry
 * with an IRoleManager.
 *
 * @author  Laurent Boatto
 * @version $Id$
 * @see com.baneo.core.security.role.RoleEntry
 */

public interface IRoleManager
{
  /**
   * Returns true if the given user id has the given role.
   *
   * @param userId the user id.
   * @param role the role.
   * @return true if the given user id has the given role.
   * @throws com.baneo.core.persistance.PersistanceException if an error occurs in the persistance layer.
   */
  public boolean isUserInRole(int userId, String role) throws PersistanceException;

  /**
   * Returns the List of RoleEntry for the given user id, or null if he doesn't
   * have any.
   *
   * @param userId the user id.
   * @return the List of RoleEntry for the given user id, or null if he doesn't
   *         have any.
   * @throws com.baneo.core.persistance.PersistanceException if an error occurs in the persistance layer.
   */
  public List findByUserId(int userId) throws PersistanceException;

  /**
   * Inserts the given RoleEntry in the system.
   *
   * @param roleEntry the RoleEntry to insert.
   * @throws com.baneo.core.persistance.PersistanceException if an error occurs in the persistance layer.
   */
  public void insert(RoleEntry roleEntry) throws PersistanceException;

  /**
   * Deletes the given RoleEntry from the system.
   *
   * @param roleEntry the RoleEntry to delete.
   * @throws com.baneo.core.persistance.PersistanceException if an error occurs in the persistance layer.
   */
  public void delete(RoleEntry roleEntry) throws PersistanceException;
}