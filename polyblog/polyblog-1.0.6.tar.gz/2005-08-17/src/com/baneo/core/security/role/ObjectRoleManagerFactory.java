package com.baneo.core.security.role;

/**
 * ObjectRoleManagerFactory.
 *
 * @author Laurent Boatto
 */
public class ObjectRoleManagerFactory
{
  private ObjectRoleManagerFactory()
  {
  }

  public static final IObjectRoleManager getIObjectRoleManager()
  {
    return HibernateObjectRoleManager.instance();
  }
}