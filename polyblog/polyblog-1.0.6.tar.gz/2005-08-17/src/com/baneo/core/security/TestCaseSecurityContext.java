/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.security;

import java.security.*;

/**
 * SecurityContext for test cases only.
 *
 * @author  Laurent Boatto
 * @version $Id$
 */
public class TestCaseSecurityContext implements ISecurityContext
{
  private String _userName;
  private int _userId;
  private String _roles;
  private String _footprint;
  private Principal _principal;

  /**
   * Constructor.
   *
   * @param username the username.
   * @param userId the user id.
   * @param roles a comma separated role list (e.g administrator,moderator).
   * @param footprint the footprint.
   */
  public TestCaseSecurityContext(String username, int userId, String roles, String footprint)
  {
    _userName = username;
    _userId = userId;
    _roles = roles;
    _footprint = footprint;
    _principal = new TestCasePrincipal(username);
  }

  public boolean isUserInRole(String role)
  {
    if (_roles == null)
    {
      return false;
    }

    return (_roles.lastIndexOf(role) != -1);
  }

  public Principal getPrincipal()
  {
    return _principal;
  }

  public void setPrincipal(Principal principal)
  {
    _principal = principal;
  }

  public String getUsername()
  {
    return _userName;
  }

  public String getFootprint()
  {
    return _footprint;
  }

  public int getUserId()
  {
    return _userId;
  }

  public void setUserId(int userId)
  {
    _userId = userId;
  }

  public void setUserName(String userName)
  {
    _userName = userName;
  }

  public void setRoles(String roles)
  {
    _roles = roles;
  }

  public void setFootprint(String footprint)
  {
    _footprint = footprint;
  }


  /**
   * A simple Principal for test cases.
   *
   * @author  Laurent Boatto
   * @version $Id$
   */
  class TestCasePrincipal implements Principal
  {
    private String _name;

    public TestCasePrincipal(String name)
    {
      _name = name;
    }

    public String getName()
    {
      return _name;
    }
  }
}