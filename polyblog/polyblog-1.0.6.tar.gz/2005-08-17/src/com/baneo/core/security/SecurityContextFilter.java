/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.security;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

/**
 * A servlet filter that automatically sets the ISecurityContext for the
 * current thread using the request.
 *
 * @author  Laurent Boatto
 * @version $Id$
 * @see com.baneo.core.security.ISecurityContext
 * @see com.baneo.core.security.SecurityContextManager
 * @see com.baneo.core.security.ServletSecurityContext
 */

public class SecurityContextFilter implements Filter
{
  public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws ServletException, IOException
  {
    // Sets the security context
    SecurityContextManager.setSecurityContext(
        new ServletSecurityContext((HttpServletRequest) request));

    try
    {
      chain.doFilter(request, response);
    }
        // We remove the SecurityContext at the end of the request, safer..
    finally
    {
      SecurityContextManager.removeSecurityContext();
    }
  }

  public void init(FilterConfig config) throws ServletException
  {
  }

  public void destroy()
  {
  }
}