package com.baneo.core.security;

import java.security.*;

/**
 * SimpleSecurityContext.
 *
 * @author Laurent Boatto
 */
public class SimpleSecurityContext implements ISecurityContext
{
  private Principal _principal;
  private String _username;
  private int _userId;
  private String _footprint;

  public SimpleSecurityContext(Principal principal, String username, int userId, String footprint)
  {
    _principal = principal;
    _username = username;
    _userId = userId;
    _footprint = footprint;
  }

  public boolean isUserInRole(String role)
  {
    return false;
  }

  public Principal getPrincipal()
  {
    return _principal;
  }

  public String getUsername()
  {
    return _username;
  }

  public int getUserId()
  {
    return _userId;
  }

  public String getFootprint()
  {
    return _footprint;
  }
}
