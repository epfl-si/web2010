package com.baneo.core.security.role;

import com.baneo.core.model.*;
import com.baneo.core.persistance.*;
import com.baneo.core.persistance.hibernate.*;

import java.security.*;
import java.util.*;

/**
 * HibernateObjectRoleManager.
 *
 * @author Laurent Boatto
 */
public class HibernateObjectRoleManager implements IObjectRoleManager
{
  private static final HibernatePersistanceManager _persistanceManager = HibernatePersistanceManager.instance();
  private static final HibernateObjectRoleManager _instance = new HibernateObjectRoleManager();
  private static final String[] HAS_ROLE_ATTRIBUTES_NAMES = new String[]{"principalName", "principalClassName", "role", "businessObjectId", "businessObjectClassName"};
  private static final String[] BY_BUSINESS_OBJECT_ATTRIBUTES_NAMES = new String[]{"businessObjectId", "businessObjectClassName"};
  private static final String[] BY_BUSINESS_OBJECT_AND_ROLE_ATTRIBUTES_NAMES = new String[]{"businessObjectId", "businessObjectClassName", "role"};


  public Collection findByPrincipal(Principal principal) throws PersistanceException
  {
    String[] attributesNames = {"principalName", "principalClassName"};

    Object[] attributesValues =
        {
          principal.getName(),
          principal.getClass().getName()
        };

    return _persistanceManager.findByAttributes(ObjectRole.class, attributesNames, attributesValues);
  }

  public Collection findAll() throws PersistanceException
  {
    return _persistanceManager.findAll(ObjectRole.class);
  }

  public Collection findByPrincipal(Principal principal, Class businessObjectClass) throws PersistanceException
  {
    String[] attributesNames = {"principalName", "principalClassName", "businessObjectClassName"};

    String[] attributesValues =
        {
          principal.getName(),
          principal.getClass().getName(),
          businessObjectClass.getName()
        };

    return _persistanceManager.findByAttributes(ObjectRole.class, attributesNames, attributesValues);
  }

  public Collection findByBusinessObject(BusinessObject object) throws PersistanceException
  {
    Object[] attributesValues =
        {
          new Integer(object.getId()),
          object.getClass().getName()
        };

    return _persistanceManager.findByAttributes(ObjectRole.class, BY_BUSINESS_OBJECT_ATTRIBUTES_NAMES, attributesValues);
  }

  public Collection findByBusinessObjectClass(Class klass) throws PersistanceException
  {
    return _persistanceManager.findByAttribute(ObjectRole.class, "businessObjectClassName", klass.getName());
  }

  public Collection findByBusinessObject(BusinessObject object, String orderBy, int startIndex, int maxResults) throws PersistanceException
  {
    Object[] attributesValues =
        {
          new Integer(object.getId()),
          object.getClass().getName()
        };

    return _persistanceManager.findByAttributes(ObjectRole.class, BY_BUSINESS_OBJECT_ATTRIBUTES_NAMES, attributesValues, orderBy, startIndex, maxResults);
  }

  public ObjectRole findFirstByBusinessObjectAndRole(BusinessObject businessObject, String role) throws PersistanceException
  {
    String[] attributesNames = {"businessObjectId", "businessObjectClassName", "role"};
    Object[] attributesValues =
        {
          new Integer(businessObject.getId()),
          businessObject.getClass().getName(),
          role
        };
    return (ObjectRole) _persistanceManager.findFirstByAttributes(ObjectRole.class, attributesNames, attributesValues);
  }

  public Collection findByBusinessObjectAndRole(BusinessObject businessObject, String role) throws PersistanceException
  {
    String[] attributesNames = {"businessObjectId", "businessObjectClassName", "role"};
    Object[] attributesValues =
        {
          new Integer(businessObject.getId()),
          businessObject.getClass().getName(),
          role
        };
    return _persistanceManager.findByAttributes(ObjectRole.class, attributesNames, attributesValues);
  }


  public int findByBusinessObjectCount(BusinessObject object) throws PersistanceException
  {
    Object[] attributesValues =
        {
          new Integer(object.getId()),
          object.getClass().getName()
        };

    return _persistanceManager.findByAttributesCount(ObjectRole.class, BY_BUSINESS_OBJECT_ATTRIBUTES_NAMES, attributesValues);
  }

  public int findByBusinessObjectAndRoleCount(BusinessObject object, String role) throws PersistanceException
  {
    Object[] attributesValues =
        {
          new Integer(object.getId()),
          object.getClass().getName(),
          role
        };

    return _persistanceManager.findByAttributesCount(ObjectRole.class, BY_BUSINESS_OBJECT_AND_ROLE_ATTRIBUTES_NAMES, attributesValues);
  }

  public ObjectRole findFirstByPrincipalAndBusinessObject(Principal principal, BusinessObject object) throws PersistanceException
  {
    String[] attributesNames = new String[]{"principalName", "principalClassName", "businessObjectId", "businessObjectClassName"};

    Object[] attributesValues =
        {
          principal.getName(),
          principal.getClass().getName(),
          new Integer(object.getId()),
          object.getClass().getName()
        };

    return (ObjectRole) _persistanceManager.findFirstByAttributes(ObjectRole.class, attributesNames, attributesValues);
  }

  public Collection findByPrincipalAndBusinessObject(Principal principal, BusinessObject object) throws PersistanceException
  {
    String[] attributesNames = new String[]{"principalName", "principalClassName", "businessObjectId", "businessObjectClassName"};

    Object[] attributesValues =
        {
          principal.getName(),
          principal.getClass().getName(),
          new Integer(object.getId()),
          object.getClass().getName()
        };

    return _persistanceManager.findByAttributes(ObjectRole.class, attributesNames, attributesValues);
  }

  public ObjectRole get(int id) throws PersistanceException
  {
    return (ObjectRole) _persistanceManager.get(ObjectRole.class, id);
  }

  public ObjectRole get(String id) throws PersistanceException
  {
    return get(Integer.parseInt(id));
  }

  public boolean hasRole(Principal principal, String role, BusinessObject object) throws PersistanceException
  {
    Object[] attributesValues =
        {
          principal.getName(),
          principal.getClass().getName(),
          role,
          new Integer(object.getId()),
          object.getClass().getName()
        };

    return null != _persistanceManager.findFirstByAttributes(ObjectRole.class, HAS_ROLE_ATTRIBUTES_NAMES, attributesValues);
  }

  public boolean hasOwnerRole(Principal principal, BusinessObject businessObject) throws PersistanceException
  {
    return hasRole(principal, ROLE_OWNER, businessObject);
  }

  public ObjectRole addRole(String role, Principal principal, String principalLabel, BusinessObject object) throws PersistanceException
  {
    ObjectRole roleAccess = new ObjectRole();
    roleAccess.setPrincipalName(principal.getName());
    roleAccess.setPrincipalClassName(principal.getClass().getName());
    roleAccess.setPrincipalLabel(principalLabel);
    roleAccess.setRole(role);
    roleAccess.setBusinessObjectId(object.getId());
    roleAccess.setBusinessObjectClassName(object.getClass().getName());

    _persistanceManager.insert(roleAccess);
    return roleAccess;
  }

  public void removeRole(String role, Principal principal, BusinessObject object) throws PersistanceException
  {
    Object[] attributesValues =
        {
          principal.getName(),
          principal.getClass().getName(),
          role,
          new Integer(object.getId()),
          object.getClass().getName()
        };

    Object toDelete = _persistanceManager.findFirstByAttributes(ObjectRole.class, HAS_ROLE_ATTRIBUTES_NAMES, attributesValues);
    _persistanceManager.delete(toDelete);
  }

  public static HibernateObjectRoleManager instance()
  {
    return _instance;
  }

  public void insert(ObjectRole objectRole) throws PersistanceException
  {
    _persistanceManager.insert(objectRole);
  }

  public void update(ObjectRole objectRole) throws PersistanceException
  {
    _persistanceManager.update(objectRole);
  }

  public void delete(ObjectRole objectRole) throws PersistanceException
  {
    _persistanceManager.delete(objectRole);
  }
}