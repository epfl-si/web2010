/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.security;

import com.baneo.core.jsp.taglib.*;

import javax.servlet.http.*;
import javax.servlet.jsp.*;

/**
 * A JSP taglib that automatically set the security context using the current
 * request.
 *
 * @author  Laurent Boatto
 * @version $Id$
 * @see     ServletSecurityContext
 * @see     SecurityContextManager
 */

public class SecurityContextTag extends AbstractTag
{
  public int doStartTag() throws JspException
  {
    SecurityContextManager.setSecurityContext(
        new ServletSecurityContext((HttpServletRequest) pageContext.getRequest()));

    return SKIP_BODY;
  }
}