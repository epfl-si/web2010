/*
 * $Id$
 */

package ch.epfl.kis.core.ldap;

import com.novell.ldap.*;

import java.util.*;

/**
 * LdapConnector.
 *
 * @author Laurent Boatto
 */
public class LdapConnector
{
  public static final int SCOPE_BASE = LDAPConnection.SCOPE_BASE;
  public static final int SCOPE_ONE = LDAPConnection.SCOPE_ONE;
  public static final int SCOPE_SUB = LDAPConnection.SCOPE_SUB;

  private static int _ldapPort = LDAPConnection.DEFAULT_PORT;
  private static int _ldapVersion = LDAPConnection.LDAP_V3;
  private static String _ldapHost;
  private static String _username;
  private static String _password;
  private static String[] _organizations;

  /**
   * Constructs a new LdapConnector.
   *
   * @param host the ldap server host.
   * @param username the ldap server username.
   * @param password the ldap server password.
   * @param organizations the organizations used importer the ldap server, e.g.
   *        "o=epfl,c=ch".
   */
  public LdapConnector(String host, String username, String password, String[] organizations)
  {
    _ldapHost = host;
    _username = username;
    _password = password;
    _organizations = organizations;
  }

  /**
   * Constructs a new LdapConnector.
   *
   * @param host the ldap server host.
   * @param port the ldap server port.
   * @param version the ldap server version.
   * @param username the ldap server username.
   * @param password the ldap server password.
   * @param organizations the organizations used importer the ldap server, e.g.
   *        "o=epfl,c=ch".
   */
  public LdapConnector(String host, int port, int version, String username, String password, String[] organizations)
  {
    _ldapPort = port;
    _ldapVersion = version;
    _ldapHost = host;
    _username = username;
    _password = password;
    _organizations = organizations;
  }

  /**
   * Returns a connection to the LDAP server.
   *
   * @return a connection to the LDAP server.
   * @throws LDAPException on ldap error.
   */
  private static LDAPConnection getConnection() throws LDAPException
  {
    LDAPConnection connection = new LDAPConnection();

    connection.connect(_ldapHost, _ldapPort);
    connection.bind(_ldapVersion, _username, _password);

    return connection;
  }

  /**
   * Tries to connect to the ldap server with the given username and password,
   * and throws a LDAPException if the creditentials are not valid.
   *
   * @param username the username.
   * @param password the password.
   * @throws LDAPException if the creditentials are not valid.
   */
  public static void checkPassword(String username, String password) throws LDAPException
  {
    LDAPConnection connection = new LDAPConnection();

    connection.connect(_ldapHost, _ldapPort);
    connection.bind(_ldapVersion, username, password);
  }

  /**
   * Find an LDAPEntry given the search filter (e.g. "(uid=foo)").
   *
   * @param scope the scope of the search, use LDAPConnection.SCOPE_*.
   * @param searchFilter the search filter (e.g. "(uid=foo)").
   * @return the LDAPEntry corresponding to the search filter.
   * @throws LDAPException on ldap error.
   */
  public LDAPEntry findFirstBySearchFilter(int scope, String searchFilter) throws LDAPException
  {
    LDAPConnection connection = getConnection();

    // We search importer various ldap trees, the most probale first
    for (int i = 0; i < _organizations.length; i++)
    {
      LDAPSearchResults searchResults =
          connection.search(_organizations[i],
              scope,
              searchFilter,
              null,
              false);

      if (searchResults.hasMore())
      {
        return searchResults.next();
      }
    }

    // disconnect with the server
    connection.disconnect();

    return null;
  }

  /**
   * Returns the LDAPEntry having the given dn.
   *
   * @param dn the LDAPEntry dn.
   * @return the LDAPEntry having the given dn.
   * @throws LDAPException on ldap error.
   */
  public LDAPEntry findByDn(String dn) throws LDAPException
  {
    LDAPConnection connection = null;

    try
    {
      connection = getConnection();
      return connection.read(dn);
    }
    finally
    {
      // disconnect with the server
      if (connection != null)
      {
        connection.disconnect();
      }
    }
  }

  /**
   * Finds the ldap entries using the given parameters.
   *
   * @param searchBase the search base, e.g. "o=epfl,c=ch".
   * @param scope the scope of the search, use LDAPConnection.SCOPE_*.
   * @param searchFilter the search filter (e.g. "(uid=foo)").
   * @return the ldap entries using the given parameters.
   * @throws LDAPException on ldap error.
   */
  public Collection find(String searchBase, int scope, String searchFilter) throws LDAPException
  {
    LDAPConnection connection = null;

    try
    {
      connection = getConnection();
      Collection results = new ArrayList();

      LDAPSearchResults searchResults =
          connection.search(searchBase,
              scope,
              searchFilter,
              null,
              false);

      while (searchResults.hasMore())
      {
        results.add(searchResults.next());
      }

      return results;
    }
    finally
    {
      // disconnect with the server
      if (connection != null)
      {
        connection.disconnect();
      }
    }
  }

  /**
   * Find an LDAPEntry given scope and the search filter (e.g. "(uid=foo)").
   *
   * @param scope the scope of the search, use LDAPConnection.SCOPE_*.
   * @param searchFilter the search filter (e.g. "(uid=foo)").
   * @param searchBase the search base, e.g. "o=epfl,c=ch".
   * @return the LDAPEntry corresponding to the search filter.
   * @throws LDAPException on ldap error.
   */
  public LDAPEntry findFirstBySearchFilter(int scope, String searchFilter, String searchBase) throws LDAPException
  {
    LDAPConnection connection = null;

    try
    {
      connection = getConnection();

      LDAPSearchResults searchResults =
          connection.search(searchBase,
              scope,
              searchFilter,
              null,
              false);

      if (searchResults.hasMore())
      {
        return searchResults.next();
      }

      return null;
    }
    finally
    {
      // disconnect with the server
      if (connection != null)
      {
        connection.disconnect();
      }
    }
  }

  /**
   * Find an LDAPEntry given the scope and the search filter (e.g. "(uid=foo)").
   *
   * @param scope the scope of the search, use LDAPConnection.SCOPE_*.
   * @param searchFilter the search filter (e.g. "(uid=foo)").
   * @param searchBase the search base, e.g. "o=epfl,c=ch".
   * @return the LDAPEntry corresponding to the search filter.
   * @throws LDAPException on ldap error.
   */
  public Collection findBySearchFilter(int scope, String searchFilter, String searchBase) throws LDAPException
  {
    LDAPConnection connection = null;

    try
    {
      connection = getConnection();
      Collection results = new ArrayList();

      LDAPSearchResults searchResults =
          connection.search(searchBase,
              scope,
              searchFilter,
              null,
              false);


      while (searchResults.hasMore())
      {
        results.add(searchResults.next());
      }

      return results;
    }
    finally
    {
      // disconnect with the server
      if (connection != null)
      {
        connection.disconnect();
      }
    }
  }

  /**
   * Find an LDAPEntry given scope and the search filter (e.g. "(uid=foo)").
   *
   * @param scope the scope of the search, use LDAPConnection.SCOPE_*.
   * @param searchFilter the search filter (e.g. "(uid=foo)").
   * @return the LDAPEntry corresponding to the search filter.
   * @throws LDAPException on ldap error.
   */
  public Collection findBySearchFilter(int scope, String searchFilter) throws LDAPException
  {
    LDAPConnection connection = null;

    try
    {
      connection = getConnection();
      Collection results = new ArrayList();

      // We search importer various ldap trees, the most probale first
      for (int i = 0; i < _organizations.length; i++)
      {
        LDAPSearchResults searchResults =
            connection.search(_organizations[i],
                scope,
                searchFilter,
                null,
                false);

        while (searchResults.hasMore())
        {
          results.add(searchResults.next());
        }
      }

      return results;
    }
    finally
    {
      // disconnect with the server
      if (connection != null)
      {
        connection.disconnect();
      }
    }
  }
}