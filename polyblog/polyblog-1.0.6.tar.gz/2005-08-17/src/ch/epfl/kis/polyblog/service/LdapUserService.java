package ch.epfl.kis.polyblog.service;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.security.*;
import com.baneo.core.persistance.*;
import com.novell.ldap.*;
import org.apache.commons.logging.*;

/**
 * LdapUserService.
 *
 * @author Laurent Boatto
 */
public class LdapUserService implements IUserService
{
  /**
   * todo put this in attributes
   */
  private static final String[] SEARCH_ATTRIBUTES = {"uniqueIdentifier", "uid", "mail"};

  /**
   * The LDAP attribute holding the name (of the Principal).
   */
  /**
   * todo put this in attribute
   */
  private static final String NAME_ATTRIBUTE = "uniqueIdentifier";

  /**
   * The log.
   */
  private static final Log _log = LogFactory.getLog(LdapUserService.class);

  public User get(String id) throws PersistanceException
  {
    try
    {
      LDAPEntry entry = null;

      // search the user using the search attributes
      /** todo use the OR ldap search notation */
      for (int i = 0; i < SEARCH_ATTRIBUTES.length; i++)
      {
        entry = LdapConnectorFactory.getLdapConnector().findFirstBySearchFilter(LDAPConnection.SCOPE_SUB, "(" + SEARCH_ATTRIBUTES[i] + "=" + id + ")");

        if (entry != null)
        {
          break;
        }
      }

      if (entry == null)
      {
        return null;
      }

      String uniqueIdentifier = entry.getAttribute(NAME_ATTRIBUTE).getStringValue();
      LdapUser user = new LdapUser(uniqueIdentifier, entry);

      try
      {
        user.setId(Integer.parseInt(uniqueIdentifier));
      }
      catch (NumberFormatException e)
      {
        // the uniqueIdentifier is not numeric, not a problem
      }

      // Sets the user attributes
      LDAPAttribute email = entry.getAttribute("mail");
      if (email != null)
      {
        user.setEmail(email.getStringValue());
      }

      LDAPAttribute firstName = entry.getAttribute("givenName");
      if (firstName != null)
      {
        user.setFirstName(firstName.getStringValue());
      }

      LDAPAttribute lastName = entry.getAttribute("sn");
      if (lastName != null)
      {
        user.setLastName(lastName.getStringValue());
      }

      LDAPAttribute uid = entry.getAttribute("uid");
      if (uid != null)
      {
        user.setUsername(uid.getStringValue());
      }

      user.setDn(entry.getDN());

      return user;
    }
    catch (LDAPException e)
    {
      _log.error(e.getMessage(), e);
      throw new PersistanceException(e);
    }
  }

  public User authenticate(String username, String password) throws PersistanceException
  {
    return LdapAuthenticator.authenticate(username, password);
  }

  public String getName()
  {
    return "ldap";
  }

  public Class<LdapUser> getUserClass()
  {
    return LdapUser.class;
  }
}