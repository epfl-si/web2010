package ch.epfl.kis.polyblog.service;

import ch.epfl.kis.core.ldap.*;
import ch.epfl.kis.polyblog.system.*;

/**
 * Factory for LdapConnector.
 *
 * @author Laurent Boatto
 */
public class LdapConnectorFactory
{
  private static final LdapConnector _ldapConnector = new LdapConnector(Constants.LDAP_HOST, Constants.LDAP_PORT, Constants.LDAP_VERSION, Constants.LDAP_USERNAME, Constants.LDAP_PASSWORD, Constants.LDAP_ORGANIZATIONS);

  /**
   * Private constructor.
   */
  private LdapConnectorFactory()
  {
  }

  /**
   * Returns the LdapConnector used by the application (singleton).
   *
   * @return the LdapConnector used by the application (singleton).
   */
  public static final LdapConnector getLdapConnector()
  {
    return _ldapConnector;
  }
}