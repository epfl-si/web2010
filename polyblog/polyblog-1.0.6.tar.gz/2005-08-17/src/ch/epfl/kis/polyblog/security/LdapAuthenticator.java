/*
 * $Id$
 *
 * Copyright 2005 EPFL. All rights reserved.
 */

package ch.epfl.kis.polyblog.security;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.service.*;
import com.baneo.core.persistance.*;
import com.novell.ldap.*;
import org.apache.commons.logging.*;

/**
 * Authenticator using LDAP.
 *
 * @author Laurent Boatto
 */
public class LdapAuthenticator
{
  /**
   * The log.
   */
  private static final Log _log = LogFactory.getLog(LdapAuthenticator.class);

  /**
   * Tries to authenticate a Principal using the given username and password.
   *
   * @param username the username.
   * @param password the password.
   * @return the authenticated Principal, or null if the authentification failed.
   */
  public static User authenticate(String username, String password)
  {
    try
    {
      // First we search a user with the given username
      LdapUser user = (LdapUser) UserService.instance().get(username, LdapUser.class);

      if (user == null)
      {
        return null;
      }

      // Ok the user exists, now we check the password
      try
      {
        // this check is important, because otherwise an anonymous connection
        // is always ok!!
        if (password == null || password.trim().equals(""))
        {
          return null;
        }

        // password check
        LdapConnectorFactory.getLdapConnector().checkPassword(user.getDn(), password);

        return user;
      }
      // Wrong creditentials
      catch (LDAPException e)
      {
        return null;
      }
    }
    catch (PersistanceException e)
    {
      // There is nothing we can do, the thread should stop
      _log.error(e.getMessage(), e);
      throw new RuntimeException(e);
    }
  }
}