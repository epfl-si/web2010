package ch.epfl.kis.polyblog.listener;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.service.*;
import com.baneo.core.persistance.*;
import com.baneo.core.service.*;

import java.util.*;

/**
 * Listeners for the BlogManager regarding the objects directly linked
 * to it.
 *
 * @author Laurent Boatto
 */
public class LinkBlogServiceListener extends BaseBusinessObjectManagerListener
{
  private static final CategoryService _categoryService = CategoryService.instance();
  private static final ArticleService _articleService = ArticleService.instance();

  public void preDelete(BusinessObjectManagerEvent event) throws PersistanceException
  {
    Blog blog = (Blog) event.getSource();

    // If a blog we be delete, we delete first..

    // all it's articles..
    Collection<Article> articles = _articleService.findByBlog(blog);

    for (Article article : articles)
    {
      _articleService.delete(article);
    }

    // all it's categories..
    Collection<Category> categories = _categoryService.findByBlogId(blog.getId());

    for (Category category : categories)
    {
      _categoryService.delete(category);
    }

    // all it's subscriptions
    SubscriptionService.instance().deleteByBlog(blog);
  }
}