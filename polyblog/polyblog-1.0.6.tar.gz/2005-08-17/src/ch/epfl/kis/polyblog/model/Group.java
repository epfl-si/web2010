package ch.epfl.kis.polyblog.model;

/**
 * Group.
 *
 * @author Laurent Boatto
 */
public abstract class Group extends User implements java.security.acl.Group
{
  private String _groupname;

  /**
   * Constructs a new Group with the given Principal name.
   *
   * @param name the Principal name.
   */
  public Group(String name)
  {
    super(name);
  }

  public String getLabel()
  {
    return _label;
  }

  public String getGroupname()
  {
    return _groupname;
  }

  public void setGroupname(String groupname)
  {
    _groupname = groupname;
  }

  public boolean equals(Object other)
  {
    if (this == other)
    {
      return true;
    }

    if (!(other instanceof Group))
    {
      return false;
    }

    final Group group = (Group) other;

    if (!getName().equals(group.getName()))
    {
      return false;
    }

    return true;
  }

  public int hashCode()
  {
    return getName().hashCode();
  }
}