/*
 * $Id$
 *
 * Copyright 2005 EPFL. All rights reserved.
 */

package ch.epfl.kis.polyblog.system;

import ch.epfl.kis.polyblog.listener.*;
import ch.epfl.kis.polyblog.service.*;
import com.baneo.core.mail.*;
import com.baneo.core.system.*;
import org.apache.commons.logging.*;

import java.io.*;
import java.util.*;

/**
 * Initializes the Blog application.
 *
 * @author Laurent Boatto
 */
public class BlogInitializer implements Initializer
{
  /**
   * The log.
   */
  private static final Log _log = LogFactory.getLog(BlogInitializer.class);

  public void initialize() throws InitializerException
  {
    SendMail.setSmtpHost(Config.get("mail.smtp.host"));

    // Check mandatory directories
    File tempDirectory = new File(Config.get("system.temp.path"));

    if (!tempDirectory.exists() || !tempDirectory.canWrite())
    {
      throw new InitializerException("Temporary directory " + tempDirectory.getAbsolutePath() + " doesn't exist or isn't writable. Please check your property 'system.temp.path' in " + ApplicationInitializer.PROPERTIES_FILE_NAME);
    }

    File documentDirectory = new File(Config.get("system.document.path"));

    if (!documentDirectory.exists() || !documentDirectory.canWrite())
    {
      throw new InitializerException("Document directory " + documentDirectory.getAbsolutePath() + " doesn't exist or isn't writable. Please check your property 'system.document.path' in " + ApplicationInitializer.PROPERTIES_FILE_NAME);
    }

    // Register the ResourceBundles
    // todo do this dynamically
    ResourceBundle enBundle = ResourceBundle.getBundle("resources/messages", Locale.ENGLISH);
    ResourceBundle frBundle = ResourceBundle.getBundle("resources/messages", Locale.FRENCH);

    //ApplicationResources.addResourceBundle(enBundle, false);
    ApplicationResources.addResourceBundle(frBundle, true);

    // Register the listeners
    BlogService.instance().addIBusinessObjectManagerListener(new ObjectRoleBlogServiceListener());
    BlogService.instance().addIBusinessObjectManagerListener(new LinkBlogServiceListener());
    ArticleService.instance().addIBusinessObjectManagerListener(new ObjectRoleArticleServiceListener());
    ArticleService.instance().addIBusinessObjectManagerListener(new LinkArticleServiceListener());
    CommentService.instance().addIBusinessObjectManagerListener(new LinkCommentServiceListener());

    // Registers the user managers
    String[] userServicesNames = Config.getStringArray("userService.provider");

    for (int i = 0; i < userServicesNames.length; i++)
    {
      String managerClass = Config.get("userService.provider." + userServicesNames[i] + ".class");

      try
      {
        IUserService userService = (IUserService) Class.forName(managerClass).newInstance();
        UserService.instance().registerIUserService(userService);
      }
      catch (Exception e)
      {
        _log.fatal(e.getMessage(), e);
        throw new InitializerException(managerClass + " is not a valid ch.epfl.kis.polyblog.service.IUserService", e);
      }
    }
  }
}