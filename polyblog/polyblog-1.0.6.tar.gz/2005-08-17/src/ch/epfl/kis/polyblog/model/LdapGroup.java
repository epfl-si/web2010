package ch.epfl.kis.polyblog.model;

import java.security.*;
import java.util.*;

/**
 * LdapGroup.
 *
 * @author Laurent Boatto
 */
public class LdapGroup extends Group
{
  private String _dn;

  /**
   * Constructs a new LdapGroup with the given Principal name.
   *
   * @param name the Principal name.
   */
  public LdapGroup(String name)
  {
    super(name);
  }

  public String getDn()
  {
    return _dn;
  }

  public void setDn(String dn)
  {
    _dn = dn;
  }

  public boolean addMember(Principal user)
  {
    throw new UnsupportedOperationException("This implementation is read only");
  }

  public boolean removeMember(Principal user)
  {
    throw new UnsupportedOperationException("This implementation is read only");
  }

  public boolean isMember(Principal member)
  {
    throw new UnsupportedOperationException("This implementation is read only");
  }

  public Enumeration members()
  {
    throw new UnsupportedOperationException("This implementation is read only");
  }

  public boolean isGuest()
  {
    throw new UnsupportedOperationException("This implementation is read only");
  }

  public Collection<Group> getGroups()
  {
    return null;
  }
}
