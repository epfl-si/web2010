/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package ch.epfl.kis.polyblog.service;

/**
 * Thrown by the TemplateService on error.
 *
 * @author Laurent Boatto
 * @version $Id$
 */

public class TemplateException extends Exception
{
  /**
   * Constructs of the TemplateException with the given cause.
   *
   * @param cause the cause of the TemplateException.
   */
  public TemplateException(Throwable cause)
  {
    super(cause);
  }
}
