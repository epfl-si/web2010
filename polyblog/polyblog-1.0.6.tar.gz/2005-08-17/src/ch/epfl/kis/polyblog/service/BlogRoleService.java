package ch.epfl.kis.polyblog.service;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.security.*;
import com.baneo.core.persistance.*;
import com.baneo.core.security.role.*;
import com.baneo.core.service.*;

import java.util.*;

/**
 * BlogRoleService.
 *
 * @author Laurent Boatto
 */
public class BlogRoleService extends BusinessObjectManager
{
  private static final IPersistanceManager _persistanceManager = PersistanceManagerFactory.getIPersistanceManager();
  private IObjectRoleManager _manager = ObjectRoleManagerFactory.getIObjectRoleManager();
  private static final BlogRoleService _instance = new BlogRoleService();

  /**
   * Returns the instance of the BlogRoleService (singleton).
   *
   * @return the instance of the BlogRoleService (singleton).
   */
  public static BlogRoleService instance()
  {
    return _instance;
  }

  /**
   * Adds the given role to the given principal for the given blog.
   *
   * @param role the role to give.
   * @param user the User to give the role to.
   * @param blog the blog the role will be linked to.
   * @return the added ObjectRole.
   * @throws PersistanceException on persistance layer error.
   */
  public ObjectRole addRole(String role, User user, Blog blog) throws PersistanceException
  {
    return _manager.addRole(role, user, user.getLabel(), blog);
  }

  /**
   * Deletes the given ObjectRole (which must be linked to SubscriptionService Blog).
   *
   * @param role the role to delete.
   * @throws PersistanceException on persistance layer error.
   */
  public void delete(ObjectRole role) throws PersistanceException
  {
    _manager.delete(role);
  }

  /**
   * Returns the ObjectRoles linked to the given blog.
   *
   * @param blog the blog.
   * @return the ObjectRoles linked to the given blog.
   * @throws PersistanceException on persistance layer error.
   */
  public Collection findByBlog(Blog blog) throws PersistanceException
  {
    return _manager.findByBusinessObject(blog);
  }

  /**
   * Checks if the given objectRoles can be deleted for the Blog, i.e. if there
   * will be enough administrators after the deletion.
   *
   * @param objectRoles the ObjectRoles that will be deleted.
   * @param blog        the blog.
   * @return true if the given objectRoles can be deleted for the Blog.
   * @throws PersistanceException on persistance layer error.
   */
  public boolean isDeletePossible(Collection objectRoles, Blog blog) throws PersistanceException
  {
    int administratorsToDelete = 0;

    for (Iterator iterator = objectRoles.iterator(); iterator.hasNext();)
    {
      ObjectRole role = (ObjectRole) iterator.next();

      if (role.getRole().equals(SecurityService.ROLE_ADMINISTRATOR))
      {
        administratorsToDelete++;
      }
    }

    int totalAdministrators = _manager.findByBusinessObjectAndRoleCount(blog, SecurityService.ROLE_ADMINISTRATOR);

    return administratorsToDelete < totalAdministrators;
  }

  /**
   * Checks if the given newRole can be affected to the given objectRole, i.e.
   * if there will be enough administrators left after the operation.
   *
   * @param objectRole the objectRole that will be updated.
   * @param newRole    the new role that will be affected to the objectRole.
   * @param blog       the blog containing the objectRole.
   * @return true if the given newRole can be affected to the given objectRole.
   * @throws PersistanceException on persistance layer error.
   */
  public boolean isUpdatePossible(ObjectRole objectRole, String newRole, Blog blog) throws PersistanceException
  {
    // we can always add an administrator
    if (newRole.equals(SecurityService.ROLE_ADMINISTRATOR))
    {
      return true;
    }

    String oldRole = objectRole.getRole();

    // if the old role was not administrator, we don't care
    if (!oldRole.equals(SecurityService.ROLE_ADMINISTRATOR))
    {
      return true;
    }

    // ok so if we arrive here the user want to remove the administrator role
    // of someone, we must check that there is at least 2 administrators
    // (so there is one left after the operation)

    int totalAdministrators = _manager.findByBusinessObjectAndRoleCount(blog, SecurityService.ROLE_ADMINISTRATOR);

    return totalAdministrators > 1;
  }

  protected IPersistanceManager getIPersistanceManager()
  {
    return _persistanceManager;
  }

  protected Class getManagedClass()
  {
    return ObjectRole.class;
  }
}