package ch.epfl.kis.polyblog.view.web.action.blog;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.security.*;
import ch.epfl.kis.polyblog.service.*;
import org.apache.struts.action.*;

import javax.servlet.http.*;

/**
 * Action for managing a Blog.
 *
 * @author Laurent Boatto
 */
public class BlogManageAction extends Action
{
  public ActionForward execute(ActionMapping actionMapping, ActionForm actionForm, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    Blog blog = BlogService.instance().get(request.getParameter("id"));
    SecurityService.checkViewMenuBlog(blog);
    request.setAttribute("blog", blog);
    String role = SecurityService.getRole(blog);
    request.setAttribute("role", role);
    return actionMapping.findForward("init");
  }
}