package ch.epfl.kis.polyblog.validator;

import ch.epfl.kis.polyblog.model.*;
import com.baneo.core.validator.*;

import java.util.*;

/**
 * CommentValidator.
 *
 * @author Laurent Boatto
 */
public class CommentValidator extends Validator
{
  public CommentValidator(Comment comment, Map values, int mode, Locale locale)
  {
    super(comment, values, mode, locale);
  }

  /**
   * Validates the content.
   *
   * @param content
   */
  public void validateContent(String content)
  {
    if (addErrorIfEmpty(content))
    {
      return;
    }

    saveTrimmedValue();
  }
}