/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package ch.epfl.kis.polyblog.view.web.action.blogRole;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.service.*;
import com.baneo.core.security.role.*;
import com.baneo.core.view.web.action.*;
import org.apache.struts.action.*;

import javax.servlet.http.*;
import java.util.*;
import java.io.*;

/**
 * Action used to delete a _object_.
 *
 * @author Laurent Boatto
 * @version $Id$
 * @see com.baneo.core.view.web.action.ObjectDeleteAction
 * @see org.apache.struts.action.Action
 */

public class BlogRoleDeleteAction extends ObjectDeleteAction
{
  private IObjectRoleManager _objectRoleManager = ObjectRoleManagerFactory.getIObjectRoleManager();
  private BlogRoleService _blogRoleService = BlogRoleService.instance();

  public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    Blog blog = BlogService.instance().get(request.getParameter("blogId"));
    request.setAttribute("blog", blog);

    ActionForward dynamicBack = new ActionForward("back", "/private/blogRole/list.do?blogId=" + request.getParameter("blogId"), true);
    ActionMapping dynamicMapping = new ActionMapping();

    dynamicMapping.addForwardConfig(mapping.findForward("init"));
    dynamicMapping.addForwardConfig(dynamicBack);

    if (request.getParameter(ObjectDeleteAction.PARAMETER_DELETE_ID) == null)
    {
      return dynamicBack;
    }

    if (!checkDelete(request))
    {
      return mapping.findForward("notEnoughAdministrators");
    }

    return super.execute(dynamicMapping, form, request, response);
  }

  protected void delete(String id, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    _objectRoleManager.delete((ObjectRole) find(id, request, response));
  }

  protected Object find(String id, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    return _objectRoleManager.get(id);
  }

  /**
   * Checks that the role can be deleted. A deletion is impossible if there
   * is not at least one administrator after it.
   *
   * @param request the request.
   * @return true if the role can be deleted.
   * @throws Exception on error.
   */
  private boolean checkDelete(HttpServletRequest request) throws Exception
  {
    String[] ids = request.getParameterValues(ObjectDeleteAction.PARAMETER_DELETE_ID);
    Blog blog = (Blog) request.getAttribute("blog");
    Collection rolesToDelete = new ArrayList();

    for (int i = 0; i < ids.length; i++)
    {
      String id = ids[i];
      ObjectRole role = _objectRoleManager.get(id);
      rolesToDelete.add(role);
    }

    return _blogRoleService.isDeletePossible(rolesToDelete, blog);
  }

  protected ActionForward getSuccessActionForward(ActionMapping mapping, HttpServletRequest request, HttpServletResponse response) throws IOException
  {
    Integer count = (Integer) request.getAttribute(ATTRIBUTE_COUNT);
    String url = request.getContextPath() + "/private/blogRole/list.do?blogId=" + request.getParameter("blogId");

    if (count > 1)
    {
      url += "&confirmation=common.blogRole.delete.confirmation.plural";
    }
    else
    {
      url += "&confirmation=common.blogRole.delete.confirmation.singular";
    }

    response.sendRedirect(url);

    return null;
  }
}