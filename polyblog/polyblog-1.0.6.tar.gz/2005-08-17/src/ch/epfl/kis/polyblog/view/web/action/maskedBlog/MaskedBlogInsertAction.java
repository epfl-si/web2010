package ch.epfl.kis.polyblog.view.web.action.maskedBlog;

import org.apache.struts.action.*;

import javax.servlet.http.*;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.service.*;
import ch.epfl.kis.polyblog.security.*;

/**
 * MaskedBlogInsertAction
 *
 * @author Laurent Boatto
 */
public class MaskedBlogInsertAction extends Action
{
  private static final BlogService _blogService = BlogService.instance();
  private static final MaskedBlogService _maskedBlogService = MaskedBlogService.instance();

  public ActionForward execute(ActionMapping mapping, ActionForm actionForm, HttpServletRequest request, HttpServletResponse httpServletResponse) throws Exception
  {
    User user = SecurityService.getUser();

    String[] ids = request.getParameterValues("ids");

    if (ids == null || ids.length == 0)
    {
      return mapping.findForward("back");
    }

    for (String id : ids)
    {
      Blog blog = _blogService.get(id);

      if (blog == null)
      {
        continue;
      }

      _maskedBlogService.mask(blog, user);
    }

    if (ids.length > 1)
    {
      return mapping.findForward("success.plural");
    }

    return mapping.findForward("success.singular");
  }
}