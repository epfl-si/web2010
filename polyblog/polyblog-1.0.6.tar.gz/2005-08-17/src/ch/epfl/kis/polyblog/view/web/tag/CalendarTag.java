package ch.epfl.kis.polyblog.view.web.tag;

import ch.epfl.kis.polyblog.model.*;
import com.baneo.core.jsp.taglib.*;
import com.baneo.core.persistance.*;
import com.baneo.core.system.*;
import com.baneo.core.util.*;
import org.apache.commons.logging.*;

import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import java.io.*;
import java.text.*;
import java.util.*;


/**
 * Displays the blog's calendar. Note : this code is largely inspired from
 * the CalendarTag of the JRoller weblog (http://www.jroller.com).
 *
 * @author Laurent Boatto
 */
public class CalendarTag extends AbstractTag
{
  private static Log _log = LogFactory.getFactory().getInstance(CalendarTag.class);

  /**
   * Constructs a new CalendarTag.
   */
  public CalendarTag()
  {
  }

  /**
   * Write to a PrintWriter so that tag may be used from Velocity
   */
  public int doStartTag(JspWriter out) throws IOException, JspException
  {
    Date displayDay = null;
    Calendar dayCalendar;
    Calendar calendar;
    Calendar todayCalendar;
    CalendarModel model;

    // ---------------------------------
    // --- initialize date variables ---

    HttpServletRequest request = (HttpServletRequest) pageContext.getRequest();
    // ---------------------------------

    // formatter Month-Year title of calendar
    SimpleDateFormat formatTitle = new SimpleDateFormat("MMMM yyyy", ApplicationResources.findBestRegisteredLocale(request.getLocale()));


    String blogParameter = request.getParameter("blog");
    Blog blog = (Blog) request.getAttribute("blog");
    String blogName = blog.getName();
    String blogDateString = null;

    if (blogParameter != null)
    {
      String[] blogData = blogParameter.split("/");
      blogDateString = null;

      if (blogData.length > 1)
      {
        blogDateString = blogData[1];
      }
    }

    Date blogDate = DateUtil.parseIsoDate(blogDateString);

    if (blogDate == null)
    {
      blogDate = new Date();
    }

    try
    {
      model = new CalendarModel(blog.getRelativeUrl(), blogDate, blog);
    }
    catch (PersistanceException e)
    {
      _log.error(e.getMessage(), e);
      throw new JspException(e.getMessage(), e);
    }

    displayDay = blogDate;

    // ceate object to represent today
    todayCalendar = Calendar.getInstance();
    todayCalendar.setTime(new Date());

    // go back to first displayDay importer month
    calendar = Calendar.getInstance();
    calendar.setTime(displayDay);
    calendar.set(Calendar.DAY_OF_MONTH, calendar.getMinimum(Calendar.DAY_OF_MONTH));
    calendar.set(Calendar.HOUR_OF_DAY, calendar.getMinimum(Calendar.HOUR_OF_DAY));
    calendar.set(Calendar.MINUTE, calendar.getMinimum(Calendar.MINUTE));
    calendar.set(Calendar.SECOND, calendar.getMinimum(Calendar.SECOND));
    calendar.set(Calendar.MILLISECOND, calendar.getMinimum(Calendar.MILLISECOND));

    // go back to sunday before that: the first sunday importer the calendar
    while (calendar.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY)
    {
      calendar.add(Calendar.DATE, -1);
    }

    // create table of 5 weeks, 7 days per row
    dayCalendar = Calendar.getInstance();
    dayCalendar.setTime(displayDay);

    //
    // draw the calendar
    //

    out.print("<table cellspacing=\"0\" border=\"0\" ");
    out.print(" class=\"calendarTable\">");
    out.print("<tr>");
    out.print("<td colspan=\"7\" align=\"center\" " +
        "class=\"calendarMonthYearRow\">");
    out.print(StringUtil.upperCaseFirstChar(formatTitle.format(displayDay)));
    out.print("</td></tr>");

    // emit the HTML calendar
    for (int week = -1; week < 6; week++)
    {
      out.print("<tr>");

      for (int d = 0; d < 7; d++)
      {
        if (week == -1)
        {
          out.print(
              "<th class=\"calendarDayHeader\" align=\"center\">");
          out.print(Message.get("common.calendar.day." + d, request.getLocale()));
          out.print("</th>");
          continue;
        }

        // determine URL for this calendar displayDay
        String url = null;
        String content = null;

        if (model != null)
        {
          Date tddate = calendar.getTime();
          url = model.computeUrl(tddate, false);
        }

        if
          // displayDay is today then use today style
            ((calendar.get(Calendar.DAY_OF_MONTH)
            == todayCalendar.get(Calendar.DAY_OF_MONTH))
            && (calendar.get(Calendar.MONTH)
            == todayCalendar.get(Calendar.MONTH))
            && (calendar.get(Calendar.YEAR)
            == todayCalendar.get(Calendar.YEAR)))
        {
          if (content != null)
          {
            out.print("<td class=\"calendarDayCurrent\">");
            out.print(content);
            out.print("</td>");
          }
          else if (url != null)
          {
            out.print("<td class=\"calendarDayCurrent\">");
            out.print("<a href=\"" + url + "\" "
                + ">");
            out.print(calendar.get(Calendar.DAY_OF_MONTH));
            out.print("</a>");
            out.print("</td>");
          }
          else
          {
            out.print("<td class=\"calendarDayCurrent\">");
            out.print(calendar.get(Calendar.DAY_OF_MONTH));
            out.print("</td>");
          }
        }
        else if
          // displayDay is importer calendar month
            ((calendar.get(Calendar.MONTH) == dayCalendar.get(Calendar.MONTH))
            && (calendar.get(Calendar.YEAR) == dayCalendar.get(Calendar.YEAR)))
        {
          if (content != null)
          {
            out.print("<td class=\"calendarDayCurrent\">");
            out.print(content);
            out.print("</td>");
          }
          else if (url != null)
          {
            out.print("<td class=\"calendarDay\">");
            out.print("<a href=\"" + url + "\">");
            out.print(calendar.get(Calendar.DAY_OF_MONTH));
            out.print("</a>");
            out.print("</td>");
          }
          else
          {
            out.print("<td class=\"calendarDay\">");
            out.print(calendar.get(Calendar.DAY_OF_MONTH));
            out.print("</td>");
          }
        }
        else
        {
          out.print("<td>");
          out.print("&nbsp;");
          out.print("</td>");
        }

        // increment calendar by one displayDay
        calendar.add(Calendar.DATE, 1);
      }
      out.print("</tr>");
    }

    out.print("<tr>");
    out.print("<td colspan=\"7\" align=\"center\">");

    /** todo i18n */
    out.print("<a href=\"" + model.computePrevMonthUrl()
        + "\">" + Message.get("common.calendar.previous", request.getLocale()) + "</a> | ");
    out.print("<a href=\"" + model.computeTodayMonthUrl()
        + "\">" + Message.get("common.calendar.today", request.getLocale()) + "</a>");

    if (!DateUtil.isSameMonth(todayCalendar.getTime(), displayDay))
    {
      out.print(" | <a href=\"" + model.computeNextMonthUrl()
          + "\">" + Message.get("common.calendar.next", request.getLocale()) + "</a>");
    }
    else
    {
      out.print(" | " + Message.get("common.calendar.next", request.getLocale()));
    }

    out.print("</td>");
    out.print("</tr>");

    out.print("</table>");

    return Tag.SKIP_BODY;
  }
}