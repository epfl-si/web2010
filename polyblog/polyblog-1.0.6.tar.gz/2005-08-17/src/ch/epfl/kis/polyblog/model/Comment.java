/*
 * $Id$
 *
 * Copyright 2005 EPFL. All rights reserved.
 */

package ch.epfl.kis.polyblog.model;

import ch.epfl.kis.polyblog.security.*;
import ch.epfl.kis.polyblog.service.*;
import com.baneo.core.model.*;
import com.baneo.core.persistance.*;
import com.baneo.core.security.role.*;

import java.util.*;

/**
 * Comment.
 *
 * @author Laurent Boatto
 */
public class Comment extends BusinessObject
{
  private String _content;
  private int _articleId;
  private Date _publicationDate;
  private String _authorFirstName;
  private String _authorLastName;

  public String getContent()
  {
    return _content;
  }

  public void setContent(String content)
  {
    _content = content;
  }

  public int getArticleId()
  {
    return _articleId;
  }

  public void setArticleId(int articleId)
  {
    _articleId = articleId;
  }

  public Date getPublicationDate()
  {
    return _publicationDate;
  }

  public void setPublicationDate(Date publicationDate)
  {
    _publicationDate = publicationDate;
  }

  public String getAuthorFirstName()
  {
    return _authorFirstName;
  }

  public void setAuthorFirstName(String authorFirstName)
  {
    _authorFirstName = authorFirstName;
  }

  public String getAuthorLastName()
  {
    return _authorLastName;
  }

  public void setAuthorLastName(String authorLastName)
  {
    _authorLastName = authorLastName;
  }

  // calculated attributes -----------------------------------------------------
  public Article getArticle() throws PersistanceException
  {
    return ArticleService.instance().get(_articleId);
  }

  public User getOwner() throws PersistanceException
  {
    ObjectRole role = ObjectRoleManagerFactory.getIObjectRoleManager().findFirstByBusinessObjectAndRole(this, SecurityService.ROLE_OWNER);
    return UserService.instance().get(role.getPrincipalName(), role.getPrincipalClass());
  }
}