package ch.epfl.kis.polyblog.listener;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.service.*;
import com.baneo.core.persistance.*;
import com.baneo.core.service.*;

/**
 * Listeners for the CommentService regarding linked objects.
 *
 * @author Laurent Boatto
 */
public class LinkCommentServiceListener extends BaseBusinessObjectManagerListener
{
  private static final ArticleService _articleService = ArticleService.instance();

  public void postInsert(BusinessObjectManagerEvent event) throws PersistanceException
  {
    Comment comment = (Comment) event.getSource();
    _articleService.incrementNumComment(comment.getArticle());

    // sends the new comments notifications

      EmailService.sendNewCommentNotification(comment);

  }

  public void postDelete(BusinessObjectManagerEvent event) throws PersistanceException
  {
    Comment comment = (Comment) event.getSource();
    _articleService.decrementNumComment(comment.getArticle());
  }
}