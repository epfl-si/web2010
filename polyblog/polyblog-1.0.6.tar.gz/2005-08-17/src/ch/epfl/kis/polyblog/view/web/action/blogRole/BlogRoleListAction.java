/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package ch.epfl.kis.polyblog.view.web.action.blogRole;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.security.*;
import ch.epfl.kis.polyblog.service.*;
import com.baneo.core.persistance.*;
import com.baneo.core.view.web.action.*;
import org.apache.struts.action.*;

import javax.servlet.http.*;
import java.util.*;

/**
 * Action used to list all the @boLabels@.
 *
 * @author Laurent Boatto
 * @version $Id$
 * @see com.baneo.core.view.web.action.ObjectListAction
 * @see org.apache.struts.action.Action
 */

public class BlogRoleListAction extends ObjectListAction
{
  /**
   * The manager used to do the search.
   */
  private static final BlogService _blogService = BlogService.instance();

  public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    return super.execute(mapping, form, request, response);
  }

  protected String getDefaultOrder()
  {
    return "principalLabel";
  }

  protected Collection find(HttpServletRequest request, HttpServletResponse response, String orderBy, int startIndex, int maxResults) throws PersistanceException
  {
    return _blogService.findRoles((Blog) request.getAttribute("blog"), orderBy, startIndex, maxResults);
  }

  protected int count(HttpServletRequest request, HttpServletResponse response) throws PersistanceException
  {
    int blogId = Integer.parseInt(request.getParameter("blogId"));
    Blog blog = BlogService.instance().get(blogId);
    SecurityService.checkManageBlogRoles(blog);
    request.setAttribute("blog", blog);
    return _blogService.findRolesCount(blog);
  }
}