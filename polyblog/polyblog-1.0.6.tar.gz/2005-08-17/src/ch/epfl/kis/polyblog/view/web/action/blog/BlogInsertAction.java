/*
 * $Id$
 *
 * Copyright 2005 EPFL. All rights reserved.
 */

package ch.epfl.kis.polyblog.view.web.action.blog;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.service.*;
import ch.epfl.kis.polyblog.util.*;
import ch.epfl.kis.polyblog.validator.*;
import com.baneo.core.system.*;
import com.baneo.core.util.*;
import com.baneo.core.validator.*;
import com.baneo.core.view.web.action.*;
import org.apache.struts.action.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

/**
 * BlogInsertAction.
 *
 * @author Laurent Boatto
 */
public class BlogInsertAction extends ObjectInsertAction
{
  private static final BlogService _blogService = BlogService.instance();

  public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    User user = (User) request.getUserPrincipal();

    if (user.isGuest())
    {
      return mapping.findForward("guest");
    }

    return super.execute(mapping, form, request, response);
  }

  protected void onInit(HttpServletRequest request, HttpServletResponse response) throws ServletException
  {
    int type = Integer.parseInt(request.getParameter("type"));

    User user = (User) request.getUserPrincipal();
    Map<String,String> values = new HashMap<String, String>();

    if (type == Blog.TYPE_PERSONAL)
    {
      values.put("label", Message.format("common.blog.blogOfFullName", request.getLocale(), user.getFirstName() + " " + user.getLastName(), request.getLocale()));
      values.put("name", Formater.getEpflPersonalBlogName(user));
    }

    values.put("isPublic", "true");
    values.put("type", String.valueOf(type));

    request.setAttribute(ATTRIBUTE_VALUES, values);
    request.setAttribute(ATTRIBUTE_ERRORS, new HashMap());
  }

  protected Validator getValidator(HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    Map values = HttpUtil.requestToMap(request, _blogService.getManagedObjectAttributesNames());
    Blog blog = new Blog();
    return new BlogValidator(blog, values, Validator.MODE_INSERT, request.getLocale());
  }

  protected void insert(Object object, Validator validator, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    _blogService.insert((Blog) object);
  }

  protected ActionForward getSuccessActionForward(ActionMapping mapping, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    Blog blog = (Blog) request.getAttribute(ATTRIBUTE_INSERTED_OBJECT);
    String url = request.getContextPath() + "/private/blog/manage.do?id=" + blog.getId() + "&confirmation=common.blog.insert.success";
    response.sendRedirect(url);
    return null;
  }
}