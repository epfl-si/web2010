package ch.epfl.kis.polyblog.view.web.action.blog;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.security.*;
import ch.epfl.kis.polyblog.service.*;
import com.baneo.core.util.*;
import org.apache.struts.action.*;

import javax.servlet.http.*;
import java.util.*;

/**
 * BlogViewAction.
 *
 * @author Laurent Boatto
 */
public class BlogViewAction extends Action
{
  private static final BlogService _blogService = BlogService.instance();

  public ActionForward execute(ActionMapping mapping, ActionForm actionForm, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    String parameter = request.getParameter("blog");

    String[] data = parameter.split("/");

    String blogName = null;
    String dateFromString = null;
    Date dateFrom = null;

    blogName = data[0];

    if (data.length > 1)
    {
      dateFromString = data[1];
      dateFrom = DateUtil.parseIsoDate(dateFromString);
    }
    else
    {
      dateFrom = new Date();
    }

    request.setAttribute("dateFrom", dateFrom);

    Blog blog = _blogService.findByName(blogName);

    if (blog == null)
    {
      return mapping.findForward("inexistant");
    }

    request.setAttribute("blog", blog);

    if (!SecurityService.hasReadAccess(blog))
    {
      return mapping.findForward("403");
    }

    return mapping.findForward("last");
  }
}