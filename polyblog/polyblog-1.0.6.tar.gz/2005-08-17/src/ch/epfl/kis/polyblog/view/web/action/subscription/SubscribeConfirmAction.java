package ch.epfl.kis.polyblog.view.web.action.subscription;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.service.*;
import org.apache.struts.action.*;

import javax.servlet.http.*;

/**
 * SubscribeConfirmAction.
 *
 * @author Laurent Boatto
 */
public class SubscribeConfirmAction extends Action
{
  private static final SubscriptionService _subscriptionService = SubscriptionService.instance();

  public ActionForward execute(ActionMapping mapping, ActionForm actionForm, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    Subscription subscription = _subscriptionService.get(request.getParameter("id"));
    String code = request.getParameter("code");

    if (subscription == null)
    {
      return mapping.findForward("global500");
    }

    request.setAttribute("blog", subscription.getBlog());
    if (subscription.getWantComments())
    {
      request.setAttribute("wantComments", new Boolean(true));
    }

    if (!subscription.getCode().equals(code))
    {
      return mapping.findForward("wrongCode");
    }

    //XXX si l'utilisateur �tait d�j� inscrit pour les articles et
    //s'est inscrit � nouveau pour les commentaires, il faut supprimer
    //l'inscription pr�c�dente
    if (subscription.getWantComments())
    {
      Subscription previousSubscription = _subscriptionService.findByBlogAndEmailOrderAsc(subscription.getBlog(), subscription.getEmail());
      if ((previousSubscription != null) && (!previousSubscription.getCode().equals(code)))
      {
        _subscriptionService.delete(previousSubscription);
      }
    }
    _subscriptionService.confirmSubscribe(subscription);

    return mapping.findForward("success");
  }
}