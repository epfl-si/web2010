/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package ch.epfl.kis.polyblog.service;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.security.*;
import ch.epfl.kis.polyblog.system.*;
import com.baneo.core.persistance.*;
import com.baneo.core.security.role.*;
import com.baneo.core.service.*;
import com.baneo.core.util.*;

import java.util.*;

/**
 * BlogManager lets you insert, update, delete and find blogs.
 *
 * @author Laurent Boatto
 * @version $Id$
 * @see ch.epfl.kis.polyblog.model.Blog
 */

public class BlogService extends BusinessObjectManager
{
  private static final IPersistanceManager _persistanceService = PersistanceManagerFactory.getIPersistanceManager();
  private static final BlogService _instance = new BlogService();
  private static final IObjectRoleManager _objectRoleManager = ObjectRoleManagerFactory.getIObjectRoleManager();

  protected IPersistanceManager getIPersistanceManager()
  {
    return _persistanceService;
  }

  protected Class getManagedClass()
  {
    return Blog.class;
  }

  /**
   * Private constructor, use instance() instead.
   */
  private BlogService()
  {
  }

  /**
   * Returns the instance of the service (singleton).
   *
   * @return the instance of the service (singleton).
   */
  public static BlogService instance()
  {
    return _instance;
  }

  /**
   * Insert the given blog into the system.
   *
   * @param blog the blog to insert.
   * @throws PersistanceException on persistance layer error.
   */
  public synchronized Blog insert(Blog blog) throws PersistanceException
  {
    SecurityService.checkInsertBlog(blog);
    format(blog);
    _persistanceService.insert(blog);
    launchPostInsertEvent(blog);
    return blog;
  }

  /**
   * Update the given blog on the system.
   *
   * @param blog the blog to update.
   * @throws PersistanceException on persistance layer error.
   */
  public void update(Blog blog) throws PersistanceException
  {
    SecurityService.checkDeleteOrUpdateBlog(blog);
    format(blog);
    _persistanceService.update(blog);
    launchPostUpdateEvent(blog);
  }

  /**
   * Returns the public blogs.
   *
   * @param orderBy    the attribute used to order the blogs.
   * @param startIndex the index to start (e.g. 0 to start at the beginning).
   * @param maxResults the maximum number of objects to return.
   * @return the public blogs.
   * @throws PersistanceException on persistance layer error.
   */
  public Collection<Blog> findPublic(String orderBy, int startIndex, int maxResults) throws PersistanceException
  {
    return _persistanceService.findByAttribute(Blog.class, "isPublic", new Integer(1), orderBy, startIndex, maxResults);
  }

  /**
   * Returns the number of public blogs.
   *
   * @return the number of public blogs.
   * @throws PersistanceException on persistance layer error.
   */
  public int findPublicCount() throws PersistanceException
  {
    return _persistanceService.findByAttributeCount(Blog.class, "isPublic", new Integer(1));
  }

  /**
   * Returns the public blogs matching the given query (search is done in label and description).
   *
   * @param query      the query.
   * @param orderBy    the attribute used to order the blogs.
   * @param startIndex the index to start (e.g. 0 to start at the beginning).
   * @param maxResults the maximum number of objects to return.
   * @return the public blogs matching the given query (search is done in label and description).
   * @throws PersistanceException on persistance layer error.
   */
  public Collection<Blog> findPublicByQuery(String query, String orderBy, int startIndex, int maxResults) throws PersistanceException
  {
    String fullTextQuery = buildFullTextQuery(query, false);
    return _persistanceService.findByQuery(fullTextQuery, null, orderBy, startIndex, maxResults);
  }

  /**
   * Returns the number of public blogs matching the given query (search is done in label and description).
   *
   * @param query the query.
   * @return the number of public blogs matching the given query (search is done in label and description).
   * @throws PersistanceException on persistance layer error.
   */
  public int findPublicByQueryCount(String query) throws PersistanceException
  {
    String fullTextQuery = buildFullTextQuery(query, true);
    return _persistanceService.findByQueryCount(fullTextQuery, null);
  }

  /**
   * Returns the full text query according to the given parameters.
   *
   * @param countQuery true if you want a count query (SELECT COUNT(*)... ), false othewise.
   * @return the full text query according to the given parameters.
   */
  private static String buildFullTextQuery(String query, boolean countQuery)
  {
    StringBuffer result = new StringBuffer();

    if (countQuery)
    {
      result.append("SELECT COUNT(*) ");
    }

    result.append("FROM ").append(Blog.class.getName()).append(" ");
    result.append("WHERE isPublic = 1 ");
    result.append("AND ");
    result.append("MATCH (label,description) AGAINST ('");

    query = StringUtil.removeDuplicateWhitespace(query);

    /** todo better parsing */
    query = query.replace('\'', ' ');

    String[] words = query.split(" ");

    for (int i = 0; i < words.length; i++)
    {
      String word = words[i];
      result.append("+").append(word).append(" ");
    }

    result.append("' IN BOOLEAN MODE)");

    return result.toString();
  }


  /**
   * Formats the given blog before inserting / updating it.
   *
   * @param blog the blog to format.
   */
  private void format(Blog blog)
  {
    blog.setLabel(StringUtil.upperCaseFirstChar(blog.getLabel()));
    blog.setName(blog.getName().trim().toLowerCase());
  }

  /**
   * Delete the given blog from the system.
   *
   * @param blog the blog to delete.
   * @throws PersistanceException on persistance layer error.
   */
  public void delete(Blog blog) throws PersistanceException
  {
    SecurityService.checkDeleteOrUpdateBlog(blog);
    launchPreDeleteEvent(blog);
    _persistanceService.delete(blog);
    launchPostDeleteEvent(blog);
  }

  /**
   * Returns the blog having the given id or null if it doesn't exist.
   *
   * @param id the blog id.
   * @return the blog having the given id or null if it doesn't exist.
   * @throws PersistanceException on persistance layer error.
   */
  public Blog get(int id) throws PersistanceException
  {
    return (Blog) _persistanceService.get(Blog.class, id);
  }

  /**
   * Returns the blog having the given id or null if it doesn't exist.
   *
   * @param id the blog id.
   * @return the blog having the given id or null if it doesn't exist.
   * @throws PersistanceException on persistance layer error.
   */
  public Blog get(String id) throws PersistanceException
  {
    return (Blog) _persistanceService.get(Blog.class, Integer.parseInt(id));
  }

  /**
   * Returns the blog having the given name.
   *
   * @param name the name.
   * @return the blog having the given name or null if it doesn't exist.
   * @throws PersistanceException on persistance layer error.
   */
  public Blog findByName(String name) throws PersistanceException
  {
    return (Blog) _persistanceService.findFirstByAttribute(Blog.class, "name", name);
  }

  /**
   * Returns the blog having the given name or id.
   *
   * @param nameOrId the name or id.
   * @return the blog having the given name of id or null if it doesn't exist.
   * @throws PersistanceException on persistance layer error.
   */
  public Blog findByNameOrId(String nameOrId) throws PersistanceException
  {
    Blog blog = findByName(nameOrId);

    if (blog == null)
    {
      blog = get(nameOrId);
    }

    return blog;
  }

  /**
   * Returns the last public blogs.
   *
   * @return the last public blogs.
   * @throws PersistanceException on persistance layer error.
   */
  public Collection<Blog> findLastPublic() throws PersistanceException
  {
    return _persistanceService.findByAttribute(Blog.class, "isPublic", Boolean.TRUE, "id DESC", 0, Constants.BLOG_LAST_PUBLIC_NUM);
  }


  public Collection<ObjectRole> findRoles(Blog blog, String orderBy, int startIndex, int maxResults) throws PersistanceException
  {
    return _objectRoleManager.findByBusinessObject(blog, orderBy, startIndex, maxResults);
  }

  public int findRolesCount(Blog blog) throws PersistanceException
  {
    return _objectRoleManager.findByBusinessObjectCount(blog);
  }

  /**
   * Returns the blogs where the given user has at least a blogger access.
   *
   * @param user the user.
   * @param includeMasked if true includes also the blogs the user has masked.
   * @return the blogs where the given user has at least a blogger access.
   * @throws PersistanceException on persistance layer error.
   */
  public Collection<Blog> findByUser(User user, boolean includeMasked) throws PersistanceException
  {
    String query = "FROM " + ObjectRole.class.getName() + " WHERE principalName = ? AND principalClassName = ? AND businessObjectClassName = ? AND role != ?";
    Map<String, Blog> blogsMap = new TreeMap<String, Blog>();

    Object[] attributes = {user.getName(), user.getClass().getName(), Blog.class.getName(), SecurityService.ROLE_READER};

    Collection<ObjectRole> roles = _persistanceService.findByQuery(query, attributes);

    Collection<Group> groups = user.getGroups();

    for (Group group : groups)
    {
      Object[] groupAttributes = {group.getName(), group.getClass().getName(), Blog.class.getName(), SecurityService.ROLE_READER};
      roles.addAll(_persistanceService.findByQuery(query, groupAttributes));
    }

    for (ObjectRole role : roles)
    {
      Blog blog = get(role.getBusinessObjectId());
      blogsMap.put(blog.getLabel(), blog);
    }

    Collection<Blog> blogs = blogsMap.values();

    if (includeMasked)
    {
      return blogs;
    }

    // if we don't want the masked blogs, we retrieve them are remove them from the results
    Collection<Blog> blogsPurged = new ArrayList<Blog>();
    blogsPurged.addAll(blogs);

    Collection<MaskedBlog> maskeds = MaskedBlogService.instance().findByUser(user);

    for (MaskedBlog masked : maskeds)
    {
      for (Blog blog : blogs)
      {
        if (blog.getId() == masked.getBlogId())
        {
          blogsPurged.remove(blog);
        }
      }
    }

    return blogsPurged;
  }



  /**
   * Returns the last blog of the system. This is most useful importer
   * test cases, to retrieve the last inserted blog.
   *
   * @return the last blog of the system.
   * @throws PersistanceException on persistance layer error.
   */
  public Blog findLast() throws PersistanceException
  {
    return (Blog) _persistanceService.findLast(Blog.class);
  }
}