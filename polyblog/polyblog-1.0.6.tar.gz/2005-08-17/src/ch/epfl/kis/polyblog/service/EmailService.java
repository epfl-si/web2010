package ch.epfl.kis.polyblog.service;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.system.*;
import com.baneo.core.mail.*;
import com.baneo.core.persistance.*;
import com.baneo.core.system.*;
import com.baneo.core.system.Message;

import javax.mail.*;
import java.util.*;

import org.apache.commons.logging.*;

/**
 * EmailService.
 *
 * @author Laurent Boatto
 */
public class EmailService
{
  /**
   * Private constructor, use static methods instead.
   */
  private EmailService()
  {
  }

  /**
   * The log.
   */
  private static final Log _log = LogFactory.getLog(EmailService.class);

  /**
   * Sends the subscribe confirmation email for the given subscription.
   *
   * @param subscription the subscription.
   * @param blog         the subscribed blog.
   * @param locale       the user locale, used to choose the email text.
   * @throws MessagingException if the email cannot be sent.
   */
  public static void sendSubscribeForArticlesConfirmation(Subscription subscription, Blog blog, Locale locale) throws MessagingException
  {
    String url = Constants.SITE_BASE_URL + "/public/subscription/subscribe.do?id=" + subscription.getId() + "&code=" + subscription.getCode();

    String subject = Message.format("email.subscribe.blog.subject", locale, blog.getLabel());
    String text = Message.format("email.subscribe.blog.text", locale, blog.getLabel(), url);
    String fromName = Constants.MAIL_INFO_NAME;
    String fromEmail = Constants.MAIL_INFO_EMAIL;
    String toEmail = subscription.getEmail();

    SendMail.sendTextMail(fromEmail, fromName, toEmail, null, subject, text);
  }

  /**
   * Sends the subscribe confirmation email for the given subscription.
   *
   * @param subscription the subscription.
   * @param blog         the subscribed blog.
   * @param locale       the user locale, used to choose the email text.
   * @throws MessagingException if the email cannot be sent.
   */
  public static void sendSubscribeForCommentsConfirmation(Subscription subscription, Blog blog, Locale locale) throws MessagingException
  {
    String url = Constants.SITE_BASE_URL + "/public/subscription/subscribe.do?id=" + subscription.getId() + "&code=" + subscription.getCode();

    String subject = Message.format("email.subscribe.comments.subject", locale, blog.getLabel());
    String text = Message.format("email.subscribe.comments.text", locale, blog.getLabel(), url);
    String fromName = Constants.MAIL_INFO_NAME;
    String fromEmail = Constants.MAIL_INFO_EMAIL;
    String toEmail = subscription.getEmail();

    SendMail.sendTextMail(fromEmail, fromName, toEmail, null, subject, text);
  }

 /**
   * Sends the subscribe confirmation email for the given subscription.
   *
   * @param subscription the subscription.
   * @param blog         the subscribed blog.
   * @param locale       the user locale, used to choose the email text.
   * @throws MessagingException if the email cannot be sent.
   */
  public static void sendSubscribeForArticlesAndCommentsConfirmation(Subscription subscription, Blog blog, Locale locale) throws MessagingException
  {
    String url = Constants.SITE_BASE_URL + "/public/subscription/subscribe.do?id=" + subscription.getId() + "&code=" + subscription.getCode();

    String subject = Message.format("email.subscribe.both.subject", locale, blog.getLabel());
    String text = Message.format("email.subscribe.both.text", locale, blog.getLabel(), url);
    String fromName = Constants.MAIL_INFO_NAME;
    String fromEmail = Constants.MAIL_INFO_EMAIL;
    String toEmail = subscription.getEmail();

    SendMail.sendTextMail(fromEmail, fromName, toEmail, null, subject, text);
  }

  /**
   * Sends the new article notification to the subscribers.
   *
   * @param article the new article.
   * @throws PersistanceException on persistance layer error.
   */
  public static void sendNewArticleNotification(Article article) throws PersistanceException
  {
    Blog blog = article.getBlog();
    Locale locale = ApplicationResources.getDefaultLocale();

    Collection<Subscription> subscriptions = SubscriptionService.instance().findConfirmedByBlog(blog);

    String subject = Message.format("email.newArticle.subject", locale, article.getBlog().getLabel(), article.getTitle());
    String text = null;
    String fromName = Constants.MAIL_INFO_NAME;
    String fromEmail = Constants.MAIL_INFO_EMAIL;
    String toEmail = null;

    for (Subscription subscription : subscriptions)
    {
      String unsubscribeUrl = Constants.SITE_BASE_URL + "/public/subscription/unsubscribe.do?id=" + subscription.getId() + "&code=" + subscription.getCode();

      Object[] textArguments =
          {
              blog.getLabel(),
              article.getAuthorFirstName() + " " + article.getAuthorLastName(),
              article.getTitle(),
              article.getPermalink(),
              unsubscribeUrl
          };

      text = Message.format("email.newArticle.text", locale, textArguments);
      toEmail = subscription.getEmail();

      try
      {
        SendMail.sendTextMail(fromEmail, fromName, toEmail, null, subject, text);
      }
      catch (MessagingException e)
      {
        _log.warn("Unable to send an email to " + toEmail + " : " + e.getMessage(), e);
      }
    }
  }

  /**
   * Sends the new comment notification to the subscribers.
   *
   * @param comment the new comment.
   * @throws PersistanceException on persistance layer error.
   */
  public static void sendNewCommentNotification(Comment comment) throws PersistanceException
  {
    Locale locale = ApplicationResources.getDefaultLocale();

    Article article = comment.getArticle();
    Blog blog = article.getBlog();

    Collection<Subscription> subscriptions = SubscriptionService.instance().findConfirmedByBlog(blog, true);

    String subject = Message.format("email.newComment.subject", locale, comment.getArticle().getTitle());
    String fromName = Constants.MAIL_INFO_NAME;
    String fromEmail = Constants.MAIL_INFO_EMAIL;
    String unsubscribeUrl = null;
    String unsubscribeBothUrl = null;
    String text = null;
    String toEmail = null;

    for (Subscription subscription : subscriptions)
    {
      unsubscribeUrl = Constants.SITE_BASE_URL + "/public/subscription/unsubscribe.do?id=" + subscription.getId() + "&code=" + subscription.getCode() + "&commentsOnly=1";
      unsubscribeBothUrl = Constants.SITE_BASE_URL + "/public/subscription/unsubscribe.do?id=" + subscription.getId() + "&code=" + subscription.getCode();

      Object[] textArguments =
          {
              article.getTitle(),
              blog.getLabel(),
              comment.getAuthorFirstName() + " " + comment.getAuthorLastName(),
              comment.getContent(),
              article.getPermalink(),
              unsubscribeUrl,
              unsubscribeBothUrl
          };

      text = Message.format("email.newComment.text", locale, textArguments);
      toEmail = subscription.getEmail();

      try
      {
        SendMail.sendTextMail(fromEmail, fromName, toEmail, null, subject, text);
      }
      catch (MessagingException e)
      {
        _log.warn("Unable to send an email to " + toEmail + " : " + e.getMessage(), e);
      }
    }
  }
}