/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package ch.epfl.kis.polyblog.view.web.action.blogRole;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.security.*;
import ch.epfl.kis.polyblog.service.*;
import ch.epfl.kis.polyblog.validator.*;
import com.baneo.core.security.role.*;
import com.baneo.core.validator.*;
import com.baneo.core.view.web.action.*;
import org.apache.struts.action.*;

import javax.servlet.http.*;
import java.util.*;

/**
 * Action used to insert a BlogRole.
 *
 * @author Laurent Boatto
 * @version $Id$
 * @see com.baneo.core.view.web.action.ObjectInsertAction
 * @see org.apache.struts.action.Action
 */

public class BlogRoleInsertAction extends ObjectInsertAction
{
  private IObjectRoleManager _manager = ObjectRoleManagerFactory.getIObjectRoleManager();

  public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    Blog blog = BlogService.instance().get(request.getParameter("blogId"));
    SecurityService.checkManageBlogRoles(blog);
    request.setAttribute("blog", blog);
    return super.execute(mapping, form, request, response);
  }

  protected void onInit(HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    super.onInit(request, response);
    Map values = (Map) request.getAttribute(ATTRIBUTE_VALUES);
    values.put("blogId", request.getParameter("blogId"));
  }

  protected Validator getValidator(HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    Blog blog = (Blog) request.getAttribute("blog");
    String principalName = request.getParameter("principalName");
    String provider = request.getParameter("provider");
    User user = UserService.instance().get(principalName, provider);

    ObjectRole role = new ObjectRole();
    Map values = new HashMap();
    values.put("blogId", String.valueOf(blog.getId()));
    values.put("provider", request.getParameter("provider"));
    values.put("principalName", request.getParameter("principalName"));
    values.put("principalClassName", LdapUser.class.getName());

    if (user != null)
    {
      values.put("principalLabel", user.getLabel());
    }

    values.put("businessObjectId", String.valueOf(blog.getId()));
    values.put("businessObjectClassName", Blog.class.getName());
    values.put("role", request.getParameter("role"));

    BlogRoleValidator validator = new BlogRoleValidator(role, values, Validator.MODE_INSERT, request.getLocale());
    validator.setBlog(blog);
    validator.setUser(user);
    return validator;
  }

  protected void insert(Object object, Validator validator, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    _manager.insert((ObjectRole) object);
  }

  protected ActionForward getSuccessActionForward(ActionMapping mapping, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    String url = request.getContextPath() + "/private/blogRole/list.do?blogId=" + request.getParameter("blogId") + "&confirmation=common.blogRole.insert.success";
    response.sendRedirect(url);
    return null;
  }
}