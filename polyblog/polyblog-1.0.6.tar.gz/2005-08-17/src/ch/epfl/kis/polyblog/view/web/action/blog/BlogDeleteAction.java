/*
 * $Id$
 *
 * Copyright 2005 EPFL. All rights reserved.
 */

package ch.epfl.kis.polyblog.view.web.action.blog;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.security.*;
import ch.epfl.kis.polyblog.service.*;
import com.baneo.core.view.web.action.*;

import javax.servlet.http.*;

import org.apache.struts.action.*;

/**
 * Action for deleting blogs.
 *
 * @author Laurent Boatto
 */
public class BlogDeleteAction extends ObjectDeleteAction
{
  private static final BlogService _blogService = BlogService.instance();

  protected void delete(String id, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    Blog toDelete = _blogService.get(id);
    _blogService.delete(toDelete);
  }

  protected Object find(String id, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    Blog blog = _blogService.get(id);
    SecurityService.checkDeleteOrUpdateBlog(blog);
    return blog;
  }

  protected ActionForward getSuccessActionForward(ActionMapping mapping, HttpServletRequest request, HttpServletResponse response)
  {
    Integer count = (Integer) request.getAttribute(ATTRIBUTE_COUNT);

    if (count.intValue() > 1)
    {
      return mapping.findForward("success.plural");
    }

    return mapping.findForward("success.singular");
  }
}