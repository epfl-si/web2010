package ch.epfl.kis.polyblog.service;

import ch.epfl.kis.polyblog.model.*;
import com.baneo.core.persistance.*;

import java.util.*;

/**
 * MaskedBlogService
 *
 * @author Laurent Boatto
 */
public class MaskedBlogService
{
  private static final IPersistanceManager _persistanceService = PersistanceManagerFactory.getIPersistanceManager();
  private static final MaskedBlogService _instance = new MaskedBlogService();
  private MaskedBlog _maskedBlog;

  /**
   * Private constructor, use instance() instead.
   */
  private MaskedBlogService()
  {
  }

  /**
   * Returns the instance of the service (singleton).
   *
   * @return the instance of the service (singleton).
   */
  public static MaskedBlogService instance()
  {
    return _instance;
  }


  /**
   * Returns the MaskedBlog having the given id.
   *
   * @param id the MaskedBlog id.
   * @return the MaskedBlog having the given id.
   * @throws PersistanceException on persistance layer error.
   */
  public MaskedBlog get(int id) throws PersistanceException
  {
    return (MaskedBlog) _persistanceService.get(MaskedBlog.class, id);
  }

  /**
   * Returns the MaskedBlog having the given id.
   *
   * @param id the MaskedBlog id.
   * @return the MaskedBlog having the given id.
   * @throws PersistanceException on persistance layer error.
   */
  public MaskedBlog get(String id) throws PersistanceException
  {
    try
    {
      return (MaskedBlog) _persistanceService.get(MaskedBlog.class, Integer.parseInt(id));
    }
    catch (NumberFormatException e)
    {
      return null;
    }
  }

  /**
   * Deletes the MaskedBlog having the given id.
   *
   * @param maskedBlog the MaskedBlog to delete.
   * @throws PersistanceException on persistance layer error.
   */
  public void delete(MaskedBlog maskedBlog) throws PersistanceException
  {
    _persistanceService.delete(maskedBlog);
  }

  /**
   * Masks the given blog for the given user.
   *
   * @param blog
   * @param user
   * @return
   * @throws PersistanceException
   */
  public MaskedBlog mask(Blog blog, User user) throws PersistanceException
  {
    MaskedBlog maskedBlog = new MaskedBlog();

    maskedBlog.setBlogId(blog.getId());
    maskedBlog.setBlogLabel(blog.getLabel());
    maskedBlog.setPrincipalName(user.getName());
    maskedBlog.setPrincipalClassName(user.getClass().getName());

    _persistanceService.insert(maskedBlog);

    return maskedBlog;
  }

  /**
   * Returns the MaskedBlogs belonging to the given user.
   *
   * @param user the user.
   * @return the MaskedBlogs belonging to the given user.
   * @throws PersistanceException on persistance layer error.
   */
  public Collection<MaskedBlog> findByUser(User user) throws PersistanceException
  {
    String[] names = {"principalName", "principalClassName"};
    Object[] values = {user.getName(), user.getClass().getName()};

    return _persistanceService.findByAttributes(MaskedBlog.class, names, values, "blogLabel", 0, Integer.MAX_VALUE);
  }

  /**
   * Returns the MaskedBlogs belonging to the given blog.
   *
   * @param blog the Blog.
   * @return the MaskedBlogs belonging to the given user.
   * @throws PersistanceException on persistance layer error.
   */
  public Collection<MaskedBlog> findByBlog(Blog blog) throws PersistanceException
  {
    return _persistanceService.findByAttribute(MaskedBlog.class, "blogId", blog.getId(), "blogLabel", 0, Integer.MAX_VALUE);
  }
}