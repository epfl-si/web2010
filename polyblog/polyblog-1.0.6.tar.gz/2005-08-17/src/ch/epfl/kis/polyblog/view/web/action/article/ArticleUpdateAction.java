/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package ch.epfl.kis.polyblog.view.web.action.article;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.security.*;
import ch.epfl.kis.polyblog.service.*;
import ch.epfl.kis.polyblog.system.*;
import ch.epfl.kis.polyblog.validator.*;
import com.baneo.core.form.*;
import com.baneo.core.servlet.*;
import com.baneo.core.util.*;
import com.baneo.core.validator.*;
import com.baneo.core.view.web.action.*;
import org.apache.struts.action.*;

import javax.servlet.http.*;
import java.util.*;

/**
 * Action used to update a article.
 *
 * @author Laurent Boatto
 * @version $Id$
 * @see org.apache.struts.action.Action
 */

public class ArticleUpdateAction extends ObjectUpdateAction
{
  private static final ArticleService _articleService = ArticleService.instance();
  private static final BlogService _blogService = BlogService.instance();

  public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    String contentType = request.getContentType();

    // If we have a multipart/form-data request, we must parse it.
    if (contentType != null && contentType.startsWith(Form.ENCTYPE_MULTIPART_FORM_DATA))
    {
      try
      {
        request = HttpUtil.getSmartUploadHttpServletRequest(getServlet().getServletConfig(), Constants.FILE_STOP_PARSING_SIZE * 1024, request, response);
      }
      // The file was way to big
      catch (SecurityException e)
      {
        return mapping.findForward("fileWayTooBig");
      }
    }

    Blog blog = _blogService.get(request.getParameter("blogId"));
    request.setAttribute("blog", blog);

    return super.execute(mapping, form, request, response);
  }

  protected void update(Object object, Validator validator, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    Article article = (Article) object;
    _articleService.update(article);

    // If we have a multipart/form-data request, we move the files to the
    // documents directory, otherwise we are done.
    if (!(request instanceof SmartUploadHttpServletRequest))
    {
      return;
    }

    DocumentService.instance().moveUploadedDocuments(request, article);
  }

  protected Map getValues(HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    prepareRequest(request, MODE_INIT);
    return (Map) request.getAttribute(ATTRIBUTE_VALUES);
  }

  protected Validator getValidator(HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    prepareRequest(request, MODE_UPDATE);
    Article article = (Article) request.getAttribute(ATTRIBUTE_UPDATED_OBJECT);
    Map values = (Map) request.getAttribute(ATTRIBUTE_VALUES);
    Validator validator = new ArticleValidator(article, values, Validator.MODE_UPDATE, request.getLocale());

    // If we have a multipart/form-data request, we must validate the documents too
    if (request instanceof SmartUploadHttpServletRequest)
    {
      DocumentService.instance().validateDocuments(request, validator);
    }

    return validator;
  }

  /**
   * Prepares the request by setting two attributes :
   * <ul>
   * <li>ATTRIBUTE_UPDATED_OBJECT - the blog we are updating.
   * <li>ATTRIBUTE_VALUES - the values of the blog, as a Map.
   * </ul>
   *
   * @param request the request.
   * @param mode    the mode, can be MODE_INIT or MODE_UPDATE.
   * @throws javax.servlet.ServletException
   */
  private void prepareRequest(HttpServletRequest request, int mode) throws Exception
  {
    Article updatedArticle = _articleService.get(Integer.parseInt(request.getParameter(PARAMETER_UPDATE_ID)));
    SecurityService.checkDeleteOrUpdateArticle(updatedArticle);
    String attributes[] = _articleService.getManagedObjectAttributesNames();

    Map values = null;

    if (mode == MODE_INIT)
    {
      values = BeanUtil.getValuesMap(updatedArticle, attributes);

      // we must set the inline attribute for the documents
      Collection documents = DocumentService.instance().findByArticleId(updatedArticle.getId());

      int i = 0;
      for (Iterator iterator = documents.iterator(); iterator.hasNext();)
      {
        Document document = (Document) iterator.next();
        values.put("inline" + i, String.valueOf(document.getInline()));
        i++;
      }
    }
    else
    {
      /** todo put this somewhere else */
      // attributes that cannot be changed
      attributes = ArrayUtil.removeFromArray(attributes, new String[]{"id", "publicationDate", "authorFirstName", "authorLastName", "numComment", "numDocument"});
      values = HttpUtil.requestToMap(request, attributes);
    }

    // Important for the id hidden field
    values.put("id", String.valueOf(updatedArticle.getId()));

    request.setAttribute(ATTRIBUTE_UPDATED_OBJECT, updatedArticle);
    request.setAttribute(ATTRIBUTE_VALUES, values);
  }

  protected ActionForward getSuccessActionForward(ActionMapping mapping, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    Article article = (Article) request.getAttribute(ATTRIBUTE_UPDATED_OBJECT);
    String url = request.getContextPath() + "/private/article/list.do?blogId=" + article.getBlogId() + "&confirmation=common.article.update.success";
    response.sendRedirect(url);
    return null;
  }
}