package ch.epfl.kis.polyblog.util;

/**
 * Util.
 *
 * @author Laurent Boatto
 */
public class Util
{
  /**
   * Private constructor, use static methods instead.
   */
  private Util()
  {
  }

  /**
   * Removes the harmul tags (e.g. <script>) of the given String.
   *
   * @param string the string.
   * @return a new String with the harmful tags replaced.
   */
  public static String stripHarmfulTags(String string)
  {
    if (string == null)
    {
      return null;
    }

    /** todo allow only a subset of html tags, and remove also harmful attributes */
    return string.replaceAll("(?i)<[ ]*(script).*>", "");
  }
}