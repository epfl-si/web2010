package ch.epfl.kis.polyblog.service;

import ch.epfl.kis.polyblog.model.*;
import com.baneo.core.persistance.*;

/**
 * Let you manage users.
 *
 * @author Laurent Boatto
 */
public interface IUserService
{
  /**
   * Returns the user having the given id, or null if it does not exists.
   *
   * @param id the user id.
   * @return the user having the given id, or null if it does not exists.
   * @throws PersistanceException on persistance layer error.
   */
  public User get(String id) throws PersistanceException;

  /**
   * Authenticates a user by finding one with the given username and password,
   * and returns it. If the username does not exist or the password is false,
   * returns null.
   *
   * @param username the username.
   * @param password the password.
   * @return the User, or null if it does not exist.
   * @throws PersistanceException on persistance layer error.u
   */
  public User authenticate(String username, String password) throws PersistanceException;

  /**
   * Returns the name of the IUserService.
   *
   * @return the name of the IUserService.
   */
  public String getName();

  /**
   * Returns the user type of class the IUserService is managing.
   *
   * @return the user type of class the IUserService is managing.
   */
  public Class getUserClass();
}