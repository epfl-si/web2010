/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package ch.epfl.kis.polyblog.service;

import ch.epfl.kis.polyblog.model.*;
import com.baneo.core.persistance.*;
import com.baneo.core.service.*;
import com.baneo.core.util.*;
import org.apache.commons.logging.*;

import javax.mail.*;
import java.util.*;

/**
 * SubscriptionService lets you insert, update, delete and find subscriptions.
 *
 * @author Laurent Boatto
 * @version $Id$
 */

public class SubscriptionService extends BusinessObjectManager
{
  /**
   * The log.
   */
  private static final Log _log = LogFactory.getLog(SubscriptionService.class);

  private static final IPersistanceManager _persistanceManager = PersistanceManagerFactory.getIPersistanceManager();
  private static final SubscriptionService _instance = new SubscriptionService();
  private static final String[] FIND_BY_BLOG_AND_EMAIL_ATTRIBUTES = new String[]{"blogId", "email"};
  private static final String[] FIND_BY_BLOG_ATTRIBUTES = new String[]{"blogId", "confirmed"};

  protected IPersistanceManager getIPersistanceManager()
  {
    return _persistanceManager;
  }

  protected Class getManagedClass()
  {
    return Subscription.class;
  }

  /**
   * Private constructor, use instance() instead.
   */
  private SubscriptionService()
  {
  }

  /**
   * Returns the instance of the service (singleton).
   *
   * @return the instance of the service (singleton).
   */
  public static SubscriptionService instance()
  {
    return _instance;
  }

  /**
   * Subscribes the given email to the given blog. A confirmation email is
   * sent with a confirmation link. Until the user has clicked on the link, the
   * user is not fully subscribed.
   *
   * @param blog   the blog the user wants to subscribe to.
   * @param email  user's email.
   * @param locale user's locale.
   * @return the newly created subscription.
   * @throws PersistanceException on persistance layer error.
   * @throws MessagingException   if the email cannot be sent.
   */
  public Subscription subscribeForArticlesAndComments(Blog blog, String email, Locale locale) throws PersistanceException, MessagingException
  {
    email = email.trim().toLowerCase();

    Subscription subscription = findByBlogAndEmail(blog, email);
    boolean newSubscription = subscription == null;

    // ajouter une inscription
    if ((newSubscription) || (!subscription.getWantComments()))
    {
      subscription = new Subscription();
      subscription.setBlogId(blog.getId());
      subscription.setConfirmed(false);
      subscription.setEmail(email);
      subscription.setCode(StringUtil.randomString(8).toLowerCase());
      subscription.setWantComments(true);
      _persistanceManager.insert(subscription);

      if (newSubscription)
      {
        EmailService.sendSubscribeForArticlesAndCommentsConfirmation(subscription, blog, locale);
      }
      else
      {
        EmailService.sendSubscribeForArticlesConfirmation(subscription, blog, locale);
      }
    }
    return subscription;
  }

  /**
   * Subscribes the given email to the given blog. A confirmation email is
   * sent with a confirmation link. Until the user has clicked on the link, the
   * user is not fully subscribed.
   *
   * @param blog                 the blog the user wants to subscribe to.
   * @param email                user's email.
   * @param locale               user's locale.
   * @return the newly created subscription.
   * @throws PersistanceException on persistance layer error.
   * @throws MessagingException   if the email cannot be sent.
   */
  /* XXX renomm� et modifi� par Lilian */
  public Subscription subscribeForArticles(Blog blog, String email, Locale locale) throws PersistanceException, MessagingException
  {
    email = email.trim().toLowerCase();

    Subscription subscription = findByBlogAndEmail(blog, email);

    // ajouter une inscription
    if (subscription == null)
    {
      subscription = new Subscription();
      subscription.setBlogId(blog.getId());
      subscription.setConfirmed(false);
      subscription.setEmail(email);
      subscription.setCode(StringUtil.randomString(8).toLowerCase());
      subscription.setWantComments(false);
      _persistanceManager.insert(subscription);
    }

    EmailService.sendSubscribeForArticlesConfirmation(subscription, blog, locale);

    return subscription;
  }

  /**
   * @param blog
   * @param email
   * @param locale
   * @return
   * @throws PersistanceException
   * @throws MessagingException
   */
  public Subscription subscribeForComments(Blog blog, String email, Locale locale) throws PersistanceException, MessagingException
  {
    email = email.trim().toLowerCase();

    Subscription subscription = findByBlogAndEmail(blog, email);

    if (subscription == null || !subscription.getWantComments())
    {
      subscription = new Subscription();
      subscription.setBlogId(blog.getId());
      subscription.setConfirmed(false);
      subscription.setEmail(email);
      subscription.setCode(StringUtil.randomString(8).toLowerCase());
      subscription.setWantComments(true);
      _persistanceManager.insert(subscription);
    }

    EmailService.sendSubscribeForCommentsConfirmation(subscription, blog, locale);

    return subscription;
  }

  /**
   * Returns true if the given email is already subscribed to the given blog.
   *
   * @param blog  the blog.
   * @param email the email.
   * @return true if the given email is already subscribed to the given blog.
   * @throws PersistanceException on persistance layer error.
   */
  public boolean hasAlreadySubscribed(Blog blog, String email) throws PersistanceException
  {
    return findByBlogAndEmail(blog, email) != null;
  }

  /**
   * Returns all the subscriptions of the given blog.
   *
   * @param blog the blog.
   * @return all the subscriptions of the given blog.
   * @throws PersistanceException on persistance layer error.
   */
  public Collection<Subscription> findByBlog(Blog blog) throws PersistanceException
  {
    return _persistanceManager.findByAttribute(Subscription.class, "blogId", new Integer(blog.getId()));
  }

  /**
   * Deletes all the subscriptions of the given blog.
   *
   * @param blog the blog.
   * @throws PersistanceException on persistance layer error.
   */
  public void deleteByBlog(Blog blog) throws PersistanceException
  {
    Collection toDelete = findByBlog(blog);

    for (Iterator iterator = toDelete.iterator(); iterator.hasNext();)
    {
      Subscription subscription = (Subscription) iterator.next();
      delete(subscription);
    }
  }

  /**
   * Returns the confirmed subscriptions of the given blog.
   *
   * @param blog the blog.
   * @return the confirmed subscriptions of the given blog.
   * @throws PersistanceException on persistance layer error.
   */
  public Collection<Subscription> findConfirmedByBlog(Blog blog) throws PersistanceException
  {
    Object[] attributesValues = {new Integer(blog.getId()), Boolean.TRUE};

    return _persistanceManager.findByAttributes(Subscription.class, FIND_BY_BLOG_ATTRIBUTES, attributesValues);
  }

  /**
   * @param blog         the blog
   * @param wantComments if the users want also to receive the new comments of the blog's articles
   * @return the confirmed subscriptions of the given blog.
   * @throws PersistanceException
   */
  public Collection<Subscription> findConfirmedByBlog(Blog blog, boolean wantComments) throws PersistanceException
  {
    String[] attributes = new String[]{"blogId", "confirmed", "wantComments"};
    Object[] attributesValues = {blog.getId(), Boolean.TRUE, wantComments};

    return _persistanceManager.findByAttributes(Subscription.class, attributes, attributesValues);
  }

  /**
   * Confirms the given subscription.
   *
   * @param subscription the subscription to confirm.
   * @throws PersistanceException on persistance layer error.
   */
  public void confirmSubscribe(Subscription subscription) throws PersistanceException
  {
    subscription.setConfirmed(true);
    _persistanceManager.update(subscription);
  }

  /**
   * Confirms the given (un)subscription.
   *
   * @param subscription the subscription to unsusbcribe.
   * @throws PersistanceException on persistance layer error.
   */
  public void confirmUnsubscribe(Subscription subscription) throws PersistanceException
  {
    _persistanceManager.delete(subscription);
  }

  /**
   * @param subscription
   * @throws PersistanceException
   */
  public void confirmUnsubscribeFromComments(Subscription subscription) throws PersistanceException
  {
    subscription.setWantComments(false);
    _persistanceManager.update(subscription);
  }

  /**
   * Returns the subscription having the given blog and email, or null if it
   * does not exist.
   *
   * @param blog  the blog.
   * @param email the email.
   * @return the subscription having the given blog and email, or null if it
   *         does not exist.
   * @throws PersistanceException
   */
  public Subscription findByBlogAndEmail(Blog blog, String email) throws PersistanceException
  {
    Object[] attributesValues = {new Integer(blog.getId()), email};
    return (Subscription) _persistanceManager.findFirstByAttributes(Subscription.class, FIND_BY_BLOG_AND_EMAIL_ATTRIBUTES, attributesValues);
  }

  /**
   * Return the first subscription matching the blog and the email,
   * ordered ascending by id
   */
  public Subscription findByBlogAndEmailOrderAsc(Blog blog, String email) throws PersistanceException
  {
    Object[] attributesValues = {new Integer(blog.getId()), email};
    Collection collection = _persistanceManager.findByAttributes(Subscription.class, FIND_BY_BLOG_AND_EMAIL_ATTRIBUTES, attributesValues, "id asc", 0, 1);

    if (collection == null || collection.isEmpty())
    {
      return null;
    }

    return (Subscription) collection.iterator().next();
  }

  /**
   * @param blog
   * @param email
   * @return
   * @throws PersistanceException
   */
  public Subscription findConfirmedByBlogAndEmail(Blog blog, String email) throws PersistanceException
  {
    String[] attributes = {"blogId", "email", "confirmed"};
    Object[] attributesValues = {new Integer(blog.getId()), email, Boolean.TRUE};
    return (Subscription) _persistanceManager.findFirstByAttributes(Subscription.class, attributes, attributesValues);
  }

  /**
   * Inserts the given subscription into the system.
   *
   * @param subscription the subscription to insert.
   * @throws PersistanceException on persistance layer error.
   */
  public Subscription insert(Subscription subscription) throws PersistanceException
  {
    _persistanceManager.insert(subscription);
    return subscription;
  }

  /**
   * Updates the given subscription on the system.
   *
   * @param subscription the subscription to update.
   * @throws PersistanceException on persistance layer error.
   */
  public void update(Subscription subscription) throws PersistanceException
  {
    _persistanceManager.update(subscription);
  }

  /**
   * Deletes the given subscription from the system.
   *
   * @param subscription the subscription to delete.
   * @throws PersistanceException on persistance layer error.
   */
  public void delete(Subscription subscription) throws PersistanceException
  {
    _persistanceManager.delete(subscription);
  }

  /**
   * Returns the subscription having the given id or null if it doesn't exist.
   *
   * @param id the subscription id.
   * @return the subscription having the given id or null if it doesn't exist.
   * @throws PersistanceException on persistance layer error.
   */
  public Subscription get(int id) throws PersistanceException
  {
    return (Subscription) _persistanceManager.get(Subscription.class, id);
  }

  /**
   * Returns the subscription having the given id or null if it doesn't exist.
   *
   * @param id the subscription id.
   * @return the subscription having the given id or null if it doesn't exist.
   * @throws PersistanceException on persistance layer error.
   */
  public Subscription get(String id) throws PersistanceException
  {
    try
    {
      return get(Integer.parseInt(id));
    }
    catch (NumberFormatException e)
    {
      return null;
    }
  }

  /**
   * Returns the last subscription of the system. This is most useful importer
   * test cases, to retrieve the last inserted subscription.
   *
   * @return the last subscription of the system.
   * @throws PersistanceException on persistance layer error.
   */
  public Subscription findLast() throws PersistanceException
  {
    return (Subscription) _persistanceManager.findLast(Subscription.class);
  }
}