package ch.epfl.kis.polyblog.view.web.action.blog;

import ch.epfl.kis.polyblog.service.*;
import com.baneo.core.view.web.action.*;

import javax.servlet.http.*;
import java.util.*;

/**
 * Search through the public blogs name and label.
 *
 * @author Laurent Boatto
 */
public class BlogDirectorySearchAction extends ObjectListAction
{
  private static final BlogService _blogService = BlogService.instance();

  protected String getDefaultOrder()
  {
    return "label";
  }

  protected Collection find(HttpServletRequest request, HttpServletResponse response, String orderBy, int startIndex, int maxResults) throws Exception
  {
    String query = request.getParameter("q");
    return _blogService.findPublicByQuery(query, orderBy, startIndex, maxResults);
  }

  protected int count(HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    String query = request.getParameter("q");
    return _blogService.findPublicByQueryCount(query);
  }
}