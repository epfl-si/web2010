/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package ch.epfl.kis.polyblog.view.web.action.article;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.security.*;
import ch.epfl.kis.polyblog.service.*;
import com.baneo.core.persistance.*;
import com.baneo.core.view.web.action.*;
import org.apache.struts.action.*;

import javax.servlet.http.*;
import java.util.*;

/**
 * Action used to list all the @boLabels@.
 *
 * @author Laurent Boatto
 * @version $Id$
 * @see com.baneo.core.view.web.action.ObjectListAction
 * @see org.apache.struts.action.Action
 */

public class ArticleListAction extends ObjectListAction
{
  /**
   * The manager used to do the search.
   */
  private static final ArticleService _articleService = ArticleService.instance();

  public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    Blog blog = BlogService.instance().get(request.getParameter("blogId"));
    request.setAttribute("blog", blog);
    return super.execute(mapping, form, request, response);
  }

  protected String getDefaultOrder()
  {
    return "publicationDate DESC";
  }

  protected Collection find(HttpServletRequest request, HttpServletResponse response, String orderBy, int startIndex, int maxResults) throws PersistanceException
  {
    Blog blog = (Blog) request.getAttribute("blog");
    return _articleService.findByBlog(blog, orderBy, startIndex, maxResults);
  }

  protected int count(HttpServletRequest request, HttpServletResponse response) throws PersistanceException
  {
    Blog blog = (Blog) request.getAttribute("blog");
    // We do the security check only here, it's enough.
    SecurityService.checkListArticle(blog);
    return _articleService.findByBlogIdCount(blog.getId());
  }
}