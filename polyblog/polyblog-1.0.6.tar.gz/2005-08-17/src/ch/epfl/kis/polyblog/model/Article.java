/*
 * $Id$
 *
 * Copyright 2005 EPFL. All rights reserved.
 */

package ch.epfl.kis.polyblog.model;

import ch.epfl.kis.polyblog.security.*;
import ch.epfl.kis.polyblog.service.*;
import ch.epfl.kis.polyblog.system.*;
import com.baneo.core.model.*;
import com.baneo.core.persistance.*;
import com.baneo.core.security.role.*;
import com.baneo.core.system.*;

import java.util.*;

/**
 * Article.
 *
 * @author Laurent Boatto
 */
public class Article extends BusinessObject
{ 
  /**
   * The status used for the publish mode.
   */
  public static final int STATUS_PUBLISH = 1;

  /**
   * The status used for the draft mode.
   */
  public static final int STATUS_DRAFT = 2;

  private String _title;
  private int _categoryId;
  private String _content;
  private int _blogId;
  private Date _publicationDate;
  private int _numComment;
  private int _numDocument;
  private boolean _allowComments;
  private int _statusId;
  private String _authorFirstName;
  private String _authorLastName;

  public int getCategoryId()
  {
    return _categoryId;
  }

  public void setCategoryId(int categoryId)
  {
    _categoryId = categoryId;
  }

  public String getTitle()
  {
    return _title;
  }

  public void setTitle(String title)
  {
    _title = title;
  }

  public String getContent()
  {
    return _content;
  }

  public void setContent(String content)
  {
    _content = content;
  }

  public int getBlogId()
  {
    return _blogId;
  }

  public void setBlogId(int blogId)
  {
    _blogId = blogId;
  }

  public Date getPublicationDate()
  {
    return _publicationDate;
  }

  public void setPublicationDate(Date publicationDate)
  {
    _publicationDate = publicationDate;
  }

  public boolean getAllowComments()
  {
    return _allowComments;
  }

  public void setAllowComments(boolean allowComments)
  {
    _allowComments = allowComments;
  }

  public int getStatusId()
  {
    return _statusId;
  }

  public void setStatusId(int statusId)
  {
    _statusId = statusId;
  }

  public int getNumComment()
  {
    return _numComment;
  }

  public void setNumComment(int numComment)
  {
    _numComment = numComment;
  }

  public String getAuthorFirstName()
  {
    return _authorFirstName;
  }

  public void setAuthorFirstName(String authorFirstName)
  {
    _authorFirstName = authorFirstName;
  }

  public String getAuthorLastName()
  {
    return _authorLastName;
  }

  public int getNumDocument()
  {
    return _numDocument;
  }

  public void setNumDocument(int numDocument)
  {
    _numDocument = numDocument;
  }

  public void setAuthorLastName(String authorLastName)
  {
    _authorLastName = authorLastName;
  }

  // Calculated attributes -----------------------------------------------------

  public Blog getBlog() throws PersistanceException
  {
    return BlogService.instance().get(_blogId);
  }

  public void setBlog(Blog blog) throws PersistanceException
  {
    if (blog != null)
    {
      _blogId = blog.getId();
    }
  }

  public Category getCategory() throws PersistanceException
  {
    return CategoryService.instance().get(_categoryId);
  }

  public User getOwner() throws PersistanceException
  {
    ObjectRole role = ObjectRoleManagerFactory.getIObjectRoleManager().findFirstByBusinessObjectAndRole(this, SecurityService.ROLE_OWNER);
    return UserService.instance().get(role.getPrincipalName(), role.getPrincipalClass());
  }

  public Collection getDocuments() throws PersistanceException
  {
    return DocumentService.instance().findByArticleId(getId());
  }

  public String getPermalink()
  {
    return Constants.SITE_BASE_URL + Config.get("article.prefixUrl") + getId();
  }
}