/*
 * $Id$
 *
 * Copyright 2005 EPFL. All rights reserved.
 */

package ch.epfl.kis.polyblog.validator;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.service.*;
import ch.epfl.kis.polyblog.system.*;
import com.baneo.core.persistance.*;
import com.baneo.core.util.*;
import com.baneo.core.validator.*;

import java.util.*;

/**
 * BlogValidator.
 *
 * @author Laurent Boatto
 */
public class BlogValidator extends Validator
{
  /**
   * The reserved names for blog names, because of urls issues.
   */
  private static final String[] RESERVED_NAMES = new String[]{"article", "document", "category", "rss", "public", "private", "p"};

  public BlogValidator(Blog blog, Map values, int mode, Locale locale)
  {
    super(blog, values, mode, locale);
  }

  /**
   * Validates the name.
   *
   * @param name the name to validate.
   * @throws PersistanceException on persistance layer error.
   */
  public void validateName(String name) throws PersistanceException
  {
    // if we are importer update mode and the name have not changed, the validation
    // stops
    if (isUpdateMode())
    {
      Blog blog = (Blog) getObject();

      // the case is important
      if (blog.getName().equals(name))
      {
        return;
      }
    }

    // The name...

    // must not be empty
    if (addErrorIfEmpty(name))
    {
      return;
    }

    name = saveTrimmedValue();

    // must match the regexp
    if (!name.matches(Constants.NAME_REGEXP))
    {
      addError("error.blog.name.invalid");
      return;
    }

    char firstChar = name.charAt(0);

    // must start with a letter or digit (this is separated from the regexp
    // check to separate the error messages).
    if (!Character.isDigit(firstChar) && !Character.isLetter(firstChar))
    {
      addError("error.blog.name.doesNotStartWithLetterOrDigit");
      return;
    }

    char lastChar = name.charAt(name.length() - 1);

    // must end with a letter or digit (this is separated from the regexp
    // check to separate the error messages).
    if (!Character.isDigit(lastChar) && !Character.isLetter(lastChar))
    {
      addError("error.blog.name.doesNotEndWithLetterOrDigit");
      return;
    }

    // must not be a reserved name
    if (ArrayUtil.isInArray(name, RESERVED_NAMES))
    {
      addError("error.blog.name.reserved");
      return;
    }

    // Must not be already taken
    if (BlogService.instance().findByName(name) != null)
    {
      addError("error.blog.name.alreadyTaken");
      return;
    }

    saveTrimmedValue();
  }

  /**
   * Validates the label.
   *
   * @param label the label to validate.
   */
  public void validateLabel(String label)
  {
    if (addErrorIfEmpty(label))
    {
      return;
    }

    saveTrimmedValue();
  }

  /**
   * Validates the description.
   *
   * @param description the description to validate.
   */
  public void validateDescription(String description)
  {
    if (addErrorIfEmpty(description))
    {
      return;
    }

    saveTrimmedValue();
  }
}