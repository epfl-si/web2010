package ch.epfl.kis.polyblog.search;

import ch.epfl.kis.polyblog.model.*;
import com.baneo.core.util.*;

import java.util.*;

/**
 * ArticleQueryBuilder.
 *
 * @author Laurent Boatto
 */
public class ArticleQueryBuilder
{
  /**
   * The parameter used to specify the words to query.
   */
  public static String PARAMETER_WORDS = "q";

  /**
   * The parameter used to specify the blog where to search (mandatory).
   */
  public static String PARAMETER_BLOG_ID = "blogId";

  /**
   * Returns the full text query according to the given parameters.
   *
   * @param parameters the query parameters.
   * @param countQuery true if you want a count query (SELECT COUNT(*)... ) false othewise.
   * @return the full text query according to the given parameters.
   */
  public static String buildFullTextQuery(Map parameters, boolean countQuery)
  {
    StringBuffer query = new StringBuffer();

    if (countQuery)
    {
      query.append("SELECT COUNT(*) ");
    }

    int blogId = Integer.parseInt((String) parameters.get(PARAMETER_BLOG_ID));

    query.append("FROM " + Article.class.getName() + " ");
    query.append("WHERE blogId = " + blogId + " ");
    query.append("AND");
    query.append(getFullTextMatchClause(parameters));
    return query.toString();
  }

  /**
   * Returns the full text match clause according to the given parameters.
   *
   * @param parameters the query parameters.
   * @return the full text match clause according to the given parameters.
   */
  public static String getFullTextMatchClause(Map parameters)
  {
    StringBuffer result = new StringBuffer(" MATCH (title,content) AGAINST ('");

    String words = (String) parameters.get(PARAMETER_WORDS);
    words = StringUtil.removeDuplicateWhitespace(words);

    /** todo better parsing */
    words = words.replace('\'', ' ');

    StringTokenizer tokenizer = new StringTokenizer(words, " ");

    while (tokenizer.hasMoreTokens())
    {
      // for now we use +
      result.append('+');
      result.append("\"");
      result.append(tokenizer.nextToken());
      result.append("\"");

      if (tokenizer.hasMoreTokens())
      {
        result.append(' ');
      }
    }

    result.append("' IN BOOLEAN MODE)");

    return result.toString();
  }
}