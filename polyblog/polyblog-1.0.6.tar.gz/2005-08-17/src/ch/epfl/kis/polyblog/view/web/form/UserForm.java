package ch.epfl.kis.polyblog.view.web.form;

import com.baneo.core.form.*;

import javax.servlet.jsp.*;
import java.util.*;

/**
 * UserForm.
 *
 * @author Laurent Boatto
 */
public class UserForm extends Form
{
  public UserForm(PageContext context, String action, int mode, Map values, Map errors)
  {
    super(context, action, mode, values, errors);
  }

  protected void initForm()
  {
    setName("user");
  }

  protected void initFields()
  {
  }

  protected void addFields()
  {
  }
}
