package ch.epfl.kis.polyblog.model;

import com.baneo.core.model.*;

/**
 * MaskedBlog.
 *
 * @author Laurent Boatto
 */
public class MaskedBlog extends BusinessObject
{
  private int _blogId;
  private String _blogLabel;
  private String _principalName;
  private String _principalClassName;

  public int getBlogId()
  {
    return _blogId;
  }

  public void setBlogId(int blogId)
  {
    _blogId = blogId;
  }

  public String getBlogLabel()
  {
    return _blogLabel;
  }

  public void setBlogLabel(String blogLabel)
  {
    _blogLabel = blogLabel;
  }

  public String getPrincipalName()
  {
    return _principalName;
  }

  public void setPrincipalName(String principalName)
  {
    _principalName = principalName;
  }

  public String getPrincipalClassName()
  {
    return _principalClassName;
  }

  public void setPrincipalClassName(String principalClassName)
  {
    _principalClassName = principalClassName;
  }
}