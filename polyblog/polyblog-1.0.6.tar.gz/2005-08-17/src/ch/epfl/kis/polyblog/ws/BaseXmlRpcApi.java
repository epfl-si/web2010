package ch.epfl.kis.polyblog.ws;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.security.*;
import ch.epfl.kis.polyblog.service.*;
import com.baneo.core.persistance.*;
import com.baneo.core.security.*;
import org.apache.commons.lang.*;

import java.util.*;

/**
 * Common class for Bogger and MetaWebLog API.
 *
 * @author Laurent Boatto
 */
public abstract class BaseXmlRpcApi
{
  protected static final ArticleService _articleService = ArticleService.instance();
  protected static final BlogService _blogService = BlogService.instance();
  protected static final UserService _userService = UserService.instance();
  protected static final CategoryService _categoryService = CategoryService.instance();

  public User authenticate(String username, String password) throws PersistanceException
  {
    User user = UserService.instance().authenticate(username, password);

    if (user == null)
    {
      throw new SecurityException("Username or password incorrect");
    }

    /** todo footprint, how to access the request? */
    SecurityContextManager.setSecurityContext(new SimpleSecurityContext(user, user.getUsername(), user.getId(), null));

    return user;
  }

  /**
   * Makes a new post to a designated blog.
   *
   * @param blogid   Unique identifier of the blog the post will be added to.
   * @param username Login for a Blogger user who has permission to post to the blog.
   * @param password Password for said username.
   * @param content  Contents of the post.
   * @param publish  : If true, the blog will be published immediately after
   *                 the post is made.
   * @return returns the unique ID of the new post.
   * @throws PersistanceException
   */
  public String newPost(String blogid, String username, String password, Hashtable content, boolean publish) throws PersistanceException
  {
    authenticate(username, password);
    Blog blog = _blogService.get(blogid);

    Article article = new Article();
    article.setBlogId(blog.getId());
    // we allow comments by default
    article.setAllowComments(true);
    fillArticle(article, content, publish);

    _articleService.insert(article);

    return String.valueOf(article.getId());
  }

  /**
   * Edits a given post. Optionally, will publish the blog after making the edit
   *
   * @param articleId Unique identifier of the post to be changed
   * @param username  Login for a MetaWeblog user who has permission
   *                  to post to the blog
   * @param password  Password for said username
   * @param data      Contents of the post
   * @param publish   If true, the blog will be published immediately after
   *                  the post is made
   * @return On success, returns a boolean true value.
   */
  public boolean editPost(String articleId, String username, String password, Hashtable data, boolean publish) throws PersistanceException
  {
    authenticate(username, password);
    Article article = _articleService.get(articleId);
    // we check here too, because we don't want to change the article object
    // and then throw a SecurityException
    SecurityService.checkDeleteOrUpdateArticle(article);

    fillArticle(article, data, publish);

    _articleService.update(article);

    return true;
  }

  /**
   * Delete a Post.
   *
   * @param postid   Unique identifier of the post to be changed
   * @param userid   Login for a Blogger user who has permission to post to the blog
   * @param password Password for said username
   * @param publish  Ignored
   * @return
   * @throws PersistanceException
   */
  public boolean deletePost(String postid, String userid, String password, boolean publish) throws PersistanceException
  {
    authenticate(userid, password);
    Article article = _articleService.get(postid);
    _articleService.delete(article);
    return true;
  }


  /**
   * Fills the given article from the given data.
   *
   * @param article the article to fill.
   * @param data    the article data.
   * @param publish
   */
  private void fillArticle(Article article, Map data, boolean publish) throws PersistanceException
  {
    String description = (String) data.get("description");
    String title = (String) data.get("title");

    if (title == null)
    {
      title = "";
    }

    description = StringEscapeUtils.unescapeHtml(description);
    title = StringEscapeUtils.unescapeHtml(title);

    article.setTitle(title);
    article.setContent(description);

    int statusId = Article.STATUS_PUBLISH;

    if (!publish)
    {
      statusId = Article.STATUS_DRAFT;
    }

    article.setStatusId(statusId);

    Vector categories = (Vector) data.get("categories");

    if (categories != null && !categories.isEmpty())
    {
      String categoryLabel = (String) categories.elementAt(0);

      Category category = _categoryService.findByLabel(categoryLabel, article.getBlogId());

      if (category != null)
      {
        article.setCategoryId(category.getId());
      }
    }
  }

  /**
   * Transforms the given article into a Hashtable suitable for XML-RPC.
   *
   * @param article the article to transform.
   * @return the given article in Hashtable format suitable for XML-RPC.
   * @throws PersistanceException on persistance layer error.
   */
  protected Hashtable articleToHashtable(Article article) throws PersistanceException
  {
    Hashtable rpcArticle = new Hashtable();
    Vector categories = new Vector();

    if (article.getCategory() != null)
    {
      categories.addElement(article.getCategory().getLabel());
    }

    rpcArticle.put("postid", String.valueOf(article.getId()));
    rpcArticle.put("username", article.getOwner().getUsername());
    rpcArticle.put("url", article.getPermalink());
    rpcArticle.put("title", article.getTitle());
    rpcArticle.put("description", article.getContent());
    rpcArticle.put("categories", categories);
    rpcArticle.put("dateCreated", article.getPublicationDate());

    return rpcArticle;
  }
}