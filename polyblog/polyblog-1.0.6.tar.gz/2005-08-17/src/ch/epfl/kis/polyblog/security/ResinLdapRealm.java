/*
 * $Id$
 *
 * Copyright 2005 EPFL. All rights reserved.
 */

package ch.epfl.kis.polyblog.security;

import com.caucho.http.security.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.security.*;

/**
 * ResinLdapRealm.
 *
 * @author Laurent Boatto
 */
public class ResinLdapRealm extends AbstractAuthenticator
{
  protected Principal loginImpl(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext, String username, String password) throws ServletException
  {
    return LdapAuthenticator.authenticate(username, password);
  }

  public boolean isUserInRole(HttpServletRequest request, HttpServletResponse httpServletResponse, ServletContext servletContext, Principal principal, String role) throws ServletException
  {
    // everybody has the user role
    if (role.equals("user"))
    {
      return true;
    }

    return false;
  }
}
