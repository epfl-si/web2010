/*
 * $Id$
 *
 * Copyright 2005 EPFL. All rights reserved.
 */

package ch.epfl.kis.polyblog.listener;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.security.*;
import com.baneo.core.persistance.*;
import com.baneo.core.security.role.*;
import com.baneo.core.service.*;

import java.util.*;

/**
 * Listener for the BlogManager regarding AccessType.
 *
 * @author Laurent Boatto
 */
public class ObjectRoleArticleServiceListener extends BaseBusinessObjectManagerListener
{
  private static final IObjectRoleManager _manager = ObjectRoleManagerFactory.getIObjectRoleManager();

  public void postInsert(BusinessObjectManagerEvent event) throws PersistanceException
  {
    Article article = (Article) event.getSource();
    // we add the administrator role to the current Principal
    User user = SecurityService.getUser();
    _manager.addRole(SecurityService.ROLE_OWNER, user, user.getLabel(), article);
  }

  public void postDelete(BusinessObjectManagerEvent event) throws PersistanceException
  {
    Article article = (Article) event.getSource();
    Collection objectRoles = _manager.findByBusinessObject(article);

    for (Iterator iterator = objectRoles.iterator(); iterator.hasNext();)
    {
      ObjectRole objectRole = (ObjectRole) iterator.next();
      _manager.delete(objectRole);
    }
  }
}