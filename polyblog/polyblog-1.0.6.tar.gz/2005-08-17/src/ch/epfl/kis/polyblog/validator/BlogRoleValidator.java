/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package ch.epfl.kis.polyblog.validator;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.service.*;
import com.baneo.core.persistance.*;
import com.baneo.core.security.role.*;
import com.baneo.core.validator.*;

import java.util.*;

/**
 * UserValidator.
 *
 * @author Laurent Boatto
 * @version $Id$
 * @see com.baneo.core.validator.Validator
 */

public class BlogRoleValidator extends Validator
{
  private Blog _blog;
  private User _user;

  /**
   * Constructs a new BlogRoleValidator with the given object, values, and mode.
   *
   * @param objectRole the objectRole to validate
   * @param values     a Map having for the key the attribute name, and for the
   *                   value the attribute value.
   * @param mode       the mode for validation, can be MODE_INSERT if you are
   *                   validating a new object, or MODE_UPDATE if you are validating an
   *                   existing object (use static variables of this class for the mode).
   * @param locale     the locale used to format the error messages, it can be null
   *                   importer which case the application default ResourceBundle will be used.
   */
  public BlogRoleValidator(ObjectRole objectRole, Map values, int mode, Locale locale)
  {
    super(objectRole, values, mode, locale);
  }

  /**
   * Validates the principalName.
   *
   * @param principalName
   * @throws PersistanceException
   */
  public void validatePrincipalName(String principalName) throws PersistanceException
  {
    if (addErrorIfEmpty(principalName))
    {
      return;
    }

    if (isUpdateMode())
    {
      return;
    }


    if (_user == null)
    {
      addError("error.user.principalName.invalid", _locale);
      return;
    }

    // The principal can not have already a role importer the blog
    Collection roles = ObjectRoleManagerFactory.getIObjectRoleManager().findByPrincipalAndBusinessObject(_user, _blog);

    if (!roles.isEmpty())
    {
      addError("error.blogRole.principalName.existant", _locale);
      return;
    }

    // it's important to set the value according to the Principal name,
    // because importer some cases (e.g. with Ldap) several attributes are allowed
    // to find a Principal name.
    setValue(_user.getName());
  }

  /**
   * Validates the role.
   *
   * @param role the role to validate.
   */
  public void validateRole(String role) throws PersistanceException
  {
    if (addErrorIfEmpty(role))
    {
      return;
    }

    if (isUpdateMode())
    {
      if (!BlogRoleService.instance().isUpdatePossible((ObjectRole) getObject(), role, _blog))
      {
        addError("error.blogRole.principalName.notEnoughAdministrators", _locale);
        return;
      }
    }
  }

  public Blog getBlog()
  {
    return _blog;
  }

  public void setBlog(Blog blog)
  {
    _blog = blog;
  }

  public User getUser()
  {
    return _user;
  }

  public void setUser(User user)
  {
    _user = user;
  }
}