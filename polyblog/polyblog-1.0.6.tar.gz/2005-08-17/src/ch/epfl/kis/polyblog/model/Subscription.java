package ch.epfl.kis.polyblog.model;

import ch.epfl.kis.polyblog.service.*;
import com.baneo.core.model.*;
import com.baneo.core.persistance.*;

/**
 * Subscription.
 *
 * @author Laurent Boatto
 */
public class Subscription extends BusinessObject
{
  private int _blogId;
  private String _email;
  private String _code;
  private boolean _confirmed;
  private boolean _wantComments;

  public int getBlogId()
  {
    return _blogId;
  }

  public void setBlogId(int blogId)
  {
    _blogId = blogId;
  }

  public String getEmail()
  {
    return _email;
  }

  public void setEmail(String email)
  {
    _email = email;
  }

  public String getCode()
  {
    return _code;
  }

  public void setCode(String code)
  {
    _code = code;
  }

  public boolean getConfirmed()
  {
    return _confirmed;
  }

  public void setConfirmed(boolean confirmed)
  {
    _confirmed = confirmed;
  }

  public boolean getWantComments()
  {
    return _wantComments;
  }

  public void setWantComments(boolean wantComments)
  {
    _wantComments = wantComments;
  }

  // calculatted attributes ----------------------------------------------------
  public Blog getBlog() throws PersistanceException
  {
    return BlogService.instance().get(_blogId);
  }
}
