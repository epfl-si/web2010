package ch.epfl.kis.polyblog.view.web.action.article;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.search.*;
import ch.epfl.kis.polyblog.security.*;
import ch.epfl.kis.polyblog.service.*;
import com.baneo.core.view.web.action.*;
import org.apache.struts.action.*;

import javax.servlet.http.*;
import java.util.*;

/**
 * ArticleSearchAction.
 *
 * @author Laurent Boatto
 */
public class ArticleSearchAction extends ObjectListAction
{
  private static final ArticleService _articleService = ArticleService.instance();

  public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    Blog blog = BlogService.instance().get(request.getParameter(ArticleQueryBuilder.PARAMETER_BLOG_ID));
    request.setAttribute("blog", blog);

    if (!SecurityService.hasReadAccess(blog))
    {
      return mapping.findForward("403");
    }

    return super.execute(mapping, form, request, response);
  }

  protected String getDefaultOrder()
  {
    return "publicationDate DESC";
  }

  protected Collection find(HttpServletRequest request, HttpServletResponse response, String orderBy, int startIndex, int maxResults) throws Exception
  {
    String query = getQuery(request, false);
    Collection results = _articleService.findByQuery(query, null, orderBy, startIndex, maxResults);
    return results;
  }

  protected int count(HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    return _articleService.findByQueryCount(getQuery(request, true), null);
  }

  /**
   * Returns the query according to the request.
   *
   * @param request    the request used to build the query.
   * @param countQuery true if you want a count query (SELECT COUNT(*)...).
   * @return the query according to the request.
   */
  private String getQuery(HttpServletRequest request, boolean countQuery)
  {
    Map parameters = getSearchParameters(request);
    return ArticleQueryBuilder.buildFullTextQuery(parameters, countQuery);
  }

  /**
   * Returns the search parameters of the given request, as a Map.
   *
   * @param request the request.
   * @return the search parameters of the given request, as a Map.
   */
  private Map getSearchParameters(HttpServletRequest request)
  {
    Map parameters = new HashMap();
    parameters.put(ArticleQueryBuilder.PARAMETER_WORDS, request.getParameter(ArticleQueryBuilder.PARAMETER_WORDS));
    parameters.put(ArticleQueryBuilder.PARAMETER_BLOG_ID, request.getParameter(ArticleQueryBuilder.PARAMETER_BLOG_ID));
    return parameters;
  }
}