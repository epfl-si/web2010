package ch.epfl.kis.polyblog.view.web.action.subscription;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.security.*;
import ch.epfl.kis.polyblog.service.*;
import ch.epfl.kis.polyblog.validator.*;
import org.apache.struts.action.*;

import javax.servlet.http.*;
import java.util.*;

/**
 * SubscriptionSubmitAction.
 *
 * @author Laurent Boatto
 */
public class SubscriptionSubmitAction extends Action
{
  private static final SubscriptionService _subscriptionService = SubscriptionService.instance();

  public ActionForward execute(ActionMapping mapping, ActionForm actionForm, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    Blog blog = BlogService.instance().get(request.getParameter("id"));

    if (blog == null)
    {
      return mapping.findForward("global404");
    }

    SecurityService.checkSubscription(blog);

    request.setAttribute("blog", blog);

    String email = request.getParameter("email");
    boolean subscribeForComments = request.getParameter("subscribeForComments") != null;

    Map values = new HashMap();
    values.put("email", email);

    SubscriptionValidator validator = new SubscriptionValidator(blog, values, subscribeForComments);
    validator.validate();

    request.setAttribute("values", values);

    if (validator.hasErrors())
    {
      request.setAttribute("errors", validator.getErrors());
      return mapping.findForward("error");
    }

    if (subscribeForComments)
    {
      Subscription previousNoCommentsSubscription = _subscriptionService.findByBlogAndEmail(blog, email);
      if (previousNoCommentsSubscription != null && !previousNoCommentsSubscription.getWantComments())
      {
        _subscriptionService.subscribeForComments(blog, email, request.getLocale());
      }
      else
      {
        _subscriptionService.subscribeForArticlesAndComments(blog, email, request.getLocale());
      }
    }
    else
    {
      _subscriptionService.subscribeForArticles(blog, email, request.getLocale());
    }

    request.setAttribute("email", email);

    return mapping.findForward("success");
  }
}