package ch.epfl.kis.polyblog.view.web.action.maskedBlog;

import org.apache.struts.action.*;

import javax.servlet.http.*;

import ch.epfl.kis.polyblog.service.*;
import ch.epfl.kis.polyblog.model.*;

/**
 * MaskedBlogDeleteAction
 *
 * @author Laurent Boatto
 */
public class MaskedBlogDeleteAction extends Action
{
  private static final MaskedBlogService _maskedBlogService = MaskedBlogService.instance();

  public ActionForward execute(ActionMapping mapping, ActionForm actionForm, HttpServletRequest request, HttpServletResponse httpServletResponse) throws Exception
  {
    String[] ids = request.getParameterValues("ids");

    if (ids == null || ids.length == 0)
    {
      return mapping.findForward("back");
    }

    for (String id : ids)
    {
      MaskedBlog maskedBlog = _maskedBlogService.get(id);

      if (maskedBlog == null)
      {
        continue;
      }

      _maskedBlogService.delete(maskedBlog);
    }

    if (ids.length > 1)
    {
      return mapping.findForward("success.plural");
    }

    return mapping.findForward("success.singular");
  }
}