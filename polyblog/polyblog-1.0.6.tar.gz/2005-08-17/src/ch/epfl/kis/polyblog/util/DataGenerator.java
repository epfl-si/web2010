package ch.epfl.kis.polyblog.util;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.service.*;
import ch.epfl.kis.polyblog.system.*;
import com.baneo.core.util.*;
import com.baneo.core.persistance.*;

import java.util.*;

/**
 * DataGenerator
 *
 * @author Laurent Boatto
 */
public class DataGenerator
{
  private static final Random _random = new Random();

  /**
   * Inserts a random Blog.
   *
   * @return the inserted random Blog.
   * @throws PersistanceException on persistance layer error.
   */
  public static Blog insertRandomBlog() throws PersistanceException
  {
    return BlogService.instance().insert(getRandomBlog());
  }

  /**
   * Returns a random Blog.
   *
   * @return a random Blog.
   */
  public static Blog getRandomBlog()
  {
    Blog blog = new Blog();
    blog.setDescription(StringUtil.randomString(32));
    blog.setLabel(StringUtil.randomString(8));
    blog.setName(StringUtil.randomString(6).toLowerCase());
    return blog;
  }

  /**
   * Returns a random User.
   *
   * @return a random User.
   */
  public static User getRandomUser()
  {
    int userId = _random.nextInt(10000000);

    DbUser user = new DbUser(String.valueOf(userId));
    user.setFirstName(StringUtil.randomString(8));
    user.setLastName(StringUtil.randomString(8));
    user.setId(userId);

    return user;
  }

  /**
   * Returns a random Subscription.
   *
   * @return a random Subscription.
   * @param blog
   */
  public static Subscription getRandomSubscription(Blog blog)
  {
    Subscription subscription = new Subscription();
    subscription.setEmail(Constants.MAIL_TEST_EMAIL);
    subscription.setId(_random.nextInt(10000000));
    subscription.setCode(StringUtil.randomString(8));
    subscription.setConfirmed(true);
    subscription.setWantComments(true);

    if (blog != null)
    {
      subscription.setBlogId(blog.getId());
    }



    return subscription;
  }

  /**
   * Inserts a random Subscription.
   *
   * @return a random Subscription.
   * @throws PersistanceException on persistance layer error.
   * @param blog
   */
  public static Subscription insertRandomSubscription(Blog blog) throws PersistanceException
  {
    return SubscriptionService.instance().insert(getRandomSubscription(blog));
  }

  /**
   * Returns a random Article.
   *
   * @return a random Article.
   * @param blog
   */
  public static Article getRandomArticle(Blog blog)
  {
    Article article = new Article();

    article.setId(_random.nextInt(10000000));
    article.setAuthorFirstName(StringUtil.randomString(8));
    article.setAuthorLastName(StringUtil.randomString(8));
    article.setContent(StringUtil.randomString(128));
    article.setPublicationDate(new Date());
    article.setStatusId(Article.STATUS_PUBLISH);
    article.setTitle(StringUtil.randomString(8));

    if (blog != null)
    {
      article.setBlogId(blog.getId());
    }

    return article;
  }

  /**
   * Inserts a random Article.
   *
   * @param blog
   * @return a random Article.
   * @throws PersistanceException
   */
  public static Article insertRandomArticle(Blog blog) throws PersistanceException
  {
    return ArticleService.instance().insert(getRandomArticle(blog));
  }

  /**
   * Returns a random Comment.
   *
   * @return a random Comment.
   */
  public static Comment getRandomComment(Article article)
  {
    Comment comment = new Comment();

    comment.setAuthorFirstName(StringUtil.randomString(8));
    comment.setAuthorLastName(StringUtil.randomString(8));
    comment.setContent(StringUtil.randomString(128));
    comment.setPublicationDate(new Date());

    if (article != null)
    {
      comment.setArticleId(article.getId());
    }

    return comment;
  }
}