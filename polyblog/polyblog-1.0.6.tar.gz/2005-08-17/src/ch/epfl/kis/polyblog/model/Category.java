/*
 * $Id$
 *
 * Copyright 2005 EPFL. All rights reserved.
 */

package ch.epfl.kis.polyblog.model;

import ch.epfl.kis.polyblog.service.*;
import ch.epfl.kis.polyblog.system.*;
import com.baneo.core.model.*;
import com.baneo.core.persistance.*;
import com.baneo.core.system.*;

/**
 * Category.
 *
 * @author Laurent Boatto
 */
public class Category extends BusinessObject
{
  private String _label;
  private int _blogId;

  public String getLabel()
  {
    return _label;
  }

  public void setLabel(String label)
  {
    _label = label;
  }

  public int getBlogId()
  {
    return _blogId;
  }

  public void setBlogId(int blogId)
  {
    _blogId = blogId;
  }

  // calculated attributes -----------------------------------------------------

  public Blog getBlog() throws PersistanceException
  {
    return BlogService.instance().get(_blogId);
  }

  /**
   * Returns the absolute url of the category.
   *
   * @return the absolute url of the category.
   */
  public String getAbsoluteUrl()
  {
    return Constants.SITE_BASE_URL + Config.get("category.prefixUrl") + getId();
  }

  /**
   * Returns the relative url of the category.
   *
   * @return the relative url of the category.
   */
  public String getRelativeUrl()
  {
    return Constants.SITE_CONTEXT_PATH + Config.get("category.prefixUrl") + getId();
  }
}