package ch.epfl.kis.polyblog.view.web.action.comment;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.security.*;
import ch.epfl.kis.polyblog.service.*;
import ch.epfl.kis.polyblog.validator.*;
import com.baneo.core.validator.*;
import com.baneo.core.view.web.action.*;
import org.apache.struts.action.*;

import javax.servlet.http.*;
import java.util.*;

/**
 * CommentInsertAction.
 *
 * @author Laurent Boatto
 */
public class CommentInsertAction extends ObjectInsertAction
{
  private static final CommentService _commentService = CommentService.instance();

  public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    String articleId = request.getParameter("articleId");
    Article article = ArticleService.instance().get(articleId);
    request.setAttribute("blog", article.getBlog());
    request.setAttribute("article", article);
    SecurityService.checkInsertComment(article);
    return super.execute(mapping, form, request, response);
  }

  protected void onInit(HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    super.onInit(request, response);
    Map values = (Map) request.getAttribute(ATTRIBUTE_VALUES);
    values.put("articleId", request.getParameter("articleId"));
  }

  protected Validator getValidator(HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    Map values = new HashMap();
    values.put("content", request.getParameter("content"));
    values.put("articleId", request.getParameter("articleId"));
    Validator validator = new CommentValidator(new Comment(), values, Validator.MODE_INSERT, request.getLocale());
    return validator;
  }

  protected void insert(Object object, Validator validator, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    _commentService.insert((Comment) object);
  }
}
