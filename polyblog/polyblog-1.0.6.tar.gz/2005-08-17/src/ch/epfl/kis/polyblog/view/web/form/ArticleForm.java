package ch.epfl.kis.polyblog.view.web.form;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.service.*;
import ch.epfl.kis.polyblog.system.*;
import com.baneo.core.form.*;
import com.baneo.core.persistance.*;
import com.baneo.core.system.*;

import javax.servlet.jsp.*;
import java.util.*;

/**
 * ArticleForm.
 *
 * @author Laurent Boatto
 */
public class ArticleForm extends Form
{
  private HiddenField _id;
  private TextField _title;
  private SelectField _categoryId;
  private TextAreaField _content;
  private MultipleFileWithCheckboxField _documentField;
  private HiddenField _blogIdField;
  private SelectWithCheckboxField _statusIdAllowComments;

  private int _blogId;

  /**
   * Constructs a new ArticleForm.
   *
   * @param context the PageContext.
   * @param action  the form URL action (without the contextPath),
   *                e.g. "/user/insert.do".
   * @param mode    the form mode (use Form.MODE_UPDATE and Form.MODE_INSERT).
   */
  public ArticleForm(PageContext context, String action, int mode)
  {
    super(context, action, mode);
    _blogId = Integer.parseInt((String) getValue("blogId"));
  }

  protected void initForm()
  {
    setName("article");
    setShowRequiredString(false);
    setShowBox(false);
    setShowHelpText(false);
    setWidth("50%");
    setEnctype(Form.ENCTYPE_MULTIPART_FORM_DATA);
  }

  protected void initFields()
  {
    try
    {
      // _id
      _id = new HiddenField("id");

      // _title
      _title = new TextField("title", Message.get("model.article.title.label", _locale), true, Constants.ATTRIBUTE_STRING_INPUT_LENGTH, 255);
      _title.setStyleClass(Field.STYLE_MEDIUM);

      // _categoryId
      _categoryId = new SelectField("categoryId", Message.get("model.article.category.label", _locale), true);

      Collection categories = CategoryService.instance().findByBlogId(_blogId);

      for (Iterator iterator = categories.iterator(); iterator.hasNext();)
      {
        Category category = (Category) iterator.next();
        _categoryId.addOption(String.valueOf(category.getId()), category.getLabel());
      }

      _categoryId.setSuffix("<a href=\"" + _request.getContextPath() + "/private/category/insert.do?blogId=" + _blogId + "\">" + Message.get("common.category.insert.new", _locale) + "</a>");
      _categoryId.setStyleClass(Field.STYLE_SMALL);

      // _content
      _content = new TextAreaField("content", Message.get("model.article.content.label", _locale), true, 80, 20);

      // _statusIdAllowComments
      _statusIdAllowComments = new SelectWithCheckboxField("statusId", Message.get("model.article.statusId.label", _locale), "allowComments", Message.get("model.article.allowComments.label", _locale), false);

      String[] statuses = Message.getAttributeValueLabels("article", "statusId", _locale);

      for (int i = 0; i < statuses.length; i++)
      {
        _statusIdAllowComments.addOption(String.valueOf(i + 1), statuses[i]);
      }

      _statusIdAllowComments.setFirstOptionEmpty(false);

      _documentField = new MultipleFileWithCheckboxField(
          "document",
          Message.get("model.document.name.label", _locale),
          "inline",
          Message.get("model.document.inline.label", _locale),
          false, 20, Constants.ARTICLE_DOCUMENT_MAX, 1);

      _blogIdField = new HiddenField("blogId");
    }
    // Should not happen
    catch (PersistanceException e)
    {
      throw new RuntimeException(e);
    }
  }

  protected void addFields()
  {
    addField(_id);
    addField(_title);
    addField(_categoryId);
    addField(_content);
    addField(_statusIdAllowComments);
    addField(_documentField);
    addField(_blogIdField);
  }
}