/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package ch.epfl.kis.polyblog.service;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.security.*;
import ch.epfl.kis.polyblog.system.*;
import com.baneo.core.persistance.*;
import com.baneo.core.service.*;
import com.baneo.core.servlet.*;
import com.baneo.core.system.*;
import com.baneo.core.util.*;
import com.baneo.core.validator.*;
import com.jspsmart.upload.*;
import org.apache.commons.logging.*;

import javax.servlet.http.*;
import java.io.*;
import java.util.*;

/**
 * Manager for Documents.
 *
 * @author Laurent Boatto
 * @version $Id$
 */
public class DocumentService extends BusinessObjectManager
{
  /**
   * The log.
   */
  private static final Log _log = LogFactory.getLog(DocumentService.class);

  private static final IPersistanceManager _persistanceManager = PersistanceManagerFactory.getIPersistanceManager();

  private static final DocumentService _instance = new DocumentService();
  private static final int MAX_FILE_SIZE = Constants.FILE_MAX_FILE_SIZE * 1024;

  /**
   * The session attribute used to store the name of the file.
   */
  private static final String SESSION_ATTRIBUTE_NAME = DocumentService.class.getName() + "-name-";

  /**
   * The session attribute used to store the mime type of the file.
   */
  private static final String SESSION_ATTRIBUTE_MIME_TYPE = DocumentService.class.getName() + "-mimeType-";

  /**
   * Returns the instance of the DocumentService (singleton).
   *
   * @return the instance of the DocumentService (singleton).
   */
  public static final DocumentService instance()
  {
    return _instance;
  }

  /**
   * Returns the document having the given id or null if it doesn't exist.
   *
   * @param id the document id.
   * @return the document having the given id or null if it doesn't exist.
   * @throws PersistanceException if SubscriptionService problem occurs with the persistance layer.
   */
  public Document get(int id) throws PersistanceException
  {
    return (Document) _persistanceManager.get(Document.class, id);
  }

  /**
   * Returns the document having the given id or null if it doesn't exist.
   *
   * @param id the document id.
   * @return the document having the given id or null if it doesn't exist.
   * @throws PersistanceException if SubscriptionService problem occurs with the persistance layer.
   */
  public Document get(String id) throws PersistanceException
  {
    return get(Integer.parseInt(id));
  }

  /**
   * Insert the given file into the system.
   *
   * @param document the document to insert.
   * @throws PersistanceException if SubscriptionService problem occurs with the persistance layer.
   */
  public void insert(Document document) throws PersistanceException
  {
    format(document);
    _persistanceManager.insert(document);
  }

  /**
   * Formats the given document before inserting or updating it.
   *
   * @param document the document to format.
   */
  private void format(Document document)
  {
    document.setName(document.getName().trim());
    document.setMimeType(document.getMimeType().trim());
  }

  /**
   * Update the given document on the system.
   *
   * @param document the document to update.
   * @throws PersistanceException if SubscriptionService problem occurs with the persistance layer.
   */
  public void update(Document document) throws PersistanceException
  {
    format(document);
    _persistanceManager.update(document);
  }

  /**
   * Delete the given document from the system.
   *
   * @param document the document to delete.
   * @throws PersistanceException if SubscriptionService problem occurs with the persistance layer.
   */
  public void delete(Document document) throws PersistanceException
  {
    _persistanceManager.delete(document);

    // now we delete the document corresponding file
    java.io.File toDelete = new java.io.File(Constants.SYSTEM_DOCUMENT_PATH + java.io.File.separator + document.getId());
    if (toDelete.exists())
    {
      toDelete.delete();
    }
  }

  /**
   * Returns the documents belonging to the given article id, ordered by the
   * insertion order (first inserted first).
   *
   * @param articleId the article id.
   * @return The documents belonging to the given article id.
   * @throws PersistanceException on persistance layer error.
   */
  public Collection<Document> findByArticleId(int articleId) throws PersistanceException
  {
    return _persistanceManager.findByAttribute(Document.class, "articleId", new Integer(articleId), "id ASC", 0, Integer.MAX_VALUE);
  }

  /**
   * Move the uploaded documents from the temp directory to the documents
   * directory and updates the article number of documents if necessary.
   *
   * @param request the request.
   * @param article the article.
   * @throws IOException          if an error occurs while moving the photos.
   * @throws PersistanceException if an error occurs with the persistance layer.
   */
  public void moveUploadedDocuments(HttpServletRequest request, Article article) throws IOException, PersistanceException
  {
    User user = SecurityService.getUser();
    int numFile = 0;
    java.io.File fromFile;
    java.io.File toFile;

    // do the article have already documents attached to it? If so we will
    // need to update them
    Collection existingDocuments = findByArticleId(article.getId());
    Iterator it = existingDocuments.iterator();

    // We search successfully uploaded files
    for (int i = 0; i < Constants.ARTICLE_DOCUMENT_MAX; i++)
    {
      // Existing document x
      Document existing = null;

      if (it.hasNext())
      {
        existing = (Document) it.next();
      }

      boolean inline = Boolean.valueOf(request.getParameter("inline" + i)).booleanValue();

      fromFile = new java.io.File(Constants.SYSTEM_TEMP_PATH + java.io.File.separator + "document-" + user.getName() + "-" + i);

      // if SubscriptionService file was not uploaded, we must check if the inline document for
      // the existing document has changed
      if (!fromFile.exists())
      {
        if (existing != null && existing.getInline() != inline)
        {
          existing.setInline(inline);
          update(existing);
        }
      }
      else
      {
        // we have SubscriptionService file
        Document document = new Document();
        document.setArticleId(article.getId());
        document.setBlogId(article.getBlogId());
        document.setLength(fromFile.length());
        document.setMimeType((String) request.getSession().getAttribute(SESSION_ATTRIBUTE_MIME_TYPE + i));
        document.setName((String) request.getSession().getAttribute(SESSION_ATTRIBUTE_NAME + i));
        document.setInline(inline);

        insert(document);

        // we delete the old one
        if (existing != null)
        {
          delete(existing);
        }

        toFile = new java.io.File(Constants.SYSTEM_DOCUMENT_PATH + java.io.File.separator + document.getId());
        // We move the files to document directory
        FileUtil.copy(fromFile, toFile);
        fromFile.delete();
        numFile++;
      }
    }

    // Update the article number of photos
    if (numFile != 0)
    {
      article.setNumDocument(numFile);
      ArticleService.instance().update(article);
    }
  }

  /**
   * Validates the documents contained importer the given request by checking their
   * size. If everything is ok, we save the documents importer the temp
   * directory. When the article is published, the documents are copied to the
   * documents directory by the moveUploadedDocuments method.
   *
   * @param request   the request containing the documents.
   * @param validator the validator to use for validation.
   * @throws IOException          if an error occurs while saving the documents.
   * @throws SmartUploadException
   */
  public void validateDocuments(HttpServletRequest request, Validator validator) throws IOException, SmartUploadException
  {
    User user = SecurityService.getUser();
    SmartUploadHttpServletRequest smartRequest = (SmartUploadHttpServletRequest) request;
    SmartUpload upload = smartRequest.getSmartUpload();
    Files files = upload.getFiles();
    long count = files.getCount();

    if (count > Constants.ARTICLE_DOCUMENT_MAX)
    {
      count = Constants.ARTICLE_DOCUMENT_MAX;
    }

    for (int i = 0; i < count; i++)
    {
      com.jspsmart.upload.File file = files.getFile(i);

      // The file input is empty
      if (file.isMissing())
      {
        continue;
      }
      // Size check
      if (file.getSize() > MAX_FILE_SIZE)
      {
        Object[] arguments = new Object[3];
        arguments[0] = file.getFileName();
        arguments[1] = new Integer(file.getSize() / 1024);
        arguments[2] = new Integer(MAX_FILE_SIZE / 1024);
        validator.setError("document" + i, Message.format("error.document.length.tooBig", request.getLocale(), arguments));
        continue;
      }

      request.getSession().setAttribute(SESSION_ATTRIBUTE_NAME + i, file.getFileName());
      request.getSession().setAttribute(SESSION_ATTRIBUTE_MIME_TYPE + i, file.getContentType());

      // We save the file importer the temp directory
      file.saveAs(Constants.SYSTEM_TEMP_PATH + java.io.File.separator + "document-" + user.getName() + "-" + i);
    }
  }

  protected IPersistanceManager getIPersistanceManager()
  {
    return _persistanceManager;
  }

  protected Class getManagedClass()
  {
    return Document.class;
  }
}