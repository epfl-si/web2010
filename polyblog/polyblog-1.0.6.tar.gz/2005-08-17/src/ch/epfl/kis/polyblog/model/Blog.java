/*
 * $Id$
 *
 * Copyright 2005 EPFL. All rights reserved.
 */

package ch.epfl.kis.polyblog.model;

import ch.epfl.kis.polyblog.service.*;
import ch.epfl.kis.polyblog.system.*;
import com.baneo.core.model.*;
import com.baneo.core.persistance.*;
import com.baneo.core.system.*;

import java.util.*;

/**
 * Blog.
 *
 * @author Laurent Boatto
 */
public class Blog extends BusinessObject
{
  /**
   * The type used for a personal blog.
   */
  public static final int TYPE_PERSONAL = 1;

  /**
   * The type used for a group blog.
   */
  public static final int TYPE_GROUP = 2;

  private int _type;
  private String _label;
  private String _name;
  private String _description;
  private boolean _isPublic;

  public int getType()
  {
    return _type;
  }

  public void setType(int type)
  {
    _type = type;
  }

  public String getName()
  {
    return _name;
  }

  public void setName(String name)
  {
    _name = name;
  }

  public String getLabel()
  {
    return _label;
  }

  public void setLabel(String label)
  {
    _label = label;
  }

  public String getDescription()
  {
    return _description;
  }

  public void setDescription(String description)
  {
    _description = description;
  }

  public boolean getIsPublic()
  {
    return _isPublic;
  }

  public void setIsPublic(boolean isPublic)
  {
    _isPublic = isPublic;
  }

  // Calculated attributes -----------------------------------------------------

  public Collection getCategories() throws PersistanceException
  {
    return CategoryService.instance().findByBlogId(getId());
  }

  /**
   * Returns the absolute url of the blog.
   *
   * @return the absolute url of the blog.
   */
  public String getAbsoluteUrl()
  {
    return Constants.SITE_BASE_URL + Config.get("blog.prefixUrl") + getName();
  }


  /**
   * Returns the relative url of the blog.
   *
   * @return the relative url of the blog.
   */
  public String getRelativeUrl()
  {
    return Constants.SITE_CONTEXT_PATH + Config.get("blog.prefixUrl") + getName();
  }
}
