/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package ch.epfl.kis.polyblog.view.web.action.blogRole;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.service.*;
import ch.epfl.kis.polyblog.validator.*;
import com.baneo.core.persistance.*;
import com.baneo.core.security.role.*;
import com.baneo.core.validator.*;
import com.baneo.core.view.web.action.*;
import org.apache.struts.action.*;

import javax.servlet.http.*;
import java.util.*;

/**
 * Action used to update a _object_.
 *
 * @author Laurent Boatto
 * @version $Id$
 * @see org.apache.struts.action.Action
 */

public class BlogRoleUpdateAction extends ObjectUpdateAction
{
  private static final IObjectRoleManager _objectRoleManager = ObjectRoleManagerFactory.getIObjectRoleManager();
  private static final BlogService _blogService = BlogService.instance();

  public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    return super.execute(mapping, form, request, response);
  }

  protected void update(Object object, Validator validator, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    _objectRoleManager.update((ObjectRole) object);
  }

  protected Map getValues(HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    prepareRequest(request, MODE_INIT);
    return (Map) request.getAttribute(ATTRIBUTE_VALUES);
  }

  protected Validator getValidator(HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    prepareRequest(request, MODE_UPDATE);
    Map values = (Map) request.getAttribute(ATTRIBUTE_VALUES);
    ObjectRole objectRole = (ObjectRole) request.getAttribute(ATTRIBUTE_UPDATED_OBJECT);
    Blog blog = (Blog) request.getAttribute("blog");
    BlogRoleValidator validator = new BlogRoleValidator(objectRole, values, Validator.MODE_UPDATE, request.getLocale());
    validator.setBlog(blog);
    return validator;
  }

  private void prepareRequest(HttpServletRequest request, int mode) throws PersistanceException
  {
    String blogId = request.getParameter("blogId");
    Blog blog = _blogService.get(blogId);
    String id = request.getParameter(PARAMETER_UPDATE_ID);
    ObjectRole objectRole = _objectRoleManager.get(Integer.parseInt(id));
    Map values = new HashMap();
    values.put("blogId", blogId);
    values.put("id", id);

    if (mode == MODE_INIT)
    {
      values.put("role", objectRole.getRole());
    }
    else if (mode == MODE_UPDATE)
    {
      values.put("role", request.getParameter("role"));
    }

    request.setAttribute("blog", blog);
    request.setAttribute(ATTRIBUTE_UPDATED_OBJECT, objectRole);
    request.setAttribute(ATTRIBUTE_VALUES, values);
  }

  protected ActionForward getSuccessActionForward(ActionMapping mapping, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    String url = request.getContextPath() + "/private/blogRole/list.do?blogId=" + request.getParameter("blogId") + "&confirmation=common.blogRole.update.success";
    response.sendRedirect(url);
    return null;
  }
}