/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package ch.epfl.kis.polyblog.system;

import com.baneo.core.system.*;
import org.apache.log4j.*;

import javax.servlet.*;
import javax.servlet.http.*;

/**
 * Servlet loaded once during application bootstrap, used for initialization importer
 * a web context.
 *
 * @author Laurent Boatto
 * @version $Id$
 */

public class BootstrapServlet extends HttpServlet implements SingleThreadModel
{
  private boolean _bootstraped;

  public void init(ServletConfig config) throws ServletException
  {
    try
    {
      // Makes sure the bootstrap is done only once.
      if (_bootstraped)
      {
        return;
      }

      super.init(config);

      System.out.println("-----------------------------------------------------");
      System.out.print("polyblog application initializing...");

      ApplicationInitializer.initialize();

      // Log4j
      String prefix = getServletContext().getRealPath("/WEB-INF/classes/");
      PropertyConfigurator.configure(prefix + "/log4j.properties");

      System.out.println(" done.");

      System.out.println("-----------------------------------------------------");


      _bootstraped = true;
    }
    catch (Exception ex)
    {
      ex.printStackTrace();
      throw new ServletException(ex);
    }
  }
}