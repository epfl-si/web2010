/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package ch.epfl.kis.polyblog.service;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.security.*;
import com.baneo.core.persistance.*;
import com.baneo.core.security.role.*;
import com.baneo.core.service.*;
import org.apache.commons.logging.*;

import java.util.*;

/**
 * CommentService lets you insert, update, delete and find comments.
 *
 * @author Laurent Boatto
 * @version $Id$
 */

public class CommentService extends BusinessObjectManager
{
  /**
   * The log.
   */
  private static final Log _log = LogFactory.getLog(CommentService.class);

  private static final IPersistanceManager _persistanceManager = PersistanceManagerFactory.getIPersistanceManager();
  private static final CommentService _instance = new CommentService();
  private static final IObjectRoleManager _objectRoleManager = ObjectRoleManagerFactory.getIObjectRoleManager();

  protected IPersistanceManager getIPersistanceManager()
  {
    return _persistanceManager;
  }

  protected Class getManagedClass()
  {
    return Comment.class;
  }

  /**
   * Private constructor, use instance() instead.
   */
  private CommentService()
  {
  }

  /**
   * Returns the instance of the service (singleton).
   *
   * @return the instance of the service (singleton).
   */
  public static CommentService instance()
  {
    return _instance;
  }

  /**
   * Inserts the given comment into the system.
   *
   * @param comment the comment to insert.
   * @throws PersistanceException on persistance layer error.
   */
  public void insert(Comment comment) throws PersistanceException
  {
    SecurityService.checkInsertComment(comment.getArticle());

    if (comment.getPublicationDate() == null)
    {
      comment.setPublicationDate(new Date());
    }

    // for performance reasons we save the author first name and last name
    // directly importer the article
    User user = SecurityService.getUser();
    comment.setAuthorFirstName(user.getFirstName());
    comment.setAuthorLastName(user.getLastName());
    _persistanceManager.insert(comment);
    // we add the owner role to the current principal for the comment
    _objectRoleManager.addRole(SecurityService.ROLE_OWNER, SecurityService.getUser(), null, comment);
    launchPostInsertEvent(comment);
  }

  /**
   * Updates the given comment from the system.
   *
   * @param comment the comment to update.
   * @throws PersistanceException on persistance layer error.
   */
  public void update(Comment comment) throws PersistanceException
  {
    /** todo security check */
    _persistanceManager.update(comment);
  }

  /**
   * Deletes the given comment from the system.
   *
   * @param comment the comment to delete.
   * @throws PersistanceException on persistance layer error.
   */
  public void delete(Comment comment) throws PersistanceException
  {
    User user = SecurityService.getUser();
    _persistanceManager.delete(comment);
    // we remove the owner role to the current principal for the comment
    _objectRoleManager.removeRole(SecurityService.ROLE_OWNER, user, comment);
    launchPostDeleteEvent(comment);
  }

  /**
   * Returns the comment having the given id or null if it doesn't exist.
   *
   * @param id the comment id.
   * @return the comment having the given id or null if it doesn't exist.
   * @throws PersistanceException on persistance layer error.
   */
  public Comment get(int id) throws PersistanceException
  {
    return (Comment) _persistanceManager.get(Comment.class, id);
  }

  /**
   * Returns the comments of the given Article id.
   *
   * @param articleId the Article id.
   * @return the comments of the given Article id.
   * @throws PersistanceException on persistance layer error.
   */
  public Collection<Comment> findByArticleId(int articleId) throws PersistanceException
  {
    return _persistanceManager.findByAttribute(Comment.class, "articleId", new Integer(articleId), "publicationDate ASC", 0, 1000);
  }

  /**
   * Returns the last comment of the system. This is most useful importer
   * test cases, to retrieve the last inserted comment.
   *
   * @return the last comment of the system.
   * @throws PersistanceException on persistance layer error.
   */
  public Comment findLast() throws PersistanceException
  {
    return (Comment) _persistanceManager.findLast(Comment.class);
  }
}