package ch.epfl.kis.polyblog.validator;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.service.*;
import com.baneo.core.persistance.*;
import com.baneo.core.util.*;
import com.baneo.core.validator.*;

import java.util.*;

/**
 * SubscriptionValidator.
 *
 * @author Laurent Boatto
 */
public class SubscriptionValidator extends Validator
{
  private Blog _blog;
  private boolean _subscribeForComments;

  public SubscriptionValidator(Blog blog, Map values, boolean subscribeForComments)
  {
    super(null, values, -1, null);
    _blog = blog;
    _subscribeForComments = subscribeForComments;
  }

  /**
   * Validates the email.
   *
   * @param email
   * @throws PersistanceException
   */
  public void validateEmail(String email) throws PersistanceException
  {
    if (addErrorIfEmpty(email))
    {
      return;
    }

    email = saveTrimmedLowerCasedValue();

    if (!Check.isValidEmailSyntax(email))
    {
      addError("error.subscription.email.invalid");
      return;
    }

    Subscription subscription = SubscriptionService.instance().findByBlogAndEmail(_blog, email);

    if (subscription == null || !subscription.getConfirmed())
    {
      return;
    }

    // XXX modifi� par Lilian
    if (subscription.getWantComments() || !_subscribeForComments)
    {
      addError("error.subscription.email.already");
      return;
    }
  }

  public Blog getBlog()
  {
    return _blog;
  }
}
