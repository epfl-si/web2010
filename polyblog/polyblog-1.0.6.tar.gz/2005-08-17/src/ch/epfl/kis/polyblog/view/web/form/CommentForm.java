package ch.epfl.kis.polyblog.view.web.form;

import com.baneo.core.form.*;
import com.baneo.core.system.*;

import javax.servlet.jsp.*;
import java.util.*;

/**
 * CommentForm.
 *
 * @author Laurent Boatto
 */
public class CommentForm extends Form
{
  private HiddenField _articleId;
  private TextAreaField _content;

  public CommentForm(PageContext context, String action, int mode, Map values, Map errors)
  {
    super(context, action, mode, values, errors);
  }

  protected void initForm()
  {
    setName("comment");
    setShowBox(false);
    setShowHelpText(false);
    setShowRequiredString(false);
    setWidth("50%");
  }

  protected void initFields()
  {
    _articleId = new HiddenField("articleId");
    // _content
    _content = new TextAreaField("content", Message.get("model.comment.content.label", _locale), true, 80, 20);
  }

  protected void addFields()
  {
    addField(_articleId);
    addField(_content);
  }
}