package ch.epfl.kis.polyblog.validator;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.service.*;
import com.baneo.core.persistance.*;
import com.baneo.core.validator.*;

import java.util.*;

/**
 * CategoryValidator.
 *
 * @author Laurent Boatto
 */
public class CategoryValidator extends Validator
{
  private static final CategoryService _categoryService = CategoryService.instance();

  public CategoryValidator(Category category, Map values, int mode, Locale locale)
  {
    super(category, values, mode, locale);
  }

  /**
   * Validates the label.
   *
   * @param label the label to validate.
   * @throws PersistanceException on persistance exception.
   */
  public void validateLabel(String label) throws PersistanceException
  {
    if (addErrorIfEmpty(label))
    {
      return;
    }

    int blogId = ((Category) getObject()).getBlogId();

    label = saveTrimmedValue();

    // If we are in update mode and the user has not changed the label, the
    // check stop.
    if (isUpdateMode())
    {
      String lastLabel = ((Category) getObject()).getLabel();

      if (lastLabel.equalsIgnoreCase(label))
      {
        return;
      }
    }

    // the label should not be already taken.
    if (_categoryService.exists(blogId, label))
    {
      addError("error.category.label.alreadyTaken", _locale);
      return;
    }
  }
}
