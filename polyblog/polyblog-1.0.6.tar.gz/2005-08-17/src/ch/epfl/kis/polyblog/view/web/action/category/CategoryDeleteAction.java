package ch.epfl.kis.polyblog.view.web.action.category;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.security.*;
import ch.epfl.kis.polyblog.service.*;
import com.baneo.core.view.web.action.*;
import org.apache.struts.action.*;

import javax.servlet.http.*;
import java.io.*;

/**
 * CategoryDeleteAction.
 *
 * @author Laurent Boatto
 */
public class CategoryDeleteAction extends ObjectDeleteAction
{
  private static final CategoryService _categoryService = CategoryService.instance();

  public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    Blog blog = BlogService.instance().get(request.getParameter("blogId"));
    request.setAttribute("blog", blog);
    SecurityService.checkDeleteOrUpdateCategory(blog);

    ActionForward dynamicBack = new ActionForward("back", "/private/category/list.do?blogId=" + request.getParameter("blogId"), true);
    ActionMapping dynamicMapping = new ActionMapping();

    dynamicMapping.addForwardConfig(mapping.findForward("init"));
    dynamicMapping.addForwardConfig(dynamicBack);

    return super.execute(dynamicMapping, form, request, response);
  }

  protected void delete(String id, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    _categoryService.delete(getCategory(id));
  }

  protected Object find(String id, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    return getCategory(id);
  }

  private Category getCategory(String id) throws Exception
  {
    int idInt = Integer.parseInt(id);
    return CategoryService.instance().get(idInt);
  }

  protected ActionForward getSuccessActionForward(ActionMapping mapping, HttpServletRequest request, HttpServletResponse response) throws IOException
  {
    Integer count = (Integer) request.getAttribute(ATTRIBUTE_COUNT);
    String url = request.getContextPath() + "/private/category/list.do?blogId=" +  request.getParameter("blogId");

    if (count > 1)
    {
      url += "&confirmation=common.category.delete.confirmation.plural";
    }
    else
    {
      url += "&confirmation=common.category.delete.confirmation.singular";
    }

    response.sendRedirect(url);

    return null;
  }

}