package ch.epfl.kis.polyblog.ws;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.security.*;
import ch.epfl.kis.polyblog.service.*;
import com.baneo.core.persistance.*;
import org.apache.commons.logging.*;

import java.util.*;

/**
 * MetaWebLogApi.
 *
 * @author Laurent Boatto
 */
public class MetaWebLogApi extends BaseXmlRpcApi
{
  /**
   * The log.
   */
  private static final Log _log = LogFactory.getLog(MetaWebLogApi.class);

  /**
   * Returns the given post.
   *
   * @param postid   the post id.
   * @param userid
   * @param password
   * @return
   * @throws PersistanceException
   */
  public Object getPost(String postid, String userid, String password) throws PersistanceException
  {
    Article article = ArticleService.instance().get(postid);
    Blog blog = article.getBlog();

    // if the blog is public we can directly return the article
    if (blog.getIsPublic())
    {
      return articleToHashtable(article);
    }

    // otherwise we have to do a security check.
    User user = authenticate(userid, password);
    SecurityService.checkReadAccess(user, article.getBlog());
    return articleToHashtable(article);
  }

  /**
   * Returns the categories of the given blog.
   *
   * @param blogid   the blog id.
   * @param userid   Login for a Blogger user who has permission to post to the blog.
   * @param password Password for said userid.
   * @return the categories of the given blog.
   * @throws PersistanceException
   */
  public Object getCategories(String blogid, String userid, String password) throws PersistanceException
  {
    Blog blog = _blogService.get(blogid);

    if (!blog.getIsPublic())
    {
      User user = _userService.authenticate(userid, password);
      SecurityService.checkReadAccess(user, blog);
    }

    Collection categories = _categoryService.findByBlogId(blog.getId());

    List result = new Vector();

    for (Iterator it = categories.iterator(); it.hasNext();)
    {
      Category category = (Category) it.next();
      String label = category.getLabel();

      Map details = new Hashtable(3);
      details.put("description", label);
      details.put("htmlUrl", category.getAbsoluteUrl());
      details.put("rssUrl", "not implemented");

      result.add(details);
    }

    return result;
  }

  /**
   * Returns the recent posts of the given blog.
   *
   * @param blogid   the blog id.
   * @param userid   Login for a Blogger user who has permission to post to the blog.
   * @param password Password for said username.
   * @param numposts
   * @return
   * @throws PersistanceException
   */
  public Object getRecentPosts(String blogid, String userid, String password, int numposts) throws PersistanceException
  {
    return getRecentPosts("", blogid, userid, password, numposts);
  }


  /**
   * @param appkey
   * @param blogid
   * @param username Login for a Blogger user who has permission to post to the blog.
   * @param password Password for said username.
   * @param numposts
   * @return
   * @throws PersistanceException
   */
  public Object getRecentPosts(String appkey, String blogid, String username, String password, int numposts) throws PersistanceException
  {
    User user = authenticate(username, password);
    Blog blog = _blogService.get(blogid);

    SecurityService.checkReadAccess(user, blog);

    Collection articles = _articleService.findLastByBlog(blog, new Date(), numposts);

    List result = new Vector();

    for (Iterator iterator = articles.iterator(); iterator.hasNext();)
    {
      Article article = (Article) iterator.next();
      Hashtable rpcArticle = articleToHashtable(article);
      result.add(rpcArticle);
    }

    return result;
  }

  /**
   * Unsupported.
   *
   * @param blogid
   * @param userid
   * @param password
   * @param struct
   * @return
   */
  public Object newMediaObject(String blogid, String userid, String password, Object struct)
  {
    throw new UnsupportedOperationException("newMediaObject is not supported");
  }
}