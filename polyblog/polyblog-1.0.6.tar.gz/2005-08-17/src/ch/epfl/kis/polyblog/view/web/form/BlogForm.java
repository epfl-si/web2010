/*
 * $Id$
 *
 * Copyright 2005 EPFL. All rights reserved.
 */

package ch.epfl.kis.polyblog.view.web.form;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.system.*;
import com.baneo.core.form.*;
import com.baneo.core.system.*;

import javax.servlet.jsp.*;

/**
 * Form for the Blogs.
 *
 * @author Laurent Boatto
 */
public class BlogForm extends Form
{
  private HiddenField _id;
  private int _type;
  private HiddenField _typeField;
  private Field _name;
  private TextField _label;
  private CheckboxField _isPublic;
  private TextAreaField _description;


  /**
   * Constructs a new BlogForm.
   *
   * @param context the PageContext.
   * @param action  the form URL action (without the contextPath),
   *                e.g. "/user/insert.do".
   * @param mode    the form mode (use Form.MODE_UPDATE and Form.MODE_INSERT).
   */
  public BlogForm(PageContext context, String action, int mode)
  {
    super(context, action, mode);
    _type = Integer.parseInt(context.getRequest().getParameter("type"));
  }

  /**
   * Init the form by setting it's properties like the name (mandatory), method,
   * header, etc.
   */
  protected void initForm()
  {
    setName("blog");
    setShowRequiredString(false);

    String mode = "insert";
    String type = "personal";

    if (isUpdateMode())
    {
      mode = "update";
    }

    if (_type == Blog.TYPE_GROUP)
    {
      type = "group";
    }

    setFormHeader(Message.get("common.blog." + type + "." + mode, _locale));
  }

  /**
   * Init the form fields.
   */
  protected void initFields()
  {
    if (isUpdateMode())
    {
      _id = new HiddenField("id");
    }

    _typeField = new HiddenField("type");

    _label = new TextField("label", Message.get("model.blog.label.label", _locale), true, Constants.ATTRIBUTE_STRING_INPUT_LENGTH, 40);
    _label.setStyleClass(Field.STYLE_MEDIUM);

    if (_type == Blog.TYPE_GROUP)
    {
      _label.setAdvice(Message.get("model.blog.label.advice", _locale));
      _label.setHelpTextRowSpan(2);
    }

    // In personal blogs, the name is preset
    if (_type == Blog.TYPE_PERSONAL)
    {
      _name = new HiddenField("name");
    }
    // In group blogs..
    else
    {
      _name = new TextField("name", Message.get("model.blog.name.label", _locale), true, 12, 40);
      ((TextField) _name).setPrefix(Constants.SITE_BASE_URL + Config.get("blog.prefixUrl"));
    }

    _isPublic = new CheckboxField("isPublic", Message.get("model.blog.isPublic.label", _locale), true);
    _isPublic.setHelpText(Message.get("model.blog.isPublic.helpText", _locale));
    _isPublic.setHelpTextRowSpan(2);

    _description = new TextAreaField("description", Message.get("model.blog.description.label", _locale), true, 40, 10);
    _description.setHelpText(null);
  }

  /**
   * Add the fields to the form.
   */
  protected void addFields()
  {
    addField(_label);
    addField(_name);
    addField(_isPublic);
    addField(_description);
    addField(_id);
    addField(_typeField);
  }
}