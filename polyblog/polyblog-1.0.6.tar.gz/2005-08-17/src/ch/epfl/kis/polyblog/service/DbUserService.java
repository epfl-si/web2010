package ch.epfl.kis.polyblog.service;

import ch.epfl.kis.polyblog.model.*;
import com.baneo.core.persistance.*;

/**
 * DbUserService.
 *
 * @author Laurent Boatto
 */
public class DbUserService implements IUserService
{
  public User get(String id) throws PersistanceException
  {
    throw new UnsupportedOperationException("not yet implemented");
  }

  public String getName()
  {
    return "db";
  }

  public User authenticate(String username, String password) throws PersistanceException
  {
    throw new UnsupportedOperationException("not yet implemented");
  }

  public Class<DbUser> getUserClass()
  {
    return DbUser.class;
  }
}