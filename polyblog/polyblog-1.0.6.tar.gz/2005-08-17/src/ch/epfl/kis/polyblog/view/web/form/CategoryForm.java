package ch.epfl.kis.polyblog.view.web.form;

import ch.epfl.kis.polyblog.system.*;
import com.baneo.core.form.*;
import com.baneo.core.system.*;

import javax.servlet.jsp.*;

/**
 * CategoryForm.
 *
 * @author Laurent Boatto
 */
public class CategoryForm extends Form
{
  private HiddenField _id;
  private HiddenField _blogId;
  private TextField _label;

  public CategoryForm(PageContext context, String action, int mode)
  {
    super(context, action, mode);
  }

  protected void initForm()
  {
    setName("category");
    setWidth("40%");
    setShowBox(false);
    setShowHelpText(false);
    setShowRequiredString(false);
  }

  protected void initFields()
  {
    _id = new HiddenField("id");
    _blogId = new HiddenField("blogId");
    _label = new TextField("label", Message.get("model.category.label.label", _locale), true, 20, Constants.ATTRIBUTE_STRING_LENGTH_MEDIUM);
    _label.setStyleClass(Field.STYLE_SMALL);
  }

  protected void addFields()
  {
    addField(_label);
    addField(_id);
    addField(_blogId);
  }
}
