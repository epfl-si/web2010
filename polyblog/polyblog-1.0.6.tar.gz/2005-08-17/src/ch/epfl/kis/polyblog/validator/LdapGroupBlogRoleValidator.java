package ch.epfl.kis.polyblog.validator;

import ch.epfl.kis.polyblog.model.*;
import com.baneo.core.persistance.*;
import com.baneo.core.security.role.*;

import java.util.*;

/**
 * LdapGroupBlogRoleValidator.
 *
 * @author Laurent Boatto
 */
public class LdapGroupBlogRoleValidator extends BlogRoleValidator
{
  private Group _group;

  public LdapGroupBlogRoleValidator(ObjectRole objectRole, Map values, int mode, Locale locale)
  {
    super(objectRole, values, mode, locale);
  }

  public void validatePrincipalName(String principalName) throws PersistanceException
  {
    if (addErrorIfEmpty(principalName))
    {
      return;
    }

    if (isUpdateMode())
    {
      return;
    }

    // The principal can not have already a role importer the blog
    Collection roles = ObjectRoleManagerFactory.getIObjectRoleManager().findByPrincipalAndBusinessObject(_group, getBlog());

    if (!roles.isEmpty())
    {
      addError("error.blogRole.group.principalName.existant", _locale);
      return;
    }
  }

  public Group getGroup()
  {
    return _group;
  }

  public void setGroup(Group group)
  {
    _group = group;
  }
}