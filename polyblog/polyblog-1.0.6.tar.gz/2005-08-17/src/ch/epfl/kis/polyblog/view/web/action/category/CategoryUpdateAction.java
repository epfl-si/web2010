package ch.epfl.kis.polyblog.view.web.action.category;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.security.*;
import ch.epfl.kis.polyblog.service.*;
import ch.epfl.kis.polyblog.validator.*;
import com.baneo.core.meta.*;
import com.baneo.core.util.*;
import com.baneo.core.validator.*;
import com.baneo.core.view.web.action.*;
import org.apache.struts.action.*;

import javax.servlet.http.*;
import java.util.*;

/**
 * CategoryUpdateAction.
 *
 * @author Laurent Boatto
 */
public class CategoryUpdateAction extends ObjectUpdateAction
{
  private static final CategoryService _categoryService = CategoryService.instance();

  public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    Category updatedCategory = _categoryService.get(Integer.parseInt(request.getParameter(PARAMETER_UPDATE_ID)));
    request.setAttribute(ATTRIBUTE_UPDATED_OBJECT, updatedCategory);
    Blog blog = updatedCategory.getBlog();
    SecurityService.checkDeleteOrUpdateCategory(blog);
    request.setAttribute("blog", blog);
    return super.execute(mapping, form, request, response);
  }

  protected Map getValues(HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    prepareRequest(request, MODE_INIT);
    return (Map) request.getAttribute(ATTRIBUTE_VALUES);
  }

  protected Validator getValidator(HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    prepareRequest(request, MODE_UPDATE);
    Map values = (Map) request.getAttribute(ATTRIBUTE_VALUES);
    Category updatedCategory = (Category) request.getAttribute(ATTRIBUTE_UPDATED_OBJECT);
    return new CategoryValidator(updatedCategory, values, Validator.MODE_UPDATE, request.getLocale());
  }

  protected void update(Object object, Validator validator, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    _categoryService.update((Category) object);
  }

  /**
   * Prepares the request by setting two attributes :
   * <ul>
   * <li>ATTRIBUTE_UPDATED_OBJECT - the category we are updating.
   * <li>ATTRIBUTE_VALUES - the values of the category, as a Map.
   * </ul>
   *
   * @param request the request.
   * @param mode    the mode, can be MODE_INIT or MODE_UPDATE.
   * @throws javax.servlet.ServletException
   */
  private void prepareRequest(HttpServletRequest request, int mode) throws Exception
  {
    Category updatedCategory = (Category) request.getAttribute(ATTRIBUTE_UPDATED_OBJECT);

    String attributes[] = MetaManagerFactory.getIMetaManager().getAttributesNames(Category.class);

    Map values = null;

    if (mode == MODE_INIT)
    {
      values = BeanUtil.getValuesMap(updatedCategory, attributes);
    }
    else
    {
      /** todo put this somewhere else */
      // the name cannot be updated
      attributes = ArrayUtil.removeFromArray(attributes, new String[]{"id", "blogId"});
      values = HttpUtil.requestToMap(request, attributes);
    }

    // Important for the id hidden field
    values.put("id", String.valueOf(updatedCategory.getId()));


    request.setAttribute(ATTRIBUTE_VALUES, values);
  }

  protected ActionForward getSuccessActionForward(ActionMapping mapping, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    String url = request.getContextPath() + "/private/category/list.do?blogId=" +  request.getParameter("blogId") + "&confirmation=common.category.update.success" ;
    response.sendRedirect(url);
    return null;
  }
}