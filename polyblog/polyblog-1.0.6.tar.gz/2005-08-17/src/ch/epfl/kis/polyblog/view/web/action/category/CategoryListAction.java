package ch.epfl.kis.polyblog.view.web.action.category;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.security.*;
import ch.epfl.kis.polyblog.service.*;
import com.baneo.core.persistance.*;
import com.baneo.core.view.web.action.*;
import org.apache.struts.action.*;

import javax.servlet.http.*;
import java.util.*;

/**
 * Action for listing categories.
 *
 * @author Laurent Boatto
 */
public class CategoryListAction extends ObjectListAction
{
  /**
   * The parameter used to specify the blog id.
   */
  public static final String PARAMETER_BLOG_ID = "blogId";

  protected String getDefaultOrder()
  {
    // the results are never ordered.
    return null;
  }

  public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    // We have a special case here, because the categories are never ordered
    // or paged (a blog has only a few categories), so we can directly set
    // the results importer the request an use it later importer the find and count methods.
    Blog blog = BlogService.instance().get(request.getParameter(PARAMETER_BLOG_ID));
    request.setAttribute("blog", blog);
    SecurityService.checkListCategory(blog);
    Collection categories = CategoryService.instance().findByBlogId(blog.getId());
    request.setAttribute(ATTRIBUTE_RESULTS, categories);
    return super.execute(mapping, form, request, response);
  }

  protected Collection find(HttpServletRequest request, HttpServletResponse response, String orderBy, int startIndex, int maxResults) throws PersistanceException
  {
    return (Collection) request.getAttribute(ATTRIBUTE_RESULTS);
  }

  protected int count(HttpServletRequest request, HttpServletResponse response) throws PersistanceException
  {
    return ((Collection) request.getAttribute(ATTRIBUTE_RESULTS)).size();
  }
}