/*
 * $Id$
 *
 * Copyright 2005 EPFL. All rights reserved.
 */

package ch.epfl.kis.polyblog.model;

import com.baneo.core.model.*;

import java.security.*;
import java.util.*;

/**
 * User.
 *
 * @author Laurent Boatto
 */
public abstract class User extends BusinessObject implements Principal
{
  private String _name;
  private String _username;
  private String _email;
  private String _firstName;
  private String _lastName;
  String _label;

  public User(String name)
  {
    _name = name;
  }

  public String getUsername()
  {
    return _username;
  }

  public void setUsername(String username)
  {
    _username = username;
  }

  public String getEmail()
  {
    return _email;
  }

  public void setEmail(String email)
  {
    _email = email;
  }

  public String getFirstName()
  {
    return _firstName;
  }

  public void setFirstName(String firstName)
  {
    _firstName = firstName;
  }

  public String getLastName()
  {
    return _lastName;
  }

  public void setLastName(String lastName)
  {
    _lastName = lastName;
  }

  public String getName()
  {
    return _name;
  }

  public String getLabel()
  {
    return getLastName() + " " + getFirstName();
  }

  public void setLabel(String label)
  {
    _label = label;
  }

  /**
   * Returns true if the given user is a guest.
   *
   * @return true if the given user is a guest.
   */
  public abstract boolean isGuest();

  /**
   * Returns the Collection of Groups this user is member of.
   *
   * @return the Collection of Groups this user is member of.
   */
  public abstract Collection<Group> getGroups();

  public boolean equals(Object other)
  {
    if (this == other)
    {
      return true;
    }
    if (!(other instanceof User))
    {
      return false;
    }

    final User user = (User) other;

    if (!_name.equals(user._name))
    {
      return false;
    }

    return true;
  }

  public int hashCode()
  {
    return _name.hashCode();
  }

  public String toString()
  {
    return "[id = " + getId() + ", username = " + _username + ", class = " + this.getClass().getName() + "]";
  }
}