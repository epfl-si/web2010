/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package ch.epfl.kis.polyblog.view.web.action.article;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.service.*;
import com.baneo.core.view.web.action.*;
import org.apache.struts.action.*;

import javax.servlet.http.*;
import java.io.*;

/**
 * Action used to delete a article.
 *
 * @author Laurent Boatto
 * @version $Id$
 * @see com.baneo.core.view.web.action.ObjectDeleteAction
 * @see org.apache.struts.action.Action
 */

public class ArticleDeleteAction extends ObjectDeleteAction
{
  private static final ArticleService _articleService = ArticleService.instance();

  public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    int blogId = Integer.parseInt(request.getParameter("blogId"));
    Blog blog = BlogService.instance().get(blogId);
    request.setAttribute("blog", blog);

    /** todo security check here */

    ActionForward dynamicBack = new ActionForward("back", "/private/article/list.do?blogId=" + request.getParameter("blogId"), true);
    ActionMapping dynamicMapping = new ActionMapping();

    dynamicMapping.addForwardConfig(mapping.findForward("init"));
    dynamicMapping.addForwardConfig(dynamicBack);
  
    return super.execute(dynamicMapping, form, request, response);
  }

  protected void delete(String id, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    _articleService.delete(_articleService.get(id));
  }

  protected Object find(String id, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    return _articleService.get(id);
  }

  protected ActionForward getSuccessActionForward(ActionMapping mapping, HttpServletRequest request, HttpServletResponse response) throws IOException
  {
    Integer count = (Integer) request.getAttribute(ATTRIBUTE_COUNT);
    String url = request.getContextPath() + "/private/article/list.do?blogId=" + request.getParameter("blogId");

    if (count > 1)
    {
      url += "&confirmation=common.article.delete.confirmation.plural";
    }
    else
    {
      url += "&confirmation=common.article.delete.confirmation.singular";
    }

    response.sendRedirect(url);

    return null;
  }
}