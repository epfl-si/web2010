package ch.epfl.kis.polyblog.view.web.form;

import com.baneo.core.form.*;
import com.baneo.core.persistance.*;
import com.baneo.core.security.role.*;

import javax.servlet.jsp.*;

/**
 * BlogRoleUpdateForm.
 *
 * @author Laurent Boatto
 */
public class BlogRoleUpdateForm extends BlogRoleForm
{
  private ObjectRole _objectRole;

  public BlogRoleUpdateForm(PageContext context, String action, int mode) throws PersistanceException
  {
    super(context, action, mode);
    _objectRole = ObjectRoleManagerFactory.getIObjectRoleManager().get(context.getRequest().getParameter("id"));
  }

  protected void initForm()
  {
    super.initForm();
    setName("blogRole");

  }

  protected void initFields()
  {
    _id = new HiddenField("id");
    _blogId = new HiddenField("blogId");
    _principalName = new LabelField("principalName", null);
    _principalName.setValue(_objectRole.getPrincipalLabel());
    initRoleField();
  }

  protected void addFields()
  {
    addField(_id);
    addField(_principalName);
    addField(_role);
    addField(_blogId);
  }
}