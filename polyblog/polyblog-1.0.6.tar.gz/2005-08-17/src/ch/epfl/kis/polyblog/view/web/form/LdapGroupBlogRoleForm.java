package ch.epfl.kis.polyblog.view.web.form;

import ch.epfl.kis.polyblog.model.*;
import com.baneo.core.form.*;

import javax.servlet.jsp.*;

/**
 * LdapGroupBlogRoleForm.
 *
 * @author Laurent Boatto
 */
public class LdapGroupBlogRoleForm extends BlogRoleForm
{
  private Group _group;
  private LabelField _principalNameField;
  private HiddenField _dn;

  public LdapGroupBlogRoleForm(PageContext context, String action, int mode)
  {
    super(context, action, mode);
  }

  protected void initForm()
  {
    setName("ldapGroup");
    setShowBox(false);
    setShowHelpText(false);
    setShowRequiredString(false);
    setWidth("60%");
  }

  protected void initFields()
  {
    _blogId = new HiddenField("blogId");
    _principalNameField = new LabelField("principalName", "Groupe");
    _principalNameField.setValue(_group.getLabel());
    _dn = new HiddenField("dn");
    initRoleField();
  }

  protected void addFields()
  {
    addField(_principalNameField);
    addField(_role);
    addField(_dn);
    addField(_blogId);
  }

  public void setGroup(Group group)
  {
    _group = group;
  }
}