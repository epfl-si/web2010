package ch.epfl.kis.polyblog.view.web.action.category;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.security.*;
import ch.epfl.kis.polyblog.service.*;
import org.apache.struts.action.*;

import javax.servlet.http.*;

/**
 * CategoryViewAction.
 *
 * @author Laurent Boatto
 */
public class CategoryViewAction extends Action
{
  public ActionForward execute(ActionMapping mapping, ActionForm actionForm, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    Category category = CategoryService.instance().get(request.getParameter("id"));
    Blog blog = category.getBlog();

    if (!SecurityService.hasReadAccess(blog))
    {
      return mapping.findForward("403");
    }

    request.setAttribute("category", category);
    request.setAttribute("blog", blog);

    return mapping.findForward("category");
  }
}