package ch.epfl.kis.polyblog.model;

import ch.epfl.kis.core.ldap.*;
import ch.epfl.kis.polyblog.service.*;
import com.novell.ldap.*;
import org.apache.commons.logging.*;

import java.util.*;

/**
 * LdapUser.
 *
 * @author Laurent Boatto
 */
public class LdapUser extends User
{
  /**
   * The log.
   */
  private static final Log _log = LogFactory.getLog(LdapUser.class);

  private String _dn;
  private Collection _groups;
  private static final LdapGroupService _ldapGroupService = LdapGroupService.instance();
  private LDAPEntry _ldapEntry;

  /**
   * Constructs a new LdapUser with the given Principal name, which must be
   * the uniqueIdentifier.
   *
   * @param name the name, which must be the uniqueIdentifier.
   */
  public LdapUser(String name, LDAPEntry entry)
  {
    super(name);
    _ldapEntry = entry;
  }

  public String getDn()
  {
    return _dn;
  }

  public void setDn(String dn)
  {
    _dn = dn;
  }

  public Collection<Group> getGroups()
  {
    // we check the cache first
    if (_groups != null)
    {
      return _groups;
    }

    try
    {
      Collection results = new HashSet();

      LdapConnector connector = LdapConnectorFactory.getLdapConnector();

      Collection entries = connector.findBySearchFilter(LDAPConnection.SCOPE_SUB, "(uniqueIdentifier=" + getName() + ")");

      for (Iterator iterator = entries.iterator(); iterator.hasNext();)
      {
        LDAPEntry entry = (LDAPEntry) iterator.next();
        String dn = entry.getDN();

        // we parse the DN to find the users's groups, e.g. the DN :
        //
        // cn=Donald Denhagen, ou=LPN, ou=IPEQ, ou=SB, o=EPFL, c=CH
        //
        // will give the following groups :
        //
        // ou=LPN, ou=IPEQ, ou=SB, o=EPFL, c=CH
        // ou=IPEQ, ou=SB, o=EPFL, c=CH
        // ou=SB, o=EPFL, c=CH
        // o=EPFL, c=CH
        int index = dn.indexOf(",");

        while (index > 0)
        {
          dn = dn.substring(index + 1).trim();

          if (dn.startsWith("ou=") || dn.startsWith("o="))
          {
            Group group = _ldapGroupService.findByDn(dn);

            if (group != null)
            {
              results.add(group);
            }
          }

          index = dn.indexOf(",");
        }
      }

      results.addAll(getExplicitGroups());

      _groups = results;
      return results;
    }
    catch (LDAPException e)
    {
      _log.error(e.getMessage(), e);
      throw new RuntimeException(e);
    }
  }

  public boolean isGuest()
  {
    return _dn.indexOf("epfl-guests") != -1;
  }

  /**
   * Retrieves the user id (id or email), retrieves the corresponding
   * LDAP entry, retrieves the "memberOf" values (explicits groups),
   * retrieves the LDAP groups corresponding to the "memberOf" values.
   *
   * @return a collection containing all the user's explicits groups.
   */
  private Collection getExplicitGroups() throws LDAPException
  {
    if (_ldapEntry == null)
    {
      return null;
    }

    // retrieves the explicit groups
    Collection explicitGroups = new HashSet();
    LDAPAttribute memberOf = _ldapEntry.getAttribute("memberOf");

    if (memberOf != null)
    {
      String[] groups = memberOf.getStringValueArray();

      if (groups != null)
      {
        for (int i = 0; i < groups.length; i++)
        {
          explicitGroups.add(_ldapGroupService.findByCommonName((groups[i])));
        }
      }
    }

    return explicitGroups;
  }
}