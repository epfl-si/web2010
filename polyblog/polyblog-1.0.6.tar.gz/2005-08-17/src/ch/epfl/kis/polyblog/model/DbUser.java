package ch.epfl.kis.polyblog.model;

import java.util.*;

/**
 * DbUser.
 *
 * @author Laurent Boatto
 */
public class DbUser extends User
{
  /**
   * Constructs a new DbUser with the given name.
   *
   * @param name the name.
   */
  public DbUser(String name)
  {
    super(name);
  }

  public Collection<Group> getGroups()
  {
    /** todo implement this */
    return new ArrayList();
  }

  public boolean isGuest()
  {
    /** todo implement this */
    return false;
  }
}