/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package ch.epfl.kis.polyblog.view.web.action.blogRole.group.ldap;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.security.*;
import ch.epfl.kis.polyblog.service.*;
import ch.epfl.kis.polyblog.validator.*;
import com.baneo.core.security.role.*;
import com.baneo.core.util.*;
import com.baneo.core.validator.*;
import com.baneo.core.view.web.action.*;
import org.apache.struts.action.*;

import javax.servlet.http.*;
import java.util.*;

/**
 * Action used to insert a ldap group as a BlogRole.
 *
 * @author Laurent Boatto
 * @version $Id$
 * @see com.baneo.core.view.web.action.ObjectInsertAction
 * @see org.apache.struts.action.Action
 */

public class LdapGroupInsertAction extends ObjectInsertAction
{
  private IObjectRoleManager _manager = ObjectRoleManagerFactory.getIObjectRoleManager();

  public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    String blogId = request.getParameter("blogId");
    Blog blog = BlogService.instance().get(blogId);
    SecurityService.checkManageBlogRoles(blog);

    request.setAttribute("blog", blog);
    String dn = request.getParameter("dn");

    if (dn == null)
    {
      return new ActionForward("/private/blogRole/group/ldap/select.do?blogId=" + blogId);
    }

    dn = HttpUtil.decode(dn);
    Group group = LdapGroupService.instance().findByDn(dn);
    request.setAttribute("group", group);
    return super.execute(mapping, form, request, response);
  }

  protected void onInit(HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    super.onInit(request, response);
    Map values = (Map) request.getAttribute(ATTRIBUTE_VALUES);
    values.put("blogId", request.getParameter("blogId"));
    values.put("dn", request.getParameter("dn"));
  }

  protected Validator getValidator(HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    Blog blog = (Blog) request.getAttribute("blog");
    Group group = (Group) request.getAttribute("group");

    ObjectRole role = new ObjectRole();
    Map values = new HashMap();
    values.put("principalName", group.getName());
    values.put("principalClassName", group.getClass().getName());
    values.put("principalLabel", group.getLabel());
    values.put("businessObjectId", String.valueOf(blog.getId()));
    values.put("businessObjectClassName", blog.getClass().getName());
    values.put("role", request.getParameter("role"));

    LdapGroupBlogRoleValidator validator = new LdapGroupBlogRoleValidator(role, values, Validator.MODE_INSERT, request.getLocale());
    validator.setBlog(blog);
    validator.setGroup(group);
    return validator;
  }

  protected void insert(Object object, Validator validator, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    _manager.insert((ObjectRole) object);
  }

 protected ActionForward getSuccessActionForward(ActionMapping mapping, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    String url = request.getContextPath() + "/private/blogRole/list.do?blogId=" + request.getParameter("blogId") + "&confirmation=common.blogRole.group.insert.success";
    response.sendRedirect(url);
    return null;
  }
}