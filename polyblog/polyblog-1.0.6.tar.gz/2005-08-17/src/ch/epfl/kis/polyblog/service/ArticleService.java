/*
 * $Id$
 *
 * Copyright 2005 EPFL. All rights reserved.
 */

package ch.epfl.kis.polyblog.service;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.security.*;
import ch.epfl.kis.polyblog.system.*;
import ch.epfl.kis.polyblog.util.*;
import com.baneo.core.persistance.*;
import com.baneo.core.service.*;
import com.baneo.core.util.*;

import java.util.*;

/**
 * ArticleManager lets you manage articles.
 *
 * @author Laurent Boatto
 */
public class ArticleService extends BusinessObjectManager
{
  private static final IPersistanceManager _persistanceManager = PersistanceManagerFactory.getIPersistanceManager();
  private static final ArticleService _instance = new ArticleService();
  private static final String FIND_BY_MONTH_QUERY = "FROM " + Article.class.getName() + " WHERE blogId = ? AND statusId = ? AND publicationDate >= ? AND publicationDate <= ?";
  private static final String FIND_LAST_PUBLIC_QUERY = "SELECT article FROM " + Article.class.getName() + " as article, " +
      Blog.class.getName() + " as blog " +
      "WHERE article.statusId = " + Article.STATUS_PUBLISH +
      " AND article.blogId = blog.id " +
      " AND blog.isPublic = 1";

  /**
   * Returns the instance of the ArticleManager (singleton).
   *
   * @return the instance of the ArticleService (singleton).
   */
  public static final ArticleService instance()
  {
    return _instance;
  }

  /**
   * Insert the given article into the system.
   *
   * @param article the article to insert.
   * @throws PersistanceException on persistance layer error.
   */
  public Article insert(Article article) throws PersistanceException
  {
    SecurityService.checkInsertArticle(article.getBlog());
    // for performance reasons we save the author first name and last name
    // directly in the article
    User user = SecurityService.getUser();
    article.setAuthorFirstName(user.getFirstName());
    article.setAuthorLastName(user.getLastName());

    if (article.getPublicationDate() == null)
    {
      article.setPublicationDate(new java.util.Date());
    }

    format(article);
    _persistanceManager.insert(article);
    launchPostInsertEvent(article);
    return article;
  }

  /**
   * Returns the last public articles.
   *
   * @return the last public articles.
   * @throws PersistanceException on persistance layer error.
   */
  public Collection<Article> findLastPublic() throws PersistanceException
  {
    return _persistanceManager.findByQuery(FIND_LAST_PUBLIC_QUERY, null, "publicationDate DESC", 0, Constants.ARTICLE_LAST_PUBLIC_NUM);
  }

  /**
   * Updates the given article.
   *
   * @param article the article to update.
   * @throws PersistanceException on persistance layer error.
   */
  public void update(Article article) throws PersistanceException
  {
    SecurityService.checkDeleteOrUpdateArticle(article);

    format(article);

    // If an article is updated and was previously in draft mode and now
    // in publish mode, we must change the publication date and send the
    // notification email
    /** todo put the following code in a listener */
    if (article.getStatusId() == Article.STATUS_PUBLISH)
    {
      Article previousVersion = get(article.getId());

      if (previousVersion.getStatusId() == Article.STATUS_DRAFT)
      {
        article.setPublicationDate(new Date());
        EmailService.sendNewArticleNotification(article);
      }
    }

    _persistanceManager.update(article);
  }

  /**
   * Formats the given article before updating or inserting it.
   *
   * @param article the article to format.
   */
  private void format(Article article)
  {
    article.setTitle(Util.stripHarmfulTags(article.getTitle()));
    article.setContent(Util.stripHarmfulTags(article.getContent()));
  }

  /**
   * Deletes the given article from the system.
   *
   * @param article the article to delete.
   * @throws PersistanceException on persistance layer error.
   */
  public void delete(Article article) throws PersistanceException
  {
    SecurityService.checkDeleteOrUpdateArticle(article);
    launchPreDeleteEvent(article);
    _persistanceManager.delete(article);
  }

  /**
   * Returns the articles corresponding to the given query string and attributes,
   * ordered by the given orderBy, starting at startIndex and returning at most
   * maxResults.
   *
   * @param queryString     the query string.
   * @param queryAttributes the query attributes.
   * @param orderBy         the attribute used to order the objects.
   * @param startIndex      the index to start (e.g. 0 to start at the beginning).
   * @param maxResults      the maximum number of objects to return.
   * @return the articles corresponding to the given query string and attributes.
   * @throws PersistanceException on persistance layer error.
   */
  public Collection<Article> findByQuery(String queryString, String[] queryAttributes, String orderBy, int startIndex, int maxResults) throws PersistanceException
  {
    return _persistanceManager.findByQuery(queryString, queryAttributes, orderBy, startIndex, maxResults);
  }

  /**
   * Returns the number of articles corresponding to the given query string and
   * attributes.
   *
   * @param queryString     the query string.
   * @param queryAttributes the query attributes, can be null.
   * @return the number of articles corresponding to the given query string and
   *         attributes.
   * @throws PersistanceException on persistance layer error.
   */
  public int findByQueryCount(String queryString, String[] queryAttributes) throws PersistanceException
  {
    return _persistanceManager.findByQueryCount(queryString, queryAttributes);
  }

  /**
   * Returns the article having the given id or null if it doesn't exist.
   *
   * @param id the article id.
   * @return the article having the given id or null if it doesn't exist.
   * @throws PersistanceException on persistance layer error.
   */
  public Article get(int id) throws PersistanceException
  {
    return (Article) _persistanceManager.get(Article.class, id);
  }

  /**
   * Returns the article having the given id or null if it doesn't exist.
   *
   * @param id the article id.
   * @return the article having the given id or null if it doesn't exist.
   * @throws PersistanceException on persistance layer error.
   */
  public Article get(String id) throws PersistanceException
  {
    return get(Integer.parseInt(id));
  }

  /**
   * Increments the number of comment for the given article.
   *
   * @param article the article to increment the number of comments.
   * @throws PersistanceException on persistance layer error.
   */
  public void incrementNumComment(Article article) throws PersistanceException
  {
    synchronized (article)
    {
      article.setNumComment(article.getNumComment() + 1);
      persistUpdateOnly(article, false);
    }
  }

  /**
   * Decrements the number of comment for this article.
   *
   * @param article the article to decrement the number of comments.
   * @throws PersistanceException on persistance layer error.
   */
  public synchronized void decrementNumComment(Article article) throws PersistanceException
  {
    synchronized (article)
    {
      article.setNumComment(article.getNumComment() - 1);
      persistUpdateOnly(article, false);
    }
  }

  /**
   * Simply persists the changes done by the system on a article. This is
   * different from <code>update(Article)</code> which saves the changes
   * done by a user. Here there is no security check, etc.
   *
   * @param article      the article.
   * @param launchEvents if true launch the manager update events.
   * @throws PersistanceException on persistance layer error.
   * @see #update(ch.epfl.kis.polyblog.model.Article)
   */
  public void persistUpdateOnly(Article article, boolean launchEvents) throws PersistanceException
  {
    _persistanceManager.update(article);
  }

  /**
   * Returns the articles belonging to the given blog.
   *
   * @param blog the blog id.
   * @return the articles belonging to the given blog id.
   * @throws PersistanceException on persistance layer error.
   */
  public Collection<Article> findByBlog(Blog blog) throws PersistanceException
  {
    return _persistanceManager.findByAttribute(Article.class, "blogId", new Integer(blog.getId()));
  }

  /**
   * Returns the articles belonging to the given blog, ordered by the given
   * orderBy, starting at startIndex and returning at most maxResults.
   *
   * @param blog       the blog.
   * @param orderBy    the attribute to use for ordering.
   * @param startIndex the index to start from.
   * @param maxResults the maximum results to return.
   * @return the articles belonging to the given blog id, ordered by the given
   *         orderBy, starting at startIndex and returning at most maxResults.
   * @throws PersistanceException on persistance layer error.
   */
  public Collection<Article> findByBlog(Blog blog, String orderBy, int startIndex, int maxResults) throws PersistanceException
  {
    return _persistanceManager.findByAttribute(Article.class, "blogId", new Integer(blog.getId()), orderBy, startIndex, maxResults);
  }

  /**
   * Returns the last articles of the given blog from the given date.
   *
   * @param blog     the blog.
   * @param fromDate the date from when to get the last articles.
   * @param num      the number of articles to return.
   * @return the last articles of the given blog.
   * @throws PersistanceException on persistance layer error.
   */
  public Collection<Article> findLastByBlog(Blog blog, Date fromDate, int num) throws PersistanceException
  {
    Calendar from = new GregorianCalendar();
    from.setTime(fromDate);
    from.set(Calendar.HOUR_OF_DAY, from.getActualMaximum(Calendar.HOUR_OF_DAY));
    from.set(Calendar.MINUTE, from.getActualMaximum(Calendar.MINUTE));
    from.set(Calendar.SECOND, from.getActualMaximum(Calendar.SECOND));
    from.set(Calendar.MILLISECOND, from.getActualMaximum(Calendar.MILLISECOND));
    String query = "FROM " + Article.class.getName() + " WHERE blogId = ? AND statusId = ? AND publicationDate <= ?";
    Object[] queryAttributes = {new Integer(blog.getId()), new Integer(Article.STATUS_PUBLISH), from.getTime()};
    return _persistanceManager.findByQuery(query, queryAttributes, "publicationDate DESC", 0, num);
  }

  /**
   * Returns the number of articles the given blog id has.
   *
   * @param blogId the blog id.
   * @return the number of articles the given blog id has.
   * @throws PersistanceException on persistance layer error.
   */
  public int findByBlogIdCount(int blogId) throws PersistanceException
  {
    return _persistanceManager.findByAttributeCount(Article.class, "blogId", new Integer(blogId));
  }

  /**
   * Returns the last Article.
   *
   * @return the last Article.
   * @throws PersistanceException on persistance layer error.
   */
  public Article findLast() throws PersistanceException
  {
    return (Article) _persistanceManager.findLast(Article.class);
  }

  /**
   * Returns the last published articles of the given category.
   *
   * @param category the category.
   * @return the last published articles of the given category.
   * @throws PersistanceException on persistance layer error.
   */
  public Collection<Article> findLastByCategory(Category category) throws PersistanceException
  {
    String[] attributesNames = {"categoryId", "statusId"};
    Object[] attributesValues = {new Integer(category.getId()), new Integer(Article.STATUS_PUBLISH)};
    return _persistanceManager.findByAttributes(Article.class, attributesNames, attributesValues, "publicationDate DESC", 0, Constants.ARTICLE_DISPLAY_NUM);
  }

  /**
   * Returns the IPersistanceManager used by the manager to persist the
   * BusinessObjects.
   *
   * @return the IPersistanceManager used by the manager to persist the
   *         business objects.
   */
  protected IPersistanceManager getIPersistanceManager()
  {
    return _persistanceManager;
  }

  /**
   * Returns the class that this BusinessObjectManager is managing.
   *
   * @return the class that this BusinessObjectManager is managing.
   */
  protected Class getManagedClass()
  {
    return Article.class;
  }


  /**
   * Returns the articles belonging to the given blog and having the same
   * month (and year) of the given date.
   *
   * @param blog  the blog.
   * @param month the date having the wanted month.
   * @return the articles belonging to the given blog and having the same
   *         month (and year) of the given date.
   * @throws PersistanceException on persistance layer error.
   */
  public Collection<Article> findByMonth(Blog blog, Date month) throws PersistanceException
  {
    // dateFrom
    Calendar dateFrom = new GregorianCalendar();
    dateFrom.setTime(month);
    dateFrom.set(Calendar.DATE, dateFrom.getActualMinimum(Calendar.DATE));
    dateFrom.set(Calendar.HOUR_OF_DAY, 0);
    dateFrom.set(Calendar.MINUTE, 0);
    dateFrom.set(Calendar.SECOND, 0);
    dateFrom.set(Calendar.MILLISECOND, 0);

    // dateTo
    Calendar dateTo = new GregorianCalendar();
    dateTo.setTime(month);
    dateTo.set(Calendar.DATE, dateTo.getActualMaximum(Calendar.DATE));
    dateTo.set(Calendar.HOUR_OF_DAY, dateTo.getActualMaximum(Calendar.HOUR_OF_DAY));
    dateTo.set(Calendar.MINUTE, dateTo.getActualMaximum(Calendar.MINUTE));
    dateTo.set(Calendar.SECOND, dateTo.getActualMaximum(Calendar.SECOND));
    dateTo.set(Calendar.MILLISECOND, dateTo.getActualMaximum(Calendar.MILLISECOND));

    Object[] queryAttributes =
        {
            new Integer(blog.getId()),
            new Integer(Article.STATUS_PUBLISH),
            dateFrom.getTime(),
            dateTo.getTime()
        };

    return _persistanceManager.findByQuery(FIND_BY_MONTH_QUERY, queryAttributes, "publicationDate DESC", 0, Integer.MAX_VALUE);
  }

  /**
   * Finds the articles belonging to the given blog and having the same
   * month (and year) of the given date, and returns them importer SubscriptionService Map having
   * for the key the day importer ISO format (e.g. "2003-02-02") and for the value
   * SubscriptionService Collection of articles from that day.
   *
   * @param blog  the blog.
   * @param month the date having the wanted month.
   * @return the articles belonging to the given blog and having the same
   *         month (and year) of the given date.
   * @throws PersistanceException on persistance layer error.
   */
  public Map<String, Collection<Article>> findByMonthMap(Blog blog, Date month) throws PersistanceException
  {
    Collection byMonth = findByMonth(blog, month);
    Map<String, Collection<Article>> results = new HashMap<String, Collection<Article>>();

    for (Iterator iterator = byMonth.iterator(); iterator.hasNext();)
    {
      Article article = (Article) iterator.next();
      String date = DateUtil.formatIsoDate(article.getPublicationDate());

      Collection<Article> byDay = results.get(date);

      if (byDay == null)
      {
        byDay = new ArrayList<Article>();
        results.put(date, byDay);
      }

      byDay.add(article);
    }

    return results;
  }
}