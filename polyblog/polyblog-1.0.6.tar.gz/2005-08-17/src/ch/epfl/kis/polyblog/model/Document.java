package ch.epfl.kis.polyblog.model;

import ch.epfl.kis.polyblog.service.*;
import ch.epfl.kis.polyblog.system.*;
import com.baneo.core.model.*;
import com.baneo.core.persistance.*;
import com.baneo.core.system.*;

/**
 * Document.
 *
 * @author Laurent Boatto
 */
public class Document extends BusinessObject
{
  private String _name;
  private long _length;
  private boolean _inline;
  private int _articleId;
  private int _blogId;
  private String _mimeType;

  public String getName()
  {
    return _name;
  }

  public void setName(String name)
  {
    _name = name;
  }

  public long getLength()
  {
    return _length;
  }

  public void setLength(long length)
  {
    _length = length;
  }

  public boolean getInline()
  {
    return _inline;
  }

  public void setInline(boolean inline)
  {
    _inline = inline;
  }

  public int getArticleId()
  {
    return _articleId;
  }

  public void setArticleId(int articleId)
  {
    _articleId = articleId;
  }

  public int getBlogId()
  {
    return _blogId;
  }

  public void setBlogId(int blogId)
  {
    _blogId = blogId;
  }

  public String getMimeType()
  {
    return _mimeType;
  }

  public void setMimeType(String mimeType)
  {
    _mimeType = mimeType;
  }

  // calculated attributes -----------------------------------------------------
  public Blog getBlog() throws PersistanceException
  {
    return BlogService.instance().get(_blogId);
  }

  /**
   * Returns the absolute url of the document.
   *
   * @return the absolute url of the document.
   */
  public String getAbsoluteUrl()
  {
    return Constants.SITE_BASE_URL + Config.get("document.prefixUrl") + getId();
  }

  /**
   * Returns the relative url of the document.
   *
   * @return the relative url of the document.
   */
  public String getRelativeUrl()
  {
    return Constants.SITE_CONTEXT_PATH + Config.get("document.prefixUrl") + getId();
  }

  /**
   * Returns true if the document is an image.
   *
   * @return true if the document is an image.
   */
  public boolean getImage()
  {
    return _mimeType != null && _mimeType.startsWith("image");
  }
}