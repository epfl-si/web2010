package ch.epfl.kis.polyblog.ws;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.service.*;
import com.baneo.core.persistance.*;

import java.util.*;

/**
 * Implementation of the Blogger API, see :
 * <p/>
 * http://www.blogger.com/developers/api/1_docs/
 *
 * @author Laurent Boatto
 */
public class BloggerApi extends BaseXmlRpcApi
{
  public String newPost(String appkey, String blogid, String username, String password, String content, boolean publish) throws PersistanceException
  {
    Hashtable data = new Hashtable();
    data.put("description", content);
    return super.newPost(blogid, username, password, data, publish);
  }

  public boolean editPost(String appkey, String articleId, String username, String password, String content, boolean publish) throws PersistanceException
  {
    Hashtable data = new Hashtable();
    data.put("description", content);
    return super.editPost(articleId, username, password, data, publish);
  }

  public boolean deletePost(String appkey, String postid, String userid, String password, boolean publish) throws PersistanceException
  {
    return super.deletePost(postid, userid, password, publish);
  }

  /**
   * Returns information on all the blogs a given user is a member of.
   *
   * @param appkey   Unique identifier/passcode of the application sending the post.
   * @param username Login for the Blogger user who's blogs will be retrieved.
   * @param password Password for said username.
   * @return information on all the blogs a given user is a member of.
   * @throws PersistanceException
   */
  public Object getUsersBlogs(String appkey, String username, String password) throws PersistanceException
  {
    User user = _userService.authenticate(username, password);

    List result = new Vector();

    Collection blogs = BlogService.instance().findByUser(user, false);

    for (Iterator iterator = blogs.iterator(); iterator.hasNext();)
    {
      Blog blog = (Blog) iterator.next();

      Hashtable rpcBlog = new Hashtable(3);
      rpcBlog.put("url", blog.getAbsoluteUrl());
      rpcBlog.put("blogid", String.valueOf(blog.getId()));
      rpcBlog.put("blogName", blog.getLabel());

      result.add(rpcBlog);
    }

    return result;
  }

  /**
   * Returns a struct containing user's userid, firstname, lastname, nickname,
   * email, and url.
   *
   * @param appkey   Unique identifier/passcode of the application sending the post.
   * @param username Login for the Blogger user who's blogs will be retrieved.
   * @param password Password for said username.
   * @return a struct containing user's informations.
   * @throws PersistanceException
   */
  public Object getUserInfo(String appkey, String username, String password) throws PersistanceException
  {
    User user = _userService.authenticate(username, password);

    Hashtable result = new Hashtable();
    result.put("nickname", user.getUsername());
    result.put("username", user.getUsername());
    result.put("url", "");
    result.put("email", user.getEmail());
    result.put("lastname", user.getLastName());
    result.put("firstname", user.getFirstName());

    return result;
  }

  /**
   * Returns text of the main or archive index template for a given blog.
   *
   * @param appkey       Unique identifier/passcode of the application sending the post.
   * @param blogid       Unique identifier of the blog who's template is to be returned.
   * @param userid       Login for a Blogger who has admin permission on give blog.
   * @param password     Password for said username.
   * @param templateType Determines which of the blog's templates will be returned.
   *                     Currently, either "main" or "archiveIndex".
   * @return text of the main or archive index template for a given blog.
   */
  public String getTemplate(String appkey, String blogid, String userid, String password, String templateType)
  {
    throw new UnsupportedOperationException("Templates are not supported by polyblog yet.");
  }

  /**
   * Edits the main index template of a given blog.
   *
   * @param appkey       Unique identifier/passcode of the application sending the post
   * @param blogid       Unique identifier of the blog the post will be added to
   * @param userid       Login for a Blogger user who has permission to post to the blog
   * @param password     Password for said username
   * @param templateType The text for the new template (usually mostly HTML).
   * @param templateType Determines which of the blog's templates is to be set.
   */
  public boolean setTemplate(String appkey, String blogid, String userid,
      String password, String templateData,
      String templateType)
  {
    throw new UnsupportedOperationException("Templates are not supported by polyblog yet.");
  }
}