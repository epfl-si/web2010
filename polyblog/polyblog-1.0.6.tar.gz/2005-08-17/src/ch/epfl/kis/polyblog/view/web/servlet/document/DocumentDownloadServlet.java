package ch.epfl.kis.polyblog.view.web.servlet.document;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.security.*;
import ch.epfl.kis.polyblog.service.*;
import ch.epfl.kis.polyblog.system.*;
import com.baneo.core.persistance.*;
import org.apache.commons.logging.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;


/**
 * DocumentDownloadServlet.
 *
 * @author Laurent Boatto
 */
public class DocumentDownloadServlet extends HttpServlet
{
  /**
   * The log.
   */
  private static final Log _log = LogFactory.getLog(DocumentDownloadServlet.class);

  private static final DocumentService _documentService = DocumentService.instance();

  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    try
    {
      Document document = _documentService.get(request.getParameter("id"));

      if (document == null)
      {
        request.getRequestDispatcher("/error/404.jsp").forward(request, response);
        return;
      }

      Blog blog = document.getBlog();

      if (!SecurityService.hasReadAccess(blog))
      {
        request.getRequestDispatcher("/p/public/blog/view/403").forward(request, response);
        return;
      }

      response.setContentLength((int) document.getLength());
      response.setContentType(document.getMimeType());
      response.setHeader("Content-Disposition", "inline; filename=" + document.getName());

      java.io.File file = new java.io.File(Constants.SYSTEM_DOCUMENT_PATH + java.io.File.separator + document.getId());
      BufferedInputStream in = new BufferedInputStream(new FileInputStream(file));
      OutputStream out = response.getOutputStream();

      int read = 0;
      while ((read = in.read()) != -1)
      {
        out.write(read);
      }

      in.close();
      out.close();
    }
    catch (PersistanceException e)
    {
      _log.error(e.getMessage(), e);
      throw new ServletException(e);
    }
  }
}