package ch.epfl.kis.polyblog.view.web.action.article;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.security.*;
import ch.epfl.kis.polyblog.service.*;
import org.apache.struts.action.*;

import javax.servlet.http.*;
import java.util.*;

/**
 * ArticleViewAction.
 *
 * @author Laurent Boatto
 */
public class ArticleViewAction extends Action
{
  private static final ArticleService _articleService = ArticleService.instance();
  private static final CommentService _commentService = CommentService.instance();

  public ActionForward execute(ActionMapping mapping, ActionForm actionForm, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    Article article = _articleService.get(request.getParameter("id"));

    if (article == null)
    {
      return mapping.findForward("404");
    }

    request.setAttribute("article", article);

    Blog blog = article.getBlog();

    if (!SecurityService.hasReadAccess(blog))
    {
      return mapping.findForward("403");
    }

    Collection comments = null;

    if (article.getAllowComments())
    {
      comments = _commentService.findByArticleId(article.getId());
    }

    request.setAttribute("blog", blog);
    request.setAttribute("comments", comments);

    return mapping.findForward("init");
  }
}