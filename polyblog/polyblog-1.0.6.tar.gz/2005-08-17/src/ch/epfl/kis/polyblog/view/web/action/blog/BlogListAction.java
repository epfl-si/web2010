/*
 * $Id$
 *
 * Copyright 2005 EPFL. All rights reserved.
 */

package ch.epfl.kis.polyblog.view.web.action.blog;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.security.*;
import ch.epfl.kis.polyblog.service.*;
import com.baneo.core.persistance.*;
import com.baneo.core.view.web.action.*;
import com.baneo.core.system.*;

import javax.servlet.http.*;
import java.util.*;

/**
 * Action for listing blogs.
 *
 * @author Laurent Boatto
 */
public class BlogListAction extends ObjectListAction
{
  private static final BlogService _blogService = BlogService.instance();
  private static final MaskedBlogService _maskedBlogService = MaskedBlogService.instance();

  protected String getDefaultOrder()
  {
    return null;
  }

  protected Collection find(HttpServletRequest request, HttpServletResponse response, String orderBy, int startIndex, int maxResults) throws PersistanceException
  {
    return (Collection) request.getAttribute(ATTRIBUTE_RESULTS);
  }

  protected int count(HttpServletRequest request, HttpServletResponse response) throws PersistanceException
  {
    User user = SecurityService.getUser();

    Collection<Blog> blogs = _blogService.findByUser(user, true);
    Collection<Blog> blogsPurged = new ArrayList<Blog>();
    blogsPurged.addAll(blogs);

    Collection<MaskedBlog> maskeds = _maskedBlogService.findByUser(user);

    for (MaskedBlog masked : maskeds)
    {
      for (Blog blog : blogs)
      {
        if (blog.getId() == masked.getBlogId())
        {
          blogsPurged.remove(blog);
        }
      }
    }

    request.setAttribute(ATTRIBUTE_RESULTS, blogsPurged);

    String maskedMessage = null;

    if (maskeds.size() > 1)
    {
      maskedMessage = Message.format("common.blog.masked.plural", request.getLocale(), request.getContextPath() + "/private/maskedBlog/list.do", maskeds.size());
    }
    else if (maskeds.size() == 1)
    {
      maskedMessage = Message.format("common.blog.masked.singular", request.getLocale(), request.getContextPath() + "/private/maskedBlog/list.do");
    }

    request.setAttribute("maskedMessage", maskedMessage);

    return blogsPurged.size();
  }
}