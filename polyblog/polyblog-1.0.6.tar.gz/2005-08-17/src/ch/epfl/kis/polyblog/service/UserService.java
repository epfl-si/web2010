/*
 * $Id$
 *
 * Copyright 2005 EPFL. All rights reserved.
 */

package ch.epfl.kis.polyblog.service;

import ch.epfl.kis.polyblog.model.*;
import com.baneo.core.persistance.*;
import org.apache.commons.logging.*;

import java.util.*;

/**
 * UserService.
 *
 * @author Laurent Boatto
 */
public class UserService
{
  /**
   * The log.
   */
  private static final Log _log = LogFactory.getLog(UserService.class);
  private static UserService _instance = new UserService();
  private static final Map<Class, IUserService> _userServicesClassMap = new HashMap<Class, IUserService>();
  private static final Map<String, IUserService> _userServicesNameMap = new HashMap<String, IUserService>();
  private static final List<IUserService> _userServicesList = new ArrayList<IUserService>();

  private UserService()
  {
  }

  /**
   * Returns the instance of the UserService (singleton).
   *
   * @return the instance of the UserService (singleton).
   */
  public static final UserService instance()
  {
    return _instance;
  }

  /**
   * Returns the user having the given id and class (e.g. LdapUser.class), or
   * null if the user does not exist.
   *
   * @param id    the user id.
   * @param klass the user class.
   * @return the user having the given id and class.
   * @throws PersistanceException
   */
  public User get(String id, Class klass) throws PersistanceException
  {
    IUserService userService = _userServicesClassMap.get(klass);

    if (userService == null)
    {
      throw new PersistanceException("No IUserService registered for class " + klass.getName());
    }

    return userService.get(id);
  }

  /**
   * Returns the user having the given id, using the IUserService having
   * the given name.
   *
   * @param id              the user id.
   * @param name the IUserService name.
   * @return the user having the given id.
   * @throws PersistanceException
   */
  public User get(String id, String name) throws PersistanceException
  {
    IUserService userService = _userServicesNameMap.get(name);

    if (userService == null)
    {
      throw new PersistanceException("No IUserService registered having the name " + name);
    }

    return userService.get(id);
  }

  /**
   * Returns the user having the given id, using all the registered
   * IUserServices in the order they were registered, or null if the user cannot
   * be found.
   *
   * @param id the user id.
   * @return the user having the given id.
   * @throws PersistanceException on persistance layer error.
   */
  public User get(String id) throws PersistanceException
  {
    for (int i = 0; i < _userServicesList.size(); i++)
    {
      IUserService userService = _userServicesList.get(i);

      User user = userService.get(id);

      if (user != null)
      {
        return user;
      }
    }

    return null;
  }

  /**
   * Authenticates a user by finding one with the given username and password,
   * and returns it. If the username does not exist or the password is false,
   * returns null.
   *
   * @param username the username.
   * @param password the password.
   * @return the User, or null if it does not exist.
   * @throws PersistanceException on persistance layer error.u
   */
  public User authenticate(String username, String password) throws PersistanceException
  {
    for (int i = 0; i < _userServicesList.size(); i++)
    {
      IUserService userService = _userServicesList.get(i);
      return userService.authenticate(username, password);
    }

    return null;
  }

  /**
   * Registers the given IUserService. The order importer which the IUserServices are
   * registered is important.
   *
   * @param userService the IUserService to register.
   */
  public void registerIUserService(IUserService userService)
  {
    _userServicesClassMap.put(userService.getUserClass(), userService);
    _userServicesNameMap.put(userService.getName(), userService);
    _userServicesList.add(userService);
  }


  /**
   * Returns the registered IUserServices.
   *
   * @return the registered IUserServices.
   */
  public List<IUserService> getIUserServices()
  {
    return Collections.unmodifiableList(_userServicesList);
  }
}