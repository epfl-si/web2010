package ch.epfl.kis.polyblog.system;

import com.baneo.core.system.*;

/**
 * Constants.
 *
 * @author Laurent Boatto
 */
public interface Constants
{
  /**
   * The site context path.
   */
  String SITE_CONTEXT_PATH = Config.get("site.contextPath");

  /**
   * The site base url, including the context (if any),
   * without a slash at the end.
   */
  String SITE_HOSTNAME = Config.get("site.hostname");

  /**
   * The site base url, including the context (if any),
   * without a slash at the end.
   */
  String SITE_BASE_URL = "http://" + SITE_HOSTNAME + SITE_CONTEXT_PATH;


  /**
   * The site secure base url, including the context (if any),
   * without a slash at the end.
   */
  String SITE_BASE_URL_SECURE = "https://" + SITE_HOSTNAME + SITE_CONTEXT_PATH;

  /**
   * The regular expressions allowed for blog names.
   */
  String NAME_REGEXP = Config.get("blog.name.regexp");

  /**
   * The default input length for string attributes.
   */
  int ATTRIBUTE_STRING_INPUT_LENGTH = 15;

  /**
   * The maximum length allowed for medium string attributes.
   */
  int ATTRIBUTE_STRING_LENGTH_MEDIUM = 64;

  /**
   * The number of blogs to show for the "last public blogs".
   */
  int BLOG_LAST_PUBLIC_NUM = 10;

  /**
   * The number of articles to display by default.
   */
  int ARTICLE_DISPLAY_NUM = Config.getInt("article.display.num");

  /**
   * The host of the LDAP server.
   */
  String LDAP_HOST = Config.get("ldap.host");

  /**
   * The port of the LDAP server.
   */
  int LDAP_PORT = Config.getInt("ldap.port");

  /**
   * The version of the LDAP server.
   */
  int LDAP_VERSION = Config.getInt("ldap.version");

  /**
   * The username used to connect to the LDAP server.
   */
  String LDAP_USERNAME = Config.get("ldap.username");

  /**
   * The password used to connect to the LDAP server.
   */
  String LDAP_PASSWORD = Config.get("ldap.password");

  /**
   * The organizations used to search the users.
   */
  String[] LDAP_ORGANIZATIONS = Config.getStringArray("ldap.organizations");

  /**
   * The file max file size, importer kb.
   */
  int FILE_MAX_FILE_SIZE = Config.getInt("file.maxFileSize");

  /**
   * The file size importer kb for which the servlet should stop parsing the request
   * and launch a SecurityException. Due to smartupload design, this cannot be
   * the same as maxFileSize
   */
  int FILE_STOP_PARSING_SIZE = Config.getInt("file.stopParsingSize");

  /**
   * The path where the application can store temporary files.
   */
  String SYSTEM_TEMP_PATH = Config.get("system.temp.path");

  /**
   * The path where the application stores the documents.
   */
  String SYSTEM_DOCUMENT_PATH = Config.get("system.document.path");

  /**
   * The maximum number of documents allowed per article.
   */
  int ARTICLE_DOCUMENT_MAX = Config.getInt("article.document.max");

  /**
   * The number of articles to show for the "last public articles".
   */
  int ARTICLE_LAST_PUBLIC_NUM = 10;

  /**
   * The mail account name used to send general emails.
   */
  String MAIL_INFO_NAME = Config.get("mail.account.info.name");

  /**
   * The mail account email used to send general emails.
   */
  String MAIL_INFO_EMAIL = Config.get("mail.account.info.email");

  /**
   * The mail account email used for test cases.
   */
  String MAIL_TEST_EMAIL = Config.get("mail.account.test.email");
}