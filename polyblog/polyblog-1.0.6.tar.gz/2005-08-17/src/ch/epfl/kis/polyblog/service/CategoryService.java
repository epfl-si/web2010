/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package ch.epfl.kis.polyblog.service;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.security.*;
import com.baneo.core.persistance.*;
import com.baneo.core.service.*;
import org.apache.commons.logging.*;

import java.util.*;

/**
 * CategoryService lets you insert, update, delete and find categories.
 *
 * @author Laurent Boatto
 * @version $Id$
 * @see ch.epfl.kis.polyblog.model.Category
 */

public class CategoryService extends BusinessObjectManager
{
  /**
   * The log.
   */
  private static final Log _log = LogFactory.getLog(CategoryService.class);

  private static final IPersistanceManager _persistanceManager = PersistanceManagerFactory.getIPersistanceManager();
  private static final CategoryService _instance = new CategoryService();

  protected IPersistanceManager getIPersistanceManager()
  {
    return _persistanceManager;
  }

  protected Class getManagedClass()
  {
    return Category.class;
  }

  /**
   * Private constructor, use instance() instead.
   */
  private CategoryService()
  {
  }

  /**
   * Returns the instance of the service (singleton).
   *
   * @return the instance of the service (singleton).
   */
  public static CategoryService instance()
  {
    return _instance;
  }

  /**
   * Insert the given category into the system.
   *
   * @param category the category to insert.
   * @throws PersistanceException on persistance layer error.
   */
  public void insert(Category category) throws PersistanceException
  {
    SecurityService.checkInsertCategory(category.getBlog());
    _persistanceManager.insert(category);
  }

  /**
   * Update the given category on the system.
   *
   * @param category the category to update.
   * @throws PersistanceException on persistance layer error.
   */
  public void update(Category category) throws PersistanceException
  {
    SecurityService.checkDeleteOrUpdateCategory(category.getBlog());
    _persistanceManager.update(category);
  }

  /**
   * Delete the given category from the system.
   *
   * @param category the category to delete.
   * @throws PersistanceException on persistance layer error.
   */
  public void delete(Category category) throws PersistanceException
  {
    SecurityService.checkDeleteOrUpdateCategory(category.getBlog());
    _persistanceManager.delete(category);
  }

  /**
   * Returns the category having the given id or null if it doesn't exist.
   *
   * @param id the category id.
   * @return the category having the given id or null if it doesn't exist.
   * @throws PersistanceException on persistance layer error.
   */
  public Category get(int id) throws PersistanceException
  {
    return (Category) _persistanceManager.get(Category.class, id);
  }

  /**
   * Returns the category having the given id or null if it doesn't exist.
   *
   * @param id the category id.
   * @return the category having the given id or null if it doesn't exist.
   * @throws PersistanceException on persistance layer error.
   */
  public Category get(String id) throws PersistanceException
  {
    return get(Integer.parseInt(id));
  }

  /**
   * Returns the category having the given label and blogId, if any.
   *
   * @param label  the category label.
   * @param blogId the blogId.
   * @return the category having the given label and blogId, if any.
   * @throws PersistanceException on persistance layer error.
   */
  public Category findByLabel(String label, int blogId) throws PersistanceException
  {
    String[] attributesNames = {"label", "blogId"};
    Object[] attributesValues = {label, new Integer(blogId)};

    return (Category) _persistanceManager.findFirstByAttributes(Category.class, attributesNames, attributesValues);
  }

  /**
   * Returns the categories belonging to the given Blog id.
   *
   * @param blogId the Blog id.
   * @return the categories belonging to the given Blog id.
   * @throws PersistanceException on persistance layer error.
   */
  public Collection<Category> findByBlogId(int blogId) throws PersistanceException
  {
    return _persistanceManager.findByAttribute(Category.class, "blogId", new Integer(blogId), "label ASC", 0, 1000);
  }

  /**
   * Returns true if SubscriptionService category belonging to the given blogId and having the
   * given label exists, false otherwise.
   *
   * @param blogId the category blog id.
   * @param label  the category label.
   * @return true if SubscriptionService category belonging to the given blogId and having the
   *         given label exists, false otherwise.
   * @throws PersistanceException
   */
  public boolean exists(int blogId, String label) throws PersistanceException
  {
    String[] attributesNames = {"blogId", "label"};
    Object[] values = new Object[]{new Integer(blogId), label};

    return null != _persistanceManager.findFirstByAttributes(Category.class, attributesNames, values);
  }

  /**
   * Returns the last category of the system. This is most useful importer
   * test cases, to retrieve the last inserted category.
   *
   * @return the last category of the system.
   * @throws PersistanceException on persistance layer error.
   */
  public Category findLast() throws PersistanceException
  {
    return (Category) _persistanceManager.findLast(Category.class);
  }
}