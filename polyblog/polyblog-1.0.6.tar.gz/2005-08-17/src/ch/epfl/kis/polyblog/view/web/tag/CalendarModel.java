package ch.epfl.kis.polyblog.view.web.tag;


import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.service.*;
import com.baneo.core.persistance.*;
import com.baneo.core.util.*;
import org.apache.commons.logging.*;

import java.util.*;

/**
 * Calendar model for calendar intended for use on view-weblog page.
 */
class CalendarModel
{
  private static Log _log = LogFactory.getFactory().getInstance(CalendarModel.class);

  private String _selfUrl;
  private Date _day;
  private Map _byMonthMap;

  public CalendarModel(String selfUrl, Date day, Blog blog) throws PersistanceException
  {
    _selfUrl = selfUrl;
    _day = day;
    _byMonthMap = ArticleService.instance().findByMonthMap(blog, day);
  }

  /**
   * Create URL for use on view-weblog page, ignores query-string.
   *
   * @param day   Day for URL
   * @param valid Always return a URL, never return null
   * @return URL for day, or null if no weblog entry on that day
   */
  public String computeUrl(Date day, boolean valid)
  {
    String url = null;

    try
    {
      if (day == null)
      {
        url = _selfUrl;
      }
      else
      {
        String isoDate = DateUtil.formatIsoDate(day);
        String dateString = null;

        if (_byMonthMap.get(isoDate) != null)
        {
          dateString = isoDate;
        }

        if (dateString != null)
        {
          // append 8 char date string on end of selfurl
          url = _selfUrl + "/" + dateString;
        }
        else if (valid)
        {
          // Make the date yyyy-MM-dd and append it to URL
          java.text.SimpleDateFormat format8chars =
              new java.text.SimpleDateFormat("yyyy-MM-dd");
          dateString = format8chars.format(day);
          url = _selfUrl + "/" + dateString;
        }
      }
    }
    catch (Exception e)
    {
      _log.error(e.getMessage(), e);
      throw new RuntimeException(e.getMessage(), e);
    }
    return url;
  }

  public String computeNextMonthUrl()
  {
    // Create yyyy-MM-dd dates for next month, prev month and today
    Calendar nextCal = Calendar.getInstance();
    nextCal.setTime(_day);
    nextCal.add(Calendar.MONTH, 1);
    nextCal.set(Calendar.DATE, nextCal.getActualMaximum(Calendar.DATE));
    String nextMonth = computeUrl(nextCal.getTime(), true);
    return nextMonth;
  }

  public String computePrevMonthUrl()
  {
    Calendar prevCal = Calendar.getInstance();
    prevCal.setTime(_day);
    prevCal.add(Calendar.MONTH, -1);
    prevCal.set(Calendar.DATE, prevCal.getActualMaximum(Calendar.DATE));
    String prevMonth = computeUrl(prevCal.getTime(), true);
    return prevMonth;
  }

  public String computeTodayMonthUrl()
  {
    return computeUrl(null, true);
  }
}