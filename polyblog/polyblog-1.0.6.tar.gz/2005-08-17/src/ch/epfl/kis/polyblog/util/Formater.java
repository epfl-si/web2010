/*
 * $Id$
 *
 * Copyright 2005 EPFL. All rights reserved.
 */

package ch.epfl.kis.polyblog.util;

import ch.epfl.kis.polyblog.model.*;
import com.baneo.core.system.*;
import com.baneo.core.util.*;

import java.text.*;
import java.util.*;
import java.util.regex.*;

/**
 * Formater contains the method used to format the different data of the
 * application.
 *
 * @author Laurent Boatto
 */
public class Formater
{
  private static final Pattern ARTICLE_CONTENT_PATTERN = Pattern.compile("[^=>'\"](?i)(((http://)|(https://))[^\\s]*(?:\\b))");

  /**
   * Private constructor, use only static methods.
   */
  private Formater()
  {
  }

  /**
   * Returns the name of a personal blog, given a user, for the EPFL. The name
   * of the blog is the username part of the email, e.g. "bob.sinclar".
   *
   * @param user the user.
   * @return the name of a personal blog, given a user, for the EPFL.
   */
  public static String getEpflPersonalBlogName(User user)
  {
    if (user == null || user.getEmail() == null)
    {
      return null;
    }

    return user.getEmail().substring(0, user.getEmail().indexOf('@'));
  }

  /**
   * Returns the formatted publication date for the given article, using the
   * short format (e.g. "12:44").
   *
   * @param article the article for which you want to format the publication date.
   * @param locale  the locale used to determine the format.
   * @return the formatted publication date for the given article, using the
   *         short format (e.g. "12:44").
   */
  public static String formatArticlePublicationDateShort(Article article, Locale locale)
  {
    locale = ApplicationResources.findBestRegisteredLocale(locale);
    String pattern = Message.get("article.publicationDate.format.short", locale);

    SimpleDateFormat format = new SimpleDateFormat(pattern, locale);
    return format.format(article.getPublicationDate());
  }

  /**
   * Returns the formatted publication date for the given comment, using the
   * long format (e.g. "le jeudi 12 f�vrier � 10:50").
   *
   * @param comment the comment for which you want to format the publication date.
   * @param locale  the locale used to determine the format.
   * @return the formatted publication date for the given comment, using the
   *         long format (e.g. "le jeudi 12 f�vrier � 10:50").
   */
  public static String formatCommentPublicationDateLong(Comment comment, Locale locale)
  {
    locale = ApplicationResources.findBestRegisteredLocale(locale);
    String pattern = Message.get("comment.publicationDate.format.long", locale);

    SimpleDateFormat format = new SimpleDateFormat(pattern, locale);
    return format.format(comment.getPublicationDate());
  }

  /**
   * Returns the formatted publication date for the given article, using the
   * long format (e.g. "le jeudi 12 f�vrier � 10:50").
   *
   * @param article the article for which you want to format the publication date.
   * @param locale  the locale used to determine the format.
   * @return the formatted publication date for the given article, using the
   *         long format (e.g. "le jeudi 12 f�vrier � 10:50").
   */
  public static String formatArticlePublicationDateLong(Article article, Locale locale)
  {
    locale = ApplicationResources.findBestRegisteredLocale(locale);
    String pattern = Message.get("article.publicationDate.format.long", locale);

    SimpleDateFormat format = new SimpleDateFormat(pattern, locale);
    return format.format(article.getPublicationDate());
  }

  /**
   * Returns the formatted publication date for the given article, using the
   * list format (e.g. "le jeudi 12 f�vrier � 10:50").
   *
   * @param article the article for which you want to format the publication date.
   * @param locale  the locale used to determine the format.
   * @return the formatted publication date for the given article, using the
   *         list format (e.g. "le jeudi 12 f�vrier � 10:50").
   */
  public static String formatArticlePublicationDateList(Article article, Locale locale)
  {
    locale = ApplicationResources.findBestRegisteredLocale(locale);
    String pattern = Message.get("article.publicationDate.format.list", locale);

    SimpleDateFormat format = new SimpleDateFormat(pattern, locale);
    return format.format(article.getPublicationDate());
  }

  /**
   * Formats the given blog date.
   *
   * @param date   the date to format.
   * @param locale the locale to use for the format.
   * @return the given blog date formatted.
   */
  public static String formatBlogDate(Date date, Locale locale)
  {
    locale = ApplicationResources.findBestRegisteredLocale(locale);
    String pattern = Message.get("blog.date.format", locale);

    SimpleDateFormat format = new SimpleDateFormat(pattern, locale);
    return format.format(date);
  }

  /**
   * Formats the given article content.
   *
   * @param article the article to format.
   * @return the formatted article content.
   */
  public static String formatArticleContent(Article article)
  {
    String escaped = escapeUrls(article.getContent());
    return StringUtil.newLineToBr(escaped);
  }

  /**
   * Formats the given comment content.
   *
   * @param comment the comment to format.
   * @return the formatted comment content.
   */
  public static String formatCommentContent(Comment comment)
  {
    String escaped = escapeUrls(comment.getContent());
    return StringUtil.newLineToBr(escaped);
  }

  /**
   * Escapes the urls in the given string.
   *
   * @param string
   * @return
   */
  /**
   * todo put this in StringUtil
   */
  private static String escapeUrls(String string)
  {
    Matcher matcher = ARTICLE_CONTENT_PATTERN.matcher(string);

    StringBuffer result = new StringBuffer();

    while (matcher.find())
    {
      String key = matcher.group();

      char first = key.charAt(0);

      // FIXME ugly hack here, cannot get the *"�*"&% regexp to work
      if (first != 'h')
      {
        key = key.substring(1);
        matcher.appendReplacement(result, first + "<a href=\"" + key + "\">" + key + "</a>");
      }
      else
      {
        matcher.appendReplacement(result, "<a href=\"" + key + "\">" + key + "</a>");
      }
    }

    matcher.appendTail(result);
    return result.toString();
  }
}
