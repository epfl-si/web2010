package ch.epfl.kis.polyblog.view.web.action.category;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.security.*;
import ch.epfl.kis.polyblog.service.*;
import ch.epfl.kis.polyblog.validator.*;
import com.baneo.core.util.*;
import com.baneo.core.validator.*;
import com.baneo.core.view.web.action.*;
import org.apache.struts.action.*;

import javax.servlet.http.*;
import java.util.*;

/**
 * CategoryInsertAction.
 *
 * @author Laurent Boatto
 */
public class CategoryInsertAction extends ObjectInsertAction
{
  /**
   * The url of the CategoryInsertAction (without the context path).
   */
  public static final String PARAMETER_BLOG_ID = "blogId";


  private static final CategoryService _categoryService = CategoryService.instance();

  public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    String blogId = request.getParameter(PARAMETER_BLOG_ID);
    Blog blog = BlogService.instance().get(Integer.parseInt(blogId));
    request.setAttribute("blog", blog);

    return super.execute(mapping, form, request, response);
  }

  protected Validator getValidator(HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    String attributes[] = _categoryService.getManagedObjectAttributesNames();
    Map values = HttpUtil.requestToMap(request, attributes);
    Category category = new Category();
    // it's important to set the blogId for the validator
    category.setBlogId(Integer.parseInt(request.getParameter(PARAMETER_BLOG_ID)));
    return new CategoryValidator(category, values, Validator.MODE_INSERT, request.getLocale());
  }

  protected void onInit(HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    Map values = new HashMap();
    Blog blog = (Blog) request.getAttribute("blog");
    values.put(PARAMETER_BLOG_ID, String.valueOf(blog.getId()));
    SecurityService.checkInsertCategory(blog);
    request.setAttribute(ATTRIBUTE_VALUES, values);
    request.setAttribute(ATTRIBUTE_ERRORS, new HashMap());
  }

  protected void insert(Object object, Validator validator, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    _categoryService.insert((Category) object);
  }

  protected ActionForward getSuccessActionForward(ActionMapping mapping, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    String url = request.getContextPath() + "/private/category/list.do?blogId=" +  request.getParameter(PARAMETER_BLOG_ID) + "&confirmation=common.category.insert.success" ;
    response.sendRedirect(url);
    return null;
  }
}