package ch.epfl.kis.polyblog.ws;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.security.*;
import ch.epfl.kis.polyblog.service.*;
import ch.epfl.kis.polyblog.validator.*;
import com.baneo.core.persistance.*;
import com.baneo.core.security.role.*;
import com.baneo.core.validator.*;
import org.apache.commons.logging.*;

import java.util.*;

/**
 * XML-RPC API for accessing the polyblog system. This API extends the Blogger
 * and MetaWebBlog APIs which are also supported. When calling the API, all
 * the methods must be prefixed by "polyblog.", e.g. "polyblog.getCategory".
 *
 * @author Laurent Boatto
 */
public class PolyblogXmlRpcApi extends BaseXmlRpcApi
{
  private static final BlogService _blogService = BlogService.instance();
  private static final CategoryService _categoryService = CategoryService.instance();
  private static final IObjectRoleManager _objectRoleManager = ObjectRoleManagerFactory.getIObjectRoleManager();
  private static final BlogRoleService _blogRoleService = BlogRoleService.instance();

  private static final Log _log = LogFactory.getLog(PolyblogXmlRpcApi.class);

  /**
   * Returns the category (as an Hashtable) having the given id.
   * <p/>
   * <pre>
   * The category Hashtable format is :
   * <p/>
   * "id" => the category id (Integer)
   * "blogId" => the category blog id (Integer)
   * "label" => the category label (String)
   * "absoluteUrl" => the category absolute url (String)
   * </pre>
   *
   * @param username   the username of the user making the call.
   * @param password   the corresponding password.
   * @param categoryId the category id.
   * @return the category (as an Hashtable) having the given id.
   * @throws PersistanceException on persistance layer error.
   */
  public Hashtable getCategory(String username, String password, int categoryId) throws PersistanceException
  {
    Category category = _categoryService.get(categoryId);
    return categoryToHashtable(category);
  }

  /**
   * Returns the category (as an Hashtable) having the given label and blog id.
   * <p/>
   * <pre>
   * The category Hashtable format is :
   * <p/>
   * "id" => the category id (Integer)
   * "blogId" => the category blog id (Integer)
   * "label" => the category label (String)
   * "absoluteUrl" => the category absolute url (String)
   * </pre>
   *
   * @param username      the username of the user making the call.
   * @param password      the corresponding password.
   * @param categoryLabel the category label.
   * @param blogId        the blog id.
   * @return the category (as an Hashtable) having the given label and blog id.
   * @throws PersistanceException on persistance layer error.
   */
  public Hashtable findCategoryByLabel(String username, String password, String categoryLabel, int blogId) throws PersistanceException
  {
    Category category = _categoryService.findByLabel(categoryLabel, blogId);
    return categoryToHashtable(category);
  }

  /**
   * Creates a new category with the given label.
   *
   * @param username      the username of the user making the call.
   * @param password      the corresponding password.
   * @param categoryLabel the category label.
   * @param blogId        the category blog id.
   * @return the id of the created category.
   * @throws PersistanceException on persistance layer error.
   */
  public int newCategory(String username, String password, String categoryLabel, int blogId) throws PersistanceException
  {
    authenticate(username, password);
    Category category = new Category();
    category.setBlogId(blogId);
    Hashtable data = new Hashtable();
    data.put("label", categoryLabel);
    validateCategory(category, data, Validator.MODE_INSERT);
    _categoryService.insert(category);
    return category.getId();
  }

  /**
   * Changes the given category label.
   *
   * @param username   the username of the user making the call.
   * @param password   the corresponding password.
   * @param categoryId the category id.
   * @param newLabel   the category new label.
   * @return true if there is no error (XML-RPC requirement).
   * @throws PersistanceException on persistance layer error.
   */
  public boolean editCategory(String username, String password, int categoryId, String newLabel) throws PersistanceException
  {
    authenticate(username, password);
    Category category = _categoryService.get(categoryId);
    Hashtable data = new Hashtable();
    data.put("label", newLabel);
    validateCategory(category, data, Validator.MODE_UPDATE);
    _categoryService.update(category);
    return true;
  }

  /**
   * Deletes the given category.
   *
   * @param username   the username of the user making the call.
   * @param password   the corresponding password.
   * @param categoryId the category id.
   * @return true if there is no error (XML-RPC requirement).
   * @throws PersistanceException on persistance layer error.
   */
  public boolean deleteCategory(String username, String password, int categoryId) throws PersistanceException
  {
    authenticate(username, password);
    Category category = _categoryService.get(categoryId);
    _categoryService.delete(category);
    return true;
  }

  /**
   * Returns the blog (as an Hashtable) having the given id.
   * <p/>
   * <pre>
   * The blog Hashtable format is :
   * <p/>
   * "id" => the blog id (Integer)
   * "name" => the blog name (String)
   * "label" => the blog label (String)
   * "description" => the blog description (String)
   * "isPublic" => true if the blog is public (Boolean)
   * "type" => the blog type (1 = PERSONAL, 2 = GROUP) (Integer)
   * "absoluteUrl" => the blog absolute url (String)
   * </pre>
   *
   * @param username the username of the user making the call.
   * @param password the corresponding password.
   * @param blogId   the blog id.
   * @return the blog (as a Hashtable) having the given id.
   * @throws PersistanceException on persistance layer error.
   */
  public Hashtable getBlog(String username, String password, int blogId) throws PersistanceException
  {
    authenticate(username, password);
    Blog blog = _blogService.get(blogId);
    SecurityService.checkReadAccess(blog);
    return blogToHashtable(blog);
  }

  /**
   * Returns the blog (as an Hashtable) having the given name.
   * <p/>
   * <p/>
   * <pre>
   * The blog Hashtable format is :
   * <p/>
   * "id" => the blog id (Integer)
   * "name" => the blog name (String)
   * "label" => the blog label (String)
   * "description" => the blog description (String)
   * "isPublic" => true if the blog is public (Boolean)
   * "type" => the blog type (1 = PERSONAL, 2 = GROUP) (Integer)
   * "absoluteUrl" => the blog absolute url (String)
   * </pre>
   *
   * @param username the username of the user making the call.
   * @param password the corresponding password.
   * @param blogName the blog name.
   * @return the blog (as an Hashtable) having the given name.
   * @throws PersistanceException on persistance layer error.
   */
  public Hashtable findBlogByName(String username, String password, String blogName) throws PersistanceException
  {
    authenticate(username, password);
    Blog blog = _blogService.findByName(blogName);
    SecurityService.checkReadAccess(blog);
    return blogToHashtable(blog);
  }

  /**
   * Creates a new blog with the given Hashtable data.
   * <p/>
   * <pre>
   * The Hashtable must have the following format :
   * <p/>
   * "name" => the blog name (String)
   * "label" => the blog label (String)
   * "description" => the blog description (String)
   * "isPublic" => true if the blog is public (Boolean)
   * "type" => the blog type (1 = PERSONAL, 2 = GROUP) (Integer)
   * </pre>
   *
   * @param username the username of the user making the call.
   * @param password the corresponding password.
   * @param data     the blog data.
   * @return the new blog id.
   * @throws PersistanceException on persistance layer error.
   * @throws ValidatorException   if the blog data is not valid.
   */
  public int newBlog(String username, String password, Hashtable data) throws PersistanceException
  {
    authenticate(username, password);
    Blog blog = new Blog();
    validateBlog(blog, data, Validator.MODE_INSERT);
    _blogService.insert(blog);
    return blog.getId();
  }

  /**
   * Edits the given blog with the given Hashtable data.
   * <p/>
   * <pre>
   * The Hashtable must have the following format :
   * <p/>
   * "name" => the blog name (String)
   * "label" => the blog label (String)
   * "description" => the blog description (String)
   * "isPublic" => true if the blog is public (Boolean)
   * "type" => the blog type (1 = PERSONAL, 2 = GROUP) (Integer)
   * </pre>
   *
   * @param username the username of the user making the call.
   * @param password the corresponding password.
   * @param blogId   the blog id.
   * @param data     the blog data.
   * @return true if there is no error (XML-RPC requirement).
   * @throws PersistanceException on persistance layer error.
   */
  public boolean editBlog(String username, String password, int blogId, Hashtable data) throws PersistanceException
  {
    authenticate(username, password);
    Blog blog = _blogService.get(blogId);
    validateBlog(blog, data, Validator.MODE_UPDATE);
    _blogService.update(blog);
    return true;
  }

  /**
   * Deletes the given blog.
   *
   * @param username the username of the user making the call.
   * @param password the corresponding password.
   * @param blogId   the blog id.
   * @return true if there is no error (XML-RPC requirement).
   * @throws PersistanceException on persistance layer error.
   */
  public boolean deleteBlog(String username, String password, int blogId) throws PersistanceException
  {
    authenticate(username, password);
    Blog blog = _blogService.get(blogId);
    _blogService.delete(blog);
    return true;
  }

  /**
   * Adds the given role to the given user for the given blog.
   * <p/>
   * The role can be :
   * <ul>
   * <li>"reader" : the user can just read the blog (for private blogs)
   * <li>"blogger" : the user can post articles but can not manage the blog
   * <li>"administrator" : the user can manage the blog
   * </ul>
   *
   * @param username      the username of the user making the call.
   * @param password      the corresponding password.
   * @param usernameToAdd the username to add the role to.
   * @param role          the role.
   * @param blogId        the blog id.
   * @return true if there is no error (XML-RPC requirement).
   * @throws PersistanceException on persistance layer error.
   */
  public boolean addRole(String username, String password, String role, String usernameToAdd, int blogId) throws PersistanceException
  {
    authenticate(username, password);
    Blog blog = _blogService.get(blogId);
    SecurityService.checkManageBlogRoles(blog);
    User user = _userService.get(usernameToAdd);
    _blogRoleService.addRole(role, user, blog);
    return true;
  }

  /**
   * Removes the given role to the given user for the given blog.
   * <p/>
   * The role can be :
   * <ul>
   * <li>"reader" : the user can just read the blog (for private blogs)
   * <li>"blogger" : the user can post articles but can not manage the blog
   * <li>"administrator" : the user can manage the blog
   * </ul>
   *
   * @param username         the username of the user making the call.
   * @param password         the corresponding password.
   * @param usernameToRemove the username having the role.
   * @param role             the role.
   * @param blogId           the blog id.
   * @return true if there is no error (XML-RPC requirement).
   */
  public boolean removeRole(String username, String password, String role, String usernameToRemove, int blogId) throws PersistanceException
  {
    authenticate(username, password);
    Blog blog = _blogService.get(blogId);
    SecurityService.checkManageBlogRoles(blog);
    User user = _userService.get(usernameToRemove);

    Collection objectRoles = _objectRoleManager.findByPrincipalAndBusinessObject(user, blog);

    for (Iterator iterator = objectRoles.iterator(); iterator.hasNext();)
    {
      ObjectRole objectRole = (ObjectRole) iterator.next();

      if (objectRole.getRole().equals(role))
      {
        _blogRoleService.delete(objectRole);
        return true;
      }
    }

    return false;
  }

  /**
   * Transforms the given category into an Hashtable suitable for XML-RPC.
   *
   * @param category the category to transform.
   * @return the category as an Hashtable suitable for XML-RPC.
   */
  private Hashtable categoryToHashtable(Category category)
  {
    Hashtable result = new Hashtable();
    result.put("id", new Integer(category.getId()));
    result.put("blogId", new Integer(category.getBlogId()));
    result.put("label", category.getLabel());
    result.put("absoluteUrl", category.getAbsoluteUrl());
    return result;
  }

  /**
   * Transforms the given blog into an Hashtable suitable for XML-RPC.
   *
   * @param blog the blog to transform.
   * @return the given blog into an Hashtable suitable for XML-RPC.
   */
  private Hashtable blogToHashtable(Blog blog)
  {
    Hashtable result = new Hashtable();
    result.put("id", new Integer(blog.getId()));
    result.put("description", blog.getDescription());
    result.put("isPublic", new Boolean(blog.getIsPublic()));
    result.put("label", blog.getLabel());
    result.put("name", blog.getName());
    result.put("type", new Integer(blog.getType()));
    result.put("absoluteUrl", blog.getAbsoluteUrl());
    return result;
  }

  /**
   * Validates the given blog with the given data.
   *
   * @param blog the blog to validate.
   * @param data the data to validate.
   * @param mode the validation mode.
   */
  private void validateBlog(Blog blog, Hashtable data, int mode)
  {
    Validator validator = new BlogValidator(blog, data, mode, null);
    validator.validate();

    if (validator.hasErrors())
    {
      throw new RuntimeException("Blog is not valid : " + validator.getErrors().values());
    }
  }

  /**
   * Validates the given category with the given data.
   *
   * @param category the category to validate.
   * @param data     the data to validate.
   * @param mode     the validation mode.
   */
  private void validateCategory(Category category, Hashtable data, int mode)
  {
    Validator validator = new CategoryValidator(category, data, mode, null);
    validator.validate();

    if (validator.hasErrors())
    {
      throw new RuntimeException("Category is not valid : " + validator.getErrors().values());
    }
  }
}