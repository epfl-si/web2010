package ch.epfl.kis.polyblog.view.web.servlet.blog;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.security.*;
import ch.epfl.kis.polyblog.service.*;
import com.baneo.core.persistance.*;
import org.apache.commons.logging.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

/**
 * BlogExportServlet.
 *
 * @author Laurent Boatto
 */
public class BlogExportServlet extends HttpServlet
{
  /**
   * The log.
   */
  private static final Log _log = LogFactory.getLog(BlogExportServlet.class);

  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    try
    {
      String blogName = request.getParameter("blog");
      String categoryId = request.getParameter("category");

      Blog blog = BlogService.instance().findByName(blogName);

      if (!SecurityService.hasReadAccess(blog))
      {
        response.getWriter().print("Private blogs do not have rss feeds.");
        return;
      }

      String content = null;

      // blog export
      if (categoryId == null)
      {
        content = TemplateService.generateRss2Feed(blog);
      }
      // category export
      else
      {
        Category category = CategoryService.instance().get(categoryId);
        content = TemplateService.generateRss2Feed(category);
      }

      response.setContentType("text/xml");
      response.getWriter().print(content);
    }
    catch (PersistanceException e)
    {
      _log.error(e.getMessage(), e);
      throw new ServletException(e.getMessage(), e);
    }
    catch (TemplateException e)
    {
      _log.error(e.getMessage(), e);
      throw new ServletException(e.getMessage(), e);
    }
  }
}