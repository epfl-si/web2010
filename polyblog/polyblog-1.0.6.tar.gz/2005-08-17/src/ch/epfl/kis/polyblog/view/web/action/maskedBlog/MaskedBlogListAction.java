package ch.epfl.kis.polyblog.view.web.action.maskedBlog;

import com.baneo.core.view.web.action.*;

import javax.servlet.http.*;
import java.util.*;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.security.*;
import ch.epfl.kis.polyblog.service.*;

/**
 * MaskedBlogListAction
 *
 * @author Laurent Boatto
 */
public class MaskedBlogListAction extends ObjectListAction
{
  private static final MaskedBlogService _maskedBlogService = MaskedBlogService.instance();

  protected String getDefaultOrder()
  {
    return "blogLabel";
  }

  protected Collection find(HttpServletRequest request, HttpServletResponse response, String orderBy, int startIndex, int maxResults) throws Exception
  {
    return (Collection) request.getAttribute(ATTRIBUTE_RESULTS);
  }

  protected int count(HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    User user = SecurityService.getUser();
    Collection<MaskedBlog> maskeds =  _maskedBlogService.findByUser(user);
    request.setAttribute(ATTRIBUTE_RESULTS, maskeds);
    return maskeds.size();
  }
}