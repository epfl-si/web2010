/*
 * $Id$
 *
 * Copyright 2005 EPFL. All rights reserved.
 */

package ch.epfl.kis.polyblog.security;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.util.*;
import com.baneo.core.model.*;
import com.baneo.core.persistance.*;
import com.baneo.core.security.*;
import com.baneo.core.security.role.*;
import com.baneo.core.util.*;

import java.util.*;

/**
 * SecurityService.
 *
 * @author Laurent Boatto
 */
public class SecurityService
{
  /**
   * The values of the roles.
   */
  private static final Map ROLE_WEIGHT = new HashMap();

  /**
   * The role used for a reader (can just read a non-public blog).
   */
  public static final String ROLE_READER = "reader";

  /**
   * The role used for a blogger (can add and edit his own articles, create
   * or updates categories).
   */
  public static final String ROLE_BLOGGER = "blogger";

  /**
   * The role used for the owner of an object.
   */

  public static final String ROLE_OWNER = IObjectRoleManager.ROLE_OWNER;

  /**
   * The role used for an administrator (can do everything).
   */
  public static final String ROLE_ADMINISTRATOR = IObjectRoleManager.ROLE_ADMINISTRATOR;

  static
  {
    ROLE_WEIGHT.put(ROLE_READER, new Integer(1));
    ROLE_WEIGHT.put(ROLE_BLOGGER, new Integer(2));
    ROLE_WEIGHT.put(ROLE_OWNER, new Integer(3));
    ROLE_WEIGHT.put(ROLE_ADMINISTRATOR, new Integer(4));
  }

  private static final IObjectRoleManager _objectRoleManager = ObjectRoleManagerFactory.getIObjectRoleManager();

  /**
   * The roles required to delete a blog.
   */
  private static final String[] ROLES_BLOG_ADMIN = new String[]{ROLE_ADMINISTRATOR, ROLE_OWNER};
  private static final String[] ROLES_BLOG_VIEW = new String[]{ROLE_OWNER, ROLE_ADMINISTRATOR, ROLE_BLOGGER, ROLE_READER};
  private static final String[] ROLES_BLOG_MANAGE = new String[]{ROLE_OWNER, ROLE_ADMINISTRATOR, ROLE_BLOGGER};
  private static final String[] ROLES_BLOG_ARTICLE_INSERT = new String[]{ROLE_ADMINISTRATOR, ROLE_BLOGGER, ROLE_OWNER};
  private static final String[] ROLES_BLOG_ARTICLE_UPDATE = new String[]{ROLE_ADMINISTRATOR, ROLE_OWNER};

  /**
   * Returns the current ISecurityContext or throws a SecurityException if it's
   * null.
   *
   * @return the current ISecurityContext.
   */
  public static ISecurityContext getISecurityContext()
  {
    ISecurityContext context = SecurityContextManager.getISecurityContext();

    if (context == null)
    {
      throw new SecurityException("No security context");
    }

    return context;
  }

  /**
   * Returns the current Principal or throws a SecurityException if there is no
   * security context.
   *
   * @return the current Principal.
   */
  public static User getUser()
  {
    return (User)getISecurityContext().getPrincipal();
  }

  /**
   * Checks that the current logged user has the right view the menu of the
   * given blog.
   *
   * @param blog the blog.
   * @throws PersistanceException on persistance layer error.
   */
  public static void checkViewMenuBlog(Blog blog) throws PersistanceException
  {
    checkRoles(ROLES_BLOG_VIEW, blog);
  }

  /**
   * Checks if the current logged user has the right to subscribe to the given
   * given blog.
   *
   * @param blog the blog.
   * @throws PersistanceException on persistance layer error.
   */
  public static void checkSubscription(Blog blog) throws PersistanceException
  {
    if (blog.getIsPublic())
    {
      return;
    }

    checkReadAccess(blog);
  }


  /**
   * Checks if the current Principal can create the given blog.
   *
   * @param blog the blog.
   */
  public static void checkInsertBlog(Blog blog)
  {
    // We just check that there is a Principal, every user has the right
    // to create blogs.
    getUser();
  }

  /**
   * Checks if the current Principal can delete the given blog and throws
   * a SecurityException if it's not the case.
   *
   * @param blog the blog.
   * @throws PersistanceException on persistance layer error.
   */
  public static void checkDeleteOrUpdateBlog(Blog blog) throws PersistanceException
  {
    checkRoles(ROLES_BLOG_ADMIN, blog);
  }

  /**
   * Checks if the current Principal has the right to insert an article importer
   * the given blog.
   *
   * @param blog the blog.
   * @throws PersistanceException on persistance layer error.
   */
  public static void checkInsertArticle(Blog blog) throws PersistanceException
  {
    checkRoles(ROLES_BLOG_ARTICLE_INSERT, blog);
  }

  /**
   * Checks if the current Principal has the right to list the user of the given
   * blog.
   *
   * @param blog the blog.
   * @throws PersistanceException on persistance layer error.
   */
  public static void checkManageBlogRoles(Blog blog) throws PersistanceException
  {
    checkRoles(ROLES_BLOG_ADMIN, blog);
  }

  /**
   * Checcks if the current Principal has the right to list the articles of
   * the given blog.
   *
   * @param blog the blog.
   * @throws PersistanceException on persistance layer error.
   */
  public static void checkListArticle(Blog blog) throws PersistanceException
  {
    checkRoles(ROLES_BLOG_MANAGE, blog);
  }

  /**
   * Checks if the current Principal can list the categories of the given blog.
   *
   * @param blog the blog.
   * @throws PersistanceException on persistance layer error.
   */
  public static void checkListCategory(Blog blog) throws PersistanceException
  {
    checkRoles(ROLES_BLOG_MANAGE, blog);
  }

  /**
   * Checks if the current Principal can insert a category importer the given blog.
   *
   * @param blog the blog.
   * @throws PersistanceException on persistance layer error.
   */
  public static void checkInsertCategory(Blog blog) throws PersistanceException
  {
    checkRoles(ROLES_BLOG_MANAGE, blog);
  }

  /**
   * Checks if the current Principal can update or delete the given category and
   * throws a SecurityException if it's not the case.
   *
   * @param blog the blog.
   * @throws PersistanceException on persistance layer error.
   */
  public static void checkDeleteOrUpdateCategory(Blog blog) throws PersistanceException
  {
    checkRoles(ROLES_BLOG_MANAGE, blog);
  }

  /**
   * Checks that the current principal has the right to update or delete the
   * given article.
   *
   * @param article the article.
   * @throws PersistanceException on persistance layer error.
   */
  public static void checkDeleteOrUpdateArticle(Article article) throws PersistanceException
  {
    // A user can update or delete an article if he is the owner of the article,
    // or if he (or one of his group) is administrator or owner of the article's
    // blog.
    if (hasOwnerRole(article))
    {
      return;
    }

    checkRoles(ROLES_BLOG_ARTICLE_UPDATE, article.getBlog());
  }

  /**
   * Checks if the current principal has the right to insert a comment importer the
   * given article.
   *
   * @param article the article where the comment will be inserted.
   * @throws PersistanceException on persistance layer error.
   */
  public static void checkInsertComment(Article article) throws PersistanceException
  {
    User user = getUser();

    if (!article.getAllowComments())
    {
      throw new SecurityException("Comments are not allowed on article #" + article.getId());
    }

    Blog blog = article.getBlog();

    // the blog is public, everyone can insert comments
    if (blog.getIsPublic())
    {
      return;
    }

    if (!hasReadAccess(user, blog))
    {
      throw new SecurityException("User #" + user + " has not enough rights to insert a comment for article #" + article.getId());
    }
  }

  /**
   * Returns true if the current Principal has the owner role for the given
   * business object.
   *
   * @param businessObject the BusinessObject.
   * @return true if the current Principal has the owner role for the given
   *         business object.
   * @throws PersistanceException on persistance layer error.
   */
  public static boolean hasOwnerRole(BusinessObject businessObject) throws PersistanceException
  {
    return _objectRoleManager.hasOwnerRole(getUser(), businessObject);
  }

  /**
   * Returns true if the current Principal has the right to read the given blog.
   *
   * @param blog the blog.
   * @return true if the current Principal has the right to read the given blog.
   * @throws PersistanceException on persistance layer error.
   */
  public static boolean hasReadAccess(Blog blog) throws PersistanceException
  {
    ISecurityContext context = SecurityContextManager.getISecurityContext();

    User user = null;

    if (context != null)
    {
      user = (User) context.getPrincipal();
    }

    return hasReadAccess(user, blog);
  }

  /**
   * Checks if the given principal has one of the required roles for the
   * given BusinessObject.
   *
   * @param requiredRoles  the required roles.
   * @param businessObject the business object.
   * @throws PersistanceException on persistance layer error.
   */
  private static void checkRoles(String[] requiredRoles, BusinessObject businessObject) throws PersistanceException
  {
    if (!hasRoles(requiredRoles, businessObject))
    {
      StringBuffer message = new StringBuffer("Principal " + getUser() + " has not at least one of the required roles (");

      for (int i = 0; i < requiredRoles.length; i++)
      {
        message.append(requiredRoles[i]);

        if (i + 1 != requiredRoles.length)
        {
          message.append(", ");
        }
      }

      message.append(") for businessObject " + businessObject);

      throw new SecurityException(message.toString());
    }
  }

  /**
   * Returns true if the given user (or one of his groups) has the given
   * objectRole.
   *
   * @param objectRole the ObjectRole to check.
   * @param user       the user.
   * @return true if the given user (or one of his groups) has the given
   *         objectRole.
   */
  public static boolean belongsToUser(ObjectRole objectRole, User user)
  {
    // we check the user first
    if (objectRole.getPrincipalName().equals(user.getName()) &&
        objectRole.getPrincipalClass().equals(user.getClass()))
    {
      return true;
    }

    Collection groups = user.getGroups();

    for (Iterator iterator = groups.iterator(); iterator.hasNext();)
    {
      Group group = (Group) iterator.next();

      if (objectRole.getPrincipalName().equals(group.getName()) &&
          objectRole.getPrincipalClass().equals(group.getClass()))
      {
        return true;
      }
    }

    return false;
  }

  /**
   * Checks if the current Principal has one of the required roles for the
   * given BusinessObject.
   *
   * @param requiredRoles  the required roles.
   * @param businessObject the business object.
   * @return true if the current Principal has one of the required roles for the
   *         given BusinessObject.
   * @throws PersistanceException on persistance layer error.
   */
  private static boolean hasRoles(String[] requiredRoles, BusinessObject businessObject) throws PersistanceException
  {
    String role = getRole(businessObject);

    for (int i = 0; i < requiredRoles.length; i++)
    {
      if (requiredRoles[i].equals(role))
      {
        return true;
      }
    }

    return false;
  }

  /**
   * Checks if the current user has the right to read the given blog, and if
   * it's not the case throws a SecurityException.
   *
   * @param blog the blog.
   * @throws PersistanceException on persistance layer error.
   * @throws SecurityException    if the user has not the right to read the blog.
   */
  public static void checkReadAccess(Blog blog) throws PersistanceException
  {
    if (!hasReadAccess(blog))
    {
      throw new PersistanceException("User has not the right to access blog " + blog);
    }
  }


  /**
   * Checks if the given user has the right to read the given blog, and if
   * it's not the case throws a SecurityException.
   *
   * @param user the user.
   * @param blog the blog.
   * @throws PersistanceException on persistance layer error.
   * @throws SecurityException    if the user has not the right to read the blog.
   */
  public static void checkReadAccess(User user, Blog blog) throws PersistanceException
  {
    if (!hasReadAccess(user, blog))
    {
      throw new PersistanceException("User " + user + " has not the right to read blog " + blog);
    }
  }

  /**
   * Returns true if the given user has the right to read the given blog.
   *
   * @param user the user.
   * @param blog the blog.
   * @return true if the given Principal has the right to read the given blog.
   * @throws PersistanceException on persistance layer error.
   */
  public static boolean hasReadAccess(User user, Blog blog) throws PersistanceException
  {
    if (blog.getIsPublic())
    {
      return true;
    }

    if (user == null)
    {
      return false;
    }

    // we search all the ObjectRoles of the blogs
    Collection objectRolesByBlog = _objectRoleManager.findByBusinessObject(blog);

    for (Iterator iterator = objectRolesByBlog.iterator(); iterator.hasNext();)
    {
      ObjectRole objectRole = (ObjectRole) iterator.next();

      if (belongsToUser(objectRole, user))
      {
        return true;
      }
    }

    return false;
  }

  /**
   * Returns the role that the current Principal have on the given
   * BusinessObject.
   *
   * @param bo the BusinessObject.
   * @return he role that the current Principal have on the given BusinessObject.
   * @throws PersistanceException on persistance layer error.
   */
  public static String getRole(BusinessObject bo) throws PersistanceException
  {
    ISecurityContext context = SecurityContextManager.getISecurityContext();

    if (context == null)
    {
      return null;
    }

    User user = (User) context.getPrincipal();

    String role = null;

    Collection objectRoles = _objectRoleManager.findByBusinessObject(bo);

    for (Iterator iterator = objectRoles.iterator(); iterator.hasNext();)
    {
      ObjectRole objectRole = (ObjectRole) iterator.next();

      // the role for the user itself always takes precedence over the role
      // assigned to one of it's group.
      if (objectRole.getPrincipalName().equals(user.getName()) &&
          objectRole.getPrincipalClass().equals(user.getClass()))
      {
        return objectRole.getRole();
      }

      if (belongsToUser(objectRole, user))
      {
        if (role == null)
        {
          role = objectRole.getRole();
        }
        else
        {
          // the role of a user is equals to the stronger role of it's groups
          int previousRoleValue = ((Integer) ROLE_WEIGHT.get(role)).intValue();
          int currentRoleValue = ((Integer) ROLE_WEIGHT.get(objectRole.getRole())).intValue();

          if (currentRoleValue > previousRoleValue)
          {
            role = objectRole.getRole();
          }
        }
      }
    }

    return role;
  }

  /**
   * Sets a SystemSecurityContext for the current thread.
   *
   * @see SystemSecurityContext
   */
  public static void setSystemSecurityContext()
  {
    SecurityContextManager.setSecurityContext(new SystemSecurityContext());
  }

  /**
   * Sets a valid user context (for test cases);
   *
   * @return the User used in the SecurityContext.
   */
  public static User setValidUserContext()
  {
    User user = DataGenerator.getRandomUser();
    SecurityContextManager.setSecurityContext(new TestCaseSecurityContext(user.getName(),  user.getId(), null, StringUtil.randomString(8)));
    TestCaseSecurityContext context = (TestCaseSecurityContext) SecurityContextManager.getISecurityContext();
    context.setPrincipal(user);
    return user;
  }
}