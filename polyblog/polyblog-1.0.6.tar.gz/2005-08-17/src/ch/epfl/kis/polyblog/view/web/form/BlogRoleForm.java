package ch.epfl.kis.polyblog.view.web.form;

import ch.epfl.kis.polyblog.security.*;
import com.baneo.core.form.*;
import com.baneo.core.system.*;

import javax.servlet.jsp.*;

/**
 * BlogRoleForm.
 *
 * @author Laurent Boatto
 */
public class BlogRoleForm extends Form
{
  HiddenField _id;
  HiddenField _blogId;
  Field _principalName;
  Field _provider;
  SelectField _role;

  public BlogRoleForm(PageContext context, String action, int mode)
  {
    super(context, action, mode);
  }

  protected void initForm()
  {
    setName("blogRole");
    setShowBox(false);
    setShowHelpText(false);
    setShowRequiredString(false);
    setWidth("70%");
  }

  protected void initFields()
  {
    _id = new HiddenField("id");
    _blogId = new HiddenField("blogId");

    _principalName = new TextField("principalName", Message.get("model.user.ldap.principalName.label", _locale), true, 10, 40);
    _principalName.setStyleClass(Field.STYLE_SMALL);

    /** todo let the user choose the provider  */
    _provider = new HiddenField("provider");
    _provider.setValue("ldap");


    initRoleField();
  }

  void initRoleField()
  {
    _role = new SelectField("role", Message.get("model.user.role.label", _locale), true);
    _role.setStyleClass(Field.STYLE_SMALL);

    _role.addOption(SecurityService.ROLE_BLOGGER, Message.get("model.user.role.valueLabel." + SecurityService.ROLE_BLOGGER, _locale));
    _role.addOption(SecurityService.ROLE_READER, Message.get("model.user.role.valueLabel." + SecurityService.ROLE_READER, _locale));
    _role.addOption(SecurityService.ROLE_ADMINISTRATOR, Message.get("model.user.role.valueLabel." + SecurityService.ROLE_ADMINISTRATOR, _locale));
    _role.setFirstOptionEmpty(false);
  }

  protected void addFields()
  {
    addField(_id);
    addField(_blogId);
    addField(_principalName);
    addField(_provider);
    addField(_role);
  }
}