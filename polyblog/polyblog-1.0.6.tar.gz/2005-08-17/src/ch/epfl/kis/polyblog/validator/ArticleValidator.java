/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package ch.epfl.kis.polyblog.validator;

import com.baneo.core.validator.*;

import java.util.*;

/**
 * ArticleValidator.
 *
 * @author Laurent Boatto
 * @version $Id$
 * @see com.baneo.core.validator.Validator
 */

public class ArticleValidator extends Validator
{
  /**
   * Constructs a new ArticleValidator with the given object, values, and mode.
   *
   * @param article the article to validate
   * @param values  a Map having for the key the attribute name, and for the
   *                value the attribute value.
   * @param mode    the mode for validation, can be MODE_INSERT if you are
   *                validating a new object, or MODE_UPDATE if you are validating an
   *                existing object (use static variables of this class for the mode).
   * @param locale  the locale used to format the error messages, it can be null
   *                in which case the application default ResourceBundle will be used.
   */
  public ArticleValidator(Object article, Map values, int mode, Locale locale)
  {
    super(article, values, mode, locale);
  }

  /**
   * Validates the given title.
   *
   * @param title the title to validate.
   */
  public void validateTitle(String title)
  {
    if (addErrorIfEmpty(title))
    {
      return;
    }

    saveTrimmedValue();
  }

  /**
   * Validates the given content.
   *
   * @param content the content to validate.
   */
  public void validateContent(String content)
  {
    if (addErrorIfEmpty(content))
    {
      return;
    }

    saveTrimmedValue();
  }
}
