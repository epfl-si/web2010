/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package ch.epfl.kis.polyblog.service;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.system.*;
import com.baneo.core.util.*;
import org.apache.commons.lang.*;
import org.apache.commons.logging.*;
import org.apache.velocity.*;
import org.apache.velocity.app.*;

import java.io.*;
import java.util.*;

/**
 * Generates various content using the velocity template engine.
 *
 * @author Laurent Boatto
 * @version $Id$
 */

public class TemplateService
{
  /**
   * The log.
   */
  private static final Log _log = LogFactory.getLog(TemplateService.class);
  private static final StringEscapeUtils _escapeUtils = new StringEscapeUtils();
  private static final DateUtil _dateUtil = new DateUtil();

  static
  {
    try
    {
      Velocity.setProperty("resource.loader", "class");
      Velocity.setProperty("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
      Velocity.init();
    }
    catch (Exception e)
    {
      throw new ExceptionInInitializerError(e);
    }
  }

  private TemplateService()
  {
  }

  /**
   * Generates the rss 2.0 feed for the given Blog.
   *
   * @param blog the Blog used for the rss generation.
   * @return the rss 2.0 feed for the given Blog.
   * @throws TemplateException if an error occurs while generating the template.
   */
  public static String generateRss2Feed(Blog blog) throws TemplateException
  {
    try
    {
      VelocityContext context = new VelocityContext();
      StringWriter writer = new StringWriter();

      context.put("escaper", _escapeUtils);
      context.put("dateUtil", _dateUtil);
      context.put("blog", blog);
      context.put("articles", ArticleService.instance().findLastByBlog(blog, new Date(), Constants.ARTICLE_DISPLAY_NUM));
      /** todo put the last article publication date here */
      context.put("lastBuildDate", DateUtil.formatRfc822Date(new Date()));
      Velocity.getTemplate("templates/rss-2.0.vm").merge(context, writer);
      return writer.toString();
    }
    catch (Exception e)
    {
      _log.error(e.getMessage(), e);
      throw new TemplateException(e);
    }
  }

  /**
   * Generates the rss 2.0 feed for the given Category.
   *
   * @param category the Category used for the rss generation.
   * @return the rss 2.0 feed for the given Category.
   * @throws TemplateException if an error occurs while generating the template.
   */
  public static String generateRss2Feed(Category category) throws TemplateException
  {
    try
    {
      VelocityContext context = new VelocityContext();
      StringWriter writer = new StringWriter();

      context.put("escaper", _escapeUtils);
      context.put("dateUtil", _dateUtil);
      context.put("blog", category.getBlog());
      context.put("category", category);
      context.put("articles", ArticleService.instance().findLastByCategory(category));
      /** todo put the last article publication date here */
      context.put("lastBuildDate", DateUtil.formatRfc822Date(new Date()));
      Velocity.getTemplate("templates/rss-2.0.vm").merge(context, writer);
      return writer.toString();
    }
    catch (Exception e)
    {
      _log.error(e.getMessage(), e);
      throw new TemplateException(e);
    }
  }
}