/*
 * $Id$
 *
 * Copyright 2005 EPFL. All rights reserved.
 */

package ch.epfl.kis.polyblog.view.web.action;

import org.apache.struts.action.*;

import javax.servlet.http.*;

/**
 * LogoutAction.
 *
 * @author Laurent Boatto
 */
public class LogoutAction extends Action
{
  public ActionForward execute(ActionMapping actionMapping, ActionForm actionForm, HttpServletRequest request, HttpServletResponse httpServletResponse) throws Exception
  {
    request.getSession().invalidate();

    return actionMapping.findForward("success");
  }
}