package ch.epfl.kis.polyblog.view.web.action.subscription;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.service.*;
import org.apache.struts.action.*;

import javax.servlet.http.*;

/**
 * SubscribeConfirmAction.
 *
 * @author Laurent Boatto
 */
public class UnsubscribeConfirmAction extends Action
{
  private static final SubscriptionService _subscriptionService = SubscriptionService.instance();

  public ActionForward execute(ActionMapping mapping, ActionForm actionForm, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    Subscription subscription = _subscriptionService.get(request.getParameter("id"));
    String code = request.getParameter("code");
    boolean commentsOnly = request.getParameter("commentsOnly") != null;

    if (subscription == null)
    {
      return mapping.findForward("global500");
    }

    request.setAttribute("blog", subscription.getBlog());

    if (!subscription.getCode().equals(code))
    {
      return mapping.findForward("wrongCode");
    }

    if (commentsOnly)
    {
      request.setAttribute("commentsOnly", new Boolean(true));
      _subscriptionService.confirmUnsubscribeFromComments(subscription);
    }
    else
    {
      request.setAttribute("commentsOnly", new Boolean(false));
      _subscriptionService.confirmUnsubscribe(subscription);
    }

    return mapping.findForward("success");
  }
}