package ch.epfl.kis.polyblog.listener;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.service.*;
import com.baneo.core.persistance.*;
import com.baneo.core.service.*;

import javax.mail.*;
import java.util.*;

/**
 * Listeners for the BlogManager regarding the objects directly linked
 * to it.
 *
 * @author Laurent Boatto
 */
public class LinkArticleServiceListener extends BaseBusinessObjectManagerListener
{
  private static final CommentService _commentService = CommentService.instance();
  private static final DocumentService _documentService = DocumentService.instance();

  public void postInsert(BusinessObjectManagerEvent event) throws PersistanceException
  {
    Article article = (Article) event.getSource();

    if (article.getStatusId() == Article.STATUS_PUBLISH)
    {
      EmailService.sendNewArticleNotification(article);
    }
  }

  public void preDelete(BusinessObjectManagerEvent event) throws PersistanceException
  {
    Article article = (Article) event.getSource();

    // Before deleting an article we first delete all it's comments...
    Collection<Comment> comments = _commentService.findByArticleId(article.getId());

    for(Comment comment : comments)
    {
      _commentService.delete(comment);
    }

    // ...documents...
    Collection<Document> documents = _documentService.findByArticleId(article.getId());

    for (Document document : documents)
    {
      _documentService.delete(document);
    }
  }
}