/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package ch.epfl.kis.polyblog.view.web.action.article;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.security.*;
import ch.epfl.kis.polyblog.service.*;
import ch.epfl.kis.polyblog.system.*;
import ch.epfl.kis.polyblog.validator.*;
import com.baneo.core.form.*;
import com.baneo.core.servlet.*;
import com.baneo.core.util.*;
import com.baneo.core.validator.*;
import com.baneo.core.view.web.action.*;
import org.apache.struts.action.*;

import javax.servlet.http.*;
import java.util.*;

/**
 * Action used to insert a article.
 *
 * @author Laurent Boatto
 * @version $Id$
 * @see com.baneo.core.view.web.action.ObjectInsertAction
 * @see org.apache.struts.action.Action
 */

public class ArticleInsertAction extends ObjectInsertAction
{
  private static final ArticleService _articleService = ArticleService.instance();
  private static final BlogService _blogService = BlogService.instance();

  public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
  {

    String contentType = request.getContentType();

    // If we have a multipart/form-data request, we must parse it.
    if (contentType != null && contentType.startsWith(Form.ENCTYPE_MULTIPART_FORM_DATA))
    {
      try
      {
        request = HttpUtil.getSmartUploadHttpServletRequest(getServlet().getServletConfig(), Constants.FILE_STOP_PARSING_SIZE * 1024, request, response);
      }
      // The file was way to big
      catch (SecurityException e)
      {
        return mapping.findForward("fileWayTooBig");
      }
    }

    Blog blog = _blogService.get(request.getParameter("blogId"));
    request.setAttribute("blog", blog);

    return super.execute(mapping, form, request, response);
  }

  protected void onInit(HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    Map<String,String> values = new HashMap<String, String>();
    Blog blog = (Blog) request.getAttribute("blog");
    SecurityService.checkInsertArticle(blog);
    values.put("blogId", String.valueOf(blog.getId()));
    values.put("allowComments", "true");
    values.put("inline0", "true");

    request.setAttribute(ATTRIBUTE_VALUES, values);
    request.setAttribute(ATTRIBUTE_ERRORS, new HashMap());
  }

  protected Validator getValidator(HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    Map values = HttpUtil.requestToMap(request, _articleService.getManagedObjectAttributesNames());

    // we add the inline attributes which are not directly part of an Article
    for (int i = 0; i < Constants.ARTICLE_DOCUMENT_MAX; i++)
    {
      values.put("inline" + i, request.getParameter("inline" + i));
    }

    Validator validator = new ArticleValidator(new Article(), values, Validator.MODE_INSERT, request.getLocale());

    // If we have a multipart/form-data request, we must validate the documents
    // too
    if (request instanceof SmartUploadHttpServletRequest)
    {
      DocumentService.instance().validateDocuments(request, validator);
    }

    return validator;
  }

  protected void insert(Object object, Validator validator, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    Article article = (Article) object;
    _articleService.insert(article);

    // If we have a multipart/form-data request, we move the files to the
    // photos directory, otherwise we are done.
    if (!(request instanceof SmartUploadHttpServletRequest))
    {
      return;
    }

    DocumentService.instance().moveUploadedDocuments(request, article);
  }

  protected ActionForward getSuccessActionForward(ActionMapping mapping, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    Article article = (Article) request.getAttribute(ATTRIBUTE_INSERTED_OBJECT);
    String url = request.getContextPath() + "/private/blog/manage.do?id=" + article.getBlogId() + "&confirmation=common.article.insert.success";
    response.sendRedirect(url);
    return null;
  }
}