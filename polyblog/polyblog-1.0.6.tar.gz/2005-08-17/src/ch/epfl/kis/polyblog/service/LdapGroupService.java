package ch.epfl.kis.polyblog.service;

import ch.epfl.kis.core.ldap.*;
import ch.epfl.kis.polyblog.model.*;
import com.baneo.core.persistance.*;
import com.novell.ldap.*;
import org.apache.commons.logging.*;

import java.util.*;

/**
 * LdapGroupService.
 *
 * @author Laurent Boatto
 */
public class LdapGroupService implements IUserService
{
  /**
   * todo put this in attribute
   */
  private static final String[] SEARCH_ATTRIBUTES = {"uniqueIdentifier", "uid"};
  private static final LdapConnector _connector = LdapConnectorFactory.getLdapConnector();

  /**
   * The log.
   */
  private static final Log _log = LogFactory.getLog(LdapUserService.class);

  private static final LdapGroupService _instance = new LdapGroupService();

  /**
   * Returns the instance of the LdapGroupService (singleton).
   *
   * @return the instance of the LdapGroupService (singleton).
   */
  public static final LdapGroupService instance()
  {
    return _instance;
  }

  /**
   * Returns the group having the given id.
   *
   * @param id the group id.
   * @return the group having the given id.
   * @throws PersistanceException
   */
  public User get(String id) throws PersistanceException
  {
    try
    {
      LDAPEntry entry = null;

      /** todo use the OR ldap search notation */
      for (int i = 0; i < SEARCH_ATTRIBUTES.length; i++)
      {
        entry = LdapConnectorFactory.getLdapConnector().findFirstBySearchFilter(LDAPConnection.SCOPE_SUB, "(" + SEARCH_ATTRIBUTES[i] + "=" + id + ")");

        if (entry != null)
        {
          break;
        }
      }

      if (entry == null)
      {
        return null;
      }

      return entryToGroup(entry);
    }
    catch (LDAPException e)
    {
      _log.error(e.getMessage(), e);
      throw new PersistanceException(e);
    }
  }

  public User authenticate(String username, String password) throws PersistanceException
  {
    throw new UnsupportedOperationException("not yet implemented");
  }

  public String getName()
  {
    return "ldapGroup";
  }

  public Class<LdapGroup> getUserClass()
  {
    return LdapGroup.class;
  }

  /**
   * Finds the children of the given organization and order them by their
   * groupname (ascending).
   *
   * @param organizationDn the organization dn.
   * @return the children of the given organization.
   * @throws LDAPException on ldap error.
   */
  public Collection<Group> findOrganizationUnitChildren(String organizationDn) throws LDAPException
  {
    /** todo put this in property */
    String searchFilter = "(|(objectclass=organizationalUnit)(objectclass=groupOfNames))";
    Collection entries = _connector.findBySearchFilter(LdapConnector.SCOPE_ONE, searchFilter, organizationDn);

    Map<String, Group> results = new TreeMap<String, Group>();

    for (Iterator iterator = entries.iterator(); iterator.hasNext();)
    {
      LDAPEntry entry = (LDAPEntry) iterator.next();
      Group group = entryToGroup(entry);
      results.put(group.getGroupname(), group);
    }

    return results.values();
  }

  /**
   * Finds the group (LDAPEntry) having the given dn.
   *
   * @param dn the dn.
   * @return the group (LDAPEntry) having the given dn.
   * @throws LDAPException on ldap error.
   */
  public Group findByDn(String dn) throws LDAPException
  {
    LDAPEntry entry = _connector.findByDn(dn);
    return entryToGroup(entry);
  }

  /**
   * Returns the group having the given common name.
   *
   * @param cn the common name.
   * @return the group having the given common name.
   */
  public Group findByCommonName(String cn) throws LDAPException
  {
    LDAPEntry entry = _connector.findFirstBySearchFilter(LdapConnector.SCOPE_SUB, "cn=" + cn);
    return entryToGroup(entry);
  }

  /**
   * Transforms an ldap entry to SubscriptionService Group.
   *
   * @param entry the entry to transform.
   * @return SubscriptionService Group from the given entry.
   */
  private Group entryToGroup(LDAPEntry entry)
  {
    if (entry == null)
    {
      return null;
    }

    // The group id. If we have a uniqueIdentifier we use it as the id,
    // otherwise we use the dn.
    String id = null;

    LDAPAttribute uniqueIdentifierAttribute = entry.getAttribute("uniqueIdentifier");

    if (uniqueIdentifierAttribute != null)
    {
      id = uniqueIdentifierAttribute.getStringValue();
    }
    else
    {
      id = entry.getDN();
    }

    LdapGroup group = new LdapGroup(id);

    LDAPAttribute descriptionAttribute = entry.getAttribute("description");

    if (descriptionAttribute != null)
    {
      group.setLabel(descriptionAttribute.getStringValue());
    }

    // for the groupname we set either the ou if it's a unit..
    LDAPAttribute groupnameAttribute = entry.getAttribute("ou");

    if (groupnameAttribute != null)
    {
      group.setGroupname(groupnameAttribute.getStringValue());
    }
    // or the organization if it's an organization
    else
    {
      LDAPAttribute organizationAttribute = entry.getAttribute("o");

      if (organizationAttribute != null)
      {
        /** TODO it's not always the last, put this in property */
        String[] values = organizationAttribute.getStringValueArray();
        group.setGroupname(values[values.length - 1]);
      }
      /* XXX ajout� par LR, ajout� l'attribut "cn" pour les enfants de "groups" */
      else
      {
        LDAPAttribute cnAttribute = entry.getAttribute("cn");
        if (cnAttribute != null)
        {
          group.setGroupname(cnAttribute.getStringValue());

          if (group.getLabel() == null && descriptionAttribute == null)
          {
            group.setLabel(cnAttribute.getStringValue());
          }
        }
      }
    }

    group.setDn(entry.getDN());

    return group;
  }
}