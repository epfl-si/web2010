package ch.epfl.kis.polyblog.view.web.action.blogRole.group.ldap;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.service.*;
import ch.epfl.kis.polyblog.system.*;
import com.baneo.core.util.*;
import org.apache.struts.action.*;

import javax.servlet.http.*;
import java.util.*;

/**
 * LdapGroupSelectAction.
 *
 * @author Laurent Boatto
 */
public class LdapGroupSelectAction extends Action
{
  private static final LdapGroupService _ldapGroupService = LdapGroupService.instance();

  public ActionForward execute(ActionMapping mapping, ActionForm actionForm, HttpServletRequest request, HttpServletResponse response) throws Exception
  {
    Blog blog = BlogService.instance().get(request.getParameter("blogId"));
    request.setAttribute("blog", blog);
    String dn = request.getParameter("dn");
    Collection results = null;

    if (dn != null)
    {
      dn = HttpUtil.decode(dn);
    }

    if (dn == null)
    {
      Map map = new TreeMap();

      String[] organizations = Constants.LDAP_ORGANIZATIONS;

      for (int i = 0; i < organizations.length; i++)
      {
        String organization = organizations[i];
        Group organizationGroup = _ldapGroupService.findByDn(organization);
        map.put(organizationGroup.getGroupname(), organizationGroup);
      }

      results = map.values();
    }
    else
    {
      results = _ldapGroupService.findOrganizationUnitChildren(dn);

      // the unit has no subunits, we can directly go to the select role view
      if (results.isEmpty())
      {
        String nextUrl = "/private/blogRole/group/ldap/insert.do?blogId=" + blog.getId() + "&dn" + HttpUtil.encode(dn);
        ActionForward forward = new ActionForward(nextUrl);
        return forward;
      }
    }


    request.setAttribute("results", results);

    return mapping.findForward("select");
  }
}