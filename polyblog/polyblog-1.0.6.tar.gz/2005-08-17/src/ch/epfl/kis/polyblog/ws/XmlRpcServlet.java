package ch.epfl.kis.polyblog.ws;

import org.apache.xmlrpc.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

/**
 * XmlRpcServlet.
 *
 * @author Laurent Boatto
 */
public class XmlRpcServlet extends HttpServlet
{
  private XmlRpcServer _server = null;

  /**
   * Initializes the servlet.
   */
  public void init(ServletConfig config) throws ServletException
  {
    super.init(config);
    _server = new XmlRpcServer();
    _server.addHandler("metaWeblog", new MetaWebLogApi());
    _server.addHandler("blogger", new BloggerApi());
    _server.addHandler("polyblog", new PolyblogXmlRpcApi());
  }

  protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    byte[] result = _server.execute(request.getInputStream());

    response.setContentType("text/xml");
    response.setContentLength(result.length);

    OutputStream output = response.getOutputStream();
    output.write(result);
    output.flush();
  }
}
