/*
 * $Id$
 *
 * Copyright 2005 EPFL. All rights reserved.
 */

package ch.epfl.kis.polyblog.listener;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.security.*;
import ch.epfl.kis.polyblog.service.*;
import com.baneo.core.persistance.*;
import com.baneo.core.security.role.*;
import com.baneo.core.service.*;

import java.util.*;

/**
 * Listener for the BlogManager regarding ObjectRoles.
 *
 * @author Laurent Boatto
 */
public class ObjectRoleBlogServiceListener extends BaseBusinessObjectManagerListener
{
  private static final BlogRoleService _blogRoleService = BlogRoleService.instance();

  public void postInsert(BusinessObjectManagerEvent event) throws PersistanceException
  {
    Blog blog = (Blog) event.getSource();
    // we add the administrator role to the current Principal
    User user = SecurityService.getUser();
    _blogRoleService.addRole(SecurityService.ROLE_ADMINISTRATOR, user, blog);
  }

  public void postDelete(BusinessObjectManagerEvent event) throws PersistanceException
  {
    Blog blog = (Blog) event.getSource();
    Collection objectRoles = _blogRoleService.findByBlog(blog);

    for (Iterator iterator = objectRoles.iterator(); iterator.hasNext();)
    {
      ObjectRole objectRole = (ObjectRole) iterator.next();
      _blogRoleService.delete(objectRole);
    }
  }
}