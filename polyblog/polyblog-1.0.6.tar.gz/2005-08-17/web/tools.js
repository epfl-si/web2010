<!-- $Id$ -->
function selectAllCheckboxes(form) {
  for (var i=0;i<form.elements.length;i++) {
    var element = form.elements[i];
    if (element.type == 'checkbox')
      element.checked = form.elements['selectAllCheckbox'].checked;
  }
}

function addFileField(idx)
{
	for (var i = 0; i < 10; i++)
	{
		var theTrStyle = document.getElementById("ligne" + i).style;
		if (theTrStyle.display == "none")
		{
			theTrStyle.display = "";

      var theNextTr = document.getElementById("ligne" + (i + 1));
			if (theNextTr == null)
			{
				var theLink = document.getElementById("addLink").style;
				theLink.display = "none";
			}
			return;
		}
	}
}