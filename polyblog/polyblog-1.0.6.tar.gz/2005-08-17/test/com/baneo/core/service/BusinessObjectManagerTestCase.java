/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.service;

import com.baneo.core.meta.*;
import com.baneo.core.model.*;
import com.baneo.core.test.*;
import com.baneo.core.util.*;

import java.lang.reflect.*;
import java.util.*;

/**
 * Parent test case class for BOs managers.
 *
 * @author  Laurent Boatto
 * @version $Id$
 */

public abstract class BusinessObjectManagerTestCase extends AbstractTestCase
{
  // Common fields
  protected static final int CREATED_BY_ID = 5;
  protected static final String CREATED_FOOTPRINT = "192.168.1.1";
  protected static final int LAST_MODIFIED_BY_ID = 6;
  protected static final String LAST_MODIFIED_FOOTPRINT = "192.168.1.2";

  /**
   * Common setup.
   */
  protected void setUp() throws Exception
  {
    super.setUp();

    setSecurityContextToInsertMode();
  }

  /**
   * Populates the given simple bean with random values, and returns the values
   * used importer a Map.
   *
   * @param bean the bean to populate.
   * @throws com.baneo.core.meta.MetaManagerException
   * @throws java.lang.IllegalAccessException
   * @throws java.lang.reflect.InvocationTargetException
   */
  protected Map populate(Object bean) throws MetaManagerException, IllegalAccessException, InvocationTargetException
  {
    IMetaManager metaManager = MetaManagerFactory.getIMetaManager();
    String[] attributes = metaManager.getAttributesNames(bean.getClass());
    Class[] classes = metaManager.getAttributesClasses(bean.getClass());
    return BeanUtil.randomPopulate(bean, attributes, classes);
  }

  /**
   * Sets the security context to insert mode.
   */
  protected void setSecurityContextToInsertMode()
  {
    setSecurityContext("administrator", CREATED_BY_ID, "administrator,moderator", CREATED_FOOTPRINT);
  }

  /**
   * Change the SecurityContext to test the lastModified and
   * lastModifiedFootprint attributes.
   */
  protected void setSecurityContextToUpdateMode()
  {
    setSecurityContext("administrator", LAST_MODIFIED_BY_ID, "administrator,moderator", LAST_MODIFIED_FOOTPRINT);
  }

  /**
   * Common tests for an insert.
   *
   * @param bean the bean to check
   */
  public void testInsert(Object bean, Map values) throws Exception
  {
    checkValues(bean, values);

    if (!(bean instanceof TaggedBusinessObject))
    {
      return;
    }

    TaggedBusinessObject taggedBo = (TaggedBusinessObject) bean;

    // We have just inserted the BO, version should be 1
    assertTrue(taggedBo.getVersion() == 1);

    assertTrue(DateUtil.isSameTime(taggedBo.getCreated().getTime(), System.currentTimeMillis(), 12000));
    assertTrue(taggedBo.getCreatedBy() == CREATED_BY_ID);
    assertEquals(taggedBo.getCreatedFootprint(), CREATED_FOOTPRINT);

    // the lastModifiedBy and lastModifiedIdentifer should be the same as
    // createdBy and createdFootprint when the BO is first inserted
    assertTrue(DateUtil.isSameTime(taggedBo.getLastModified().getTime(), System.currentTimeMillis(), 12000));
    assertEquals(taggedBo.getLastModifiedBy(), CREATED_BY_ID);
    assertEquals(taggedBo.getLastModifiedFootprint(), CREATED_FOOTPRINT);
  }

  /**
   * Common tests for an update.
   *
   * @param bean the BusinessObject to check
   */
  public void testUpdate(Object bean, Map values) throws Exception
  {
    checkValues(bean, values);
  }

  public void testFindAll() throws Exception
  {
    BusinessObjectManager manager = getBusinessObjectManager();

    Collection all = manager.findAll();
    assertNotNull(all);
  }

  public void testCount() throws Exception
  {
    BusinessObjectManager manager = getBusinessObjectManager();

    Collection all = manager.findAll();
    int count = manager.count();

    assertEquals(count, all.size());
  }


  protected abstract BusinessObjectManager getBusinessObjectManager();

  /**
   * Checks that the values of the bean are the same than the values contained
   * importer the Map.
   *
   * @param bean the bean to check.
   * @param values the Map containing the values to check.
   */
  protected void checkValues(Object bean, Map values) throws Exception
  {
    String[] attributes = (String[]) values.keySet().toArray(new String[values.keySet().size()]);
    boolean isTagged = bean instanceof TaggedBusinessObject;

    for (int i = 0; i < attributes.length; i++)
    {
      String attribute = attributes[i];

      if (isTagged && TaggedBusinessObject.isCalculatedAttribute(attribute))
      {
        continue;
      }

      Object value = MetaManagerFactory.getIMetaManager().geAttributeValue(bean, attribute);

      /**
       * todo how to check dates?
       */
      if (value instanceof Date)
      {
        continue;
      }

      if (isVerbose())
      {
        debug("Attribute '" + attribute + "' checking value '" + value + "'");
      }

      if (value == null)
      {
        assertNull("Error comparing attribute " + attribute + " should be null but has value '" + values.get(attribute) + "'", values.get(attribute));
        continue;
      }

      assertEquals("Error comparing attribute " + attribute + " of class " + value.getClass().getName(), value, values.get(attribute));
    }
  }
}