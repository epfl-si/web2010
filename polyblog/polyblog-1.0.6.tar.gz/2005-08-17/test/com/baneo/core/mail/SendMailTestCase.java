/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.mail;

import junit.framework.*;

/**
 * SendMailTestCase.
 *
 * @author Laurent Boatto
 * @version $Id$
 */

public class SendMailTestCase extends TestCase
{
  public static void testSendTextEmail() throws Exception
  {
    SendMail.setSmtpHost("smtp.urbanet.ch");
    SendMail.sendTextMail("test@urbanet.ch", "boatto@urbanet.ch", "Test", "Hello");
  }
}
