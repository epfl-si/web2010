/*
 * $Id$
 *
 * Copyright 2005 EPFL. All rights reserved.
 */

package com.baneo.core.system;

import com.baneo.core.test.*;

import java.util.*;

/**
 * ApplicationResourcesTestCase.
 *
 * @author Laurent Boatto
 */
public class ApplicationResourcesTestCase extends AbstractTestCase
{
  public void testFindBestResourceBundle()
  {
    Locale frCH = new Locale("fr", "CH");
    Locale frFR = new Locale("fr", "FR");
    Locale fr = new Locale("fr");
    Locale en = new Locale("en");


    ResourceBundle frFRResource = new MockResourceBundle(frFR);
    ResourceBundle frResource = new MockResourceBundle(fr);
    ResourceBundle enResource = new MockResourceBundle(en);

    ApplicationResources.addResourceBundle(enResource, true);
    ApplicationResources.addResourceBundle(frResource, false);
    ApplicationResources.addResourceBundle(frFRResource, false);
    ApplicationResources.addResourceBundle(enResource, false);

    ResourceBundle frCHBest = ApplicationResources.findBestResourceBundle(frCH);
    ResourceBundle frFRBest = ApplicationResources.findBestResourceBundle(frFR);
    ResourceBundle cnBest = ApplicationResources.findBestResourceBundle(Locale.CHINESE);

    assertEquals(frResource, frCHBest);
    assertEquals(frFRResource, frFRBest);
    assertEquals(enResource, cnBest);
  }

  /**
   * Mock implementation of ResourceBundle, just for this TestCase.
   */
  private class MockResourceBundle extends ResourceBundle
  {
    private Locale _locale;

    public MockResourceBundle(Locale locale)
    {
      _locale = locale;
    }

    public Locale getLocale()
    {
      return _locale;
    }

    protected Object handleGetObject(String key)
    {
      return null;
    }

    public Enumeration getKeys()
    {
      return null;
    }
  }
}
