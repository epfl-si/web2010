/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.system;

import junit.framework.*;

import java.util.*;

/**
 * ConfigTestCase
 *
 * @author  Laurent Boatto
 * @version $Id$
 */

public class ConfigTestCase extends TestCase
{
  private Properties _properties = null;

  protected void setUp() throws Exception
  {
    // Some properties we will use for the TestCase.
    _properties = new Properties();

    _properties.put("key", "value");
    _properties.put("String", "aString");
    _properties.put("booleanTrue", "true");
    _properties.put("booleanFalse", "false");
    _properties.put("int", "5");
    _properties.put("char", "c");
    _properties.put("stringArray.1", "value1");
    _properties.put("stringArray.2", "value2");
    _properties.put("stringArray.3", "value3");
    _properties.put("charArray.1", "a");
    _properties.put("charArray.2", "b");
    _properties.put("charArray.3", "c");

    ApplicationResources.setProperties(_properties);
  }

  protected void tearDown() throws Exception
  {
    _properties = null;
  }

  public void testGet()
  {
    assertEquals("value", Config.get("key"));
    assertNull(Config.get("idonotexistandwillneverdo"));
  }

  public void testGetCharArray()
  {
    char[] array = Config.getCharArray("charArray");

    assertEquals('a', array[0]);
    assertEquals('b', array[1]);
    assertEquals('c', array[2]);
  }

  public void testGetStringArray()
  {
    String[] array = Config.getStringArray("stringArray");

    assertEquals(3, array.length);

    for (int i = 0; i < array.length; i++)
    {
      String s = array[i];

      assertEquals(s, "value" + (i + 1));
    }
  }

  public void testGetInt()
  {
    assertEquals(5, Config.getInt("int"));
  }

  public void testGetBoolean()
  {
    assertTrue(Config.getBoolean("booleanTrue"));
    assertFalse(Config.getBoolean("booleanFalse"));
  }

  public void testGetChar()
  {
    assertEquals('c', Config.getChar("char"));
  }

  public void testGetProperties()
  {
    assertEquals(_properties, Config.getProperties());
  }
}