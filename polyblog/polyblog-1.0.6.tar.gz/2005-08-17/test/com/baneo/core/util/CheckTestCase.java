/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.util;

import junit.framework.*;

/**
 * ClassifiedCheckTestCase.
 *
 * @author  Laurent Boatto
 * @version $Id$
 */

public class CheckTestCase extends TestCase
{
  public CheckTestCase(String name)
  {
    super(name);
  }

  /**
   * Tests the hasValidLengthMultiple method.
   */
  public void testHasValidLengthMultiple()
  {
    String length8 = "12345678";

    // should be valid
    assertTrue(Check.hasValidLengthMultiple(length8, 2));
    assertTrue(Check.hasValidLengthMultiple(length8, 4));
    assertTrue(Check.hasValidLengthMultiple(length8, 8));

    // should be invalid
    assertTrue(!Check.hasValidLengthMultiple(length8, 3));
    assertTrue(!Check.hasValidLengthMultiple(length8, 6));
    assertTrue(!Check.hasValidLengthMultiple(length8, 9));
  }

  public void testContainsEmail()
  {
    assertTrue(Check.containsEmail("bob@urbanet.ch"));
    assertTrue(Check.containsEmail(" bob@urbanet.ch......."));
    assertTrue(Check.containsEmail("blablabla bob@urbanet.com blablabla"));
    assertTrue(Check.containsEmail("blablabla bob_sinclar@host.me.urbanet.com blablabla"));
    assertTrue(Check.containsEmail("bob_sinclar@host.me.urbanet.com blablabla"));
    assertTrue(Check.containsEmail("test the email at the end.of@the.text.com"));

    assertFalse(Check.containsEmail("blablabla blablabla @ blablabla.com."));
    assertFalse(Check.containsEmail("blablabla www.site.com"));
    assertFalse(Check.containsEmail("lookslike@anemail...."));
  }

  /**
   * Tests hasEnoughWords.
   */
  public void testHasEnoughWords()
  {
    assertTrue(Check.hasEnoughWords("un deux trois", 3));
    assertTrue(Check.hasEnoughWords("   un     deux         trois       ", 3));

    assertFalse(Check.hasEnoughWords("un deux trois", 4));
    assertFalse(Check.hasEnoughWords("un   deux    trois", 4));
    assertFalse(Check.hasEnoughWords("           un    deux     trois       ", 4));
  }

  public void testHasTooMuchNonAlphaNumericChars()
  {
    int percentAllowed = 30;

    assertFalse(Check.hasTooMuchNonAlphaNumericChars("A vendre :", percentAllowed));
    assertFalse(Check.hasTooMuchNonAlphaNumericChars("1 1111 22 2222", percentAllowed));
    assertFalse(Check.hasTooMuchNonAlphaNumericChars("Alfa Romeo 147 Selespeed, 2001, 47'000 km, 26'900.-", percentAllowed));

    assertTrue(Check.hasTooMuchNonAlphaNumericChars("A v e n d r e", percentAllowed));
    assertTrue(Check.hasTooMuchNonAlphaNumericChars("A v.e.n.d.r.e", percentAllowed));
    assertTrue(Check.hasTooMuchNonAlphaNumericChars("Vend v e l o m o t e u r", percentAllowed));
  }

  /**
   * Tests the startsWithLetter method.
   *
   * @throws Exception
   */
  public void testStartsWithLetter() throws Exception
  {
    // Should be true
    assertTrue(Check.startsWithLetter("abc"));
    assertTrue(Check.startsWithLetter("Abc"));
    assertTrue(Check.startsWithLetter("bbc"));
    assertTrue(Check.startsWithLetter("k323232"));
    assertTrue(Check.startsWithLetter("Zbc"));

    // Should be false
    assertFalse(Check.startsWithLetter(null));
    assertFalse(Check.startsWithLetter(""));
    assertFalse(Check.startsWithLetter(" "));
    assertFalse(Check.startsWithLetter(" a"));
    assertFalse(Check.startsWithLetter("1"));
    assertFalse(Check.startsWithLetter("&"));
    assertFalse(Check.startsWithLetter("*"));
  }

  /**
   * Tests the isValidInt method.
   *
   * @throws Exception
   */
  public void testIsValidInt() throws Exception
  {
    assertTrue(Check.isValidInt("2"));
    assertTrue(Check.isValidInt("299"));
    assertTrue(Check.isValidInt("32423523"));

    assertFalse(Check.isValidInt(null));
    assertFalse(Check.isValidInt(""));
    assertFalse(Check.isValidInt(" 2"));
    assertFalse(Check.isValidInt("2 "));
    assertFalse(Check.isValidInt("a"));
    assertFalse(Check.isValidInt("*�%"));
  }

  /**
   * Tests the isEmpty method.
   *
   * @throws Exception
   */
  public void testIsEmpty() throws Exception
  {
    assertTrue(Check.isEmpty(null));
    assertTrue(Check.isEmpty(""));
    assertTrue(Check.isEmpty(" "));
    assertTrue(Check.isEmpty("       "));

    assertFalse(Check.isEmpty(" ."));
    assertFalse(Check.isEmpty("null"));
    assertFalse(Check.isEmpty("assd"));
  }

  /**
   * Tests the isInRange method.
   *
   * @throws Exception
   */
  public void testIsInRange() throws Exception
  {
    // The second parameter must be lower than the third
    try
    {
      Check.isInRange(5, 5, 4);
      // The exception wasn't thrown as it should have been
      fail();
    }
    catch (IllegalArgumentException e)
    {
    }

    assertTrue(Check.isInRange(5, 4, 5));
    assertTrue(Check.isInRange(5, 5, 6));
    assertTrue(Check.isInRange(5, 5, 5));
    assertTrue(Check.isInRange(0, 0, 0));
    assertTrue(Check.isInRange(5, -5, 55));

    assertFalse(Check.isInRange(5, 3, 4));
    assertFalse(Check.isInRange(5, 6, 10));
  }

  /**
   * Tests the hasValidLength method.
   * @throws Exception
   */
  public void testHasValidLength() throws Exception
  {
    // The second parameter must be lower than the third
    try
    {
      Check.hasValidLength("aba", 5, 4);
      // The exception wasn't thrown as it should have been
      fail();
    }
    catch (IllegalArgumentException e)
    {
    }

    assertTrue(Check.hasValidLength("123", 3, 3));
    assertTrue(Check.hasValidLength("123", 0, 3));
    assertTrue(Check.hasValidLength("123", 3, 10));

    assertFalse(Check.hasValidLength(null, 0, 0));
    assertFalse(Check.hasValidLength(" ", 0, 0));
    assertFalse(Check.hasValidLength("123", 4, 5));
    assertFalse(Check.hasValidLength("123", 0, 2));
  }

  /**
   * testIsValidEmailSyntax
   *
   * @throws Exception
   */
  public void testIsValidEmailSyntax() throws Exception
  {
    assertTrue(Check.isValidEmailSyntax("first@host.com"));
    assertTrue(Check.isValidEmailSyntax("first@host.info"));
    assertTrue(Check.isValidEmailSyntax("FIRST@HOST.INFO"));
    assertTrue(Check.isValidEmailSyntax("first_last@host.info"));
    assertTrue(Check.isValidEmailSyntax("first.last@host.info"));
    assertTrue(Check.isValidEmailSyntax("first.last@my.very.very.very.very.long.host.info"));

    assertFalse(Check.isValidEmailSyntax("first@host"));
    assertFalse(Check.isValidEmailSyntax("first@host-.com"));
    assertFalse(Check.isValidEmailSyntax("first@-host.com"));
    assertFalse(Check.isValidEmailSyntax("first@123"));
    assertFalse(Check.isValidEmailSyntax("first@.com"));
    assertFalse(Check.isValidEmailSyntax("first@my_machine.host.com"));
    assertFalse(Check.isValidEmailSyntax("@host.com"));
    assertFalse(Check.isValidEmailSyntax(".@host.com"));
  }

  /**
   * testIsEmailDomainValid
   *
   * @throws Exception
   */
  public void testIsValidEmailDomain() throws Exception
  {
    try
    {
      // An invalid email should throw an IllegalArgumentException
      Check.isValidEmailDomain("askfj");
      fail();
    }
    catch (IllegalArgumentException e)
    {
      // this is expected
    }

    assertTrue(Check.isValidEmailDomain("me@yahoo.com"));
    assertTrue(Check.isValidEmailDomain("me@mail.yahoo.com"));
    assertTrue(Check.isValidEmailDomain("me@yahoo.fr"));

    assertFalse(Check.isValidEmailDomain("me@jdaslkdfjwejkwejerwierjw.ch"));
    assertFalse(Check.isValidEmailDomain("me@bluwind.ch"));
  }
}
