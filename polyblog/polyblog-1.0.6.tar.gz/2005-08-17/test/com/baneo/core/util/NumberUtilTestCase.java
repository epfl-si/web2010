/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.util;

import com.baneo.core.test.*;

import java.text.*;
import java.util.*;

/**
 * IntUtilTestCase
 *
 * @author  Laurent Boatto
 * @version $Id$
 */

public class NumberUtilTestCase extends AbstractTestCase
{
  /**
   * testFormat
   */
  public void testFormatInt()
  {
    char separator = '\'';

    assertEquals("0", NumberUtil.formatInt(0, separator));
    assertEquals("1", NumberUtil.formatInt(1, separator));
    assertEquals("10", NumberUtil.formatInt(10, separator));
    assertEquals("100", NumberUtil.formatInt(100, separator));
    assertEquals("1'000", NumberUtil.formatInt(1000, separator));
    assertEquals("10'000", NumberUtil.formatInt(10000, separator));
    assertEquals("100'000", NumberUtil.formatInt(100000, separator));
    assertEquals("1'000'000", NumberUtil.formatInt(1000000, separator));
    assertEquals("10'000'000", NumberUtil.formatInt(10000000, separator));
    assertEquals("100'000'000", NumberUtil.formatInt(100000000, separator));
    assertEquals("1'000'000'000", NumberUtil.formatInt(1000000000, separator));
    assertEquals("2'147'483'647", NumberUtil.formatInt(Integer.MAX_VALUE, separator));

    assertEquals("-1", NumberUtil.formatInt(-1, separator));
    assertEquals("-10", NumberUtil.formatInt(-10, separator));
    assertEquals("-100", NumberUtil.formatInt(-100, separator));
    assertEquals("-1'000", NumberUtil.formatInt(-1000, separator));
    assertEquals("-10'000", NumberUtil.formatInt(-10000, separator));
    assertEquals("-100'000", NumberUtil.formatInt(-100000, separator));
    assertEquals("-1'000'000", NumberUtil.formatInt(-1000000, separator));
    assertEquals("-10'000'000", NumberUtil.formatInt(-10000000, separator));
    assertEquals("-100'000'000", NumberUtil.formatInt(-100000000, separator));
    assertEquals("-1'000'000'000", NumberUtil.formatInt(-1000000000, separator));
    assertEquals("-2'147'483'647", NumberUtil.formatInt(-Integer.MAX_VALUE, separator));
  }

  /**
   * Tests the performance of IntUtil.format
   * (it is 2x faster than DecimalFormat).
   */
  public void testFormatPerformance()
  {
    // First we findByDn the ints to test..
    int[] toFormat = new int[1000000];
    Random random = new Random();

    for (int i = 0; i < toFormat.length; i++)
    {
      toFormat[i] = random.nextInt(1000000000);

      if (i % 2 == 0)
      {
        toFormat[i] = toFormat[i] * -1;
      }
    }

    // Next we test with DecimalFormat
    DecimalFormat decimalFormat = new DecimalFormat("#,###");

    long start = System.currentTimeMillis();

    for (int i = 0; i < toFormat.length; i++)
    {
      decimalFormat.format(toFormat[i]);
    }

    long stop = System.currentTimeMillis();

    long elapsedDecimalFormat = stop - start;

    if (isVerbose())
    {
      debug("Elapsed time for DecimalFormat : " + elapsedDecimalFormat);
    }

    // We do the same test with IntUtil
    start = System.currentTimeMillis();

    for (int i = 0; i < toFormat.length; i++)
    {
      NumberUtil.formatInt(toFormat[i], '\'');
    }

    stop = System.currentTimeMillis();
    long elapsedIntUtil = stop - start;

    if (isVerbose())
    {
      debug("Elapsed time for IntUtil : " + elapsedIntUtil);
    }

    // IntUtil 2x faster than DecimalFormat...
    assertTrue(elapsedIntUtil < elapsedDecimalFormat);
  }

  public void testParseIntLenient()
  {
    assertEquals(5, NumberUtil.parseIntLenient("a5a"));
    assertEquals(50000, NumberUtil.parseIntLenient("50'000.-"));
    assertEquals(1000000, NumberUtil.parseIntLenient("big money : 1,000,000.-"));

  }

  public void testParseIntLenientWithDefault()
  {
    assertEquals(5, NumberUtil.parseIntLenient("a5a"));
    assertEquals(5, NumberUtil.parseIntLenient(null, 5));
    assertEquals(5, NumberUtil.parseIntLenient("      ", 5));

  }

  /**
   * Checks the parseInt method.
   *
   * @throws Exception
   */
  public void testParseInt() throws Exception
  {
    // Should be parsed correctly
    assertEquals(NumberUtil.parseInt("5", 0), 5);
    assertEquals(NumberUtil.parseInt("10000", 0), 10000);
    assertEquals(NumberUtil.parseInt("0", 5), 0);

    // Should return the default value
    assertEquals(NumberUtil.parseInt("a", 5), 5);
    assertEquals(NumberUtil.parseInt(null, 5), 5);
    assertEquals(NumberUtil.parseInt(" ", 5), 5);
    assertEquals(NumberUtil.parseInt(" 5", 5), 5);
  }

  public void testParseFloatLenient() throws Exception
  {
    char[] unitSeparators = {'.', ','};

    assertEquals(1200f, NumberUtil.parseDoubleLenient("1200", unitSeparators), 0);
    assertEquals(1200f, NumberUtil.parseDoubleLenient("1'200", unitSeparators), 0);
    assertEquals(1200f, NumberUtil.parseDoubleLenient("1'200.-", unitSeparators), 0);
    assertEquals(1200f, NumberUtil.parseDoubleLenient("1'200.00", unitSeparators), 0);
    assertEquals(1200f, NumberUtil.parseDoubleLenient("1'200,00", unitSeparators), 0);
    assertEquals(1200f, NumberUtil.parseDoubleLenient("1'2'0'0.00", unitSeparators), 0);
    assertEquals(1200f, NumberUtil.parseDoubleLenient("1'200.000000", unitSeparators), 0);
    // multiples unit separators
    assertEquals(1200f, NumberUtil.parseDoubleLenient("1'200.000.000", unitSeparators), 0);
    assertEquals(1200f, NumberUtil.parseDoubleLenient("1'200.000,000", unitSeparators), 0);
  }

  public void testParseFloatLenientWithDefault() throws Exception
  {
    char[] unitSeparators = {'.', ','};

    assertEquals(1200f, NumberUtil.parseDoubleLenient(null, unitSeparators, 1200), 0);
    assertEquals(1200f, NumberUtil.parseDoubleLenient("    ", unitSeparators, 1200), 0);
    assertEquals(1200f, NumberUtil.parseDoubleLenient("expensive", unitSeparators, 1200), 0);
  }
}