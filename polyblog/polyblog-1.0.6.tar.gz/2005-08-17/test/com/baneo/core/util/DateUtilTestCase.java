/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.util;

import com.baneo.core.test.*;

import java.text.*;
import java.util.*;

/**
 * DateUtilTestCase.
 *
 * @author Laurent Boatto
 * @version $Id$
 */

public class DateUtilTestCase extends AbstractTestCase
{
  /**
   * Tests the getCurrentYear method.
   *
   * @throws Exception
   */
  public void testGetCurrentYear() throws Exception
  {
    int year = DateUtil.getCurrentYear();

    // ummm...
    assertTrue(year >= 2004);
  }

  public void testParseIsoDate() throws Exception
  {
    String test = "2003-01-01";

    Date result = DateUtil.parseIsoDate(test);

    Calendar calendar = new GregorianCalendar();
    calendar.setTime(result);

    assertEquals(2003, calendar.get(Calendar.YEAR));
    assertEquals(0, calendar.get(Calendar.MONTH));
    assertEquals(1, calendar.get(Calendar.DAY_OF_MONTH));
  }

  public void testFormatRfc822Date()
  {
    debug(DateUtil.formatRfc822Date(new Date()));
  }

  public void testParseIsoDatePerformance() throws Exception
  {
    String[] dates = new String[12];
    dates[0] = "2003-01-12";
    dates[1] = "2003-02-11";
    dates[2] = "2003-03-10";
    dates[3] = "2003-04-09";
    dates[4] = "2003-05-08";
    dates[5] = "2003-06-07";
    dates[6] = "2003-07-06";
    dates[7] = "2003-08-05";
    dates[8] = "2003-09-04";
    dates[9] = "2003-10-03";
    dates[10] = "2003-11-02";
    dates[11] = "2003-12-01";

    DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");

    // We start the test for SimpleDateFormat
    long start = System.currentTimeMillis();

    for (int i = 0; i < 1000; i++)
    {
      for (int j = 0; j < dates.length; j++)
      {
        formatter.parse(dates[j]);
      }
    }

    long stop = System.currentTimeMillis();

    long elapsedSimpleDateFormat = stop - start;

    debug("Elasped time for SimpleDateFormat : " + elapsedSimpleDateFormat);

    // Now we do the same parsing with DateUtil
    start = System.currentTimeMillis();

    for (int i = 0; i < 1000; i++)
    {
      for (int j = 0; j < dates.length; j++)
      {
        DateUtil.parseIsoDate(dates[j]);
      }
    }

    stop = System.currentTimeMillis();

    long elapsedDateUtil = stop - start;

    debug("Elasped time for DateUtil : " + elapsedDateUtil);

    assertTrue(elapsedDateUtil < elapsedSimpleDateFormat);
  }

  /**
   * testIsSameMonth
   *
   * @throws Exception
   */
  public void testIsSameMonth() throws Exception
  {
    Calendar calendar1 = new GregorianCalendar();
    Calendar calendar2 = new GregorianCalendar();
    Calendar calendar3 = new GregorianCalendar();
    Calendar calendar4 = new GregorianCalendar();

    calendar1.set(Calendar.YEAR, 1999);
    calendar2.set(Calendar.YEAR, 1999);
    calendar3.set(Calendar.YEAR, 1999);
    calendar4.set(Calendar.YEAR, 2000);

    calendar1.set(Calendar.MONTH, 2);
    calendar2.set(Calendar.MONTH, 2);
    calendar3.set(Calendar.MONTH, 3);
    calendar4.set(Calendar.MONTH, 2);

    assertTrue(DateUtil.isSameMonth(calendar1.getTime(), calendar2.getTime()));
    assertFalse(DateUtil.isSameMonth(calendar1.getTime(), calendar3.getTime()));
    assertFalse(DateUtil.isSameMonth(calendar1.getTime(), calendar4.getTime()));
  }

  /**
   * testGetDaysBetweenDates
   *
   * @throws Exception
   */
  public void testGetDaysBetweenDates() throws Exception
  {
    Calendar day = new GregorianCalendar(2003, 11, 5);
    Calendar oneAfter = new GregorianCalendar(2003, 11, 6);
    Calendar tenAfter = new GregorianCalendar(2003, 11, 15);

    assertEquals(1, DateUtil.daysBetweenDates(day.getTime(), oneAfter.getTime()));
    assertEquals(-1, DateUtil.daysBetweenDates(oneAfter.getTime(), day.getTime()));
    assertEquals(10, DateUtil.daysBetweenDates(day.getTime(), tenAfter.getTime()));
    assertEquals(-10, DateUtil.daysBetweenDates(tenAfter.getTime(), day.getTime()));
  }
}
