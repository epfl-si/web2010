/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.util;

import com.baneo.core.test.*;
import org.easymock.*;

import javax.servlet.http.*;
import java.util.*;

/**
 * HttpUtilTestCase.
 *
 * @author Laurent Boatto
 * @version $Id$
 */

public class HttpUtilTestCase extends AbstractTestCase
{
  public void testAddParameterToRequest()
  {
    MockControl requestControl = MockControl.createControl(javax.servlet.http.HttpServletRequest.class);
    HttpServletRequest request = (HttpServletRequest) requestControl.getMock();

    // Set parameters values
    request.getParameter("a");
    // The spaces importer parameter values must be supported
    requestControl.setReturnValue("1 2");
    request.getParameter("b");
    requestControl.setReturnValue("3 4");

    MockControl enumerationControl = MockControl.createControl(java.util.Enumeration.class);
    Enumeration enumeration = (Enumeration) enumerationControl.getMock();

    enumeration.hasMoreElements();
    enumerationControl.setReturnValue(true);
    enumeration.hasMoreElements();
    enumerationControl.setReturnValue(true);
    enumeration.hasMoreElements();
    enumerationControl.setReturnValue(false);

    enumeration.nextElement();
    enumerationControl.setReturnValue("a");
    enumeration.nextElement();
    enumerationControl.setReturnValue("b");

    enumerationControl.replay();

    request.getParameterNames();
    requestControl.setReturnValue(enumeration);

    requestControl.replay();

    String baseUrl = "/admin/user/list.do";
    String parameterName = "page";
    String parameterValue = "4";

    String result = HttpUtil.addParameterToRequest(baseUrl, request, parameterName, parameterValue);

    debug(result);
    assertEquals("/admin/user/list.do?a=1+2&b=3+4&page=4", result);
  }

  /**
   * Tests the getParameter method.
   *
   * @throws Exception
   */
  public void testGetParameter() throws Exception
  {
    MockControl control = MockControl.createControl(javax.servlet.http.HttpServletRequest.class);
    HttpServletRequest request = (HttpServletRequest) control.getMock();

    // Different cases
    request.getParameter("testSpaceOnly");
    control.setReturnValue("  ");

    request.getParameter("testEmpty");
    control.setReturnValue("");

    request.getParameter("testNull");
    control.setReturnValue(null);

    request.getParameter("testValid");
    control.setReturnValue("valid");

    control.replay();

    assertEquals(null, HttpUtil.getParameter(request, "testSpaceOnly", null));
    assertEquals(null, HttpUtil.getParameter(request, "testEmpty", null));
    assertEquals(null, HttpUtil.getParameter(request, "testNull", null));
    assertEquals("valid", HttpUtil.getParameter(request, "testValid", null));
  }
}