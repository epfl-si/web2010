/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.util;

import junit.framework.*;

/**
 * CharacterUtilTestCase
 *
 * @author  Laurent Boatto
 * @version $Id$
 */

public class CharacterUtilTestCase extends TestCase
{
  public void testIsInArray()
  {
    char[] array = {'a', 'b', 'c'};

    assertTrue(CharacterUtil.isInArray('a', array));
    assertTrue(CharacterUtil.isInArray('b', array));
    assertTrue(CharacterUtil.isInArray('c', array));
    assertFalse(CharacterUtil.isInArray('d', array));
    assertFalse(CharacterUtil.isInArray('e', array));
    assertFalse(CharacterUtil.isInArray('f', array));
  }
}
