/*
 * $Id$
 *
 * Copyright 2005 EPFL. All rights reserved.
 */

package com.baneo.core.util;

import com.baneo.core.test.*;

import java.io.*;
import java.util.*;

/**
 * FileUtilTestCase.
 *
 * @author Laurent Boatto
 */
public class FileUtilTestCase extends AbstractTestCase
{
  public void testGetFileAbsolutePath() throws Exception
  {
    assertNull(FileUtil.getFileAbsolutePath(StringUtil.randomString(16)));
  }

  public void testCopy() throws Exception
  {
    Random random = new Random();

    File fromFile = File.createTempFile("fromFile", String.valueOf(random.nextInt(1000000)));

    FileOutputStream output = new FileOutputStream(fromFile);

    for (int i = 0; i < 10000; i++)
    {
      output.write(8);
    }

    output.close();

    File toFile = File.createTempFile("toFile", String.valueOf(random.nextInt(1000000)));

    FileUtil.copy(fromFile, toFile);

    // We wait some second, otherwise toFile.length() is wrong
    Thread.sleep(3000);

    // Document length should be same
    assertEquals(fromFile.length(), toFile.length());

    // Both file should be deletable (stream closed!)
    assertTrue(fromFile.delete());
    assertTrue(toFile.delete());
  }
}
