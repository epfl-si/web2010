/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.util;

import com.baneo.core.test.*;
import org.apache.commons.beanutils.*;

import java.util.*;

/**
 * BeanUtilTestCase
 *
 * @author  Laurent Boatto
 * @version $Id$
 */

public class BeanUtilTestCase extends AbstractTestCase
{
  /**
   * testHaveSomeProperties
   *
   * @throws Exception
   */
  public void testHaveSomeProperties() throws Exception
  {
    Random random = new Random();

    MyBean bean1 = new MyBean();
    MyBean bean2 = new MyBean();

    String randomString = StringUtil.randomString(8);

    bean1.setMyDouble(random.nextDouble());
    bean1.setMyFloat(random.nextFloat());
    bean1.setMyInt(random.nextInt());
    bean1.setMyLong(random.nextLong());
    bean1.setMyString(randomString);

    PropertyUtils.copyProperties(bean2, bean1);

    bean2.setMyString("asdf" + randomString);

    assertFalse(BeanUtil.haveSamePropertiesValues(bean1, bean2));

    bean2.setMyString(randomString);

    assertTrue(BeanUtil.haveSamePropertiesValues(bean1, bean2));
  }

  /**
   * Bean for the test case, it has to be public.
   */
  public static class MyBean
  {
    private String _myString;
    private int _myInt;
    private long _myLong;
    private float _myFloat;
    private double _myDouble;
    private boolean _myBoolean;

    public String getMyString()
    {
      return _myString;
    }

    public void setMyString(String myString)
    {
      _myString = myString;
    }

    public int getMyInt()
    {
      return _myInt;
    }

    public void setMyInt(int myInt)
    {
      _myInt = myInt;
    }

    public long getMyLong()
    {
      return _myLong;
    }

    public void setMyLong(long myLong)
    {
      _myLong = myLong;
    }

    public float getMyFloat()
    {
      return _myFloat;
    }

    public void setMyFloat(float myFloat)
    {
      _myFloat = myFloat;
    }

    public double getMyDouble()
    {
      return _myDouble;
    }

    public void setMyDouble(double myDouble)
    {
      _myDouble = myDouble;
    }

    public boolean getMyBoolean()
    {
      return _myBoolean;
    }

    public void setMyBoolean(boolean myBoolean)
    {
      _myBoolean = myBoolean;
    }
  }
}