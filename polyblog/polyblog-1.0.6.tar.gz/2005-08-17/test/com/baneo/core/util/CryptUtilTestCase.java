/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.util;

import junit.framework.*;

/**
 * CryptUtilTestCase.
 *
 * @author Laurent Boatto
 * @version $Id$
 */

public class CryptUtilTestCase extends TestCase
{
  public void testMd5()
  {
    // With php, md5("gageure95") returns "182657e1bb7c670dd81a094f984655be"
    String str = "gageure95";
    String expectedHash = "182657e1bb7c670dd81a094f984655be";

    assertEquals(expectedHash, CryptUtil.md5(str));
  }
}
