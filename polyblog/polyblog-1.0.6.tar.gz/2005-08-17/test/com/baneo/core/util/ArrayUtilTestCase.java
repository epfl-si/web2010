/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.util;

import junit.framework.*;

/**
 * TestCase for ArrayUtil.
 *
 * @author  Laurent Boatto
 * @version $Id$
 */

public class ArrayUtilTestCase extends TestCase
{
  public ArrayUtilTestCase(String name)
  {
    super(name);
  }

  /**
   * Tests the mergeStringArrays method.
   *
   * @throws Exception if the test fails.
   */
  public void testMergeStringArrays() throws Exception
  {
    String[] array1 = {"tree", "bird", "sky", "grass", "flower"};
    String[] array2 = {"grass", "sky", "bird", "apple", "flower"};

    String[] result = ArrayUtil.mergeStringArrays(array1, array2);

    assertEquals(result.length, 6);

    assertEquals(result[0], "tree");
    assertEquals(result[1], "bird");
    assertEquals(result[2], "sky");
    assertEquals(result[3], "grass");
    assertEquals(result[4], "flower");
    assertEquals(result[5], "apple");
  }

  /**
   * Tests the equalsInArray method.
   *
   * @throws Exception if the test fails.
   */
  public void testIsInArray() throws Exception
  {
    String s1 = "hello";
    String s2 = "darling";

    String[] stringArray = {s1, new String("darling")};
    assertTrue(ArrayUtil.isInArray(s2, stringArray));

    Integer i1 = new Integer(5);
    Integer i2 = new Integer(5);

    Integer[] integerArray = {i1, i2};
    assertTrue(ArrayUtil.isInArray(i2, integerArray));
  }

  /**
   * Tests the equalsInArray method.
   *
   * @throws Exception if the test fails.
   */
  public void testIsInIntArray() throws Exception
  {
    int i = 5;

    int[] values = {1, 2, 3, 4, 5};

    assertTrue(ArrayUtil.isInArray(i, values));
    assertFalse(ArrayUtil.isInArray(6, values));
  }

  /**
   * testRemoveFromArray
   */
  public void testRemoveFromArray()
  {
    String[] subject = {"linux", "windows", "mac", "solaris"};
    String[] remove = {"windows", "beos"};

    String[] result = ArrayUtil.removeFromArray(subject, remove);

    assertEquals(3, result.length);
    assertEquals(result[0], "linux");
    assertEquals(result[1], "mac");
    assertEquals(result[2], "solaris");
  }
}