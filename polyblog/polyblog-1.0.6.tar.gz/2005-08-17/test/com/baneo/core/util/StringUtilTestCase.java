/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.util;

import junit.framework.*;

/**
 * StringUtilTestCase.
 *
 * @author Laurent Boatto
 * @version $Id$
 */

public class StringUtilTestCase extends TestCase
{
  public StringUtilTestCase(String name)
  {
    super(name);
  }

  public void testLowerCaseFirstChar()
  {
    assertEquals("bob", StringUtil.lowerCaseFirstChar("Bob"));
  }

  public void testReplaceQuote() throws Exception
  {
    String test = "\" bob \"";

    String result = StringUtil.escapeDoubleQuote(test);

    assertEquals(result, "&quot; bob &quot;");
  }

  public void testRemoveSpaces() throws Exception
  {
    assertEquals("12345", StringUtil.removeWhitespace(" 1    2  3  4 5     "));
    assertEquals("12345", StringUtil.removeWhitespace("12345"));
    assertEquals("", StringUtil.removeWhitespace("    "));
    assertEquals("", StringUtil.removeWhitespace(""));
  }

  public void testUpperCaseFirstChar()
  {
    assertEquals("Bob", StringUtil.upperCaseFirstChar("bob"));
    assertEquals("", StringUtil.upperCaseFirstChar(""));
    assertEquals(" ", StringUtil.upperCaseFirstChar(" "));
    assertEquals(null, StringUtil.upperCaseFirstChar(null));
  }

  public void testNewLineToBr()
  {
    assertEquals(null, StringUtil.newLineToBr(null));
    assertEquals("Hello<br>moto", StringUtil.newLineToBr("Hello\nmoto"));
  }
}
