/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package com.baneo.core.security.role;

import com.baneo.core.test.*;
import com.baneo.core.util.*;

import java.util.*;

/**
 * HibernateRoleManagerTestCase
 *
 * @author  Laurent Boatto
 * @version $Id$
 */

public class HibernateRoleManagerTestCase extends AbstractTestCase
{
  private static final HibernateRoleManager _manager = HibernateRoleManager.instance();

  /**
   * testInsert
   *
   * @throws java.lang.Exception
   */
  public void testInsert() throws Exception
  {
    Random random = new Random();
    int userId = 10000000 + random.nextInt(10000000);
    RoleEntry entry = new RoleEntry();
    entry.setUserId(userId);
    entry.setRole("administrator");
    _manager.insert(entry);

    List userRoles = _manager.findByUserId(userId);

    assertTrue(userRoles.contains(entry));

    if (cleanupAfterTest())
    {
      _manager.delete(entry);
    }
  }

  /**
   * testDelete
   *
   * @throws java.lang.Exception
   */
  public void testDelete() throws Exception
  {
    Random random = new Random();
    int userId = 10000000 + random.nextInt(10000000);
    RoleEntry entry = new RoleEntry();
    entry.setUserId(userId);
    entry.setRole("administrator");
    _manager.insert(entry);

    List userRoles = _manager.findByUserId(userId);

    // Try to remove the entry directly, this is forbidden and should fail
    try
    {
      userRoles.remove(entry);
      fail();
    }
    catch (UnsupportedOperationException e)
    {
    }

    _manager.delete(entry);
    userRoles = _manager.findByUserId(userId);

    assertNull(userRoles);
  }

  /**
   * testFindByUserId
   *
   * @throws java.lang.Exception
   */
  public void testFindByUserId() throws Exception
  {
    Random random = new Random();
    int userId = 10000000 + random.nextInt(10000000);

    for (int i = 0; i < 100; i++)
    {
      RoleEntry entry = new RoleEntry();
      entry.setUserId(userId);
      entry.setRole("role" + i);
      _manager.insert(entry);
    }

    List userRoles = _manager.findByUserId(userId);

    assertEquals(100, userRoles.size());

    if (cleanupAfterTest())
    {
      for (int i = 0; i < userRoles.size(); i++)
      {
        RoleEntry entry = (RoleEntry) userRoles.get(i);
        _manager.delete(entry);
      }
    }
  }

  /**
   * testIsUserInRole
   *
   * @throws java.lang.Exception
   */
  public void testIsUserInRole() throws Exception
  {
    Random random = new Random();
    int userId = 10000000 + random.nextInt(10000000);
    RoleEntry entry = new RoleEntry();
    entry.setUserId(userId);
    String role = StringUtil.randomString(5).toLowerCase();
    entry.setRole(role);
    _manager.insert(entry);

    // a null or empty role should always return false
    assertFalse(_manager.isUserInRole(userId, null));
    assertFalse(_manager.isUserInRole(userId, ""));

    assertTrue(_manager.isUserInRole(userId, role));
    _manager.delete(entry);
    assertFalse(_manager.isUserInRole(userId, role));

    assertFalse(_manager.isUserInRole(999999, StringUtil.randomString(8)));
  }
}
