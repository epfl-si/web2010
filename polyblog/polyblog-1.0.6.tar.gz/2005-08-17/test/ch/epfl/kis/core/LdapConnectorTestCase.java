package ch.epfl.kis.core;

import ch.epfl.kis.polyblog.service.*;
import com.baneo.core.test.*;
import com.novell.ldap.*;

import java.util.*;

/**
 * LdapConnectorTestCase.
 *
 * @author Laurent Boatto
 */
public class LdapConnectorTestCase extends AbstractTestCase
{

  public void testFind() throws Exception
  {
    Collection results = LdapConnectorFactory.getLdapConnector().find("o=EPFL,c=CH", LDAPConnection.SCOPE_ONE, "(objectclass=posixGroup)");

    for (Iterator iterator = results.iterator(); iterator.hasNext();)
    {
      LDAPEntry entry = (LDAPEntry) iterator.next();
    }

    results = LdapConnectorFactory.getLdapConnector().find("o=EPFL,c=CH", LDAPConnection.SCOPE_SUB, "(&(ou=P)(objectClass=posixGroup))");

    for (Iterator iterator = results.iterator(); iterator.hasNext();)
    {
      LDAPEntry entry = (LDAPEntry) iterator.next();
      debug("entry = " + entry);
    }
  }
}
