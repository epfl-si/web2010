package ch.epfl.kis.polyblog.util;

import ch.epfl.kis.polyblog.model.*;
import com.baneo.core.security.*;
import com.baneo.core.test.*;

/**
 * Base test case for all the polyblog application test cases, providing
 * some common methods.
 *
 * @author Laurent Boatto
 */
public abstract class AbstractBlogTestCase extends AbstractTestCase
{
  /**
   * Creates a valid ISecurityContext with a random user.
   *
   * @return a the user contained importer the ISecurityContext.
   */
  protected User setValidUserContext()
  {
    int userId = _random.nextInt(10000000);
    User user = new DbUser(String.valueOf(userId));
    setSecurityContext("", userId, "", "");
    TestCaseSecurityContext context = (TestCaseSecurityContext) SecurityContextManager.getISecurityContext();
    context.setPrincipal(user);
    return user;
  }
}