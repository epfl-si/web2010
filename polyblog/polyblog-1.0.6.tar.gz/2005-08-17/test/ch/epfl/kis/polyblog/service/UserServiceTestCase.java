/*
 * $Id$
 *
 * Copyright 2005 EPFL. All rights reserved.
 */

package ch.epfl.kis.polyblog.service;

import ch.epfl.kis.polyblog.model.*;
import com.baneo.core.test.*;

/**
 * UserServiceTestCase.
 *
 * @author Laurent Boatto
 */
public class UserServiceTestCase extends AbstractTestCase
{
  public void testGet() throws Exception
  {
    int sciper = 157489;

    User user = UserService.instance().get(String.valueOf(sciper), LdapUser.class);

    assertEquals(user.getEmail(), "laurent.boatto@epfl.ch");
    assertEquals(user.getFirstName() + " " + user.getLastName(), "Laurent Boatto");
    assertEquals(user.getId(), sciper);
    assertEquals(user.getUsername(), "boatto");
  }
}
