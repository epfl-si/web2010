package ch.epfl.kis.polyblog.search;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.service.*;
import ch.epfl.kis.polyblog.util.*;
import com.baneo.core.persistance.*;
import com.baneo.core.util.*;

import java.util.*;

/**
 * ArticleQueryBuilderTestCase.
 *
 * @author Laurent Boatto
 */
public class ArticleQueryBuilderTestCase extends AbstractBlogTestCase
{
  private static BlogService _blogService;
  private static ArticleService _articleService;

  protected void setUp() throws Exception
  {
    super.setUp();
    setSecurityContext(StringUtil.randomString(8), _random.nextInt(10000000), "", "");
    _blogService = BlogService.instance();
    _articleService = ArticleService.instance();
  }

  public void testBuildQuery() throws Exception
  {
    User user = setValidUserContext();

    Map parameters = new HashMap();

    Blog blog = new Blog();
    blog.setLabel(StringUtil.randomString(8, _random));
    _blogService.insert(blog);

    String word1 = "l'�t�";
    String word2 = StringUtil.randomString(8, _random);
    String word3 = StringUtil.randomString(8, _random);

    Article article1 = new Article();
    Article article2 = new Article();

    article1.setTitle(word1 + " " + word2);
    article2.setContent(word3);
    article1.setBlogId(blog.getId());
    article2.setBlogId(blog.getId());

    _articleService.insert(article1);
    _articleService.insert(article2);

    parameters.put(ArticleQueryBuilder.PARAMETER_WORDS, word1);
    parameters.put(ArticleQueryBuilder.PARAMETER_BLOG_ID, String.valueOf(blog.getId()));

    String query = ArticleQueryBuilder.buildFullTextQuery(parameters, false);

    debug(query);

    IPersistanceManager persistanceManager = PersistanceManagerFactory.getIPersistanceManager();

    Collection results = persistanceManager.findByQuery(query, null);


    if (cleanupAfterTest())
    {
      _blogService.delete(blog);
    }
  }
}