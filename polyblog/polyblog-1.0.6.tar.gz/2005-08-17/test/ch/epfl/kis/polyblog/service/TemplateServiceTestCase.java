package ch.epfl.kis.polyblog.service;

import ch.epfl.kis.polyblog.model.*;
import com.baneo.core.security.*;
import com.baneo.core.test.*;
import com.baneo.core.util.*;

/**
 * TemplateServiceTestCase.
 *
 * @author Laurent Boatto
 */
public class TemplateServiceTestCase extends AbstractTestCase
{
  private static BlogService _blogService;
  private static ArticleService _articleService;
  private static CategoryService _categoryService;

  protected void setUp() throws Exception
  {
    super.setUp();
    _blogService = BlogService.instance();
    _articleService = ArticleService.instance();
    _categoryService = CategoryService.instance();
  }

  public void testGenerateRss2Feed() throws Exception
  {
    User user = setValidUserContext();

    Blog blog = new Blog();
    blog.setLabel("L�l� <b> l�");
    blog.setName("test");
    blog.setDescription("hihi <b> l��l�");

    _blogService.insert(blog);

    Category category1 = new Category();
    category1.setLabel("l�l�");
    category1.setBlogId(blog.getId());
    _categoryService.insert(category1);

    Article article1 = new Article();
    Article article2 = new Article();
    Article article3 = new Article();
    article1.setStatusId(Article.STATUS_PUBLISH);
    article2.setStatusId(Article.STATUS_PUBLISH);
    article3.setStatusId(Article.STATUS_PUBLISH);
    article1.setBlogId(blog.getId());
    article2.setBlogId(blog.getId());
    article3.setBlogId(blog.getId());
    article1.setCategoryId(category1.getId());
    article1.setTitle("C'est l'�t� bande de 駰#�@5<<");
    article2.setTitle("Colchiques dans les pr�s, fleurissent, fleurissent");
    article3.setTitle("Pierre r�le r�le");
    article1.setContent(StringUtil.randomString(8));
    article2.setContent(StringUtil.randomString(8));
    article3.setContent(StringUtil.randomString(8));
    _articleService.insert(article1);
    _articleService.insert(article2);
    _articleService.insert(article3);

    String feed = TemplateService.generateRss2Feed(blog);
    debug(feed);

    // cleanup
    _blogService.delete(blog);
  }

  /**
   * Creates SubscriptionService valid ISecurityContext with SubscriptionService random user.
   *
   * @return SubscriptionService the user contained importer the ISecurityContext.
   */
  private User setValidUserContext()
  {
    int userId = _random.nextInt(10000000);
    User user = new DbUser(String.valueOf(userId));
    setSecurityContext("", userId, "", "");
    TestCaseSecurityContext context = (TestCaseSecurityContext) SecurityContextManager.getISecurityContext();
    context.setPrincipal(user);
    return user;
  }
}