package ch.epfl.kis.polyblog.system;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.service.*;
import ch.epfl.kis.polyblog.util.*;
import ch.epfl.kis.polyblog.security.*;

import java.util.*;

import com.baneo.core.test.*;

/**
 * EmailServiceTestCase.
 *
 * @author Laurent Boatto
 */
public class EmailServiceTestCase extends AbstractTestCase
{
  /**
   * testSendSubscribeForArticlesAndCommentsConfirmation
   *
   * @throws Exception
   */
  public void testSendSubscribeForArticlesAndCommentsConfirmation() throws Exception
  {
    Subscription subscription = DataGenerator.getRandomSubscription(null);
    Blog blog = DataGenerator.getRandomBlog();

    EmailService.sendSubscribeForArticlesAndCommentsConfirmation(subscription, blog, Locale.FRENCH);
  }

  /**
   * testSendSubscribeForArticlesConfirmation
   *
   * @throws Exception
   */
  public void testSendSubscribeForArticlesConfirmation() throws Exception
  {
    Subscription subscription = DataGenerator.getRandomSubscription(null);
    Blog blog = DataGenerator.getRandomBlog();

    EmailService.sendSubscribeForArticlesConfirmation(subscription, blog, Locale.FRENCH);
  }

  /**
   * testSendSubscribeForCommentsConfirmation
   *
   * @throws Exception
   */
  public void testSendSubscribeForCommentsConfirmation() throws Exception
  {
    Subscription subscription = DataGenerator.getRandomSubscription(null);
    Blog blog = DataGenerator.getRandomBlog();

    EmailService.sendSubscribeForCommentsConfirmation(subscription, blog, Locale.FRENCH);
  }

  /**
   * testSendNewArticleNotification
   *
   * @throws Exception
   */
  public void testSendNewArticleNotification() throws Exception
  {
    SecurityService.setValidUserContext();

    Blog blog = DataGenerator.insertRandomBlog();
    DataGenerator.insertRandomSubscription(blog);

    Article article = DataGenerator.getRandomArticle(blog);

    EmailService.sendNewArticleNotification(article);
  }

  /**
   * testSendNewCommentNotification
   *
   * @throws Exception
   */
  public void testSendNewCommentNotification() throws Exception
  {
    SecurityService.setValidUserContext();

    Blog blog = DataGenerator.insertRandomBlog();
    DataGenerator.insertRandomSubscription(blog);

    Article article = DataGenerator.insertRandomArticle(blog);

    Comment comment = DataGenerator.getRandomComment(article);

    EmailService.sendNewCommentNotification(comment);
  }
}