package ch.epfl.kis.polyblog.util;

import ch.epfl.kis.polyblog.model.*;
import com.baneo.core.security.*;
import com.baneo.core.service.*;
import com.baneo.core.util.*;

/**
 * AbstractBlogBusinessObjectManagerTestCase.
 *
 * @author Laurent Boatto
 */
public abstract class AbstractBlogBusinessObjectManagerTestCase extends BusinessObjectManagerTestCase
{
  /**
   * Creates a valid ISecurityContext with a random user.
   *
   * @return a the user contained importer the ISecurityContext.
   */
  protected User setValidUserContext()
  {
    User user = DataGenerator.getRandomUser();
    setSecurityContext("", user.getId(), "", "");
    TestCaseSecurityContext context = (TestCaseSecurityContext) SecurityContextManager.getISecurityContext();
    context.setPrincipal(user);
    return user;
  }
}
