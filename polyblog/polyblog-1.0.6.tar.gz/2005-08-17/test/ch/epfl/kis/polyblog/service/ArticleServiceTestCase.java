/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package ch.epfl.kis.polyblog.service;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.security.*;
import ch.epfl.kis.polyblog.util.*;
import ch.epfl.kis.polyblog.system.*;
import com.baneo.core.meta.*;
import com.baneo.core.persistance.*;
import com.baneo.core.security.*;
import com.baneo.core.service.*;
import com.baneo.core.util.*;

import java.lang.reflect.*;
import java.util.*;

/**
 * Test case for the BlogManager.
 *
 * @author  Laurent Boatto
 * @version $Id$
 */

public class ArticleServiceTestCase extends AbstractBlogBusinessObjectManagerTestCase
{
  private ArticleService _articleService;
  private CategoryService _categoryService;
  private UserService _userService;
  private static BlogService _blogService;
  private Article _article;
  private Map _values;

  /**
   * Junit setUp, called at the beginning of every testcase.
   *
   * @throws java.lang.Exception
   */
  protected void setUp() throws Exception
  {
    super.setUp();
    setCleanupAfterTest(true);
    _article = new Article();
    _values = super.populate(_article);
    _blogService = BlogService.instance();
    _articleService = ArticleService.instance();
    _categoryService = CategoryService.instance();
    _userService = UserService.instance();
  }

  protected BusinessObjectManager getBusinessObjectManager()
  {
    return _articleService;
  }

  /**
   * Junit tearDown, called at the end of every testcase.
   *
   * @throws java.lang.Exception
   */
  protected void tearDown() throws Exception
  {
    _article = null;
    _values = null;
  }

  /**
   * testFindLastPublic
   *
   * @throws Exception
   */
  public void testFindLastPublic() throws Exception
  {
    User user = setValidUserContext();
    Blog publicBlog = insertRandomBlog();
    Blog privateBlog = insertRandomBlog();

    publicBlog.setIsPublic(true);
    _blogService.update(publicBlog);
    privateBlog.setIsPublic(false);
    _blogService.update(privateBlog);


    Article publicArticle = new Article();
    Article draftArticle = new Article();
    Article privateArticle = new Article();

    publicArticle.setBlogId(publicBlog.getId());
    draftArticle.setBlogId(publicBlog.getId());
    privateArticle.setBlogId(privateBlog.getId());

    publicArticle.setStatusId(Article.STATUS_PUBLISH);
    draftArticle.setStatusId(Article.STATUS_DRAFT);
    privateArticle.setStatusId(Article.STATUS_PUBLISH);

    _articleService.insert(publicArticle);
    _articleService.insert(draftArticle);
    _articleService.insert(privateArticle);

    Collection lastPublicArticles = _articleService.findLastPublic();

    assertEquals(publicArticle, lastPublicArticles.iterator().next());

    assertFalse(lastPublicArticles.contains(draftArticle));
    assertFalse(lastPublicArticles.contains(privateArticle));

    _blogService.delete(publicBlog);
    _blogService.delete(privateBlog);
  }

  /**
   * Tests the insert method.

   * @throws java.lang.Exception
   */
  public void testInsert() throws Exception
  {
    User user = setValidUserContext();
    user.setFirstName("firstName");
    user.setLastName("lastName");
    _values.put("authorFirstName", "firstName");
    _values.put("authorLastName", "lastName");

    // we must insert SubscriptionService valid blog
    Blog blog = insertRandomBlog();

    _article.setBlogId(blog.getId());

    _values.put("blogId", new Integer(blog.getId()));

    _articleService.insert(_article);
    Article last = _articleService.findLast();
    super.testInsert(last, _values);

    // The publication date should have been set to the current date
    DateUtil.isSameTime(last.getPublicationDate(), new java.util.Date(), 10000);

    // the current principal should have the owner role on the article
    SecurityService.hasOwnerRole(last);

    if (cleanupAfterTest())
    {
      _blogService.delete(blog);
      assertNull(_articleService.get(last.getId()));
    }
  }

  /**
   * Tests the insert method.

   * @throws java.lang.Exception
   */
  public void testInsertDraftNotification() throws Exception
  {
    User user = setValidUserContext();

    // we must insert SubscriptionService valid blog
    Blog blog = insertRandomBlog();

    Subscription subscription = SubscriptionService.instance().subscribeForArticles(blog, Constants.MAIL_TEST_EMAIL, null);
    SubscriptionService.instance().confirmSubscribe(subscription);

    _article.setBlogId(blog.getId());
    _article.setTitle("This article should NOT be sent");
    _article.setStatusId(Article.STATUS_DRAFT);
    _articleService.insert(_article);

    if (cleanupAfterTest())
    {
      _blogService.delete(blog);
      assertNull(_articleService.get(_article.getId()));
    }
  }

  /**
   * Tests the insert method.

   * @throws java.lang.Exception
   */
  public void testInsertPublishNotification() throws Exception
  {
    User user = setValidUserContext();

    // we must insert SubscriptionService valid blog
    Blog blog = insertRandomBlog();

    Subscription subscription = SubscriptionService.instance().subscribeForArticles(blog, Constants.MAIL_TEST_EMAIL, null);
    SubscriptionService.instance().confirmSubscribe(subscription);

    _article.setBlogId(blog.getId());
    _article.setTitle("This article should be sent");
    _article.setStatusId(Article.STATUS_PUBLISH);
    _articleService.insert(_article);

    if (cleanupAfterTest())
    {
      _blogService.delete(blog);
      assertNull(_articleService.get(_article.getId()));
    }
  }

  /**
   * Inserts SubscriptionService random blog and returns it.
   *
   * @return
   * @throws MetaManagerException
   * @throws IllegalAccessException
   * @throws InvocationTargetException
   * @throws PersistanceException
   */
  private Blog insertRandomBlog() throws Exception
  {
    Blog blog = new Blog();
    populate(blog);
    _blogService.insert(blog);
    return blog;
  }

  public void testFindByMonthMap() throws Exception
  {
    User user = setValidUserContext();
    Blog blog1 = insertRandomBlog();
    Blog blog2 = insertRandomBlog();

    Article january1_1 = new Article();
    Article january1_2 = new Article();
    Article january1_3 = new Article();
    Article january2 = new Article();

    populate(january1_1);
    populate(january1_2);
    populate(january1_3);
    populate(january2);

    january1_1.setStatusId(Article.STATUS_PUBLISH);
    january1_2.setStatusId(Article.STATUS_PUBLISH);
    january1_3.setStatusId(Article.STATUS_PUBLISH);
    january2.setStatusId(Article.STATUS_PUBLISH);

    january1_1.setBlogId(blog1.getId());
    january1_2.setBlogId(blog1.getId());
    january1_3.setBlogId(blog2.getId());
    january2.setBlogId(blog1.getId());

    _articleService.insert(january1_1);
    _articleService.insert(january1_2);
    _articleService.insert(january1_3);
    _articleService.insert(january2);


    Calendar january1Date = new GregorianCalendar(2003, 00, 01, 00, 00, 00);
    Calendar january2Date = new GregorianCalendar(2003, 00, 2, 23, 59, 59);
    january1_1.setPublicationDate(january1Date.getTime());
    january1_2.setPublicationDate(january1Date.getTime());
    january1_3.setPublicationDate(january1Date.getTime());
    january2.setPublicationDate(january2Date.getTime());
    _articleService.update(january1_1);
    _articleService.update(january1_2);
    _articleService.update(january1_3);
    _articleService.update(january2);

    Map byJanuary = _articleService.findByMonthMap(blog1, january1Date.getTime());

    Collection byJanuary1 = (Collection) byJanuary.get("2003-01-01");

    assertNotNull(byJanuary1);
    assertTrue(byJanuary1.contains(january1_1));
    assertTrue(byJanuary1.contains(january1_2));
    // Not for the same blog
    assertFalse(byJanuary1.contains(january1_3));
    assertFalse(byJanuary1.contains(january2));

    Collection byJanuary2 = (Collection) byJanuary.get("2003-01-02");

    assertNotNull(byJanuary2);
    assertFalse(byJanuary2.contains(january1_1));
    assertFalse(byJanuary2.contains(january1_2));
    assertFalse(byJanuary2.contains(january1_3));
    assertTrue(byJanuary2.contains(january2));

    // cleanup
    _blogService.delete(blog1);
    _blogService.delete(blog2);
  }

  public void testFindByMonth() throws Exception
  {
    User user = setValidUserContext();
    Blog blog1 = insertRandomBlog();
    Blog blog2 = insertRandomBlog();

    Article january1 = new Article();
    Article january31 = new Article();
    Article january3 = new Article();
    Article february1 = new Article();
    Article february2 = new Article();
    populate(january1);
    populate(january31);
    populate(february1);
    populate(february2);

    january1.setStatusId(Article.STATUS_PUBLISH);
    january31.setStatusId(Article.STATUS_PUBLISH);
    january3.setStatusId(Article.STATUS_PUBLISH);
    february1.setStatusId(Article.STATUS_PUBLISH);
    february2.setStatusId(Article.STATUS_PUBLISH);

    january1.setBlogId(blog1.getId());
    january31.setBlogId(blog1.getId());
    january3.setBlogId(blog2.getId());
    february1.setBlogId(blog1.getId());
    february2.setBlogId(blog1.getId());
    _articleService.insert(january1);
    _articleService.insert(january31);
    _articleService.insert(january3);
    _articleService.insert(february1);
    _articleService.insert(february2);

    Calendar january1Date = new GregorianCalendar(2003, 00, 01, 00, 00, 00);
    Calendar january31Date = new GregorianCalendar(2003, 00, 31, 23, 59, 59);
    Calendar january3Date = new GregorianCalendar(2003, 00, 03, 23, 59, 59);
    Calendar february1Date = new GregorianCalendar(2003, 01, 01, 00, 00, 00);
    Calendar february2Date = new GregorianCalendar(2003, 01, 02, 23, 59, 59);
    january1.setPublicationDate(january1Date.getTime());
    january31.setPublicationDate(january31Date.getTime());
    january3.setPublicationDate(january3Date.getTime());
    february1.setPublicationDate(february1Date.getTime());
    february2.setPublicationDate(february2Date.getTime());
    _articleService.update(january1);
    _articleService.update(january31);
    _articleService.update(january3);
    _articleService.update(february1);
    _articleService.update(february2);

    Date januaryMonth = new GregorianCalendar(2003, 00, 5).getTime();
    Date februaryMonth = new GregorianCalendar(2003, 01, 27).getTime();

    Collection byJanuaryMonth = _articleService.findByMonth(blog1, januaryMonth);

    assertNotNull(byJanuaryMonth);
    assertTrue(byJanuaryMonth.contains(january1));
    assertTrue(byJanuaryMonth.contains(january31));
    assertFalse(byJanuaryMonth.contains(january3));
    assertFalse(byJanuaryMonth.contains(february1));
    assertFalse(byJanuaryMonth.contains(february2));

    Collection byFebruaryMonth = _articleService.findByMonth(blog1, februaryMonth);

    assertNotNull(byFebruaryMonth);
    assertFalse(byFebruaryMonth.contains(january1));
    assertFalse(byFebruaryMonth.contains(january31));
    assertFalse(byFebruaryMonth.contains(january3));
    assertTrue(byFebruaryMonth.contains(february1));
    assertTrue(byFebruaryMonth.contains(february2));

    // cleanup
    _blogService.delete(blog1);
    _blogService.delete(blog2);
  }


  /**
   * testFindByBlogId
   *
   * @throws Exception
   */
  public void testFindByBlog() throws Exception
  {
    User user = setValidUserContext();

    // we must insert SubscriptionService valid blog
    Blog blog = new Blog();
    populate(blog);
    _blogService.insert(blog);

    Article article1 = new Article();
    Article article2 = new Article();
    Article article3 = new Article();
    populate(article1);
    populate(article2);
    populate(article3);

    article1.setBlogId(blog.getId());
    article2.setBlogId(blog.getId());
    article3.setBlogId(blog.getId());

    article1.setTitle("z");
    article2.setTitle("y");
    article3.setTitle("x");

    _articleService.insert(article1);
    _articleService.insert(article2);
    _articleService.insert(article3);

    Collection articles = _articleService.findByBlog(blog, "title ASC", 0, 10);
    Iterator it = articles.iterator();

    // the order is important
    assertEquals(article3, it.next());
    assertEquals(article2, it.next());
    assertEquals(article1, it.next());

    if (cleanupAfterTest())
    {
      _blogService.instance().delete(blog);
      assertNull(_articleService.get(article1.getId()));
      assertNull(_articleService.get(article2.getId()));
      assertNull(_articleService.get(article3.getId()));
    }
  }

  /**
   * testFindLastByBlog
   *
   * @throws Exception
   */
  public void testFindLastByBlog() throws Exception
  {
    User user = new LdapUser(String.valueOf(_random.nextInt(10000000)), null);
    setSecurityContext(StringUtil.randomString(8), _random.nextInt(10000000), "", "");
    TestCaseSecurityContext context = (TestCaseSecurityContext) SecurityContextManager.getISecurityContext();
    context.setPrincipal(user);

    Blog blog1 = new Blog();
    Blog blog2 = new Blog();
    populate(blog1);
    populate(blog2);
    _blogService.insert(blog1);
    _blogService.insert(blog2);

    Article article1 = new Article();
    Article article2 = new Article();
    Article article3 = new Article();
    Article article4 = new Article();
    Article article5 = new Article();
    populate(article1);
    populate(article2);
    populate(article3);
    populate(article4);
    populate(article5);
    article1.setStatusId(Article.STATUS_PUBLISH);
    article2.setStatusId(Article.STATUS_DRAFT);
    article3.setStatusId(Article.STATUS_PUBLISH);
    article4.setStatusId(Article.STATUS_PUBLISH);
    article5.setStatusId(Article.STATUS_PUBLISH);
    article1.setBlogId(blog1.getId());
    article2.setBlogId(blog1.getId());
    article3.setBlogId(blog1.getId());
    article4.setBlogId(blog2.getId());
    article5.setBlogId(blog2.getId());
    _articleService.insert(article1);
    _articleService.insert(article2);
    _articleService.insert(article3);
    _articleService.insert(article4);
    _articleService.insert(article5);

    Collection last = _articleService.findLastByBlog(blog1, new Date(), Constants.ARTICLE_DISPLAY_NUM);

    assertTrue(last.contains(article1));
    assertFalse(last.contains(article2));
    assertTrue(last.contains(article3));
    assertFalse(last.contains(article4));
    assertFalse(last.contains(article5));

    // cleanup
    _blogService.delete(blog1);
    assertNull(_articleService.get(article1.getId()));
    assertNull(_articleService.get(article2.getId()));
    assertNull(_articleService.get(article3.getId()));
    _articleService.delete(article4);
    _articleService.delete(article5);
  }

  /**
   * testFindLastByCategory
   * @throws Exception
   */
  public void testFindLastByCategory() throws Exception
  {
    User user = setValidUserContext();

    // We create 2 blogs..
    Blog blog1 = new Blog();
    Blog blog2 = new Blog();

    populate(blog1);
    populate(blog2);

    _blogService.insert(blog1);
    _blogService.insert(blog2);

    // 3 categories..
    Category category1 = new Category();
    Category category2 = new Category();
    Category category3 = new Category();

    populate(category1);
    populate(category2);
    populate(category3);

    category1.setBlogId(blog1.getId());
    category2.setBlogId(blog1.getId());
    category3.setBlogId(blog1.getId());

    _categoryService.insert(category1);
    _categoryService.insert(category2);
    _categoryService.insert(category3);

    // And 5 articles..
    Article article1 = new Article();
    Article article2 = new Article();
    Article article3 = new Article();
    Article article4 = new Article();
    Article article5 = new Article();

    populate(article1);
    populate(article2);
    populate(article3);
    populate(article4);

    article1.setStatusId(Article.STATUS_PUBLISH);
    article2.setStatusId(Article.STATUS_PUBLISH);
    article3.setStatusId(Article.STATUS_PUBLISH);
    article4.setStatusId(Article.STATUS_PUBLISH);
    article4.setStatusId(Article.STATUS_DRAFT);

    article1.setBlogId(blog1.getId());
    article2.setBlogId(blog1.getId());
    article3.setBlogId(blog1.getId());
    article4.setBlogId(blog2.getId());
    article5.setBlogId(blog1.getId());

    article1.setCategoryId(category1.getId());
    article2.setCategoryId(category1.getId());
    article3.setCategoryId(category2.getId());
    article4.setCategoryId(category3.getId());
    article4.setCategoryId(category1.getId());

    // Sleep between insertion to test order
    _articleService.insert(article1);
    Thread.sleep(1000);
    _articleService.insert(article2);
    Thread.sleep(1000);
    _articleService.insert(article3);
    Thread.sleep(1000);
    _articleService.insert(article4);
    Thread.sleep(1000);
    _articleService.insert(article5);

    Collection lastByCategory = _articleService.findLastByCategory(category1);
    Iterator it = lastByCategory.iterator();

    // The order is important
    assertEquals(article2, it.next());
    assertEquals(article1, it.next());
    assertFalse(lastByCategory.contains(article3));
    assertFalse(lastByCategory.contains(article4));
    // it's importer draft mode, should not be importer the last
    assertFalse(lastByCategory.contains(article5));

    if (cleanupAfterTest())
    {
      _blogService.delete(blog1);
      _blogService.delete(blog2);
    }
  }

  /**
   * Test the case where an article is updated from draft to publish mode.
   */
  public void testUpdateDraftToPublishPublicationDate() throws Exception
  {
    User user = setValidUserContext();

    Blog blog = new Blog();
    populate(blog);
    _blogService.insert(blog);

    Article article = new Article();
    populate(article);
    article.setBlogId(blog.getId());
    article.setStatusId(Article.STATUS_DRAFT);
    _articleService.insert(article);

    Thread.sleep(3000);

    article.setStatusId(Article.STATUS_PUBLISH);
    _articleService.update(article);

    assertTrue(DateUtil.isSameTime(System.currentTimeMillis(), article.getPublicationDate().getTime(), 500));

    // cleanup
    _blogService.delete(blog);
    assertNull(_articleService.get(article.getId()));
  }

  /**
   * Test the case where an article is updated from draft to publish mode.
   */
  public void testUpdateDraftToPublishNotification() throws Exception
  {
    User user = setValidUserContext();

    Blog blog = new Blog();
    populate(blog);
    _blogService.insert(blog);

    Subscription subscription = SubscriptionService.instance().subscribeForArticles(blog, Constants.MAIL_TEST_EMAIL, null);
    SubscriptionService.instance().confirmSubscribe(subscription);

    _article.setBlogId(blog.getId());
    _article.setStatusId(Article.STATUS_DRAFT);

    _articleService.insert(_article);

    Article last = _articleService.findLast();
    last.setStatusId(Article.STATUS_PUBLISH);
    last.setTitle("PUBLISH MODE");
    _articleService.update(last);

    if (cleanupAfterTest())
    {
      _blogService.delete(blog);
    }
  }

  /**
   * testFindByBlogIdCount
   * @throws Exception
   */
  public void testFindByBlogIdCount() throws Exception
  {
    User user = setValidUserContext();

    // we must insert SubscriptionService valid blog1
    Blog blog1 = new Blog();
    Blog blog2 = new Blog();
    populate(blog1);
    populate(blog2);
    _blogService.insert(blog1);
    _blogService.insert(blog2);
    int blogId1 = blog1.getId();
    int blogId2 = blog2.getId();

    Article article1 = new Article();
    Article article2 = new Article();
    Article article3 = new Article();
    populate(article1);
    populate(article2);
    populate(article3);
    article1.setBlogId(blogId1);
    article2.setBlogId(blogId1);
    article3.setBlogId(blogId2);

    int countBefore = _articleService.findByBlogIdCount(blogId1);

    _articleService.insert(article1);
    _articleService.insert(article2);
    _articleService.insert(article3);

    int countAfter = _articleService.findByBlogIdCount(blogId1);

    assertEquals(countAfter, countBefore + 2);

    if (cleanupAfterTest())
    {
      _blogService.delete(blog1);
      _blogService.delete(blog2);
    }
  }

  /**
   * Tests the update method.
   *
   * @throws java.lang.Exception
   */
  public void testUpdate() throws Exception
  {
    User user = setValidUserContext();

    // we must insert SubscriptionService valid blog
    Blog blog = new Blog();
    populate(blog);
    _blogService.insert(blog);

    _article.setBlogId(blog.getId());

    _articleService.insert(_article);
    Article last = _articleService.findLast();
    // We repopulate the bean to change the values
    _values = super.populate(last);

    _articleService.update(last);
    super.testUpdate(last, _values);

    if (cleanupAfterTest())
    {
      _blogService.delete(blog);
    }
  }


  /**
   * Tests the delete method.
   *
   * @throws java.lang.Exception
   */
  public void testDelete() throws Exception
  {
    User user = setValidUserContext();

    // we must insert SubscriptionService valid blog
    Blog blog = new Blog();
    populate(blog);
    _blogService.insert(blog);

    _article.setBlogId(blog.getId());

    _articleService.insert(_article);
    Article inserted = _article;

    // Deletes the _article and make sure that only one _article
    // has been deleted.
    int countBefore = _articleService.count();
    _articleService.delete(inserted);
    int countAfter = _articleService.count();
    assertTrue(countBefore == (countAfter + 1));

    assertNull(_articleService.get(inserted.getId()));

    if (cleanupAfterTest())
    {
      _blogService.delete(blog);
    }
  }

  public static void main(String[] args)
  {
    junit.textui.TestRunner.run(ArticleServiceTestCase.class);
  }
}