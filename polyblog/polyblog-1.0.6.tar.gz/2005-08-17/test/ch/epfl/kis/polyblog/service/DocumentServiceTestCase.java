package ch.epfl.kis.polyblog.service;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.util.*;
import com.baneo.core.service.*;

import java.util.*;

/**
 * DocumentServiceTestCase.
 *
 * @author Laurent Boatto
 */
public class DocumentServiceTestCase extends AbstractBlogBusinessObjectManagerTestCase
{
  private DocumentService _documentService;
  private ArticleService _articleService;
  private BlogService _blogService;

  protected void setUp() throws Exception
  {
    super.setUp();
    _documentService = DocumentService.instance();
    _articleService = ArticleService.instance();
    _blogService = BlogService.instance();
  }

  protected BusinessObjectManager getBusinessObjectManager()
  {
    return _documentService;
  }

  public void testFindByArticleId() throws Exception
  {
    User user = setValidUserContext();

    Blog blog = new Blog();
    populate(blog);
    _blogService.insert(blog);

    Article article1 = new Article();
    Article article2 = new Article();
    populate(article1);
    populate(article2);
    article1.setBlogId(blog.getId());
    article2.setBlogId(blog.getId());
    _articleService.insert(article1);
    _articleService.insert(article2);

    Document document1 = new Document();
    Document document2 = new Document();
    Document document3 = new Document();

    populate(document1);
    populate(document2);
    populate(document3);

    document1.setArticleId(article1.getId());
    document2.setArticleId(article1.getId());
    document3.setArticleId(article2.getId());

    _documentService.insert(document1);
    _documentService.insert(document2);
    _documentService.insert(document3);

    Collection byArticle = _documentService.findByArticleId(article1.getId());

    assertTrue(byArticle.contains(document1));
    assertTrue(byArticle.contains(document2));
    assertFalse(byArticle.contains(document3));

    // cleanup
    _blogService.delete(blog);
    assertNull(_articleService.get(article1.getId()));
    assertNull(_articleService.get(article2.getId()));
    assertNull(_documentService.get(document1.getId()));
    assertNull(_documentService.get(document2.getId()));
    assertNull(_documentService.get(document3.getId()));
  }

  public void testInsert() throws Exception
  {
    Document document = new Document();
    Map values = populate(document);
    _documentService.insert(document);
    testInsert(document, values);
  }
}
