/*
 * $Id$
 *
 * Copyright 2005 EPFL. All rights reserved.
 */

package ch.epfl.kis.polyblog.system;

import com.baneo.core.test.*;

/**
 * BlogInitializerTestCase.
 *
 * @author Laurent Boatto
 */
public class BlogInitializerTestCase extends AbstractTestCase
{
  public void testInitialize() throws Exception
  {
    BlogInitializer initializer = new BlogInitializer();

    initializer.initialize();
  }
}