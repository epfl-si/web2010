package ch.epfl.kis.polyblog.service;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.system.*;
import com.baneo.core.test.*;

import java.util.*;

/**
 * LdapGroupServiceTestCase.
 *
 * @author Laurent Boatto
 */
public class LdapGroupServiceTestCase extends AbstractTestCase
{
  public static LdapGroupService _ldapGroupService;

  protected void setUp() throws Exception
  {
    super.setUp();
    _ldapGroupService = LdapGroupService.instance();
  }

  /**
   * testFindByDn
   *
   * @throws Exception
   */
  public void testFindByDn() throws Exception
  {
    String[] organizations = Constants.LDAP_ORGANIZATIONS;

    for (int i = 0; i < organizations.length; i++)
    {
      String organization = organizations[i];
      Group group = _ldapGroupService.findByDn(organization);
      debug(group.getGroupname());
      debug(group.getLabel());
    }
  }

  /**
   * testFindOrganizationUnitChildren
   *
   * @throws Exception
   */
  public void testFindOrganizationUnitChildren() throws Exception
  {
    Collection children = _ldapGroupService.findOrganizationUnitChildren("o=epfl,c=ch");

    for (Iterator iterator = children.iterator(); iterator.hasNext();)
    {
      Group group = (Group) iterator.next();
      debug(group.getLabel());
      debug(group.getGroupname());
    }
  }

  /**
   * testFindByName
   *
   * @throws Exception
   */
  public void testFindByName() throws Exception
  {
    Group implicitGroup = _ldapGroupService.findByCommonName("PL-DIT");
    debug(implicitGroup.getLabel());
    debug(implicitGroup.getGroupname());

    Group explicitGroup = _ldapGroupService.findByCommonName("jahia_users");
    debug(explicitGroup.getLabel());
    debug(explicitGroup.getGroupname());
  }
}