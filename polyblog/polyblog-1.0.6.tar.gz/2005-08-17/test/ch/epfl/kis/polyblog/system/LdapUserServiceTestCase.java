package ch.epfl.kis.polyblog.system;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.service.*;
import com.baneo.core.test.*;

/**
 * LdapUserServiceTestCase.
 *
 * @author Laurent Boatto
 */
public class LdapUserServiceTestCase extends AbstractTestCase
{
  private LdapUserService _ldapUserService;

  protected void setUp() throws Exception
  {
    super.setUp();
    _ldapUserService = new LdapUserService();
  }

  public void testGet() throws Exception
  {
    String sciper = "157489";
    String uid = "boatto";

    LdapUser bySciper = (LdapUser) _ldapUserService.get(sciper);
    checkUser(bySciper);

    LdapUser byUid = (LdapUser) _ldapUserService.get(uid);
    checkUser(byUid);
  }

  private void checkUser(LdapUser user)
  {
    assertEquals("Laurent", user.getFirstName());
    assertEquals("Boatto", user.getLastName());
    assertEquals(157489, user.getId());
    assertEquals("157489", user.getName());
    assertEquals("laurent.boatto@epfl.ch", user.getEmail());
    assertEquals("boatto", user.getUsername());
    assertEquals("cn=Laurent Boatto, ou=KIS, ou=PL-DIT, ou=PL, o=EPFL, c=CH", user.getDn());
  }
}
