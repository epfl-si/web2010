/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package ch.epfl.kis.polyblog.service;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.util.*;
import com.baneo.core.security.role.*;
import com.baneo.core.service.*;

import java.util.*;

/**
 * Test case for the CommentService.
 *
 * @author  Laurent Boatto
 * @version $Id$
 */

public class CommentServiceTestCase extends AbstractBlogBusinessObjectManagerTestCase
{
  private CommentService _commentService;
  private IObjectRoleManager _objectRoleManager;
  private ArticleService _articleService;
  private BlogService _blogService;
  private Comment _comment;
  private Map _values;

  /**
   * Junit setUp, called at the beginning of every testcase.
   *
   * @throws java.lang.Exception
   */
  protected void setUp() throws Exception
  {
    super.setUp();
    setCleanupAfterTest(false);
    _commentService = CommentService.instance();
    _blogService = BlogService.instance();
    _articleService = ArticleService.instance();
    _objectRoleManager = ObjectRoleManagerFactory.getIObjectRoleManager();
    _comment = new Comment();
    _values = super.populate(_comment);
  }

  protected BusinessObjectManager getBusinessObjectManager()
  {
    return _commentService;
  }

  /**
   * Junit tearDown, called at the end of every testcase.
   *
   * @throws java.lang.Exception
   */
  protected void tearDown() throws Exception
  {
    _comment = null;
    _values = null;
  }

  /**
   * Tests the insert method.
   *
   * @throws java.lang.Exception
   */
  public void testInsert() throws Exception
  {
    User user = setValidUserContext();

    Blog blog = new Blog();
    populate(blog);
    blog.setIsPublic(true);
    _blogService.insert(blog);

    Article article = new Article();
    populate(article);
    article.setAllowComments(true);
    article.setBlogId(blog.getId());
    _articleService.insert(article);

    _comment.setArticleId(article.getId());

    int numCommentBefore = article.getNumComment();

    _commentService.insert(_comment);

    article = _articleService.get(article.getId());

    int numCommentAfter = article.getNumComment();

    assertEquals(numCommentAfter, numCommentBefore + 1);

    Comment last = _commentService.findLast();

    // calculated attributes
    _values.put("articleId", new Integer(article.getId()));
    _values.put("authorFirstName", user.getFirstName());
    _values.put("authorLastName", user.getLastName());

    super.testInsert(last, _values);

    // cleanup
    _blogService.delete(blog);
    assertNull(_articleService.get(article.getId()));
    assertNull(_commentService.get(_comment.getId()));
    assertTrue(_objectRoleManager.findByBusinessObject(blog).isEmpty());
    assertTrue(_objectRoleManager.findByBusinessObject(_comment).isEmpty());
  }

  /**
   * testFindByArticleId
   *
   * @throws Exception
   */
  public void testFindByArticleId() throws Exception
  {
    User user = setValidUserContext();

    Blog blog = new Blog();
    populate(blog);
    _blogService.insert(blog);

    Article article = new Article();
    populate(article);
    article.setBlogId(blog.getId());
    article.setAllowComments(true);
    _articleService.insert(article);

    Comment comment1 = new Comment();
    Comment comment2 = new Comment();
    Comment comment3 = new Comment();
    populate(comment1);
    populate(comment2);
    populate(comment3);
    comment1.setArticleId(article.getId());
    comment2.setArticleId(article.getId());
    comment3.setArticleId(article.getId());

    // The results are ordered by date
    Date today = new Date();
    Date yesterday = new Date(today.getTime() - (1000 * 60 * 60 * 24));
    Date tomorrow = new Date(today.getTime() + (1000 * 60 * 60 * 24));

    _commentService.insert(comment1);
    _commentService.insert(comment2);
    _commentService.insert(comment3);

    comment1.setPublicationDate(today);
    comment2.setPublicationDate(yesterday);
    comment3.setPublicationDate(tomorrow);
    // the publication date is set automatically importer insert, so we must update it
    // to test the order
    _commentService.update(comment1);
    _commentService.update(comment2);
    _commentService.update(comment3);

    debug("comment1.getArticleId() = " + comment1.getArticleId());
    debug("comment2.getArticleId() = " + comment2.getArticleId());
    debug("comment3.getArticleId() = " + comment3.getArticleId());

    debug("Trying to find comment with article id " + article.getId());

    Collection result = _commentService.findByArticleId(article.getId());
    Iterator it = result.iterator();

    // Check the result order
    assertEquals(comment2, it.next());
    assertEquals(comment1, it.next());
    assertEquals(comment3, it.next());
    assertFalse(it.hasNext());

    // cleanup
    _blogService.delete(blog);
    assertNull(_articleService.get(article.getId()));
    assertNull(_commentService.get(comment1.getId()));
    assertNull(_commentService.get(comment2.getId()));
    assertNull(_commentService.get(comment3.getId()));
    assertTrue(_objectRoleManager.findByBusinessObject(comment1).isEmpty());
    assertTrue(_objectRoleManager.findByBusinessObject(comment2).isEmpty());
    assertTrue(_objectRoleManager.findByBusinessObject(comment3).isEmpty());
  }

  /**
   * Tests the delete method.
   *
   * @throws java.lang.Exception
   */
  public void testDelete() throws Exception
  {
    User user = setValidUserContext();

    Blog blog = new Blog();
    populate(blog);
    _blogService.insert(blog);

    Article article = new Article();
    populate(article);
    article.setBlogId(blog.getId());
    article.setAllowComments(true);
    _articleService.insert(article);

    _comment.setArticleId(article.getId());

    _commentService.insert(_comment);
    Comment inserted = _comment;

    // Deletes the comment and make sure that only one comment
    // has been deleted.
    int countBefore = _commentService.count();
    _commentService.delete(inserted);
    int countAfter = _commentService.count();
    assertTrue(countBefore == (countAfter + 1));

    assertNull(_commentService.get(inserted.getId()));

    // cleanup
    _blogService.delete(blog);
  }
}