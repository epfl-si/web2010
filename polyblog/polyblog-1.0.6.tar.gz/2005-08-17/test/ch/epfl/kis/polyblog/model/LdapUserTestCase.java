package ch.epfl.kis.polyblog.model;

import ch.epfl.kis.polyblog.service.*;
import ch.epfl.kis.polyblog.util.*;

import java.util.*;

/**
 * LdapUserTestCase.
 *
 * @author Laurent Boatto
 */
public class LdapUserTestCase extends AbstractBlogTestCase
{
  public void testGetGroups() throws Exception
  {
    int sciperStart = 100000;

    for (int i = 0; i < 100; i++)
    {
      LdapUser user = (LdapUser) UserService.instance().get(String.valueOf(sciperStart + i), LdapUser.class);

      if (user == null)
      {
        continue;
      }

      System.out.println(user.getDn());

      Collection groups = user.getGroups();

      for (Iterator iterator = groups.iterator(); iterator.hasNext();)
      {
        LdapGroup group = (LdapGroup) iterator.next();
        System.out.println(group.getDn());
        System.out.println(group.getLabel());
        System.out.println("---");
      }

      System.out.println("------------------------------------------------");

      Thread.sleep(1000);
    }
  }

  public void testGetGroupsSingle() throws Exception
  {
    LdapUser user = (LdapUser) UserService.instance().get("106070", LdapUser.class);

    Collection groups = user.getGroups();

    for (Iterator iterator = groups.iterator(); iterator.hasNext();)
    {
      LdapGroup group = (LdapGroup) iterator.next();
      System.out.println(group.getDn());
      System.out.println(group.getLabel());
      System.out.println("---");
    }

    System.out.println("------------------------------------------------");
  }
}