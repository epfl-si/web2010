package ch.epfl.kis.polyblog.util;

import com.baneo.core.test.*;

/**
 * UtilTestCase.
 *
 * @author Laurent Boatto
 */
public class UtilTestCase extends AbstractTestCase
{
  public void testStripHarmfulTags() throws Exception
  {
    String subject = "Some content with some <script> and < script> and <    script language='JavaScript'   >tags";

    String result = Util.stripHarmfulTags(subject);

    assertEquals("Some content with some tags", result);
  }
}