package ch.epfl.kis.polyblog.ws;

import org.apache.xmlrpc.*;
import ch.epfl.kis.polyblog.system.*;

import java.util.*;

import com.baneo.core.test.*;

/**
 * MetaWebLogApiHandlerTestCase.
 *
 * @author Laurent Boatto
 */
public class MetaWebLogApiHandlerTestCase extends AbstractTestCase
{
  public void testGetCategories() throws Exception
  {
    XmlRpcClient client = new XmlRpcClient(Constants.SITE_BASE_URL + "/public/api/xmlrpc");

    Vector params = new Vector();
    params.addElement("1");
    params.addElement("bob");
    params.addElement("thesnake");

    Vector result = (Vector) client.execute("metaWeblog.getCategories", params);

    for (int i = 0; i < result.size(); i++)
    {
      Object o = (Object) result.elementAt(i);
      System.out.println("o = " + o);
    }
  }
}