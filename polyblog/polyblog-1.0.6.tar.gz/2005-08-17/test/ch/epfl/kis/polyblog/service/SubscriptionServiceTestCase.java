/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package ch.epfl.kis.polyblog.service;

import com.baneo.core.service.*;
import com.baneo.core.util.*;

import java.util.*;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.system.*;

/**
 * Test case for the SubscriptionService.
 *
 * @author  Laurent Boatto
 * @version $Id$
 */

public class SubscriptionServiceTestCase extends BusinessObjectManagerTestCase
{
  private SubscriptionService _subscriptionService = SubscriptionService.instance();
  private Subscription _subscription;
  private Map _values;
  private static BlogService _blogService;

  /**
   * Junit setUp, called at the beginning of every testcase.
   *
   * @throws java.lang.Exception
   */
  protected void setUp() throws Exception
  {
    super.setUp();
    setCleanupAfterTest(true);
    _subscription = new Subscription();
    _values = super.populate(_subscription);
    _blogService = BlogService.instance();
  }

  protected BusinessObjectManager getBusinessObjectManager()
  {
    return _subscriptionService;
  }

  /**
   * Junit tearDown, called at the end of every testcase.
   *
   * @throws java.lang.Exception
   */
  protected void tearDown() throws Exception
  {
    _subscription = null;
    _values = null;
  }

  /**
   * Tests the insert method.
   *
   * @throws java.lang.Exception
   */
  public void testInsert() throws Exception
  {
    _subscriptionService.insert(_subscription);
    Subscription last = _subscriptionService.findLast();
    super.testInsert(last, _values);

    if (cleanupAfterTest())
    {
      _subscriptionService.delete(last);
    }
  }

  /**
   * Tests the update method.
   *
   * @throws java.lang.Exception
   */
  public void testUpdate() throws Exception
  {
    _subscriptionService.insert(_subscription);
    Subscription last = _subscriptionService.findLast();
    // We repopulate the bean to change the values
    _values = super.populate(last);
    // We change the security context to check the lastModified, etc. attributes
    setSecurityContextToUpdateMode();
    _subscriptionService.update(last);
    super.testUpdate(last, _values);

    if (cleanupAfterTest())
    {
      _subscriptionService.delete(last);
    }
  }

  /**
   * Tests the delete method.
   *
   * @throws java.lang.Exception
   */
  public void testDelete() throws Exception
  {
    _subscriptionService.insert(_subscription);
    Subscription inserted = _subscription;

    // Deletes the subscription and make sure that only one subscription
    // has been deleted.
    int countBefore = _subscriptionService.count();
    _subscriptionService.delete(inserted);
    int countAfter = _subscriptionService.count();
    assertTrue(countBefore == (countAfter + 1));

    assertNull(_subscriptionService.get(inserted.getId()));
  }

  /**
   * testSubscribeForArticles
   *
   * @throws Exception
   */
  public void testSubscribeForArticles() throws Exception
  {
    int blogId = _random.nextInt(10000000);
    Blog blog = new Blog();
    blog.setId(blogId);
    blog.setLabel("hello");

    String email = Constants.MAIL_TEST_EMAIL;

    Subscription subscription = _subscriptionService.subscribeForArticles(blog, email, Locale.FRENCH);

    assertEquals(blogId, subscription.getBlogId());
    assertEquals(8, subscription.getCode().length());
    assertEquals(email, subscription.getEmail());
    assertFalse(subscription.getWantComments());
    assertFalse(subscription.getConfirmed());

    _subscriptionService.delete(subscription);
  }

  /**
   * testSubscribeForArticlesAndComments
   *
   * @throws Exception
   */
  public void testSubscribeForArticlesAndComments() throws Exception
  {
    int blogId = _random.nextInt(10000000);
    Blog blog = new Blog();
    blog.setId(blogId);
    blog.setLabel("hello");

    String email = Constants.MAIL_TEST_EMAIL;

    Subscription subscription = _subscriptionService.subscribeForArticlesAndComments(blog, email, Locale.FRENCH);

    assertEquals(blogId, subscription.getBlogId());
    assertEquals(8, subscription.getCode().length());
    assertEquals(email, subscription.getEmail());
    assertTrue(subscription.getWantComments());
    assertFalse(subscription.getConfirmed());

    _subscriptionService.delete(subscription);
  }

  /**
   * testSubscribeForComments
   *
   * @throws Exception
   */
  public void testSubscribeForComments() throws Exception
  {
    int blogId = _random.nextInt(10000000);
    Blog blog = new Blog();
    blog.setId(blogId);
    blog.setLabel("hello");

    String email = Constants.MAIL_TEST_EMAIL;

    Subscription subscription = _subscriptionService.subscribeForComments(blog, email, Locale.FRENCH);

    assertEquals(blogId, subscription.getBlogId());
    assertEquals(8, subscription.getCode().length());
    assertEquals(email, subscription.getEmail());
    assertTrue(subscription.getWantComments());
    assertFalse(subscription.getConfirmed());

    _subscriptionService.delete(subscription);
  }


  /**
   * testHasAlreadySubscribed
   *
   * @throws Exception
   */
  public void testHasAlreadySubscribed() throws Exception
  {
    int blogId = _random.nextInt(10000000);
    Blog blog = new Blog();
    blog.setId(blogId);
    blog.setLabel(StringUtil.randomString(8));

    String email = Constants.MAIL_TEST_EMAIL;

    assertFalse(_subscriptionService.hasAlreadySubscribed(blog, email));

    _subscriptionService.subscribeForArticles(blog, email, Locale.FRENCH);

    assertTrue(_subscriptionService.hasAlreadySubscribed(blog, email));
  }

  /**
   * testConfirmSubscribe
   *
   * @throws Exception
   */
  public void testConfirmSubscribe() throws Exception
  {
    int blogId = _random.nextInt(10000000);
    Blog blog = new Blog();
    blog.setId(blogId);
    blog.setLabel(StringUtil.randomString(8));

    String email = Constants.MAIL_TEST_EMAIL;

    assertFalse(_subscriptionService.hasAlreadySubscribed(blog, email));

    Subscription subscription = _subscriptionService.subscribeForArticles(blog, email, Locale.FRENCH);

    _subscriptionService.confirmSubscribe(subscription);

    assertTrue(subscription.getConfirmed());
  }

  /**
   * testConfirmUnsubscribe
   *
   * @throws Exception
   */
  public void testConfirmUnsubscribe() throws Exception
  {
    int blogId = _random.nextInt(10000000);
    Blog blog = new Blog();
    blog.setId(blogId);
    blog.setLabel(StringUtil.randomString(8));

    String email = Constants.MAIL_TEST_EMAIL;

    assertFalse(_subscriptionService.hasAlreadySubscribed(blog, email));

    Subscription subscription = _subscriptionService.subscribeForArticles(blog, email, Locale.FRENCH);

    _subscriptionService.confirmUnsubscribe(subscription);

    assertFalse(_subscriptionService.hasAlreadySubscribed(blog, email));
    assertNull(_subscriptionService.findByBlogAndEmail(blog, email));
  }

  /**
   * testConfirmUnsubscribeFromComments
   *
   * @throws Exception
   */
  public void testConfirmUnsubscribeFromComments() throws Exception
  {
    int blogId = _random.nextInt(10000000);
    Blog blog = new Blog();
    blog.setId(blogId);
    blog.setLabel(StringUtil.randomString(8));

    String email = Constants.MAIL_TEST_EMAIL;

    assertFalse(_subscriptionService.hasAlreadySubscribed(blog, email));

    Subscription subscription = _subscriptionService.subscribeForArticlesAndComments(blog, email, Locale.FRENCH);

    _subscriptionService.confirmUnsubscribeFromComments(subscription);

    assertFalse(_subscriptionService.hasAlreadySubscribed(blog, email));
    assertNull(_subscriptionService.findByBlogAndEmail(blog, email));
  }

  /**
   * testFindByBlog
   *
   * @throws Exception
   */
  public void testFindByBlog() throws Exception
  {
    User user = new LdapUser("1234", null);
    setSecurityContext(user, 1234, null, null);

    Blog blog1 = new Blog();
    Blog blog2 = new Blog();

    _blogService.insert(blog1);
    _blogService.insert(blog2);

    Subscription subscription1 = new Subscription();
    Subscription subscription2 = new Subscription();
    Subscription subscription3 = new Subscription();

    subscription1.setBlogId(blog1.getId());
    subscription2.setBlogId(blog1.getId());
    subscription3.setBlogId(blog2.getId());

    subscription1.setConfirmed(true);
    subscription2.setConfirmed(false);
    subscription3.setConfirmed(true);

    subscription1.setEmail(StringUtil.randomString(8, _random));
    subscription2.setEmail(StringUtil.randomString(8, _random));
    subscription3.setEmail(StringUtil.randomString(8, _random));

    _subscriptionService.insert(subscription1);
    _subscriptionService.insert(subscription2);
    _subscriptionService.insert(subscription3);

    Collection byBlog = _subscriptionService.findConfirmedByBlog(blog1);

    assertTrue(byBlog.contains(subscription1));
    assertFalse(byBlog.contains(subscription2));
    assertFalse(byBlog.contains(subscription3));

    _blogService.delete(blog1);
    _blogService.delete(blog2);

    assertTrue(_subscriptionService.findByBlog(blog1).isEmpty());
    assertTrue(_subscriptionService.findByBlog(blog2).isEmpty());
  }

  /**
   * testFindConfirmedByBlog
   *
   * @throws Exception
   */
  public void testFindConfirmedByBlog() throws Exception
  {
    User user = new LdapUser("1234", null);
    setSecurityContext(user, 1234, null, null);

    Blog blog1 = new Blog();
    Blog blog2 = new Blog();

    _blogService.insert(blog1);
    _blogService.insert(blog2);

    Subscription subscription1 = new Subscription();
    Subscription subscription2 = new Subscription();
    Subscription subscription3 = new Subscription();
    Subscription subscription4 = new Subscription();
    Subscription subscription5 = new Subscription();
    Subscription subscription6 = new Subscription();

    subscription1.setBlogId(blog1.getId());
    subscription2.setBlogId(blog1.getId());
    subscription3.setBlogId(blog2.getId());
    subscription4.setBlogId(blog1.getId());
    subscription5.setBlogId(blog1.getId());
    subscription6.setBlogId(blog2.getId());

    subscription1.setConfirmed(true);
    subscription2.setConfirmed(false);
    subscription3.setConfirmed(true);
    subscription4.setConfirmed(false);
    subscription5.setConfirmed(true);
    subscription6.setConfirmed(false);

    subscription1.setWantComments(true);
    subscription2.setWantComments(false);
    subscription3.setWantComments(true);
    subscription4.setWantComments(false);
    subscription5.setWantComments(false);
    subscription6.setWantComments(false);

    subscription1.setEmail(StringUtil.randomString(8, _random));
    subscription2.setEmail(StringUtil.randomString(8, _random));
    subscription3.setEmail(StringUtil.randomString(8, _random));
    subscription4.setEmail(StringUtil.randomString(8, _random));
    subscription5.setEmail(StringUtil.randomString(8, _random));
    subscription6.setEmail(StringUtil.randomString(8, _random));

    _subscriptionService.insert(subscription1);
    _subscriptionService.insert(subscription2);
    _subscriptionService.insert(subscription3);
    _subscriptionService.insert(subscription4);
    _subscriptionService.insert(subscription5);
    _subscriptionService.insert(subscription6);

    Collection byBlog = _subscriptionService.findConfirmedByBlog(blog1, false);

    assertFalse(byBlog.contains(subscription1));
    assertFalse(byBlog.contains(subscription2));
    assertFalse(byBlog.contains(subscription3));
    assertFalse(byBlog.contains(subscription4));
    assertTrue(byBlog.contains(subscription5));
    assertFalse(byBlog.contains(subscription6));

    _blogService.delete(blog1);
    _blogService.delete(blog2);

    assertTrue(_subscriptionService.findByBlog(blog1).isEmpty());
    assertTrue(_subscriptionService.findByBlog(blog2).isEmpty());
  }

  /**
   * testFindByBlogAndEmail
   *
   * @throws Exception
   */
  public void testFindByBlogAndEmail() throws Exception
  {
    int blogId1 = _random.nextInt(10000000);
    int blogId2 = _random.nextInt(10000000);
    Blog blog1 = new Blog();
    blog1.setId(blogId1);
    blog1.setLabel(StringUtil.randomString(8));

    Blog blog2 = new Blog();
    blog2.setId(blogId2);
    blog2.setLabel(StringUtil.randomString(8));

    String email = Constants.MAIL_TEST_EMAIL;

    Subscription subscription = _subscriptionService.subscribeForArticles(blog1, email, Locale.FRENCH);

    assertEquals(subscription, _subscriptionService.findByBlogAndEmail(blog1, email));

    _subscriptionService.confirmUnsubscribe(subscription);

    assertNull(_subscriptionService.findByBlogAndEmail(blog1, email));
  }

  /**
   * testFindConfirmedByBlogAndEmail
   *
   * @throws Exception
   */
  public void testFindConfirmedByBlogAndEmail() throws Exception
  {
    int blogId1 = _random.nextInt(10000000);
    int blogId2 = _random.nextInt(10000000);
    Blog blog1 = new Blog();
    blog1.setId(blogId1);
    blog1.setLabel(StringUtil.randomString(8));

    Blog blog2 = new Blog();
    blog2.setId(blogId2);
    blog2.setLabel(StringUtil.randomString(8));

    String email = Constants.MAIL_TEST_EMAIL;

    Subscription subscription = _subscriptionService.subscribeForArticles(blog1, email, Locale.FRENCH);
    _subscriptionService.confirmSubscribe(subscription);

    assertEquals(subscription, _subscriptionService.findConfirmedByBlogAndEmail(blog1, email));

    _subscriptionService.confirmUnsubscribe(subscription);

    assertNull(_subscriptionService.findConfirmedByBlogAndEmail(blog1, email));
  }
}