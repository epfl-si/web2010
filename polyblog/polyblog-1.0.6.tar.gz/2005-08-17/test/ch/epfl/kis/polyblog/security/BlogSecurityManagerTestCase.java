package ch.epfl.kis.polyblog.security;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.service.*;
import ch.epfl.kis.polyblog.util.*;
import com.baneo.core.security.role.*;
import com.baneo.core.util.*;

/**
 * BlogSecurityManagerTestCase.
 *
 * @author Laurent Boatto
 */
public class BlogSecurityManagerTestCase extends AbstractBlogTestCase
{
  private static BlogService _blogService;
  private static BlogRoleService _blogRolemanager;
  private static IObjectRoleManager _objectRolemanager;

  protected void setUp() throws Exception
  {
    super.setUp();
    _blogService = BlogService.instance();
    _blogRolemanager = BlogRoleService.instance();
    _objectRolemanager = ObjectRoleManagerFactory.getIObjectRoleManager();
  }

  /**
   * testHasReadAccess
   *
   * @throws Exception
   */
  public void testHasReadAccess() throws Exception
  {
    User user = setValidUserContext();

    Blog blog = new Blog();
    blog.setName(StringUtil.randomString(8));
    blog.setIsPublic(false);
    _blogService.insert(blog);

    User owner = SecurityService.getUser();
    User guest = new LdapUser("guest", null);

    assertTrue(SecurityService.hasReadAccess(owner, blog));
    assertFalse(SecurityService.hasReadAccess(guest, blog));

    _blogRolemanager.addRole(SecurityService.ROLE_READER, guest, blog);

    assertTrue(SecurityService.hasReadAccess(guest, blog));

    assertFalse(SecurityService.hasReadAccess(null, blog));

    // cleanup
    _blogService.delete(blog);
    assertTrue(_objectRolemanager.findByBusinessObject(blog).isEmpty());
  }
}