/*
 * $Id$
 *
 * Copyright 2005 EPFL. All rights reserved.
 */

package ch.epfl.kis.polyblog.service;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.util.*;
import com.baneo.core.security.*;
import com.baneo.core.security.role.*;
import com.baneo.core.service.*;
import com.baneo.core.util.*;

import java.security.*;
import java.util.*;

/**
 * Test case for the BlogManager.
 *
 * @author  Laurent Boatto
 * @version $Id$
 */

public class BlogServiceTestCase extends AbstractBlogBusinessObjectManagerTestCase
{
  private IObjectRoleManager _objectRoleManager;
  private BlogService _blogService;
  private Blog _blog;
  private Map _values;

  /**
   * Junit setUp, called at the beginning of every testcase.
   *
   * @throws java.lang.Exception
   */
  protected void setUp() throws Exception
  {
    super.setUp();
    _objectRoleManager = ObjectRoleManagerFactory.getIObjectRoleManager();
    _blogService = BlogService.instance();
    setCleanupAfterTest(true);
    _blog = new Blog();
    _values = super.populate(_blog);
  }

  protected BusinessObjectManager getBusinessObjectManager()
  {
    return _blogService;
  }

  /**
   * Junit tearDown, called at the end of every testcase.
   *
   * @throws java.lang.Exception
   */
  protected void tearDown() throws Exception
  {
    _blog = null;
    _values = null;
  }

  /**
   * Tests the insert method.
   *
   * @throws java.lang.Exception
   */
  public void testInsert() throws Exception
  {
    User user = setValidUserContext();
    _blogService.insert(_blog);
    Blog last = _blogService.findLast();
    // label & name are formated
    _values.put("label", StringUtil.upperCaseFirstChar((String) _values.get("label")));
    _values.put("name", ((String)_values.get("name")).toLowerCase());
    super.testInsert(last, _values);

    Principal principal = SecurityContextManager.getISecurityContext().getPrincipal();
    assertTrue(_objectRoleManager.hasRole(principal, IObjectRoleManager.ROLE_ADMINISTRATOR, last));


    // cleanup
    //_ldapGroupService.delete(last);
  }

  public void testFindLastPublic() throws Exception
  {
    User user = setValidUserContext();
    Blog publicBlog1 = new Blog();
    Blog publicBlog2 = new Blog();
    Blog privateBlog1 = new Blog();
    populate(publicBlog1);
    populate(publicBlog2);
    populate(privateBlog1);
    publicBlog1.setIsPublic(true);
    publicBlog2.setIsPublic(true);
    privateBlog1.setIsPublic(false);
    _blogService.insert(publicBlog1);
    _blogService.insert(publicBlog2);
    _blogService.insert(privateBlog1);

    Collection lastPublic = _blogService.findLastPublic();

    Iterator it = lastPublic.iterator();

    assertEquals(publicBlog2, it.next());
    assertEquals(publicBlog1, it.next());
    assertFalse(lastPublic.contains(privateBlog1));

    // cleanup
    _blogService.delete(publicBlog1);
    _blogService.delete(publicBlog2);
    _blogService.delete(privateBlog1);
  }

  public void testFindByUser() throws Exception
  {
    User user = setValidUserContext();

    Blog blog = new Blog();
    populate(blog);
    _blogService.insert(blog);

    Collection byUser = _blogService.findByUser(user, true);

    debug("Blogs size : " + byUser.size());

    assertTrue(byUser.contains(blog));

    if (cleanupAfterTest())
    {
      _blogService.delete(blog);
    }
  }

  /**
   * Tests the update method.
   *
   * @throws java.lang.Exception
   */
  public void testUpdate() throws Exception
  {
    User user = setValidUserContext();
    _blogService.insert(_blog);
    Blog last = _blogService.findLast();
    // We repopulate the bean to change the values
    _values = super.populate(last);
    // label & name are formated
    _values.put("label", StringUtil.upperCaseFirstChar((String) _values.get("label")));
    _values.put("name", ((String)_values.get("name")).toLowerCase());

    _blogService.update(last);
    super.testUpdate(last, _values);

    if (cleanupAfterTest())
    {
      _blogService.delete(last);
    }
  }

  /**
   * testFindByName
   *
   * @throws Exception
   */
  public void testFindByName() throws Exception
  {
    User user = setValidUserContext();
    String name = StringUtil.randomString(16);

    Blog blog = new Blog();
    populate(blog);
    blog.setName(name);

    _blogService.insert(blog);

    Blog result = _blogService.findByName(name);

    assertEquals(blog, result);

    if (cleanupAfterTest())
    {
      _blogService.delete(blog);
    }
  }

  /**
   * Tests the delete method.
   *
   * @throws java.lang.Exception
   */
  public void testDelete() throws Exception
  {
    User user = setValidUserContext();
    _blogService.insert(_blog);
    Blog inserted = _blog;

    // Deletes the Blog and make sure that only one Blog
    // has been deleted.
    int countBefore = _blogService.count();
    _blogService.delete(inserted);
    int countAfter = _blogService.count();
    assertTrue(countBefore == (countAfter + 1));

    assertNull(_blogService.get(inserted.getId()));

    assertTrue(_objectRoleManager.findByBusinessObject(inserted).isEmpty());
  }

  public static void main(String[] args)
  {
    junit.textui.TestRunner.run(BlogServiceTestCase.class);
  }
}