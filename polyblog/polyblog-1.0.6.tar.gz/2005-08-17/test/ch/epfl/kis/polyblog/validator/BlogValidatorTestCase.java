/*
 * $Id$
 *
 * Copyright 2005 EPFL. All rights reserved.
 */

package ch.epfl.kis.polyblog.validator;

import com.baneo.core.util.*;
import com.baneo.core.validator.*;

import java.util.*;

/**
 * BlogValidatorTestCase.
 *
 * @author Laurent Boatto
 */
public class BlogValidatorTestCase extends AbstractValidatorTestCase
{
  private Validator _validator;

  /**
   * Sets up the test case.
   */
  protected void setUp() throws Exception
  {
    super.setUp();

    _validator = new BlogValidator(null, new HashMap(), 0, Locale.FRENCH);
  }

  public void testAttributes() throws Exception
  {
    String name = StringUtil.randomString(8).toLowerCase();

    testAttributeAssertValid("name", name);

    testAttributeAssertInvalid("name", "****");
    testAttributeAssertInvalid("name", "-asdf");
    testAttributeAssertInvalid("name", "asdf-");
    testAttributeAssertInvalid("name", "ASDF");
  }

  public Validator getValidator()
  {
    return _validator;
  }
}
