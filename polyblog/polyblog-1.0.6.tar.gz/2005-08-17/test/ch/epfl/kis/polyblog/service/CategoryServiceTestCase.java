/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package ch.epfl.kis.polyblog.service;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.util.*;
import com.baneo.core.meta.*;
import com.baneo.core.persistance.*;
import com.baneo.core.service.*;
import com.baneo.core.util.*;

import java.lang.reflect.*;
import java.util.*;

/**
 * Test case for the CategoryService.
 *
 * @author  Laurent Boatto
 * @version $Id$
 */

public class CategoryServiceTestCase extends AbstractBlogBusinessObjectManagerTestCase
{
  private CategoryService _categoryService;
  private BlogService _blogService;
  private Category _category;
  private Map _values;

  /**
   * Junit setUp, called at the beginning of every testcase.
   *
   * @throws java.lang.Exception
   */
  protected void setUp() throws Exception
  {
    super.setUp();
    setCleanupAfterTest(true);
    _category = new Category();
    _values = super.populate(_category);
    _categoryService = CategoryService.instance();
    _blogService = BlogService.instance();

  }

  protected BusinessObjectManager getBusinessObjectManager()
  {
    return _categoryService;
  }

  /**
   * Junit tearDown, called at the end of every testcase.
   *
   * @throws java.lang.Exception
   */
  protected void tearDown() throws Exception
  {
    _category = null;
    _values = null;
  }

  /**
   * Tests the insert method.
   *
   * @throws java.lang.Exception
   */
  public void testInsert() throws Exception
  {
    User user = setValidUserContext();

    Blog blog = insertRandomBlog();
    _category.setBlogId(blog.getId());
    _values.put("blogId", new Integer(blog.getId()));
    _categoryService.insert(_category);
    Category last = _categoryService.findLast();
    super.testInsert(last, _values);

    // cleanup
    _blogService.delete(blog);
    assertNull(_categoryService.get(last.getId()));
  }

  /**
   * Tests the update method.
   *
   * @throws java.lang.Exception
   */
  public void testUpdate() throws Exception
  {
    User user = setValidUserContext();

    Blog blog = insertRandomBlog();
    _category.setBlogId(blog.getId());
    _values.put("blogId", new Integer(blog.getId()));
    _categoryService.insert(_category);
    Category last = _categoryService.findLast();
    // We repopulate the bean to change the values
    _values = super.populate(last);
    last.setBlogId(blog.getId());
    _values.put("blogId", new Integer(blog.getId()));

    _categoryService.update(last);
    super.testUpdate(last, _values);

    // cleanup
    _blogService.delete(blog);
    assertNull(_categoryService.get(last.getId()));
  }

  /**
   * testExists.
   *
   * @throws Exception
   */
  public void testExists() throws Exception
  {
    User user = setValidUserContext();

    Blog blog = insertRandomBlog();
    int blogId = blog.getId();
    String label = StringUtil.randomString(8, _random).toLowerCase();

    Category category = new Category();
    category.setBlogId(blogId);
    category.setLabel(label);

    _categoryService.insert(category);

    assertTrue(_categoryService.exists(blogId, label));
    assertTrue(_categoryService.exists(blogId, label.toUpperCase()));
    assertFalse(_categoryService.exists(_random.nextInt(10000000), label));
    assertFalse(_categoryService.exists(blogId, label + StringUtil.randomString(8)));

    // cleanup
    _blogService.delete(blog);
    assertNull(_categoryService.get(category.getId()));
  }

  private Blog insertRandomBlog() throws MetaManagerException, IllegalAccessException, InvocationTargetException, PersistanceException
  {
    Blog blog = new Blog();
    populate(blog);
    _blogService.insert(blog);
    return blog;
  }

  /**
   * testFindByBlogId
   *
   * @throws Exception
   */
  public void testFindByLabelAndBlogId() throws Exception
  {
    User user = setValidUserContext();

    Blog blog1 = insertRandomBlog();
    int blogId1 = blog1.getId();

    Blog blog2 = insertRandomBlog();
    int blogId2 = blog1.getId();

    Category category1 = new Category();
    Category category2 = new Category();
    Category category3 = new Category();

    populate(category1);
    populate(category2);
    populate(category3);

    String label1 = StringUtil.randomString(8, _random);
    String label2 = StringUtil.randomString(8, _random);

    // the sort should by done by name
    category1.setLabel(label1);
    category2.setLabel(label2);
    category3.setLabel(label1);

    category1.setBlogId(blogId1);
    category2.setBlogId(blogId1);
    category3.setBlogId(blogId2);

    _categoryService.insert(category1);
    _categoryService.insert(category2);
    _categoryService.insert(category3);

    Category result1 = _categoryService.findByLabel(label1.toUpperCase(), blogId1);
    assertEquals(result1, category1);

    Category result2 = _categoryService.findByLabel(label2.toUpperCase(), blogId1);
    assertEquals(result2, category2);

    if (cleanupAfterTest())
    {
      _categoryService.delete(category1);
      _categoryService.delete(category2);
      _categoryService.delete(category3);
    }
  }


  /**
   * testFindByBlogId
   *
   * @throws Exception
   */
  public void testFindByBlogId() throws Exception
  {
    User user = setValidUserContext();

    Blog blog = insertRandomBlog();
    int blogId = blog.getId();

    Category category1 = new Category();
    Category category2 = new Category();
    Category category3 = new Category();
    populate(category1);
    populate(category2);
    populate(category3);
    // the sort should by done by name
    category1.setLabel("SubscriptionService");
    category2.setLabel("b");
    category3.setLabel("c");
    category1.setBlogId(blogId);
    category2.setBlogId(blogId);
    category3.setBlogId(blogId);

    // invert the role of inserting to test the sort order at the end
    _categoryService.insert(category3);
    _categoryService.insert(category2);
    _categoryService.insert(category1);

    Collection result = _categoryService.findByBlogId(blogId);

    Iterator it = result.iterator();

    assertEquals(category1, it.next());
    assertEquals(category2, it.next());
    assertEquals(category3, it.next());
    assertFalse(it.hasNext());

    if (cleanupAfterTest())
    {
      _categoryService.delete(category1);
      _categoryService.delete(category2);
      _categoryService.delete(category3);
    }
  }

  /**
   * Tests the delete method.
   *
   * @throws java.lang.Exception
   */
  public void testDelete() throws Exception
  {
    User user = setValidUserContext();

    Blog blog = insertRandomBlog();
    _category.setBlogId(blog.getId());
    _categoryService.insert(_category);
    Category inserted = _category;

    // Deletes the category and make sure that only one category
    // has been deleted.
    int countBefore = _categoryService.count();
    _categoryService.delete(inserted);
    int countAfter = _categoryService.count();
    assertTrue(countBefore == (countAfter + 1));

    assertNull(_categoryService.get(inserted.getId()));

    _blogService.delete(blog);
  }
}