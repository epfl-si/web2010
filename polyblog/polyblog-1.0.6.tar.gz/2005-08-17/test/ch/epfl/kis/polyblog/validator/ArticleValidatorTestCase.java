/*
 * $Id$
 *
 * Copyright 2005 baneo. All rights reserved.
 */

package ch.epfl.kis.polyblog.validator;

import com.baneo.core.validator.*;

import java.util.*;

/**
 * ArticleValidator test case. Makes sure that the different validateXXX()
 * methods of the ArticleValidator are rejecting invalid values, and accepting
 * valid ones.
 *
 * @author  Laurent Boatto
 * @version $Id$
 */

public class ArticleValidatorTestCase extends AbstractValidatorTestCase
{
  /**
   * The validator that will be used during the test case, here a
   * ArticleValidator.
   */
  private Validator _validator;

  /**
   * Sets up the test case.
   */
  protected void setUp() throws Exception
  {
    super.setUp();

    _validator = new ArticleValidator(null, new HashMap(), 0, null);
  }

  /**
   * Tests the different attributes with both valid and invalid values to see
   * if the validator is working.
   *
   * @throws java.lang.Exception if there is any problem during the test case.
   */
  public void testAttributes() throws Exception
  {
    /** todo Test the different attributes here */
  }

  /**
   * Returns the Validator that will be used during the test case, here a
   * ArticleValidator.
   *
   * @return the Validator that will be used during the test case.
   */
  public Validator getValidator()
  {
    return _validator;
  }
}