/*
 * $Id$
 *
 * Copyright 2005 EPFL. All rights reserved.
 */

package ch.epfl.kis.polyblog.system;

import com.baneo.core.system.*;
import com.baneo.core.test.*;
import com.baneo.core.util.*;
import org.easymock.*;

import javax.servlet.*;

/**
 * BootstrapServletTestCase.
 *
 * @author Laurent Boatto
 */
public class BootstrapServletTestCase extends AbstractTestCase
{
  public void testInit() throws Exception
  {
    BootstrapServlet bootstrapServlet = new BootstrapServlet();
    MockControl configControl = MockControl.createControl(javax.servlet.ServletConfig.class);
    ServletConfig config = (ServletConfig) configControl.getMock();
    MockControl contextControl = MockControl.createControl(javax.servlet.ServletContext.class);
    ServletContext context = (ServletContext) contextControl.getMock();

    // To find the real path of /WEB-INF/classes/ (needed by the bootstrap),
    // we use the log4j.properties file path
    String path = FileUtil.getFileAbsolutePath("log4j.properties");
    path = path.substring(0, path.lastIndexOf("log4j"));

    context.getRealPath("/WEB-INF/classes/");
    contextControl.setReturnValue(path);
    context.log("myName: init");
    contextControl.setDefaultVoidCallable();
    contextControl.replay();
    config.getServletName();
    configControl.setReturnValue("myName");
    config.getServletContext();
    configControl.setDefaultReturnValue(context);

    configControl.replay();

    bootstrapServlet.init(config);

    assertNotNull(ApplicationResources.getDefaultResourceBundle());
  }
}