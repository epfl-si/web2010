package ch.epfl.kis.polyblog.service;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.security.*;
import ch.epfl.kis.polyblog.util.*;
import com.baneo.core.security.role.*;
import com.baneo.core.service.*;

import java.util.*;

/**
 * BlogRoleManagerTestCase.
 *
 * @author Laurent Boatto
 */
public class BlogRoleManagerTestCase extends AbstractBlogBusinessObjectManagerTestCase
{
  private static BlogRoleService _blogRoleService;
  private static BlogService _blogService;
  private static IObjectRoleManager _objectRoleManager;

  protected void setUp() throws Exception
  {
    super.setUp();

    _blogRoleService = BlogRoleService.instance();
    _blogService = BlogService.instance();
    _objectRoleManager = ObjectRoleManagerFactory.getIObjectRoleManager();
  }

  protected BusinessObjectManager getBusinessObjectManager()
  {
    return _blogRoleService;
  }

  /**
   * testIsDeletePossible
   *
   * @throws Exception
   */
  public void testIsDeletePossible() throws Exception
  {
    User user = setValidUserContext();

    Blog blog = new Blog();
    populate(blog);
    _blogService.insert(blog);

    // The administrator role should have been created by the BlogManager
    ObjectRole administratorRole1 = (ObjectRole) _blogRoleService.findByBlog(blog).iterator().next();

    Collection objectRoles = new ArrayList();
    objectRoles.add(administratorRole1);

    // We should not be able to delete it
    assertFalse(_blogRoleService.isDeletePossible(objectRoles, blog));

    ObjectRole administratorRole2 = _blogRoleService.addRole(SecurityService.ROLE_ADMINISTRATOR, user, blog);

    // Now we can, there are 2 administrators
    assertTrue(_blogRoleService.isDeletePossible(objectRoles, blog));

    // cleanup
    //_blogManager.delete(blog);
    //assertTrue(_blogRoleService.findConfirmedByBlog(blog).isEmpty());
  }

  /**
   * testIsUpdatePossible
   * @throws Exception
   */
  public void testIsUpdatePossible() throws Exception
  {
    User user = setValidUserContext();

    Blog blog = new Blog();

    debug("Before user : " + _objectRoleManager.findByPrincipal(user).size());
    debug("Before blog : " + _objectRoleManager.findByBusinessObject(blog).size());

    populate(blog);
    _blogService.insert(blog);

    debug("After user : " + _objectRoleManager.findByPrincipal(user).size());
    debug("After blog : " + _objectRoleManager.findByBusinessObject(blog).size());

    // The administrator role should have been created by the BlogManager
    ObjectRole administratorRole1 = (ObjectRole) _blogRoleService.findByBlog(blog).iterator().next();

    Collection objectRoles = new ArrayList();
    objectRoles.add(administratorRole1);

    // We should not be able to change the role from administrator to blogger
    assertFalse(_blogRoleService.isUpdatePossible(administratorRole1, SecurityService.ROLE_BLOGGER, blog));

    ObjectRole administratorRole2 = _blogRoleService.addRole(SecurityService.ROLE_ADMINISTRATOR, user, blog);

    // Now we can, there are 2 administrators
    assertTrue(_blogRoleService.isUpdatePossible(administratorRole1, SecurityService.ROLE_BLOGGER, blog));

    // cleanup
    _blogService.delete(blog);
    assertTrue(_blogRoleService.findByBlog(blog).isEmpty());
  }
}