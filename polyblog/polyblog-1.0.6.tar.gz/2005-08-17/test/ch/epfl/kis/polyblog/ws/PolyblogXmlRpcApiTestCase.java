package ch.epfl.kis.polyblog.ws;

import ch.epfl.kis.polyblog.system.*;
import com.baneo.core.system.*;
import com.baneo.core.test.*;
import com.baneo.core.util.*;
import org.apache.xmlrpc.*;

import java.util.*;

/**
 * PolyblogXmlRpcApiTestCase.
 *
 * @author Laurent Boatto
 */
public class PolyblogXmlRpcApiTestCase extends AbstractTestCase
{
  protected void setUp() throws Exception
  {
    super.setUp();
  }

  /**
   * testGetCategory
   *
   * @throws Exception
   */
  public void testGetCategory() throws Exception
  {
    Integer id = insertRandomCategory();
    Hashtable inserted = getCategory(id);
    assertEquals(id, inserted.get("id"));
    deleteBlog((Integer) inserted.get("blogId"));
  }

  /**
   * testFindCategoryByLabel
   *
   * @throws Exception
   */
  public void testFindCategoryByLabel() throws Exception
  {
    Integer id = insertRandomCategory();
    Hashtable inserted = getCategory(id);

    String label = (String) inserted.get("label");
    Integer blogId = (Integer) inserted.get("blogId");

    Vector params = getAuthentifiedParams();
    params.add(label);
    params.add(blogId);

    Hashtable found = (Hashtable) call("polyblog.findCategoryByLabel", params);

    assertEquals(inserted, found);

    deleteBlog((Integer) inserted.get("blogId"));
  }

  /**
   * testNewCategory
   *
   * @throws Exception
   */
  public void testNewCategory() throws Exception
  {
    Integer id = insertRandomCategory();
    Hashtable inserted = getCategory(id);
    deleteBlog((Integer) inserted.get("blogId"));
  }

  /**
   * testEditCategory
   *
   * @throws Exception
   */
  public void testEditCategory() throws Exception
  {
    Integer id = insertRandomCategory();
    Hashtable inserted = getCategory(id);

    String newLabel = StringUtil.randomString(8);

    Vector params = getAuthentifiedParams();
    params.add(id);
    params.add(newLabel);

    call("polyblog.editCategory", params);

    Hashtable modified = getCategory(id);

    assertEquals(modified.get("label"), newLabel);

    deleteBlog((Integer) inserted.get("blogId"));
  }

  /**
   * testDeleteCategory
   *
   * @throws Exception
   */
  public void testDeleteCategory() throws Exception
  {
    Integer id = insertRandomCategory();

    deleteCategory(id);

    try
    {
      getCategory(id);
      fail();
    }
    catch (Exception e)
    {
    }
  }

  /**
   * testGetBlog
   *
   * @throws Exception
   */
  public void testGetBlog() throws Exception
  {
    Integer id = insertRandomBlog();

    Hashtable result = getBlog(id);

    assertEquals(id, result.get("id"));

    deleteBlog(id);
  }

  /**
   * testFindBlogByName
   *
   * @throws Exception
   */
  public void testFindBlogByName() throws Exception
  {
    Integer id = insertRandomBlog();
    Hashtable inserted = getBlog(id);

    Vector params = getAuthentifiedParams();
    params.add(inserted.get("name"));
    Hashtable found = (Hashtable) call("polyblog.findBlogByName", params);

    assertEquals(inserted, found);

    deleteBlog(id);
  }

  /**
   * testNewBlog
   *
   * @throws Exception
   */
  public void testNewBlog() throws Exception
  {
    Integer id = insertRandomBlog();
    deleteBlog(id);
  }

  /**
   * testEditBlog
   *
   * @throws Exception
   */
  public void testEditBlog() throws Exception
  {
    Integer id = insertRandomBlog();
    Hashtable random = randomBlogData();

    Vector params = getAuthentifiedParams();
    params.add(id);
    params.add(random);
    call("polyblog.editBlog", params);

    Hashtable modified = getBlog(id);

    assertEquals(random.get("name"), modified.get("name"));
    assertEquals(random.get("label"), modified.get("label"));
    assertEquals(random.get("description"), modified.get("description"));

    deleteBlog(id);
  }

  /**
   * testDeleteBlog
   *
   * @throws Exception
   */
  public void testDeleteBlog() throws Exception
  {
    Integer id = insertRandomBlog();

    Vector params = getAuthentifiedParams();
    params.add(id);
    call("polyblog.deleteBlog", params);

    try
    {
      getBlog(id);
      fail();
    }
    catch (Exception e)
    {
    }
  }

  /**
   * testAddRole
   *
   * @throws Exception
   */
  public void testAddRole() throws Exception
  {
    Integer id = insertRandomBlog();
    addRole("administrator", Config.get("test.username.other"), id);
    deleteBlog(id);
  }

  /**
   * testRemoveRole
   *
   * @throws Exception
   */
  public void testRemoveRole() throws Exception
  {
    Integer id = insertRandomBlog();
    addRole("administrator", Config.get("test.username.other"), id);

    Vector params = getAuthentifiedParams();
    params.add("administrator");
    params.add(Config.get("test.username.other"));
    params.add(id);

    call("polyblog.removeRole", params);

    deleteBlog(id);
  }

  /**
   * Returns the blog having the given id, using the webservice.
   *
   * @param id the id.
   * @return the blog having the given id, using the webservice.
   * @throws Exception
   */
  protected Hashtable getBlog(Integer id) throws Exception
  {
    Vector params = getAuthentifiedParams();
    params.add(id);

    return (Hashtable) call("polyblog.getBlog", params);
  }

  /**
   * Returns the category having the given id, using the webservice.
   *
   * @param id the id.
   * @return the category having the given id, using the webservice.
   * @throws Exception
   */
  protected Hashtable getCategory(Integer id) throws Exception
  {
    Vector params = getAuthentifiedParams();
    params.add(id);

    return (Hashtable) call("polyblog.getCategory", params);
  }

  /**
   * Deletes the blog having the given id, using the webservice.
   *
   * @param id the id.
   * @throws Exception
   */
  protected void deleteBlog(Integer id) throws Exception
  {
    Vector params = getAuthentifiedParams();
    params.add(id);

    call("polyblog.deleteBlog", params);
  }

  /**
   * Deletes the category having the given id, using the webservice.
   *
   * @param id the id.
   * @throws Exception
   */
  protected void deleteCategory(Integer id) throws Exception
  {
    Vector params = getAuthentifiedParams();
    params.add(id);

    call("polyblog.deleteCategory", params);
  }

  /**
   * Inserts a random category.
   *
   * @return the category id.
   * @throws Exception
   */
  protected Integer insertRandomCategory() throws Exception
  {
    Integer blogId = insertRandomBlog();

    Vector params = getAuthentifiedParams();
    String label = StringUtil.randomString(8);

    params.add(label);
    params.add(blogId);

    return (Integer) call("polyblog.newCategory", params);
  }

  /**
   * Inserts a random blog.
   *
   * @return the blog id.
   * @throws Exception
   */
  protected Integer insertRandomBlog() throws Exception
  {
    Vector params = getAuthentifiedParams();

    Hashtable data = randomBlogData();

    params.add(data);

    return (Integer) call("polyblog.newBlog", params);
  }

  /**
   * Returns random blog data.
   *
   * @return random blog data.
   */
  private Hashtable randomBlogData()
  {
    Hashtable data = new Hashtable();
    data.put("name", "a" + StringUtil.randomString(8).toLowerCase());
    data.put("label", StringUtil.upperCaseFirstChar(StringUtil.randomString(16)));
    data.put("description", StringUtil.randomString(32));
    data.put("isPublic", Boolean.TRUE);
    data.put("type", new Integer(1));
    return data;
  }

  /**
   * Call the given method with the given params on the webservice.
   *
   * @param methodName the method name.
   * @param params the method parameters.
   * @return the method result.
   * @throws Exception
   */
  protected Object call(String methodName, Vector params) throws Exception
  {
    XmlRpcClient client = new XmlRpcClient(Constants.SITE_BASE_URL + Config.get("ws.xml-rpc.url"));

    return client.execute(methodName, params);
  }

  /**
   * Adds to the given role to the given username for the given blog id.
   *
   * @param username the username.
   * @param role the role.
   * @param blogId the blogId.
   * @throws Exception
   */
  protected void addRole(String role, String username, Integer blogId) throws Exception
  {
    Vector params = getAuthentifiedParams();
    params.add(role);
    params.add(username);
    params.add(blogId);

    call("polyblog.addRole", params);
  }

  /**
   * Returns a Vector with the username and password already added.
   *
   * @return  a Vector with the username and password already added.
   * @throws Exception
   */
  protected Vector getAuthentifiedParams() throws Exception
  {
    Vector vector = new Vector();
    vector.add(Config.get("test.username"));
    vector.add(Config.get("test.password"));
    return vector;
  }
}