package ch.epfl.kis.polyblog.listener;

import ch.epfl.kis.polyblog.model.*;
import ch.epfl.kis.polyblog.service.*;
import ch.epfl.kis.polyblog.util.*;
import com.baneo.core.util.*;

/**
 * LinkBlogServiceListenerTestCase.
 *
 * @author Laurent Boatto
 */
public class LinkBlogServiceListenerTestCase extends AbstractBlogTestCase
{
  private static BlogService _blogService;
  private static ArticleService _articleService;
  private static CategoryService _categoryService;

  protected void setUp() throws Exception
  {
    super.setUp();
    _blogService = BlogService.instance();
    _articleService = ArticleService.instance();
    _categoryService = CategoryService.instance();
    setSecurityContext("username", _random.nextInt(10000000), null, null);
  }

  public void testPostDelete() throws Exception
  {
    User user = setValidUserContext();

    // We insert a blog a we link to it 2 articles and 2 categories...
    Blog blog = new Blog();
    BeanUtil.randomPopulate(blog, _blogService.getManagedObjectAttributesNames(), _blogService.getManagedObjectAttributesClasses());
    _blogService.insert(blog);

    Article article1 = new Article();
    Article article2 = new Article();

    BeanUtil.randomPopulate(article1, _articleService.getManagedObjectAttributesNames(), _articleService.getManagedObjectAttributesClasses());
    BeanUtil.randomPopulate(article2, _articleService.getManagedObjectAttributesNames(), _articleService.getManagedObjectAttributesClasses());

    article1.setBlogId(blog.getId());
    article2.setBlogId(blog.getId());

    _articleService.insert(article1);
    _articleService.insert(article2);

    Category category1 = new Category();
    Category category2 = new Category();

    BeanUtil.randomPopulate(category1, _categoryService.getManagedObjectAttributesNames(), _categoryService.getManagedObjectAttributesClasses());
    BeanUtil.randomPopulate(category2, _categoryService.getManagedObjectAttributesNames(), _categoryService.getManagedObjectAttributesClasses());

    category1.setBlogId(blog.getId());
    category2.setBlogId(blog.getId());

    _categoryService.insert(category1);
    _categoryService.insert(category2);

    // now we delete the blog and expect the articles and categories have also
    // been deleted

    _blogService.delete(blog);

    assertNull(_articleService.get(article1.getId()));
    assertNull(_articleService.get(article2.getId()));
    assertNull(_categoryService.get(category1.getId()));
    assertNull(_categoryService.get(category2.getId()));
  }
}