package ch.epfl.kis.polyblog.service;

import ch.epfl.kis.polyblog.util.*;
import ch.epfl.kis.polyblog.model.*;
import com.baneo.core.service.*;

import java.util.*;

/**
 * MaskedBlogServiceTestCase
 *
 * @author Laurent Boatto
 */
public class MaskedBlogServiceTestCase extends AbstractBlogBusinessObjectManagerTestCase
{
  private MaskedBlogService _maskedBlogService;

  protected void setUp() throws Exception
  {
    super.setUp();
    _maskedBlogService = MaskedBlogService.instance();
  }

  protected BusinessObjectManager getBusinessObjectManager()
  {
    return null;
  }

  /**
   * testMask
   *
   * @throws Exception
   */
  public void testMask() throws Exception
  {
    User user = setValidUserContext();

    Blog blog = DataGenerator.insertRandomBlog();
    MaskedBlog maskedBlog = _maskedBlogService.mask(blog, user);

    MaskedBlog fromDb = _maskedBlogService.get(maskedBlog.getId());

    assertEquals(blog.getId(), maskedBlog.getBlogId());
    assertEquals(blog.getLabel(), maskedBlog.getBlogLabel());
    assertEquals(user.getName(), maskedBlog.getPrincipalName());
    assertEquals(user.getClass().getName(), maskedBlog.getPrincipalClassName());

    assertEquals(maskedBlog, fromDb);

    _maskedBlogService.delete(maskedBlog);
  }

  /**
   * testFindByUser
   * 
   * @throws Exception
   */
  public void testFindByUser() throws Exception
  {
    User user = setValidUserContext();

    Blog blog1 = DataGenerator.insertRandomBlog();
    Blog blog2 = DataGenerator.insertRandomBlog();
    Blog blog3 = DataGenerator.insertRandomBlog();
    Blog blog4 = DataGenerator.insertRandomBlog();

    MaskedBlog masked1 = _maskedBlogService.mask(blog1, user);
    MaskedBlog masked2 = _maskedBlogService.mask(blog2, user);
    MaskedBlog masked3 = _maskedBlogService.mask(blog3, user);
    MaskedBlog masked4 = _maskedBlogService.mask(blog4, DataGenerator.getRandomUser());

    Collection<MaskedBlog> results = _maskedBlogService.findByUser(user);

    assertTrue(results.contains(masked1));
    assertTrue(results.contains(masked2));
    assertTrue(results.contains(masked3));
    assertFalse(results.contains(masked4));

    _maskedBlogService.delete(masked1);
    _maskedBlogService.delete(masked2);
    _maskedBlogService.delete(masked3);
    _maskedBlogService.delete(masked4);
  }

  /**
   * testFindByBlog
   *
   * @throws Exception
   */
  public void testFindByBlog() throws Exception
  {
    setValidUserContext();

    Blog blog1 = DataGenerator.insertRandomBlog();
    Blog blog2 = DataGenerator.insertRandomBlog();

    MaskedBlog masked1 = _maskedBlogService.mask(blog1, DataGenerator.getRandomUser());
    MaskedBlog masked2 = _maskedBlogService.mask(blog1, DataGenerator.getRandomUser());
    MaskedBlog masked3 = _maskedBlogService.mask(blog1, DataGenerator.getRandomUser());
    MaskedBlog masked4 = _maskedBlogService.mask(blog2, DataGenerator.getRandomUser());

    Collection<MaskedBlog> results = _maskedBlogService.findByBlog(blog1);

    assertTrue(results.contains(masked1));
    assertTrue(results.contains(masked2));
    assertTrue(results.contains(masked3));
    assertFalse(results.contains(masked4));

    _maskedBlogService.delete(masked1);
    _maskedBlogService.delete(masked2);
    _maskedBlogService.delete(masked3);
    _maskedBlogService.delete(masked4);
  }
}
