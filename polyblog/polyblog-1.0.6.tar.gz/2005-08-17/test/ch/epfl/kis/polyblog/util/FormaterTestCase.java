/*
 * $Id$
 *
 * Copyright 2005 EPFL. All rights reserved.
 */

package ch.epfl.kis.polyblog.util;

import ch.epfl.kis.polyblog.model.*;
import com.baneo.core.test.*;
import com.baneo.core.util.*;

/**
 * FormaterTestCase.
 *
 * @author Laurent Boatto
 */
public class FormaterTestCase extends AbstractTestCase
{
  public void testGetPersonalBlogName()
  {
    User user = new LdapUser(StringUtil.randomString(8), null);
    assertNull(Formater.getEpflPersonalBlogName(user));

    user.setEmail("bob.sinclar@host.com");
    assertEquals("bob.sinclar", Formater.getEpflPersonalBlogName(user));

    assertNull(Formater.getEpflPersonalBlogName(null));
  }
}
