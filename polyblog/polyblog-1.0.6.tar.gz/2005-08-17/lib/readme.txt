This directory contains library needed by the polyblog
progject but not at runtime (because the JSP container
already contain them e.g.).