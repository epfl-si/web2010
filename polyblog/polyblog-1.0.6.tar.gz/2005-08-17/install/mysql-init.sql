# Initialization script for the polyblog application

DROP DATABASE IF EXISTS `polyblog`;

CREATE DATABASE `polyblog`;
USE `polyblog`

#
# Table structure for table article
#

DROP TABLE IF EXISTS `article`;

CREATE TABLE `article` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(255) default NULL,
  `categoryId` int(11) default NULL,
  `content` text,
  `blogId` int(11) default NULL,
  `numComment` int(11) NOT NULL default '0',
  `numDocument` int(11) NOT NULL default '0',
  `publicationDate` datetime default NULL,
  `allowComments` tinyint(1) default NULL,
  `authorFirstName` varchar(255) default NULL,
  `authorLastName` varchar(255) default NULL,
  `statusId` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `blogIdIndex` (`blogId`),
  FULLTEXT KEY `articleIndex` (`title`,`content`)
) TYPE=MyISAM;


#
# Table structure for table blog
#

DROP TABLE IF EXISTS `blog`;

CREATE TABLE `blog` (
  `id` int(11) NOT NULL auto_increment,
  `type` int(11) default NULL,
  `label` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `description` text,
  `isPublic` tinyint(1) default NULL,
  PRIMARY KEY  (`id`),
  KEY `nameIndex` (`name`),
  FULLTEXT KEY `labelDescriptionIndex` (`label`,`description`)
) TYPE=MyISAM;


#
# Table structure for table category
#

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `id` int(11) NOT NULL auto_increment,
  `label` varchar(255) default NULL,
  `blogId` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `blogIdIndex` (`blogId`)
) TYPE=MyISAM;


#
# Table structure for table comment
#

DROP TABLE IF EXISTS `comment`;

CREATE TABLE `comment` (
  `id` int(11) NOT NULL auto_increment,
  `content` text,
  `articleId` int(11) default NULL,
  `authorFirstName` varchar(255) default NULL,
  `authorLastName` varchar(255) default NULL,
  `publicationDate` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `articleIdIndex` (`articleId`)
) TYPE=MyISAM;


#
# Table structure for table dbuser
#

DROP TABLE IF EXISTS `dbuser`;

CREATE TABLE `dbuser` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `username` varchar(255) default NULL,
  `email` varchar(255) default NULL,
  `firstName` varchar(255) default NULL,
  `lastName` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;


#
# Table structure for table document
#

DROP TABLE IF EXISTS `document`;

CREATE TABLE `document` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `length` bigint(20) default NULL,
  `inline` tinyint(1) default NULL,
  `articleId` int(11) default NULL,
  `blogId` int(11) default NULL,
  `mimeType` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  KEY `articleIdIndex` (`articleId`)
) TYPE=MyISAM;


#
# Table structure for table objectRole
#

DROP TABLE IF EXISTS `objectRole`;

CREATE TABLE `objectRole` (
  `id` int(11) NOT NULL auto_increment,
  `principalName` varchar(255) default NULL,
  `principalClassName` varchar(255) default NULL,
  `principalLabel` varchar(255) default NULL,
  `businessObjectId` int(11) default NULL,
  `businessObjectClassName` varchar(255) default NULL,
  `role` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  KEY `businessObjectClassNameIndex` (`businessObjectClassName`),
  KEY `businessObjectIdIndex` (`businessObjectId`)
) TYPE=MyISAM;


#
# Table structure for table subscription
#
DROP TABLE IF EXISTS `subscription`;

CREATE TABLE `subscription` (
  `id` int(11) NOT NULL auto_increment,
  `blogId` int(11) default NULL,
  `email` varchar(255) default NULL,
  `code` varchar(8) default NULL,
  `confirmed` tinyint(1) default NULL,
  `wantComments` tinyint(1) default NULL,
  PRIMARY KEY  (`id`),
  KEY `blogIdIndex` (`blogId`)
) TYPE=MyISAM;

GRANT ALL ON polyblog.*
TO polyblog@localhost IDENTIFIED BY 'polyblog';

FLUSH PRIVILEGES;
