drop table if exists maskedBlog;
drop table if exists article;
drop table if exists subscription;
drop table if exists document;
drop table if exists category;
drop table if exists comment;
drop table if exists objectRole;
drop table if exists dbUser;
drop table if exists blog;
create table maskedBlog (
   id INTEGER NOT NULL AUTO_INCREMENT,
   blogId INTEGER,
   blogLabel VARCHAR(255),
   principalName VARCHAR(255),
   principalClassName VARCHAR(255),
   primary key (id)
);
create table article (
   id INTEGER NOT NULL AUTO_INCREMENT,
   title VARCHAR(255),
   categoryId INTEGER,
   content TEXT,
   blogId INTEGER,
   numComment INTEGER not null,
   numDocument INTEGER not null,
   publicationDate DATETIME,
   allowComments BIT,
   authorFirstName VARCHAR(255),
   authorLastName VARCHAR(255),
   statusId INTEGER,
   primary key (id)
);
create table subscription (
   id INTEGER NOT NULL AUTO_INCREMENT,
   blogId INTEGER,
   email VARCHAR(255),
   code VARCHAR(8),
   confirmed BIT,
   wantComments BIT,
   primary key (id)
);
create table document (
   id INTEGER NOT NULL AUTO_INCREMENT,
   name VARCHAR(255),
   length BIGINT,
   inline BIT,
   articleId INTEGER,
   blogId INTEGER,
   mimeType VARCHAR(255),
   primary key (id)
);
create table category (
   id INTEGER NOT NULL AUTO_INCREMENT,
   label VARCHAR(255),
   blogId INTEGER,
   primary key (id)
);
create table comment (
   id INTEGER NOT NULL AUTO_INCREMENT,
   content TEXT,
   articleId INTEGER,
   authorFirstName VARCHAR(255),
   authorLastName VARCHAR(255),
   publicationDate DATETIME,
   primary key (id)
);
create table objectRole (
   id INTEGER NOT NULL AUTO_INCREMENT,
   principalName VARCHAR(255),
   principalClassName VARCHAR(255),
   principalLabel VARCHAR(255),
   businessObjectId INTEGER,
   businessObjectClassName VARCHAR(255),
   role VARCHAR(255),
   primary key (id)
);
create table dbUser (
   id INTEGER NOT NULL AUTO_INCREMENT,
   name VARCHAR(255),
   username VARCHAR(255),
   email VARCHAR(255),
   firstName VARCHAR(255),
   lastName VARCHAR(255),
   primary key (id)
);
create table blog (
   id INTEGER NOT NULL AUTO_INCREMENT,
   type INTEGER,
   label VARCHAR(255),
   name VARCHAR(255),
   description TEXT,
   isPublic BIT,
   primary key (id)
);
create index principalNameIndex on maskedBlog (principalName);
create index blogIdIndex on maskedBlog (blogId);
create index blogIdIndex on article (blogId);
create index blogIdIndex on subscription (blogId);
create index articleIdIndex on document (articleId);
create index blogIdIndex on category (blogId);
create index articleIdIndex on comment (articleId);
create index principalClassNameIndex on objectRole (principalClassName);
create index principalNameIndex on objectRole (principalName);
create index businessObjectClassNameIndex on objectRole (businessObjectClassName);
create index businessObjectIdIndex on objectRole (businessObjectId);
create index nameIndex on blog (name);
